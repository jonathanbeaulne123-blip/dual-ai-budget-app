# Foot source review for current draft PR

Scope: read-only source review and saved numerical evidence, not fresh execution. No checkout writes by this agent. Jonathan has requested wrap-up; further optimization development has stopped.

## Actual source boundary

The current checkout contains new `footLaneJoin.ts`, `reducePlanarJoin.ts`, `bake-source.ts` and the expanded `horizon-foot-lane-apron.test.ts`. `fitFootLaneJoin` still constructs mainFoot and otherFoot through the1m fittedQuad→native clip→seal path. `reducePlanarJoin` is called only in `fitFunicularFootJoin` (current line584). The planar reducer does not repair or certify the other seven Foot outputs.

The shared production prejoin builder was byte-exact in root's completed check:98.49s wall,103.12s user,2.44s system,727MB maximum RSS,3,026 input hashes unchanged. This verifies refactoring parity, not the entire PR's runtime acceptance. Root has later source/ground changes; only root's final checks establish their status.

## Saved evidence to disclose, without turning it into a current-head test claim

`/tmp/mountain-other-planar-reduction` is a numerical study of frozen v20 Foot meshes. Its outputs are not adopted:
- YearWalk bed baseline:12 oriented-edge balance failures;8 positive double/bake9 faces below the runtime determinant;58 localFloat32 invalid faces in that study's absolute-origin model.
- S1surface7 and mainFoot apron retain tiny-top/precision failures after their attempted planar reductions. MainFoot candidate:1,518 faces,22 double/bake9 invalid and200 absoluteFloat32 invalid. S1surface7 candidate:914 faces,30 double/bake9 invalid and124 absoluteFloat32 invalid.
- YearWalk shoulder candidate fails bidirectional coverage (50/31 witnesses) and retains24 Float32 invalid faces. Those are failed experiments, not accepted optimized geometry.
- Three smaller candidates passed the study's numerical gates; that does not certify the other four or authorize mixing candidate outputs into production.

Current source concerns explaining those results: clipping dense source grids against internal native triangle diagonals creates fragments; the later T-junction barycentre fans can create tiny faces; `sealFootJoin` does not resolve source polygon overlaps or guarantee directed edge balance. `STEP` also determines physical blend distances, so increasing it would change geometry rather than merely reduce tessellation.

Budget remains a blocker to full acceptance based on root's latest supplied number:20,028 added lite solid triangles after exact funicular reduction, before ground/art. The otherFoot+mainFoot subtotal is8,152; even removing all of it would leave11,876, above the unchanged10,000 delta. No new Foot proposal can honestly be described as closing that gate.

## Unapplied proposals retained outside checkout

- `/tmp/mountain-foot-boundary-study/README.md`: frozen syntax-only boundary-first/adaptive prototype; unrun and unfinished for production.
- `/tmp/mountain-foot-surface-design/DESIGN.md`: design and budget reasoning only.
- `/tmp/mountain-stillwater-shared-rows-study/HANDOFF.md`: unrun shared-row source study; still explicitly a source-to-new-mitre geometry redesign.
- `/tmp/mountain-stillwater-swept-proof/REVIEW.md`: known mitre/lap/support/settlement issues and saved-data proof script. Any root-run results must be reported separately from this source review.

Draft-PR recommendation: include only root's applied, reviewed scope and its precise final verification results; retain these unresolved geometry/budget limitations visibly. Do not adopt these `/tmp` candidates, waive determinant/coverage/movement checks, or imply all Foot meshes benefit from the funicular reducer. Deployment and complete visual/device/route acceptance remain separate from creating a reviewable draft PR.
