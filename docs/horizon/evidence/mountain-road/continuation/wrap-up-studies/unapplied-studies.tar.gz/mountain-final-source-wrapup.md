# Draft PR wrap-up: bounded final source review

Scope: read-only review of frozen V7 ground/collar changes and current region refresh/readiness integration. No world imports, tests, browser, bake, geometry study or checkout edits were performed. V7 remains immutable.

## Findings

No new concrete blocking runtime-correctness defect was found in this bounded source pass. All three combined-patch base hashes still match the checkout. V7 overlay geography, region index, scene, runtime and funicular path art are byte-identical to current source; the review did not accidentally compare an older lifecycle.

The refresh copies solid membership, constructs the new geography synchronously, invalidates/cancels the old scene before publishing its provider, clears the generation-specific ground cache, and retains forwarding providers. Runtime closes the initial load race and invokes the same refresh before registering later chunk solids. Movement waits for the replacement region scene. These are source observations; late-delivery browser proof remains required.

V7 retains the canonical Float32 positions/indices in both drawing tiers and uses those same triangles/normals for the local physical floor. Adaptive boundary paint vertices have explicit interpolation recipes. The collar retains actual shared outer-edge indices, gates nonmanifold/unmatched edges and Float32 closure, and adds independent 2 cm plan grids/edge samples to the previous seven construction probes. All real physical/error/allocation predicates remain in place.

## Existing blockers and acceptance gaps remain explicit

- Checkout V1 is known to throw on the actual served apron. It must not be described as a working final runtime. V7 is the pending correction, not a passed result.
- Frozen V6 closed both rendered boundaries but failed independent bank error acceptance (26 full / 12 lite samples). V7 must pass the same independent corpus; constructor sampling alone is insufficient.
- V7 adds about 28 MB of transient density cache per tier and more synchronous preparation work. Runtime preparation and final streaming latency remain measured gates. The earlier ~228-246 ms geography construction time excludes scene preparation, which was roughly 13 seconds full / 5-6 seconds lite.
- Ground preflight is separate from ordinary walks, full-width/body clearance, path art, all rendering budgets, live captures and streaming delivery. A draft PR may retain these open items; it must not call the entire implementation accepted.

## Deferred core optimization

Stopped immediately when Jonathan asked to wrap up and create a PR. Only installed Meshoptimizer API documentation, the saved core schema and the existing comparison helper were read. No approximate prototype or candidate was produced; no simplifier was imported or run.

Frozen input: /tmp/mountain-funicular-served-ground-proof-6/canonical-ground.json (4,515 faces; same physical core as V7). Exact saved-data estimate remains /tmp/mountain-funicular-shared-ground-v7/coplanar-estimate.json: theoretical 602 redundant coplanar faces, leaving 3,913; no implementation or budget pass.

Future bounded study, if separately resumed: boundary-lock every knot, reuse original positions, compare continuous old/new planes over an independent common refinement in both directions, reject domain/coverage/topology/Float32 defects, retain no new/worsened steep slopes, use the same final indices for drawing and physical queries, and repeat route/body/art/ceiling acceptance. The existing comparator is /tmp/mountain-funicular-reduced-served-runner-v6/compare-ground.mjs. A major reduction is unproven and is not necessary work to prepare the requested draft PR.

## Checked patch bases

- `src/harbour/horizon/regions/mountainV2/walkingGroundPatch.ts`: `73b57ebb061c8c42c48a008fc3a77898acaa87d832dff1bc00abd99686b698c5`; matches recorded base: True.
- `src/harbour/horizon/regions/mountainV2/ground.ts`: `d5612098e58625df7800b6c2956d20a689fe64a78f4c526172965b16b127fd4a`; matches recorded base: True.
- `test/horizon-walking-ground-patch.test.ts`: `956c4a9abc7a1bfcb91c5f8728d6fc45f50c4b197d8c4086a8936b43e006fcf6`; matches recorded base: True.
