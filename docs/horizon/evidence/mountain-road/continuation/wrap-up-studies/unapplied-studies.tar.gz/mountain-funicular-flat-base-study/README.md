# Conservative closed underside feasibility study — unrun

Root command (fresh output required):

```sh
node /tmp/mountain-funicular-flat-base-study/run.mjs '/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book' /tmp/mountain-funicular-flat-base-proof
```

Input is the accepted numerical exact-planar 6704-face saved candidate. The study reads exact production before-funicular cuts and current saved terrain, and constructs only the source ground environment. It does not fit, build the world, edit the checkout or update assets. Source/bundle/input hashes are retained.

## Measured count bound

Pure saved JSON classification using the production normal predicate gives 2487 protected top faces, 2431 bottom faces and 1786 side faces. There are 1668 bottom vertices; 975 touch existing sides, 693 are strictly bottom-interior, and none touch the top. Locking all side edges therefore permits at most 693 interior fan removals, saving 1386 faces: **5318 is the best possible total for this conservative variant**, not an achieved result. Even an impossible zero-face bottom could save only 2431.

Initial naive sign-only classification was discarded: nearly vertical sides can have tiny signed Y normals. The saved corrected topology report is diagnostic only; its many tiny boundary loops are NOT claimed as defects. Every domain hole is retained through the original bottom triangulation and boundary, with no polygon-fill approximation.

## What the root-run study does

1. Checks burial of every old underside vertex, edge midpoint, face centroid and a 0.1m plan grid against the exact ownership-aware prejoin ground. Any old underside point less than 0.099m below ground rejects the conservative option: flattening such a point downward would extend a visible side or replace a visible underside.
2. Chooses a flat base at least 0.15m below the measured ground minimum and below every old bottom vertex. Inventories all native walking lines across full width against the added volume, and all potentially intersecting prejoin static-solid AABBs. An actual route-envelope hit rejects the option. AABB candidates remain explicit unresolved underground/support checks.
3. Only if the finite burial and route gates clear, lowers bottom-only vertices. Original top positions/indices and all other metadata/origin remain exact. It then runs the existing exact-double planar reducer restricted to the 693 original bottom-interior vertices. Existing side boundary vertices are locked during simplification; no top or side fan may be removed.
4. Requires closure/orientation, double/bake9/local-Float32 checks and exact whole common-refinement versus the flattened intermediate; explicit original top/index/origin parity is recorded. Flattening can collapse an inherited tiny side triangle: the ordinary baseline gate rejects that candidate, rather than silently deleting faces.

This is a **feasibility study**, not final acceptance. Finite ground samples do not prove a continuous 0.099m lower bound. The exact static/underground-volume and visible-side support proof must be completed before integrating any candidate. Final body/headroom/art/shared-ground and complete district budgets still apply. No combined 10k lite claim is made.

Only syntax checks and pure saved-data topology/count arithmetic were executed by the agent. No environment bundle, flattening or reduction has run.
