import json,collections,math
s=json.load(open('/tmp/mountain-planar-reduction-study-2/candidate.json'))[0];p=[s['positions'][i:i+3] for i in range(0,len(s['positions']),3)];F=[s['indices'][i:i+3] for i in range(0,len(s['indices']),3)]
def normal(f):
 a,b,c=[p[i] for i in f];u=[b[i]-a[i]for i in range(3)];v=[c[i]-a[i]for i in range(3)];return [u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
def kind(f):
 n=normal(f);l=math.sqrt(sum(x*x for x in n));return 'top' if n[1]>1e-9 or n[1]/l>.5 else 'bottom' if n[1]<-1e-9 or n[1]/l<-.5 else 'wall'
g={k:[]for k in ['top','bottom','wall']}
for f in F:g[kind(f)].append(f)
E=collections.defaultdict(list)
for f in g['top']:
 for a,b in zip(f,f[1:]+f[:1]):E[tuple(sorted([a,b]))].append((a,b))
boundary=[v[0] for v in E.values() if len(v)==1]; nxt=collections.defaultdict(list)
for a,b in boundary:nxt[a].append(b)
loops=[];todo=set(nxt)
while todo:
 a=min(todo);start=a;loop=[]
 while a not in loop:
  loop.append(a);todo.discard(a)
  if len(nxt[a])!=1:break
  a=nxt[a][0]
 loops.append({'vertices':len(loop),'closed':a==start,'planArea':sum(p[loop[i]][0]*p[loop[(i+1)%len(loop)]][2]-p[loop[(i+1)%len(loop)]][0]*p[loop[i]][2] for i in range(len(loop)))/2,'ids':loop})
r={'faces':{k:len(v)for k,v in g.items()},'topBoundaryEdges':len(boundary),'loops':loops,'topBounds':[[min(p[i][j]for f in g['top']for i in f),max(p[i][j]for f in g['top']for i in f)]for j in range(3)],'allYBounds':[min(v[1]for v in p),max(v[1]for v in p)],'limits':'Saved topology only; no ground or underground-envelope execution'}
json.dump(r,open('/tmp/mountain-funicular-flat-base-study/topology.json','w'),indent=2);print({k:v for k,v in r.items()if k!='loops'});print('loops',[(v['vertices'],v['closed'],v['planArea'])for v in loops])
