# Reduced apron + frozen shared-ground v7

Prepared, unexecuted against the world. Root-only serial command with a fresh output:

```sh
node /tmp/mountain-funicular-reduced-served-runner-v7/run.mjs '/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book' /tmp/mountain-funicular-reduced-served-proof-v7 /tmp/mountain-planar-reduction-study-2/candidate.json
```

Use after root's original actual-served v7 preflight succeeds. V3 and v5 runner artifacts remain untouched/unrun. This runner reads the frozen v7 shadow map, current checkout apron/cone, actual served assets, and exact planar6704 candidate. It invokes no fitter/source environment, and refuses a bundle containing either. Candidate serialization uses the ACTUAL serializeHorizonJson function before physical/drawn composition, retaining every original served metadata field and full logical renderOrigin. Only positions/indices replace the one logical apron, and optional old lite buffers are cleared.

## New canonical-ground comparison

Before expensive walking/art stages, build two independently owned regions with identical callbacks:

- Original region: complete actual served solids, including original served apron.
- Reduced region: the same served solids with only the bake-serialized exact planar candidate replacing that apron.

Save both canonical Float32 position/index arrays, bounds and construction proofs. Check exact buffer identity first. If they differ, independently common-refine their XZ triangles in BOTH directions; report signed floor changes, maximum absolute height change, normal difference, coverage and exact witness coordinates. This exposes iteration-order effects in capGroundMesh instead of assuming triangulation reduction preserves its output. Original rendered-ground arrays are not replaced by a fixture.

A changed domain or >1µm geometric difference rejects reduction parity and saves the result BEFORE traversal. This is a separate arithmetic equivalence test for the reducer's side effect, not a relaxed support/walking tolerance. The analytical common-refinement comparison uses explicitly recorded area-roundoff checks; a missing patch portion fails. No old preflight floor values are reused as candidate support: all movement/art queries use the candidate's actual composed floor.

Files: original-served-canonical-ground.json, reduced-canonical-ground.json, canonical-reduction-comparison.json. A failure stops the expensive matrix honestly with failure.json; it is not a completed movement proof.

## Retained gates and measurements

Fourteen walkers,26 raw and26 continuous width sweeps, six body-safe town widths, exact original outer-post attribution, six actual theme/tier art variants, unsupported art rejection, stone-corner support, closed topology, bake/local-Float32 facets, both-side physical ground boundaries, real drawn support and collar seam gates stay unchanged. V6's separate independent collar-corpus preflight remains required.

Report local source triangles, original/candidate rendered-ground triangles and six art counts. The actual combined district25k/10k and12-call budget harness remains a separate acceptance gate; this runner cannot label individual source/ground/paint counts a whole-district pass.

Preparation checks: JS syntax passed; four tiny pure-array comparison fixtures passed (identity, different coplanar diagonal,1cm height change rejection, missing half rejection). No world imports, fitting, geometry generation, controller execution or checkout writes by this agent.

Status: UNRUN. Ground v6 was rejected for independent collar bank errors despite path/seam checks; v7 is a new ground proposal and must pass its own preflight. This package changes no acceptance gate. Source syntax checks only.
