import assert from'node:assert/strict';import{compareCanonicalGround}from'./compare-ground.mjs';
const a={positions:[0,0,0,1,0,0,1,0,1,0,0,1],indices:[0,2,1,0,3,2]},b={...a,indices:[0,3,1,1,3,2]};
assert(compareCanonicalGround(a,a).byteEquivalent);const r=compareCanonicalGround(a,b);assert(r.acceptedReductionParity);assert.equal(r.forward.maxAbsHeight,0);assert.equal(r.forward.coverageFailures,0);
const moved={...b,positions:b.positions.map((x,i)=>i%3===1?x+.01:x)};const m=compareCanonicalGround(a,moved);assert.equal(m.acceptedReductionParity,false);assert(Math.abs(m.forward.maxSignedHeight-.01)<1e-12);
assert.equal(compareCanonicalGround(a,{...a,indices:[0,2,1]}).acceptedReductionParity,false);
console.log('Pure comparison fixtures: identity, diagonal parity, 1cm displacement and missing half passed.');
