# Boundary-first Foot construction study

**Unexecuted, unaccepted saved-data experiment.** `node --check` passes. No checkout mutation, world import, fit, geometry run or reduction claim. Root owns execution and all acceptance.

Run alone, after other heavy work, with an outer deadline:

    node /tmp/mountain-foot-boundary-study/study.mjs /tmp/mountain-production-prejoin-v20 /tmp/mountain-production-fit-v20 '/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book' FRESH_OUTPUT_DIRECTORY

The only imported geometry utility is Three's standalone `earcut.js` (Mapbox Earcut3.0.2 already installed in this checkout). No scene/region/bake/fit module is imported. The original Foot source is read and hashed, not executed. Inputs: saved prejoin cuts, saved `before-funicular-cuts.json.gz`, and unchanged nativeV2 JSON. Outputs stay in the fresh directory.

## Concrete algorithm

1. Reproduce the current `near()` prism selection and physical STEP=1/margin/longitudinal constants without changing their meanings. Reconstruct mainFoot original mitred quads with the existing JOINT_REACH=1/end policy. Require the selected logical IDs to exactly equal the frozen seven Foot IDs. Funicular and Stillwater are excluded.
2. Build the arrangement **before** interior triangulation, from original selected prism quad boundaries, exact native road outer edges, and the relevant V03 host plane boundaries. Native road triangles/metadata are unchanged. Segment predicates, collinearity, intersections, ordering and vertex identities use exact BigInt rational arithmetic on the original IEEE754 XZ coordinates, with no epsilon weld, Float32 dedupe or polygon pruning. Rational intersections are converted once to doubles for mesh use.
3. Walk bounded faces and holes, retain only selected domains supported by the frozen fit, and triangulate them with constrained Earcut. Every omitted collinear boundary knot is explicitly reinserted; it cannot silently disappear. Four-corner source cells start with only two top triangles, providing the original-quad fast-path candidate.
4. Evaluate **the frozen actual fitted upper surface and underside**, not a newly guessed analytic height field. This preserves the target of the existing fit at the actual drawn/colliding surface level. Trial top errors are measured by continuous triangle/polygon intersection with the frozen upper envelope, including overlapping old source prisms; candidate/reference coverage is checked in both directions. This is a surface reconstruction study, not yet a drop-in implementation of the original analytic callbacks.
5. Run two independently reported modes:1e-9 exact-surface target and5mm interior reconstruction target. The latter is only a candidate-search allocation; it is never substituted for the existing physical join or movement gates. Bottoms and locked source/host boundaries retain a1e-9 equality requirement in both modes. Boundary proof includes every crossed reference triangle edge and every competing plane-height equality, so it checks affine extrema throughout the segment.
6. Adapt at the maximum-error witness. Interior insertion splits one triangle; edge insertion splits **all** current incident faces, including neighbors already checked. Original vertices never move. A computed intersection may be projected back onto its existing exact edge only within1e-10m arithmetic roundoff, which is recorded; a larger discrepancy rejects the trial. There are no hanging nodes, late global barycentre fans, blanket vertex pruning or dropped failed faces.
7. Close true shell boundaries once, with paired underside triangles. Use a shared stable rounded logical renderOrigin per source solid, preserving world-space doubles. Check oriented edge incidence/balance, vertex links and duplicate faces. Require raw/bake9/localFloat32 orientation, nondegeneracy, positive-top determinant≥1e-8 and tops≤40degrees; exposed road faces use the existing12% cap. Repeat continuous surface/coverage checks in raw, bake9 and actual origin-relative Float32 coordinates. A trial does not pass by simply failing to render a problematic positive source face.

## Fail-closed behavior and finite bounds

Per source/mode:250,000 segment pairs;10,000 arrangement vertices;2,000,000 reference operations;1,500 refinement insertions;12,000 active triangles. Earcut and complete final audits are finite but have no wall-clock timeout; root supplies the outer deadline. A rejection writes a reason and counters, then advances to the next source/mode. No rejected trial overwrites or substitutes for the frozen source. Reported candidate geometry is always explicitly unaccepted. No source “baseline failure exemption” exists.

Likely useful failure reports include a genuinely discontinuous old overlap, locked boundary that cannot meet precision/grade, an unsupported source vertex, or an exact-bottom constraint forcing too much subdivision. Those need a specific source decision; they are not reasons to loosen gates. If early sparse triangulation already passes error but fails precision/grade, this first prototype rejects instead of attempting unconstrained diagonal changes.

`originalQuadInitialCandidates` counts qualifying initial two-top-triangle original quads, not final accepted fast paths; refinement may remove that benefit. Triangle counts are emitted only after a completed trial. `numericalStudyPass` is a saved-data subset, never production acceptance.

## Required independent work before integration

The frozen target is the strongest available actual-surface reference, but this study deliberately does **not** import the native/Horizon ground provider or replay the original analytic `height(p)` callback. Integration must compare new vertices against those unchanged callbacks and actual support fields using the production snapshot adapter; any discrepancy is an explicit rejection/design issue. The current native/host boundary is unchanged and every source surface boundary is compared to the frozen physical boundary, but an interior5mm approximation is still a geometric change needing review.

Actual fullwidth surfaces/contact/ceiling,≤2cm road joins,12% road/40degree walk grades, source/host seam ownership, terrain support,14ordinary walks/22sweeps, all six art variants, exact served/source parity, unchanged source metadata, and combined full/lite budgets remain mandatory. Exact geometric self-intersection and renderer theme checks are not certified by the saved-data flags. No native/controller change is proposed.

Foot-only feasibility remains unchanged:20,028−8,152=11,876 lite added solid triangles even if every Foot triangle disappeared, before ground/art. This experiment cannot by itself close the10,000 gate.
