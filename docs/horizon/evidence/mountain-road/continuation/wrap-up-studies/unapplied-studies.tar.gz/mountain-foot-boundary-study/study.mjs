// Offline Foot construction experiment. No world imports, fit calls or checkout writes.
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const [PRE,FIT,ROOT,OUT]=process.argv.slice(2,6).map(p=>resolve(p));
if(!OUT||existsSync(OUT))throw Error('Usage: node study.mjs PREJOIN_DIRECTORY FIT_DIRECTORY REPO_ROOT FRESH_OUT');
mkdirSync(OUT,{recursive:true});
const read=p=>readFileSync(p),json=p=>JSON.parse(read(p)),sha=b=>createHash('sha256').update(b).digest('hex');
const sourceBytes=read(PRE+'/cuts.json.gz'),referenceBytes=read(FIT+'/before-funicular-cuts.json.gz');
const source=JSON.parse(gunzipSync(sourceBytes)),reference=JSON.parse(gunzipSync(referenceBytes));
const modulePath=ROOT+'/node_modules/.pnpm/three@0.185.1/node_modules/three/src/extras/lib/earcut.js';
const {default:earcut}=await import(pathToFileURL(modulePath).href); // pure triangulation utility only
const sourcePath=ROOT+'/src/harbour/horizon/land/mountainV2/footLaneJoin.ts',v2=json(ROOT+'/src/harbour/horizon/land/mountainV2/v2-data.json');
const limits={segmentPairs:250000,arrangementVertices:10000,referenceOperations:2000000,refinements:1500,triangles:12000};
const budget={};function tick(name,n=1){budget[name]=(budget[name]??0)+n;if(budget[name]>(limits[name]??Infinity))throw Error('Finite study budget: '+name);}
const save=(name,v)=>writeFileSync(OUT+'/'+name,JSON.stringify(v,null,2));
const sub=(a,b)=>a.map((x,i)=>x-b[i]),dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const orient=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const signed=p=>p.reduce((s,a,i)=>s+orient(p[0],a,p[(i+1)%p.length]),0)/2;
const ccw=p=>signed(p)<0?[...p].reverse():p;
const clean=p=>{const q=p.filter((a,i)=>i===0||a[0]!==p[i-1][0]||a[1]!==p[i-1][1]);if(q.length>1&&q[0][0]===q.at(-1)[0]&&q[0][1]===q.at(-1)[1])q.pop();return q.length>=3&&signed(q)!==0?q:[];};
function half(poly,fn){const out=[];if(!poly.length)return out;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],u=fn(a),v=fn(b);if(u>=0)out.push(a);if((u>=0)!==(v>=0)){const t=u/(u-v);out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]);}}return clean(out);}
function clip(a,b){let p=a;for(let i=0;i<b.length&&p.length;i++){const x=b[i],y=b[(i+1)%b.length];p=half(p,q=>orient(x,y,q));}return p;}
function difference(a,b){let left=a;const out=[];for(let i=0;i<b.length&&left.length;i++){const x=b[i],y=b[(i+1)%b.length],p=half(left,q=>-orient(x,y,q));if(p.length)out.push(p);left=half(left,q=>orient(x,y,q));}return out;}
const bounds=p=>[Math.min(...p.map(p=>p[0])),Math.min(...p.map(p=>p[1])),Math.max(...p.map(p=>p[0])),Math.max(...p.map(p=>p[1]))];
const overlap=(a,b)=>a[0]<=b[2]&&b[0]<=a[2]&&a[1]<=b[3]&&b[1]<=a[3];
const inside=(p,poly)=>{let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;};
// Exact rational segment arrangement: IEEE754 inputs, exact predicates/intersection keys.
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b){const r=a%b;a=b;b=r;}return a;};
function rat(n,d=1n){if(d<0n){n=-n;d=-d;}if(!n)return[0n,1n];const g=gcd(n,d);return[n/g,d/g];}
const plus=(a,b)=>rat(a[0]*b[1]+b[0]*a[1],a[1]*b[1]),neg=a=>[-a[0],a[1]],minus=(a,b)=>plus(a,neg(b)),mul=(a,b)=>rat(a[0]*b[0],a[1]*b[1]),div=(a,b)=>rat(a[0]*b[1],a[1]*b[0]);
const cmp=(a,b)=>{const v=a[0]*b[1]-b[0]*a[1];return v<0n?-1:v>0n?1:0;},num=a=>Number(a[0])/Number(a[1]),zero=[0n,1n],one=[1n,1n];
function exact(x){if(!Number.isFinite(x))throw Error('Nonfinite coordinate');if(!x)return zero;const v=new DataView(new ArrayBuffer(8));v.setFloat64(0,x);const bits=v.getBigUint64(0),sign=bits>>63n?-1n:1n,e=Number((bits>>52n)&2047n),m=(bits&((1n<<52n)-1n))+(e?1n<<52n:0n),exp=(e?e-1023:-1022)-52;return exp>=0?rat(sign*m*(1n<<BigInt(exp))):rat(sign*m,1n<<BigInt(-exp));}
const rp=p=>p.map(exact),rsub=(a,b)=>a.map((v,i)=>minus(v,b[i])),rcross=(a,b)=>minus(mul(a[0],b[1]),mul(a[1],b[0])),rkey=p=>p.map(a=>a.join('/')).join(','),pkey=p=>p.join(',');
function arrangement(polys){
 const segments=[];for(const poly of polys)for(let i=0;i<poly.length;i++){const a=rp(poly[i]),b=rp(poly[(i+1)%poly.length]);if(rkey(a)!==rkey(b))segments.push({a,b,points:new Map([[rkey(a),a],[rkey(b),b]]),box:bounds([poly[i],poly[(i+1)%poly.length]])});}
 const between=(t)=>cmp(t,zero)>=0&&cmp(t,one)<=0;
 for(let i=0;i<segments.length;i++)for(let j=i+1;j<segments.length;j++){tick('segmentPairs');const a=segments[i],b=segments[j];if(!overlap(a.box,b.box))continue;const u=rsub(a.b,a.a),v=rsub(b.b,b.a),w=rsub(b.a,a.a),det=rcross(u,v);
  if(det[0]){const t=div(rcross(w,v),det),s=div(rcross(w,u),det);if(between(t)&&between(s)){const p=a.a.map((x,k)=>plus(x,mul(u[k],t))),key=rkey(p);a.points.set(key,p);b.points.set(key,p);}}
  else if(!rcross(w,u)[0]){for(const p of[a.a,a.b,b.a,b.b]){for(const seg of[a,b]){const d=rsub(seg.b,seg.a),axis=d[0][0]?0:1,t=div(minus(p[axis],seg.a[axis]),d[axis]);if(between(t))seg.points.set(rkey(p),p);}}}
 }
 const vertices=[],map=new Map(),adj=new Map(),edges=new Set();
 const add=p=>{const key=rkey(p);if(!map.has(key)){tick('arrangementVertices');map.set(key,vertices.length);vertices.push({r:p,p:p.map(num)});}return map.get(key);};
 for(const s of segments){const d=rsub(s.b,s.a),axis=d[0][0]?0:1,ps=[...s.points.values()].sort((a,b)=>cmp(a[axis],b[axis])*cmp(d[axis],zero));for(let i=1;i<ps.length;i++){const a=add(ps[i-1]),b=add(ps[i]);if(a===b)continue;const key=a<b?a+':'+b:b+':'+a;if(edges.has(key))continue;edges.add(key);for(const[x,y]of[[a,b],[b,a]]){if(!adj.has(x))adj.set(x,[]);adj.get(x).push(y);}}}
 const upper=d=>cmp(d[1],zero)>0||(!d[1][0]&&cmp(d[0],zero)>=0);
 for(const[v,ns]of adj)ns.sort((a,b)=>{const x=rsub(vertices[a].r,vertices[v].r),y=rsub(vertices[b].r,vertices[v].r);if(upper(x)!==upper(y))return upper(x)?-1:1;return -cmp(rcross(x,y),zero);});
 const seen=new Set(),cycles=[];
 for(const[a,ns]of adj)for(const b of ns){if(seen.has(a+':'+b))continue;let x=a,y=b;const ids=[];do{const key=x+':'+y;if(seen.has(key))throw Error('Arrangement repeated directed edge');seen.add(key);ids.push(x);const n=adj.get(y),k=n.indexOf(x),z=n[(k+n.length-1)%n.length];x=y;y=z;if(ids.length>vertices.length*2)throw Error('Arrangement cycle bound');}while(x!==a||y!==b);const poly=ids.map(i=>vertices[i].p),s=signed(poly);if(s===0)throw Error('Zero-area arrangement cycle');cycles.push({ids,poly,s});}
 const outer=cycles.filter(c=>c.s>0),negative=cycles.filter(c=>c.s<0);
 for(const c of outer)c.holes=[];
 for(const h of negative){const candidates=outer.filter(o=>o.s>-h.s&&inside(h.poly[0],o.poly)).sort((a,b)=>a.s-b.s);if(candidates.length)candidates[0].holes.push(h);}
 return{vertices,outer,edges:[...edges],segments:segments.length};
}
function plane(q,tag){const p=q.map(v=>[v[0],v[2]]),d=orient(...p);if(!d)return null;const gx=((q[1][1]-q[0][1])*(p[2][1]-p[0][1])-(q[2][1]-q[0][1])*(p[1][1]-p[0][1]))/d,gz=((p[1][0]-p[0][0])*(q[2][1]-q[0][1])-(p[2][0]-p[0][0])*(q[1][1]-q[0][1]))/d;return{p:ccw(p),q,k:[gx,gz,q[0][1]-gx*p[0][0]-gz*p[0][1]],box:bounds(p),up:d<0,tag};}
const height=(f,p)=>f.k[0]*p[0]+f.k[1]*p[1]+f.k[2];
function faces(s){const result=[];for(let i=0;i<s.indices.length;i+=3){const f=plane(s.indices.slice(i,i+3).map(j=>s.positions.slice(j*3,j*3+3)),i/3);if(f)result.push(f);}return result;}
class Index{constructor(fs){this.all=fs;this.map=new Map();for(const f of fs)for(const k of this.keys(f.box)){if(!this.map.has(k))this.map.set(k,[]);this.map.get(k).push(f);}}keys(b){const out=[];for(let x=Math.floor(b[0]/4);x<=Math.floor(b[2]/4);x++)for(let z=Math.floor(b[1]/4);z<=Math.floor(b[3]/4);z++)out.push(x+':'+z);return out;}query(poly){const b=bounds(poly);return[...new Set(this.keys(b).flatMap(k=>this.map.get(k)??[]))].filter(f=>overlap(f.box,b));}}
function envelope(index,domain,upper){const fs=index.query(domain).map(f=>({f,p:clip(domain,f.p)})).filter(v=>v.p.length),out=[];for(let i=0;i<fs.length;i++){const {f,p}=fs[i];let pieces=[p];for(let j=0;j<fs.length&&pieces.length;j++){if(i===j)continue;tick('referenceOperations');const g=fs[j].f,q=fs[j].p,k=g.k.map((v,n)=>(v-f.k[n])*(upper?1:-1));let cover;if(k.every(v=>v===0)){if(j<i)continue;cover=q;}else cover=half(q,p=>k[0]*p[0]+k[1]*p[1]+k[2]);if(cover.length)pieces=pieces.flatMap(p=>difference(p,cover));}for(const p of pieces)out.push({f,p});}return out;}
function lookup(index,p,upper){let value=upper?-Infinity:Infinity;for(const f of index.query([p,p,p])){const ds=f.p.map((a,i)=>orient(a,f.p[(i+1)%3],p));if(ds.every(d=>d>=-1e-9)){const y=height(f,p);value=upper?Math.max(value,y):Math.min(value,y);}}if(!Number.isFinite(value))throw Error('Frozen surface does not support constrained vertex '+p);return value;}
function proofFace(q,index,upper){const f=plane(q,'candidate');if(!f)throw Error('Vertical candidate top/bottom');const cells=envelope(index,f.p,upper);let remain=[f.p],maxError=0,worst=null;for(const cell of cells){remain=remain.flatMap(p=>difference(p,cell.p));for(const p of cell.p){const error=Math.abs(height(f,p)-height(cell.f,p));if(error>maxError){maxError=error;worst=p;}}}const missing=remain.reduce((n,p)=>n+Math.abs(signed(p)),0);return{maxError,worst,missing,area:Math.abs(signed(f.p)),cells:cells.length};}
const lane=source.beds.find(b=>b.id==='mountainV2.footLane');if(!lane)throw Error('Missing source lane');const STEP=1,margin=lane.width/2+2*STEP+1;
const x0=Math.min(...lane.points.map(p=>p[0]))-margin,x1=Math.max(...lane.points.map(p=>p[0]))+margin,z0=Math.min(...lane.points.map(p=>p[2]))-2*STEP-1,z1=Math.max(...lane.points.map(p=>p[2]))+2*STEP+1;
const near=q=>Math.max(...q.map(p=>p[0]))>=x0&&Math.min(...q.map(p=>p[0]))<=x1&&Math.max(...q.map(p=>p[2]))>=z0&&Math.min(...q.map(p=>p[2]))<=z1;
// Literal existing mitredSlab joint policy for mainFoot's original source quads.
function apronQuads(points,width){const out=[];for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],l=Math.hypot(b[0]-a[0],b[2]-a[2]);if(l<1e-7)continue;const n=[-(b[2]-a[2])/l,(b[0]-a[0])/l];const joint=(v,end)=>{if(end)return[n,1];let p=v,q=v;while(p>0&&Math.hypot(points[p][0]-points[v][0],points[p][2]-points[v][2])<1)p--;while(q<points.length-1&&Math.hypot(points[q][0]-points[v][0],points[q][2]-points[v][2])<1)q++;const P=points[p],Q=points[q],V=points[v],d=Math.hypot(Q[0]-P[0],Q[2]-P[2]);if(d<1e-6)return[n,1];const J=[-(Q[2]-P[2])/d,(Q[0]-P[0])/d],dots=[];for(const[A,B]of[[P,V],[V,Q]]){const l=Math.hypot(B[0]-A[0],B[2]-A[2]);if(l>=1e-6)dots.push((-(B[2]-A[2])*J[0]+(B[0]-A[0])*J[1])/l);}const c=dots.length?Math.min(...dots):1,own=dot(n,J);return c<.5||own<.5?[n,1]:[J,1/own];};const[A,ka]=joint(i-1,i===1),[B,kb]=joint(i,i===points.length-1),at=(p,n,k,sign)=>[p[0]+n[0]*sign*width/2*k,p[1],p[2]+n[1]*sign*width/2*k];out.push([at(a,A,ka,-1),at(a,A,ka,1),at(b,B,kb,1),at(b,B,kb,-1)]);}return out;}
const nativeTris=[],roadRows=s=>[-s.hw,-s.hw+.55,-.45,.45,s.hw-.55,s.hw].map(w=>[s.at[0]+s.normal[0]*w,s.at[1],s.at[2]+s.normal[2]*w]);let roadLength=0;
for(let i=1;i<v2.road.samples.length&&roadLength<40;i++){const a=v2.road.samples[i-1],b=v2.road.samples[i];roadLength+=Math.hypot(b.at[0]-a.at[0],b.at[2]-a.at[2]);const A=roadRows(a),B=roadRows(b);for(let k=1;k<A.length;k++)nativeTris.push([A[k-1],B[k-1],B[k]],[A[k-1],B[k],A[k]]);}
const nativeEdges=new Map();for(const t of nativeTris)for(let i=0;i<3;i++){const a=t[i],b=t[(i+1)%3],A=pkey(a),B=pkey(b),k=A<B?A+'|'+B:B+'|'+A;if(nativeEdges.has(k))nativeEdges.delete(k);else nativeEdges.set(k,[a,b]);}
// Each two-point polygon contributes the same geometric segment twice; arrangement deduplicates it.
const nativeSegments=[...nativeEdges.values()].map(e=>e.map(p=>[p[0],p[2]]));
const sources=[];for(const s of source.solids){if(!/^(yearWalk|S1)\.(bed|surface|shoulders|batter)(\.|$)/.test(s.id))continue;if(s.positions.length%24)throw Error('Source prism contract');const qs=[];for(let v=0;v<s.positions.length/3;v+=8){const q=[4,5,6,7].map(k=>s.positions.slice((v+k)*3,(v+k)*3+3));if(near(q))qs.push(q);}if(qs.length)sources.push({id:s.id+'.footJoin',quads:qs});}sources.push({id:'mountainV2.footLane.apron',quads:apronQuads(lane.points,lane.width)});
const onRoad=p=>lane.points.some((a,i)=>{const b=lane.points[i+1];if(!b)return false;const dx=b[0]-a[0],dz=b[2]-a[2],l=Math.hypot(dx,dz),t=((p[0]-a[0])*dx+(p[1]-a[2])*dz)/(l*l);return t>=-(i===0?.5/l:0)&&t<=1+(i===lane.points.length-2?.5/l:0)&&Math.abs((p[0]-a[0])*dz-(p[1]-a[2])*dx)/l<=lane.width/2;});
function faceAudit(q,origin,top){const ref=cross(sub(q[1],q[0]),sub(q[2],q[0]));for(let mode=0;mode<3;mode++){const p=q.map(v=>v.map((n,k)=>mode===0?n:mode===1?Number(n.toFixed(9)):Math.fround(Number(n.toFixed(9))-origin[k])+origin[k])),n=cross(sub(p[1],p[0]),sub(p[2],p[0])),len=Math.hypot(...n);if(!(len>1e-14)||dot(n,ref)<=0)return{reason:'degenerate/flip',mode,n};if(top&&(n[1]<1e-8||Math.atan2(Math.hypot(n[0],n[2]),n[1])*180/Math.PI>40+1e-7))return{reason:'top determinant/grade',mode,n};if(top){const xy=p.map(v=>[v[0],v[2]]);if(xy.some(onRoad)||onRoad([xy.reduce((n,p)=>n+p[0]/3,0),xy.reduce((n,p)=>n+p[1]/3,0)])){if(Math.hypot(n[0],n[2])/n[1]>.12+1e-7)return{reason:'road grade',mode,n};}}}return null;}
function buildTrial(entry,ref,errorLimit){
 const fs=faces(ref),topIndex=new Index(fs.filter(f=>f.up)),bottomIndex=new Index(fs.filter(f=>!f.up)),origin=[0,1,2].map(k=>Math.round((Math.min(...entry.quads.flat().map(p=>p[k]))+Math.max(...entry.quads.flat().map(p=>p[k])))/2));
 const hostConstraints=source.solids.filter(s=>s.walkable&&s.bedIds.includes('V03')&&s.id.includes('.corridor.deck')).flatMap(s=>faces(s).filter(f=>f.up&&near(f.q)).map(f=>f.p));const arr=arrangement([...entry.quads.map(q=>q.map(p=>[p[0],p[2]])),...nativeSegments,...hostConstraints]);
 const positions=[],indices=[],triangleData=[],locked=[],vertices=new Map(),footprintFailures=[];let refines=0,acceptedCells=0,fastQuads=0;const node=p=>{const key=pkey(p);if(vertices.has(key))return vertices.get(key);const top=lookup(topIndex,p,true),bottom=lookup(bottomIndex,p,false),i=positions.length/3;positions.push(p[0],top,p[1],p[0],bottom,p[1]);vertices.set(key,i);return i;};
 for(const cell of arr.outer){const loops=[cell,...cell.holes],flat=[],mapping=[],holes=[];for(let i=0;i<loops.length;i++){if(i)holes.push(mapping.length);for(const v of loops[i].ids){mapping.push(v);flat.push(...arr.vertices[v].p);}}let tri=earcut(flat,holes,2);if(!tri.length)throw Error('Constrained domain failed initial triangulation');
  const first=tri.slice(0,3).map(k=>arr.vertices[mapping[k]].p),centre=[first.reduce((n,p)=>n+p[0]/3,0),first.reduce((n,p)=>n+p[1]/3,0)];if(!entry.quads.some(q=>inside(centre,q.map(p=>[p[0],p[2]]))))continue;
  const support=topIndex.query([centre,centre,centre]).some(f=>f.p.every((a,i)=>orient(a,f.p[(i+1)%3],centre)>=0));if(!support)continue;
  // Reject partial domain ownership instead of dropping unsupported constrained points.
  let V=mapping.map(i=>node(arr.vertices[i].p)),F=[];for(let i=0;i<tri.length;i+=3){const f=tri.slice(i,i+3).map(i=>V[i]);const q=f.map(i=>[positions[i*3],positions[i*3+2]]);F.push(orient(...q)<0?f:[f[0],f[2],f[1]]);}
  // Earcut may skip collinear constraints. Reinsert them by splitting any spanning edge,
  // preserving every actual boundary height knot; never silently prune a small triangle.
  const boundary=new Set(V);for(const v of boundary){if(F.some(f=>f.includes(v)))continue;const p=[positions[v*3],positions[v*3+2]];let inserted=false;const next=[];for(const f of F){let done=false;for(let k=0;k<3&&!done;k++){const a=f[k],b=f[(k+1)%3],A=[positions[a*3],positions[a*3+2]],B=[positions[b*3],positions[b*3+2]],ra=rp(A),rb=rp(B),rr=rp(p);if(!rcross(rsub(rb,ra),rsub(rr,ra))[0]&&p[0]>=Math.min(A[0],B[0])&&p[0]<=Math.max(A[0],B[0])&&p[1]>=Math.min(A[1],B[1])&&p[1]<=Math.max(A[1],B[1])){const c=f[(k+2)%3];next.push([a,v,c],[v,b,c]);inserted=done=true;}}if(!done)next.push(f);}if(!inserted)throw Error('Earcut omitted a locked source boundary');F=next;}
  if(cell.ids.length===4&&!cell.holes.length&&F.length===2&&entry.quads.some(q=>q.every(p=>cell.poly.some(x=>x[0]===p[0]&&x[1]===p[2]))))fastQuads++;
  for(const loop of loops)for(let i=0;i<loop.ids.length;i++)locked.push([node(arr.vertices[loop.ids[i]].p),node(arr.vertices[loop.ids[(i+1)%loop.ids.length]].p)]);
  triangleData.push(...F);acceptedCells++;
 }
 // Check the complete piecewise-linear frozen height on every locked edge.
 // Include reference triangle boundary crossings and pairwise plane equality
 // knots, then compare affine endpoint extrema within each resulting interval.
 function boundaryError(f){let maxError=0,worst=null;
  for(let k=0;k<3;k++){
   const a=f[k],b=f[(k+1)%3],A=[positions[a*3],positions[a*3+2]],B=[positions[b*3],positions[b*3+2]],dx=B[0]-A[0],dz=B[1]-A[1],l2=dx*dx+dz*dz;
   const onConstraint=locked.some(([c,d])=>{const C=[positions[c*3],positions[c*3+2]],D=[positions[d*3],positions[d*3+2]],rx=D[0]-C[0],rz=D[1]-C[1],ll=Math.hypot(rx,rz);return[A,B].every(P=>Math.abs(orient(C,D,P))/ll<=1e-10&&(P[0]-C[0])*rx+(P[1]-C[1])*rz>=-1e-10&&(P[0]-D[0])*rx+(P[1]-D[1])*rz<=1e-10);});
   if(!onConstraint)continue;
   const fs=topIndex.query([A,B,A]),ts=new Set([0,1]);
   for(const g of fs)for(let i=0;i<3;i++){const C=g.p[i],D=g.p[(i+1)%3],rx=D[0]-C[0],rz=D[1]-C[1],den=dx*rz-dz*rx;if(!den)continue;const t=((C[0]-A[0])*rz-(C[1]-A[1])*rx)/den,u=((C[0]-A[0])*dz-(C[1]-A[1])*dx)/den;if(t>0&&t<1&&u>=0&&u<=1)ts.add(t);}
   for(let i=0;i<fs.length;i++)for(let j=i+1;j<fs.length;j++){tick('referenceOperations');const da=height(fs[i],A)-height(fs[j],A),db=height(fs[i],B)-height(fs[j],B);if(da!==db){const t=da/(da-db);if(t>0&&t<1)ts.add(t);}}
   const sorted=[...ts].sort((a,b)=>a-b);for(let i=1;i<sorted.length;i++){const lo=sorted[i-1],hi=sorted[i],mid=(lo+hi)/2,M=[A[0]+dx*mid,A[1]+dz*mid],active=fs.filter(g=>g.p.every((P,j)=>orient(P,g.p[(j+1)%3],M)>=-1e-10));if(!active.length)throw Error('Locked edge reference gap');let chosen=active[0];for(const g of active)if(height(g,M)>height(chosen,M))chosen=g;for(const t of[lo,hi]){const p=[A[0]+dx*t,A[1]+dz*t],y=positions[a*3+1]+t*(positions[b*3+1]-positions[a*3+1]),e=Math.abs(y-height(chosen,p));if(e>maxError){maxError=e;worst=p;}}}
  }return{maxError,worst};
 }
 // Refine globally, including already-checked neighboring faces. No hanging nodes.
 const active=new Map(triangleData.map((f,i)=>[i,f])),queue=[...active.keys()];let nextFace=triangleData.length,queueAt=0,maxEdgeProjectionRoundoff=0;
 const xy=v=>[positions[v*3],positions[v*3+2]];
 while(queueAt<queue.length){
  const fid=queue[queueAt++],f=active.get(fid);if(!f)continue;
  if(active.size>limits.triangles)throw Error('Triangle cap');
  const top=f.map(i=>positions.slice(i*3,i*3+3)),bottom=f.map(i=>positions.slice((i+1)*3,(i+1)*3+3)),a=proofFace(top,topIndex,true),b=proofFace(bottom,bottomIndex,false);
  if(Math.max(a.missing,b.missing)>Math.max(1e-13,a.area*1e-9))throw Error('Source boundary/coverage mismatch');
  const seam=boundaryError(f),need=a.maxError>errorLimit||b.maxError>1e-9||seam.maxError>1e-9;
  if(!need){const bad=faceAudit(top,origin,true);if(bad)throw Error('Constrained triangulation precision/grade '+JSON.stringify(bad));if(faceAudit([bottom[0],bottom[2],bottom[1]],origin,false))throw Error('Bottom precision');continue;}
  let p=seam.maxError>1e-9?seam.worst:b.maxError>1e-9?b.worst:a.worst;if(!p)throw Error('Missing refinement witness');
  let edge=null;
  for(let k=0;k<3;k++){
   const va=f[k],vb=f[(k+1)%3],A=xy(va),B=xy(vb),dx=B[0]-A[0],dz=B[1]-A[1],l=Math.hypot(dx,dz),dist=Math.abs(orient(A,B,p))/l,t=((p[0]-A[0])*dx+(p[1]-A[1])*dz)/(l*l);
   if(dist<=1e-10&&t>0&&t<1){
    // Only arithmetic roundoff in a computed intersection may project to its
    // existing exact edge. Original vertices never move; record this bound.
    const ra=rp(A),rb=rp(B),axis=Math.abs(dx)>=Math.abs(dz)?0:1,rt=div(minus(exact(p[axis]),ra[axis]),minus(rb[axis],ra[axis])),q=ra.map((v,j)=>num(plus(v,mul(minus(rb[j],v),rt))));
    const movement=Math.hypot(q[0]-p[0],q[1]-p[1]);if(movement>1e-10)throw Error('Computed edge intersection roundoff exceeds bound');maxEdgeProjectionRoundoff=Math.max(maxEdgeProjectionRoundoff,movement);p=q;edge=[va,vb];break;
   }
  }
  const before=positions.length,n=node(p);if(positions.length===before||f.includes(n))throw Error('Refinement lands on existing locked vertex');
  tick('refinements');refines++;
  const append=t=>{const id=nextFace++;active.set(id,t);queue.push(id);};
  if(edge){
   let changed=0;for(const[id,t]of [...active]){for(let k=0;k<3;k++){const va=t[k],vb=t[(k+1)%3];if((va===edge[0]&&vb===edge[1])||(va===edge[1]&&vb===edge[0])){const c=t[(k+2)%3];active.delete(id);append([va,n,c]);append([n,vb,c]);changed++;break;}}}
   if(!changed)throw Error('Refinement edge absent');
  }else{
   const pts=top.map(p=>[p[0],p[2]]);if(pts.some((x,i)=>orient(x,pts[(i+1)%3],p)>=0))throw Error('Refinement witness outside constrained triangle');
   active.delete(fid);append([f[0],f[1],n]);append([f[1],f[2],n]);append([f[2],f[0],n]);
  }
 }
 triangleData.length=0;triangleData.push(...active.values());
 // One shell per connected top fan. Shared top indices never weld different Y
 // values; all field discontinuities therefore fail the final geometry proof.
 const edgeMap=new Map();for(const f of triangleData){indices.push(...f,f[0]+1,f[2]+1,f[1]+1);for(let i=0;i<3;i++){const a=f[i],b=f[(i+1)%3],k=a<b?a+':'+b:b+':'+a;if(!edgeMap.has(k))edgeMap.set(k,[]);edgeMap.get(k).push([a,b]);}}
 for(const e of edgeMap.values()){if(e.length>2||e.length===2&&e[0][0]===e[1][0])throw Error('Arrangement generated top overlap/winding');if(e.length===1){const[a,b]=e[0];indices.push(a,a+1,b+1,a,b+1,b);}}
 const maxSourceBoundaryError=Math.max(0,...triangleData.map(f=>boundaryError(f).maxError));const candidate={...ref,positions,indices,renderOrigin:origin};const edges=new Map();let invalid=0;for(let i=0;i<indices.length;i+=3){const f=indices.slice(i,i+3),q=f.map(i=>positions.slice(i*3,i*3+3)),n=cross(sub(q[1],q[0]),sub(q[2],q[0]));if(faceAudit(q,origin,n[1]>0))invalid++;for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],k=a<b?a+':'+b:b+':'+a,e=edges.get(k)??[0,0];e[0]++;e[1]+=a<b?1:-1;edges.set(k,e);}}
 let badVertexLinks=0;const incident=new Map(),faceKeys=new Set();let duplicateFaces=0;
 for(let i=0;i<indices.length;i+=3){const f=indices.slice(i,i+3),key=[...f].sort((a,b)=>a-b).join(':');if(faceKeys.has(key))duplicateFaces++;faceKeys.add(key);for(let k=0;k<3;k++){const v=f[k];if(!incident.has(v))incident.set(v,[]);incident.get(v).push([f[(k+1)%3],f[(k+2)%3]]);}}
 for(const pairs of incident.values()){const adj=new Map();for(const[a,b]of pairs)for(const[x,y]of[[a,b],[b,a]]){if(!adj.has(x))adj.set(x,new Set());adj.get(x).add(y);}if([...adj.values()].some(s=>s.size!==2)){badVertexLinks++;continue;}const seen=new Set(),queue=[[...adj.keys()][0]];while(queue.length){const v=queue.pop();if(seen.has(v))continue;seen.add(v);queue.push(...adj.get(v));}if(seen.size!==adj.size)badVertexLinks++;}
 const topology=[...edges.values()].filter(e=>e[0]!==2||e[1]!==0).length+badVertexLinks+duplicateFaces;
 // Bidirectional envelope coverage and errors, independent of arrangement cells.
 const cf=faces(candidate),ci=new Index(cf.filter(f=>f.up));let globalError=0,missing=0;for(const f of cf.filter(f=>f.up)){const p=proofFace(f.q,topIndex,true);globalError=Math.max(globalError,p.maxError);missing=Math.max(missing,p.missing);}
 for(const f of fs.filter(f=>f.up)){const old=envelope(topIndex,f.p,true);for(const cell of old){for(let i=1;i<cell.p.length-1;i++){const q=[cell.p[0],cell.p[i],cell.p[i+1]].map(p=>[p[0],height(cell.f,p),p[1]]),p=proofFace(q,ci,true);globalError=Math.max(globalError,p.maxError);missing=Math.max(missing,p.missing);}}}
 const variants=[];
 for(const mode of[0,1,2]){
  const convert=s=>({...s,positions:s.positions.map((v,i)=>mode===0?v:mode===1?Number(v.toFixed(9)):Math.fround(Number(v.toFixed(9))-origin[i%3])+origin[i%3])});
  const old=faces(convert(ref)).filter(f=>f.up),fresh=faces(convert(candidate)).filter(f=>f.up),oldIndex=new Index(old),newIndex=new Index(fresh);let error=0,gap=0;
  for(const [A,B]of[[fresh,oldIndex],[old,newIndex]])for(const f of A){const check=proofFace(f.q,B,true);error=Math.max(error,check.maxError);gap=Math.max(gap,check.missing);}
  variants.push({variant:['double','bake9','bake9-localFloat32'][mode],maxError:error,maxMissingArea:gap,passes:error<=errorLimit&&gap<=1e-10});
 }
 const pass=maxSourceBoundaryError<=1e-9&&!topology&&!invalid&&globalError<=errorLimit&&missing<=1e-10&&variants.every(v=>v.passes);
 return{candidate,report:{status:'UNACCEPTED_SAVED_FOOT_CONSTRUCTION',numericalStudyPass:pass,originalTriangles:ref.indices.length/3,candidateTriangles:indices.length/3,physicalDomain:{STEP,margin,x0,x1,z0,z1},arrangementSegments:arr.segments,arrangementVertices:arr.vertices.length,acceptedCells,originalQuadInitialCandidates:fastQuads,refinements:refines,maxEdgeProjectionRoundoff,lockedBoundarySegments:locked.length,maxSourceBoundaryError,maxContinuousTopError:globalError,maxMissingArea:missing,topologyFailures:topology,badVertexLinks,duplicateFaces,precisionOrGradeFailures:invalid,variantCoverage:variants,errorLimit,bottomErrorLimit:1e-9,origin,remainingGates:['Full runtime native/Horizon movement/contact/ceiling and actual served/art parity.','Exact original analytic-height oracle replay and source-support callback replay at newly inserted vertices.','All host seam and physical footprint acceptance, full/lite combined budget.'],note:'Top target is the exact frozen actual fitted upper envelope, not a new analytic fit. Bottom target is frozen underside, exact1e-9. No component automatically accepted.'}};
}
const expected=reference.solids.filter(s=>s.id.endsWith('.footJoin')||s.id==='mountainV2.footLane.apron').map(s=>s.id).sort();if(JSON.stringify(expected)!==JSON.stringify(sources.map(s=>s.id).sort()))throw Error('Affected source selection differs from frozen fit');
const reports=[];for(const entry of sources){const ref=reference.solids.find(s=>s.id===entry.id);if(!ref){reports.push({id:entry.id,status:'REJECTED',reason:'Missing frozen source'});continue;}for(const tolerance of[1e-9,.005]){Object.keys(budget).forEach(k=>delete budget[k]);const started=performance.now();try{const {candidate,report}=buildTrial(entry,ref,tolerance);report.id=entry.id;report.budget={...budget};report.wallMs=performance.now()-started;save(entry.id+'-'+tolerance+'.json',[candidate]);save(entry.id+'-'+tolerance+'-report.json',report);reports.push(report);console.log(JSON.stringify({id:entry.id,tolerance,status:report.status,pass:report.numericalStudyPass,before:report.originalTriangles,after:report.candidateTriangles}));}catch(e){const report={id:entry.id,tolerance,status:'REJECTED',reason:String(e),budget:{...budget},wallMs:performance.now()-started};reports.push(report);save(entry.id+'-'+tolerance+'-rejection.json',report);console.log(JSON.stringify(report));}}}
save('report.json',{status:'UNACCEPTED_ISOLATED_FOOT_STUDY',hashes:{prejoin:sha(sourceBytes),frozenBeforeFunicular:sha(referenceBytes),study:sha(read(new URL(import.meta.url))),footLaneJoinSource:sha(read(sourcePath)),earcut:sha(read(modulePath))},limits,selection:sources.map(s=>({id:s.id,quads:s.quads.length})),reports});
