# Offline candidate: one continuous, supported Stillwater lining. Does not edit assets.
import sys,json,gzip,math,pathlib,hashlib,time
root=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]); out.mkdir(exist_ok=False)
data=(root/'cuts.json.gz').read_bytes();cuts=json.loads(gzip.decompress(data)); solids={s['id']:s for s in cuts['solids']};road=next(b['points'] for b in cuts['beds'] if b['id']=='spur stillwater')
f=solids['stillwaterTunnel.floor']; P=[f['positions'][i:i+3] for i in range(0,len(f['positions']),3)]
start=[(P[4][k]+P[5][k])/2 for k in range(3)]; end=[(P[-2][k]+P[-1][k])/2 for k in range(3)]
def dist(a,b):return math.hypot(a[0]-b[0],a[2]-b[2])
def lerp(a,b,t):return [x+(y-x)*t for x,y in zip(a,b)]
def locate(p):
 best=None;s=0
 for a,b in zip(road,road[1:]):
  d=dist(a,b);t=max(0,min(1,((p[0]-a[0])*(b[0]-a[0])+(p[2]-a[2])*(b[2]-a[2]))/(d*d))) if d else 0;q=lerp(a,b,t);v=(dist(p,q),s+d*t,q)
  if best is None or v[0]<best[0]:best=v
  s+=d
 return best
A=locate(start); B=locate(end);s=0;tube=[start]
for a,b in zip(road,road[1:]):
 s+=dist(a,b)
 if s>A[1]+1e-7 and s<B[1]-1e-7:tube.append(b)
tube.append(end)
# Exact intersections of adjacent offset lines: one shared cross-section per route vertex.
frames=[]
for i,p in enumerate(tube):
 dirs=[]
 for a,b in [(tube[max(0,i-1)],p),(p,tube[min(len(tube)-1,i+1)])]:
  d=dist(a,b)
  if d>1e-9:dirs.append(((b[0]-a[0])/d,(b[2]-a[2])/d))
 if len(dirs)==1: x,z=dirs[0];frames.append((-z,x))
 else:
  ax,az=dirs[0];bx,bz=dirs[1];den=1+ax*bx+az*bz
  if den<.5:raise RuntimeError('unsafe mitre')
  frames.append((-(az+bz)/den,(ax+bx)/den))
def strip_rows(left,right,rise,thickness):
 rows=[]
 for p,n in zip(tube,frames):
  def at(o,y):return [p[0]+n[0]*o,y,p[2]+n[1]*o]
  y=p[1]+rise;rows.append([at(left,y-thickness),at(right,y-thickness),at(left,y),at(right,y)])
 return rows
# Footing bottoms conservatively retain the lower neighboring authored foot corners.
raw=solids['stillwaterTunnel.footings']; FP=[raw['positions'][i:i+3] for i in range(0,len(raw['positions']),3)]
def footing_rows(side):
 rows=strip_rows(side*6.3-.3,side*6.3+.3,-.6,.3)
 for i,row in enumerate(rows):
  pieces=[j for j in (i-1,i) if 0<=j<len(tube)-1]
  lower=min(FP[j*16+(0 if side==-1 else 8)+k][1] for j in pieces for k in range(4))
  for p in row[:2]:p[1]=min(p[1],lower)
 return rows
rowsByPart={'floor':strip_rows(-6,6,0,.6),'roof':strip_rows(-6.6,6.6,6,.6),'walls':[strip_rows(-6.6,-6,5.4,6),strip_rows(6,6.6,5.4,6)],'footings':[footing_rows(-1),footing_rows(1)]}
arcs=[0]
for a,b in zip(tube,tube[1:]):arcs.append(arcs[-1]+dist(a,b))
def reduce(rows,tolerance):
 keep=[0];err=0;start=0
 while start<len(rows)-1:
  last=start+1;best=0
  for end in range(start+2,len(rows)):
   error=0
   for k in range(start+1,end):
    t=(arcs[k]-arcs[start])/(arcs[end]-arcs[start])
    for v in range(4):error=max(error,math.dist(rows[k][v],lerp(rows[start][v],rows[end][v],t)))
   if error>tolerance:break
   last=end;best=error
  keep.append(last);err=max(err,best);start=last
 return [rows[i] for i in keep],keep,err
def mesh(rows):
 positions=[x for r in rows for p in r for x in p];indices=[]
 # row 0/1 bottom left/right, 2/3 top left/right. Positive top winding for descending route.
 for i in range(1,len(rows)):
  a=(i-1)*4;b=i*4
  indices += [a,a+1,b+1,a,b+1,b,a+2,b+3,a+3,a+2,b+2,b+3,a,b,a+2,b,b+2,a+2,a+1,a+3,b+1,b+1,a+3,b+3]
 # End closures. Each face orientation will be repaired globally if needed below.
 n=(len(rows)-1)*4;indices += [0,2,3,0,3,1,n,n+1,n+3,n,n+3,n+2]
 # Determine outward orientation from positive top; list above assumes route plan winding convention.
 a,b,c=[positions[j*3:j*3+3] for j in indices[6:9]]
 ny=(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2])
 if ny<0:
  indices=[v for i in range(0,len(indices),3) for v in [indices[i],indices[i+2],indices[i+1]]]
 return positions,indices
def join(parts):
 P=[];I=[]
 for rows in parts:
  p,ix=mesh(rows);n=len(P)//3;P+=p;I += [x+n for x in ix]
 return P,I
# Use exactly the union of the original reducer's six independently selected row sets.
# This does NOT make the new mitre geometry equal to the authored source geometry.
def interpolation_error(rows,keep):
 error=0
 for first,last in zip(keep,keep[1:]):
  for k in range(first+1,last):
   t=(arcs[k]-arcs[first])/(arcs[last]-arcs[first])
   for v in range(4):error=max(error,math.dist(rows[k][v],lerp(rows[first][v],rows[last][v],t)))
 return error

def roof_grid(keep):
 # One closed roof mesh with shared width breaks at both actual wall faces.
 # This makes roof bottom and wall top triangulation identical on their bearing bands.
 widths=[-6.6,-6,6,6.6];m=len(widths);positions=[];indices=[]
 for i in keep:
  p,n=tube[i],frames[i]
  for rise in [5.4,6]:
   for w in widths:positions.extend([p[0]+n[0]*w,p[1]+rise,p[2]+n[1]*w])
 stride=2*m
 for i in range(1,len(keep)):
  a=(i-1)*stride;b=i*stride
  for j in range(m-1):
   indices.extend([a+j,a+j+1,b+j+1,a+j,b+j+1,b+j])
   indices.extend([a+m+j,b+m+j+1,a+m+j+1,a+m+j,b+m+j,b+m+j+1])
  indices.extend([a,b,a+m,b,b+m,a+m,a+m-1,a+2*m-1,b+m-1,b+m-1,a+2*m-1,b+2*m-1])
 n=(len(keep)-1)*stride
 for j in range(m-1):
  indices.extend([j,m+j,m+j+1,j,m+j+1,j+1,n+j,n+j+1,n+m+j+1,n+j,n+m+j+1,n+m+j])
 a,b,c=[positions[j*3:j*3+3] for j in indices[6:9]]
 ny=(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2])
 if ny<0:indices=[v for i in range(0,len(indices),3) for v in [indices[i],indices[i+2],indices[i+1]]]
 return positions,indices

results=[]
for tolerance in [0,.002,.005,.01,.02]:
 selections={};all_keep=set()
 for name,rawRows in rowsByPart.items():
  chains=rawRows if name in ('walls','footings') else [rawRows]
  for chain,rows in enumerate(chains):
   new,keep,err=reduce(rows,tolerance)
   selections[(name,chain)]={'keep':keep,'error':err}
   all_keep.update(keep)
 keep=sorted(all_keep)
 assert len(selections)==6 and keep[0]==0 and keep[-1]==len(tube)-1
 record={'tolerance':tolerance,'sharedRetainedRows':keep,'rowSelection':'union of unchanged independent reducer selections across all six chains','parts':[]}
 for name,rawRows in rowsByPart.items():
  chains=rawRows if name in ('walls','footings') else [rawRows]
  reduced=[[rows[i] for i in keep] for rows in chains]
  errors=[interpolation_error(rows,keep) for rows in chains]
  # Union refinement need not make a chord-error metric monotone: record actual errors,
  # and never add another row or claim a tolerance pass just from the old reduction.
  p,ix=roof_grid(keep) if name=='roof' else join(reduced);old=solids['stillwaterTunnel.'+name];result={**old,'positions':p,'indices':ix}
  (out/(name+'-'+str(tolerance)+'.json')).write_text(json.dumps(result,separators=(',',':')))
  edges={}
  for k in range(0,len(ix),3):
   f=ix[k:k+3]
   for a,b in zip(f,f[1:]+f[:1]):
    key=tuple(sorted([a,b]));n,s=edges.get(key,(0,0));edges[key]=(n+1,s+(1 if a<b else -1))
  bad=sum(n!=2 or s!=0 for n,s in edges.values())
  record['parts'].append({'id':old['id'],'beforeTriangles':len(old['indices'])//3,'afterTriangles':len(ix)//3,'rows':[len(x) for x in reduced],'maxCornerInterpolationError':max(errors),'perChainCornerInterpolationError':errors,'cornerInterpolationWithinRequestedTolerance':max(errors)<=tolerance,'independentRetainedRows':[selections[(name,c)]['keep'] for c in range(len(chains))],'independentMaxCornerInterpolationErrors':[selections[(name,c)]['error'] for c in range(len(chains))],'badEdges':bad})
 results.append(record)
report={'status':'UNACCEPTED offline swept geometry redesign. One shared retained row set plus shared roof/wall bearing columns removes mismatched roof/wall triangulation; source-to-new-mitre approximation, geometry and foundation changes remain unproved. All movement/error/clearance proof still required.','sourceSha256':hashlib.sha256(data).hexdigest(),'studySha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'parentStudySha256':'5af7a01eb632a169967622ee7198e1a998cdb5cb4a9672149a02c98dd9bea361','tubePoints':len(tube),'endpointMatches':[A[0],B[0]],'tubeLength':arcs[-1],'results':results}
(out/'report.json').write_text(json.dumps(report,indent=2));(out/'tube.json').write_text(json.dumps(tube));print(json.dumps(report,indent=2))
