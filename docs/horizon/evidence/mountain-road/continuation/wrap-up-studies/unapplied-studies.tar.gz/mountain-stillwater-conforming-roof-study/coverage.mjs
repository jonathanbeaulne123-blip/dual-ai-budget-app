// Independent polygon-union coverage proof; uses installed Manifold/Clipper2.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const [ROOT,CAND,OUT]=process.argv.slice(2);mkdirSync(OUT,{recursive:false});
const Module=(await import(pathToFileURL(resolve(ROOT,'node_modules/manifold-3d/manifold.js')))).default;
const api=await Module();api.setup();const {CrossSection}=api;
const raw=readFileSync('/tmp/mountain-production-prejoin-v20/cuts.json.gz'),source=JSON.parse(gunzipSync(raw)),old=new Map(source.solids.map(s=>[s.id,s]));
const tube=JSON.parse(readFileSync(CAND+'/tube.json')),study=JSON.parse(readFileSync(CAND+'/report.json')),anchor=tube[0];
const sha=b=>createHash('sha256').update(b).digest('hex');
if(study.sourceSha256!==sha(raw))throw Error('Source snapshot mismatch');
const xy=p=>[p[0]-anchor[0],p[2]-anchor[2]],area=p=>p.reduce((s,v,i)=>{const w=p[(i+1)%p.length];return s+v[0]*w[1]-w[0]*v[1]},0)/2;
const ccw=p=>area(p)<0?p.slice().reverse():p;
const frames=tube.map((p,i)=>{const ds=[];for(const [a,b] of [[tube[Math.max(0,i-1)],p],[p,tube[Math.min(tube.length-1,i+1)]]]){const L=Math.hypot(b[0]-a[0],b[2]-a[2]);if(L>1e-10)ds.push([(b[0]-a[0])/L,(b[2]-a[2])/L]);}if(ds.length===1)return[-ds[0][1],ds[0][0]];const [a,b]=ds,den=1+a[0]*b[0]+a[1]*b[1];return[-(a[1]+b[1])/den,(a[0]+b[0])/den];});
const rows=tube.map((p,i)=>[-5,5].map(o=>[p[0]-anchor[0]+frames[i][0]*o,p[2]-anchor[2]+frames[i][1]*o]));
const domains=[];for(let i=1;i<rows.length;i++){const [a,b]=rows[i-1],[c,d]=rows[i];domains.push(ccw([a,b,d]),ccw([a,d,c]));}
const planFaces=(s,up)=>{const out=[];for(let i=0;i<s.indices.length;i+=3){const q=s.indices.slice(i,i+3).map(j=>s.positions.slice(j*3,j*3+3)),p=q.map(xy),n=-2*area(p);if(Math.abs(n)>1e-8&&(up===undefined||(n>0)===up))out.push(ccw(p));}return out;};
const cross=polys=>new CrossSection(polys,'Positive');
const diff=(domain,surface)=>{const a=cross(domain),b=cross(surface),missing=a.subtract(b),result={domainArea:a.area(),coveredArea:b.area(),missingArea:missing.area(),missingContours:missing.toPolygons()};a.delete();b.delete();missing.delete();return result;};
const sourceReport={floor:diff(domains,planFaces(old.get('stillwaterTunnel.floor'),true)),roof:diff(domains,planFaces(old.get('stillwaterTunnel.roof'),false))};
const results=[];
for(const entry of study.results){const tol=entry.tolerance,parts=Object.fromEntries(['floor','roof','walls','footings'].map(name=>[name,JSON.parse(readFileSync(CAND+'/'+name+'-'+tol+'.json'))])),floor=planFaces(parts.floor,true),roof=planFaces(parts.roof,false),apron=planFaces(old.get('stillwaterTunnel.apron'),true);
 const portal=[];for(const end of [0,tube.length-1]){const p=xy(tube[end]),n=frames[end],L=Math.hypot(...n),t=[n[1]/L,-n[0]/L];portal.push(ccw([[-.001,-5],[.001,-5],[.001,5],[-.001,5]].map(([a,b])=>[p[0]+t[0]*a+n[0]*b,p[1]+t[1]*a+n[1]*b])));}
 const r={tolerance:tol,floor:diff(domains,floor),roof:diff(domains,roof),portals:diff(portal,[...floor,...apron]),wallBearing:diff(planFaces(parts.walls,false),planFaces(parts.footings,true)),roofBearing:diff(planFaces(parts.walls,true),roof)};
 r.accepted=Object.values(r).filter(v=>v&&typeof v==='object'&&'missingArea'in v).every(v=>v.missingArea<=1e-8);results.push(r);console.log(JSON.stringify({tolerance:tol,accepted:r.accepted,gaps:Object.fromEntries(Object.entries(r).filter(([k,v])=>v&&typeof v==='object'&&'missingArea'in v).map(([k,v])=>[k,v.missingArea]))}));}
const result={status:'INDEPENDENT_NUMERICAL_COVERAGE_ONLY',library:JSON.parse(readFileSync(resolve(ROOT,'node_modules/manifold-3d/package.json'))).version,coordinateFrame:'World XZ translated by original tube start; no rotation',areaGate:1e-8,sourceSha256:sha(raw),studySha256:sha(readFileSync(CAND+'/report.json')),scriptSha256:sha(readFileSync(new URL(import.meta.url))),sourceReport,results,limits:['Clipper2 fixed precision polygon operations supplement the continuous surface comparison; source mesh equality, vertical joints, self-intersection and runtime movement remain separate.','No missing-area threshold was increased; source and candidate gaps remain distinct.']};writeFileSync(OUT+'/report.json',JSON.stringify(result,null,2));process.exitCode=results.every(r=>r.accepted)?0:2;
