// src/harbour/horizon/world/MANIFEST.json
var MANIFEST_default = {
  title: "The Horizon \u2014 MANIFEST",
  version: "2.6",
  date: "2026-09-28",
  status: "Design numbers for implementation. Control points are centreline intent to be solved into splines by the land pass; not navigation or collision data until baked into WorldDefinition v3. v2.2: paces and surface grip (RIDE D42) and the FLIGHT sky fields (D34\u2013D38), reconciled onto the v2.1 land \u2014 data only, no geometry change.",
  units: {
    x: "east, concept metres",
    y: "south, concept metres (engine z)",
    height: "metres above sea level (engine y)",
    scale: "engine units = concept metres \xD7 scale.factor (see scale)",
    north: "-z"
  },
  extent: {
    w: 2e3,
    h: 1800
  },
  seaLevel: 0,
  island: {
    outline: [
      [
        900,
        180
      ],
      [
        1200,
        190
      ],
      [
        1420,
        300
      ],
      [
        1600,
        500
      ],
      [
        1690,
        760
      ],
      [
        1620,
        1080
      ],
      [
        1440,
        1330
      ],
      [
        1150,
        1480
      ],
      [
        860,
        1480
      ],
      [
        720,
        1330
      ],
      [
        660,
        1180
      ],
      [
        700,
        1e3
      ],
      [
        820,
        860
      ],
      [
        860,
        720
      ],
      [
        780,
        560
      ],
      [
        640,
        520
      ],
      [
        520,
        620
      ],
      [
        500,
        800
      ],
      [
        540,
        940
      ],
      [
        460,
        1020
      ],
      [
        370,
        940
      ],
      [
        300,
        720
      ],
      [
        340,
        470
      ],
      [
        520,
        300
      ],
      [
        700,
        210
      ]
    ],
    note: "Closed smooth curve through these points (Catmull-Rom). Shore is 12 m of sand/rock stroke; shallows extend 50 m."
  },
  offshore: [
    {
      id: "lamp",
      label: "The Lamp",
      xy: [
        540,
        1230
      ],
      r: 40,
      heightMax: 8,
      holds: "lighthouse (25 m gallery: glider launch), rowboat dock"
    },
    {
      id: "needle",
      label: "The Needle's Eye",
      xy: [
        1790,
        680
      ],
      r: 34,
      heightMax: 30,
      holds: "natural arch (Ring Run gate 1, sunrise gate)"
    },
    {
      id: "stacks",
      label: "The Stacks",
      xy: [
        [
          1770,
          880
        ],
        [
          1810,
          930
        ],
        [
          1750,
          960
        ]
      ],
      heightMax: 24,
      holds: "Ring Run gate 2 between them"
    },
    {
      id: "wreck",
      label: "The Wreck",
      xy: [
        250,
        1150
      ],
      r: 30,
      heightMax: 4,
      holds: "a wreck on the reef; boat destination; nothing to do"
    },
    {
      id: "sandbar",
      label: "Bight sandbar",
      xy: [
        620,
        1e3
      ],
      note: "shows at full moon"
    }
  ],
  landformRule: "polygons are clipped to the island outline; the Hollow, the Stillwater terrace and the Cup are cut INTO the Shoulder (their own band wins inside them); elsewhere where polygons overlap the innermost (higher) band wins; band edges blend over 60 m; a bed (road, skate, rail, walk) overrides the bands within its profile width + 15 m each side and holds its own grade limits, so band steps never appear as cliffs on a route",
  districts: [
    {
      id: "harbour",
      neighbourhood: "harbour",
      note: "town + the Terraces + the town quay",
      heart: [
        1470,
        1170
      ]
    },
    {
      id: "landing",
      neighbourhood: "landing",
      note: "Long Sands, the Landing quay, the Boathouse, Campfire, Tideline park",
      heart: [
        1060,
        1410
      ]
    },
    {
      id: "reach",
      neighbourhood: "landing",
      note: "the wetland and the river mouth",
      heart: [
        1280,
        1260
      ]
    },
    {
      id: "green",
      neighbourhood: "lakeside",
      note: "the Green and the Glasshouse steps",
      heart: [
        1030,
        1060
      ]
    },
    {
      id: "hollow",
      neighbourhood: "hollow",
      note: "the orchard bowl, the Adit",
      heart: [
        985,
        580
      ]
    },
    {
      id: "scholars",
      neighbourhood: "scholars",
      note: "the woodland rise and the north pass",
      heart: [
        765,
        400
      ]
    },
    {
      id: "flats",
      neighbourhood: "flats",
      note: "the arm: strip, hangar, balloon, the Wash",
      heart: [
        420,
        685
      ]
    },
    {
      id: "bight",
      neighbourhood: "flats",
      note: "the lagoon, the sandbar, Bight Shore, the Bight Bridge",
      heart: [
        745,
        995
      ]
    },
    {
      id: "lakeside",
      neighbourhood: "lakeside",
      note: "Stillwater, the sill falls (v2.6: the dam and L01 moved to Mountain v2)",
      heart: [
        1130,
        820
      ]
    },
    {
      id: "notch",
      neighbourhood: "lakeside",
      note: "the gorge, the High Span",
      heart: [
        1205,
        1070
      ]
    },
    {
      id: "prow",
      neighbourhood: "crown",
      note: "the cliffs, the zip tower, the Sea Door",
      heart: [
        1600,
        780
      ]
    },
    {
      id: "crown",
      neighbourhood: "crown",
      note: "the Shoulder and the summit; the Undercroft is its underground child district v2.6: Mountain v2 stands here (regions.mountainV2), its glass dam and L01 on the crest",
      heart: [
        1310,
        470
      ]
    },
    {
      id: "offshore",
      neighbourhood: null,
      note: "the Lamp, the Needle's Eye, the Stacks, the Wreck; the sky ring streams by the districts beneath it"
    }
  ],
  landforms: [
    {
      id: "harbour",
      label: "Little Harbour",
      h: [
        0,
        18
      ],
      poly: [
        [
          1380,
          1060
        ],
        [
          1540,
          1040
        ],
        [
          1580,
          1160
        ],
        [
          1520,
          1280
        ],
        [
          1400,
          1300
        ],
        [
          1350,
          1180
        ]
      ],
      faces: "north-west (the dam) and south (the harbour)"
    },
    {
      id: "sands",
      label: "Long Sands & the Landing",
      h: [
        0,
        5
      ],
      poly: [
        [
          720,
          1360
        ],
        [
          1e3,
          1400
        ],
        [
          1350,
          1360
        ],
        [
          1400,
          1440
        ],
        [
          1150,
          1500
        ],
        [
          860,
          1480
        ],
        [
          740,
          1420
        ]
      ],
      faces: "south"
    },
    {
      id: "reach",
      label: "The Reach",
      h: [
        2,
        6
      ],
      poly: [
        [
          1180,
          1180
        ],
        [
          1320,
          1180
        ],
        [
          1370,
          1300
        ],
        [
          1300,
          1360
        ],
        [
          1200,
          1340
        ],
        [
          1160,
          1260
        ]
      ]
    },
    {
      id: "green",
      label: "The Green",
      h: [
        10,
        25
      ],
      poly: [
        [
          1e3,
          900
        ],
        [
          1150,
          960
        ],
        [
          1250,
          1040
        ],
        [
          1300,
          1180
        ],
        [
          1150,
          1200
        ],
        [
          950,
          1200
        ],
        [
          820,
          1100
        ],
        [
          830,
          960
        ]
      ],
      faces: "south, open"
    },
    {
      id: "hollow",
      label: "The Hollow",
      h: [
        30,
        45
      ],
      poly: [
        [
          880,
          500
        ],
        [
          1060,
          480
        ],
        [
          1090,
          600
        ],
        [
          1040,
          680
        ],
        [
          900,
          680
        ],
        [
          850,
          600
        ]
      ],
      faces: "south-facing bowl"
    },
    {
      id: "scholars",
      label: "Scholars' Edge",
      h: [
        35,
        60
      ],
      poly: [
        [
          640,
          300
        ],
        [
          900,
          260
        ],
        [
          960,
          420
        ],
        [
          880,
          520
        ],
        [
          700,
          520
        ],
        [
          600,
          420
        ]
      ],
      faces: "north-west rise, shaded"
    },
    {
      id: "flats",
      label: "The Flats",
      h: [
        30,
        45
      ],
      poly: [
        [
          330,
          480
        ],
        [
          520,
          340
        ],
        [
          560,
          620
        ],
        [
          520,
          900
        ],
        [
          430,
          1e3
        ],
        [
          320,
          850
        ]
      ],
      faces: "west, sunset"
    },
    {
      id: "stillwater",
      label: "Stillwater terrace",
      h: [
        45,
        55
      ],
      poly: [
        [
          1e3,
          720
        ],
        [
          1260,
          720
        ],
        [
          1280,
          900
        ],
        [
          1e3,
          900
        ]
      ]
    },
    {
      id: "notch",
      label: "The Notch",
      h: "cut 25\u201345 below the terrace",
      centreline: [
        [
          1140,
          905
        ],
        [
          1170,
          980
        ],
        [
          1220,
          1060
        ],
        [
          1250,
          1140
        ],
        [
          1280,
          1220
        ],
        [
          1330,
          1290
        ],
        [
          1350,
          1345
        ],
        [
          1364,
          1390
        ]
      ],
      width: [
        40,
        70
      ],
      walls: "strata"
    },
    {
      id: "prow",
      label: "The Prow",
      h: [
        40,
        70
      ],
      poly: [
        [
          1560,
          480
        ],
        [
          1640,
          560
        ],
        [
          1700,
          760
        ],
        [
          1660,
          960
        ],
        [
          1600,
          1080
        ],
        [
          1560,
          1e3
        ],
        [
          1620,
          780
        ],
        [
          1560,
          600
        ]
      ],
      faces: "east, dawn; sea cliffs"
    },
    {
      id: "shoulder",
      label: "The Shoulder",
      h: [
        90,
        110
      ],
      poly: [
        [
          1060,
          330
        ],
        [
          1400,
          300
        ],
        [
          1520,
          420
        ],
        [
          1500,
          680
        ],
        [
          1400,
          860
        ],
        [
          1180,
          900
        ],
        [
          1060,
          800
        ],
        [
          1e3,
          600
        ]
      ],
      cutInto: [
        "hollow",
        "stillwater",
        "cup"
      ],
      note: "stays \u2265 60 m inland of the north coast so the coast drive is not in its band"
    },
    {
      id: "crown",
      label: "The Crown",
      h: [
        110,
        160
      ],
      poly: [
        [
          1120,
          330
        ],
        [
          1330,
          280
        ],
        [
          1500,
          380
        ],
        [
          1520,
          560
        ],
        [
          1420,
          700
        ],
        [
          1240,
          700
        ],
        [
          1120,
          560
        ]
      ],
      summit: [
        1310,
        470
      ],
      summitH: 158,
      snow: "Dec\u2013Mar, longest on the north face"
    },
    {
      id: "undercroft",
      label: "The Undercroft",
      h: [
        30,
        95
      ],
      footprint: {
        cx: 1300,
        cy: 470,
        rx: 170,
        ry: 130
      }
    }
  ],
  protected: {
    green: {
      cx: 1040,
      cy: 1065,
      r: 160,
      rule: "no building, plot, or prop taller than a bench (0.85 eu); disc-golf baskets and lantern posts ring the outside of it"
    }
  },
  water: {
    stillwater: {
      cx: 1130,
      cy: 820,
      rx: 110,
      ry: 85,
      surface: 50,
      note: "natural lake; never encodes money; ice Jan\u2013Feb; v2.6 (D-M3): held by the natural sill at its south end (no dam)"
    },
    river: {
      lower: [
        [
          1140,
          905
        ],
        [
          1170,
          980
        ],
        [
          1220,
          1060
        ],
        [
          1250,
          1140
        ],
        [
          1280,
          1220
        ],
        [
          1330,
          1290
        ],
        [
          1350,
          1345
        ],
        [
          1364,
          1390
        ]
      ],
      note: "v2.6: mountain (v2 river through the Foot) feeds the lake; lower leaves the lake over the natural sill through the Notch to the Reach and the harbour. v2.5: upper feeds the lake; lower leaves the dam through the Notch to the Reach and the harbour",
      mountain: {
        pts: [
          [
            1317,
            833
          ],
          [
            1300,
            838
          ],
          [
            1270,
            836.5
          ],
          [
            1232,
            832
          ]
        ],
        levels: [
          53.9,
          51.2,
          50,
          50
        ],
        width_m: 5,
        depth_m: 0.8,
        note: "v2.6 (D-M3): Mountain v2 river runs its own town channel on the Foot terrace (the region draws it, the gorge mouth [1311,730] to v2 channel end [1317,833], native (9,-0.1,69)); from there the Horizon carries it west into Stillwater east shore as a brook (it replaces river.upper as the lake inflow)",
        kind: "brook"
      },
      sill: {
        xy: [
          1136,
          896
        ],
        level: 50,
        note: "v2.6 (D-M3): Stillwater drains over a natural rock sill into the Notch: river.lower begins in the lake at the sill lip (50) and falls to its old head [1140,905] at 22; no structure"
      }
    },
    brook: {
      pts: [
        [
          880,
          480
        ],
        [
          900,
          600
        ],
        [
          880,
          700
        ],
        [
          865,
          800
        ],
        [
          820,
          860
        ]
      ],
      note: "Orchard Brook: woodland to the Bight under the covered bridge"
    },
    wash: {
      pts: [
        [
          480,
          560
        ],
        [
          465,
          700
        ],
        [
          485,
          800
        ],
        [
          515,
          900
        ]
      ],
      note: "dry streambed on the Flats; runs only after almanac rain; the Wash skate bowl at [465,700]"
    },
    reachChannels: [
      [
        [
          1280,
          1220
        ],
        [
          1240,
          1270
        ],
        [
          1230,
          1330
        ]
      ],
      [
        [
          1280,
          1220
        ],
        [
          1320,
          1260
        ],
        [
          1320,
          1320
        ]
      ]
    ],
    deep: {
      cx: 1300,
      cy: 420,
      surface: 40,
      note: "cavern lake at the foot of the Throat, under the skylight shaft; the underground river leaves it east through the Sea Passage to the sea"
    },
    spring: {
      xy: [
        1250,
        1180
      ],
      note: "a decorative spring at the Reach; not the Deep's outflow"
    }
  },
  hostRule: "footprint_m is the building's plan (w \xD7 d, concept metres, scales); roofH_eu is ridge height above its ground in engine units (does not scale)",
  hosts: [
    {
      id: "home",
      footprint_m: [
        22,
        16
      ],
      roofH_eu: 9,
      label: "Our home",
      placeIds: [
        "kitchen",
        "tower",
        "cellar",
        "atlas"
      ],
      xy: [
        1505,
        1165
      ],
      h: 14,
      door: "west, onto the square; the kitchen window looks north-west at the dam",
      arrival: "square (walk); upper street spur (wheels)"
    },
    {
      id: "bank",
      footprint_m: [
        20,
        18
      ],
      roofH_eu: 10,
      label: "The Fund bank",
      placeIds: [
        "bank"
      ],
      xy: [
        1443,
        1125
      ],
      h: 16,
      door: "south, onto the square (the bank stands on the square's north side)",
      v2_0_footprint_m: [
        26,
        18
      ],
      v2_0_xy: [
        1440,
        1125
      ],
      massNote_v2_1: "page A: the south wall's west 6 m stood in the Shoulder's sight line from the square (design lead, Stage A Wave 5 integration 2026-09-27; reversible)"
    },
    {
      id: "library",
      footprint_m: [
        42,
        30
      ],
      roofH_eu: 14,
      label: "The Library",
      placeIds: [
        "library"
      ],
      xy: [
        740,
        400
      ],
      h: 48,
      door: "south-east, onto the reading courtyard",
      arrival: "garden walk; Green Road north pass spur"
    },
    {
      id: "glasshouse",
      footprint_m: [
        25,
        18
      ],
      roofH_eu: 9,
      label: "The Glasshouse",
      placeIds: [
        "glasshouse"
      ],
      xy: [
        1007.5,
        790
      ],
      h: 56,
      door: "south, onto the Glasshouse steps down to the Green (ramp twin); faces Stillwater across the terrace",
      arrival: "garden walk; Green Road spur",
      v1_7: {
        footprint_m: [
          30,
          18
        ],
        xy: [
          1010,
          790
        ]
      }
    },
    {
      id: "studio",
      footprint_m: [
        24,
        16
      ],
      roofH_eu: 8,
      label: "The Pottery Studio",
      placeIds: [
        "kiln"
      ],
      xy: [
        1020,
        540
      ],
      h: 40,
      door: "west, onto the studio terrace; the Adit is 70 m east along the terrace"
    },
    {
      id: "cottage",
      footprint_m: [
        18,
        14
      ],
      roofH_eu: 7,
      label: "Hercules's cottage",
      placeIds: [
        "cottage"
      ],
      xy: [
        920,
        620
      ],
      h: 36,
      door: "south, into the orchard"
    },
    {
      id: "boathouse",
      footprint_m: [
        20,
        14
      ],
      roofH_eu: 7,
      label: "The Boathouse",
      placeIds: [
        "boathouse"
      ],
      xy: [
        1285,
        1315
      ],
      h: 3,
      door: "east, onto its dock on the harbour's west bank beside the Landing quay; the floatplane dock is the town's, not this one"
    }
  ],
  places: [
    {
      id: "court",
      label: "Queen's Court (the square)",
      xy: [
        1455,
        1175
      ],
      h: 12
    },
    {
      id: "campfire",
      label: "Campfire",
      xy: [
        1200,
        1430
      ],
      h: 2
    },
    {
      id: "L01",
      label: "Fund instrument (the glass dam crest plaques)",
      xy: [
        1316,
        539.2
      ],
      h: 142,
      reads: "BasinReading only",
      v1_9_xy: [
        1172,
        912
      ],
      decided: "D-C6 (recommended, accepted Jonathan 2026-09-27)",
      v2_5_xy: [
        1173,
        912
      ],
      v2_5_h: 52,
      decided_v2_6: "D-M3 (Jonathan 2026-09-28): Mountain v2 DAM_PARTS.promenade[6] + offset; BasinReading only; the region draws the plaques, the Horizon keeps its place pad as a deck (no earth)"
    },
    {
      id: "L02",
      label: "Summit lookout, observatory, the bell",
      xy: [
        1310,
        470
      ],
      h: 158
    }
  ],
  profileRule: "widths and lengths of routes scale with scale.factor (they are concept metres); clearances, gauges, rises and anything sized to the body or a vehicle are engine units and never scale",
  profiles: {
    road: {
      surface_m: 8,
      shoulder_m: 1,
      clear_m: 5,
      grade_typ_pct: [
        4,
        6
      ],
      grade_review_pct: 8,
      grade_max_pct: 12,
      exception: "the Prow cliff drive may hold 13 % for \u2264 150 m with a passing place",
      kerb: true,
      parapet_on_drop: true,
      exceptions: [
        "the Prow cliff drive may hold 13 % for \u2264 150 m with a passing place",
        "Crown Road (V02) may hold 12 % continuously for its climb from [1454,411] to the Shoulder Tunnel (\u2248 300 m): the manifest geometry forces 36 m over 382 m; every other stretch over 8 % is listed in the bake report"
      ]
    },
    spur: {
      surface_m: 5,
      clear_m: 4
    },
    trail: {
      surface_m: 2.5,
      material: "gravel",
      modes: [
        "feet",
        "bicycle"
      ]
    },
    walk: {
      surface_m: [
        2,
        2.5
      ],
      modes: [
        "feet"
      ],
      grade_max_pct: 12,
      grade_typ_pct: [
        0,
        8
      ],
      note: "walks and trails, including the Year Walk: 12 % maximum, \u2264 8 % typical; a stair's step-free twin keeps \u2264 8 %"
    },
    walkable: {
      slope_max_deg: 40,
      lip_step_max_eu: 0.5,
      note: "the body cannot climb steeper than 40\xB0 (Mountain v2's kept body limit, CONTRACT); a lip above 0.5 eu is an edge, not a step"
    },
    skateMain: {
      surface_m: [
        3,
        4
      ],
      bank_deg_max: 30,
      runout_m: 25,
      grade_typ_pct: [
        8,
        14
      ],
      grade_max_pct: 18,
      note: "grades apply to the bed after the land pass solves it; S1 averages ~15 % with real gravity"
    },
    skatePocket: {
      surface_m: [
        5,
        6
      ]
    },
    boardwalk: {
      surface_m: 3,
      onPiles: true,
      pace: "flow"
    },
    stair: {
      width_m: 3,
      rise_m: 0.17,
      twin: "ramp \u2264 8 % or path",
      exceptions: [
        {
          stair: "marketStair",
          twin: "none",
          stepFree: "structures.marketStair.stepFree (walk square, 94 eu at \u2264 8 %)",
          why: "D-C11"
        }
      ]
    },
    rail: {
      gauge_m: 0.9,
      tunnel_clear_m: 3.2,
      grade_max_pct: 6,
      chainLift: {
        from: [
          1300,
          420
        ],
        to: [
          1345,
          680
        ],
        note: "the Ore Line's climb out of the Deep to the South Portal is a named chain-lift incline (ORE.chainLift) exempt from grade_max_pct; the drop at [1270,450] (rail.ORE.drop) is the other named exception"
      }
    },
    cable: {
      clear_eu: 8,
      towerSpacing_m: [
        120,
        200
      ],
      note: "clear_eu never scales; spacing is concept metres"
    },
    cave: {
      clear_m: [
        6,
        30
      ],
      throatMouth_m: [
        26,
        18
      ]
    }
  },
  surfaces: {
    paved: {
      pace: "fast",
      footstep: "stone",
      grip: 1
    },
    packedEarth: {
      pace: "fast",
      footstep: "earth",
      grip: 0.95
    },
    apron: {
      pace: "flow",
      footstep: "concrete",
      note: "the dam's spillway apron",
      grip: 1
    },
    bankedTurf: {
      pace: "flow",
      footstep: "grass",
      grip: 1.1
    },
    boardwalk: {
      pace: "flow",
      footstep: "plank",
      grip: 0.9
    },
    cobble: {
      pace: "slow",
      footstep: "cobble",
      grip: 0.7
    },
    gravel: {
      pace: "slow",
      footstep: "gravel",
      grip: 0.6
    },
    sand: {
      pace: "slow",
      footstep: "sand",
      prints: true,
      grip: 0.5
    },
    plaza: {
      pace: "threshold",
      footstep: "stone",
      grip: 1
    },
    duff: {
      pace: "n/a",
      footstep: "needles",
      grip: null
    },
    ochre: {
      pace: "fast",
      footstep: "dust",
      grip: 0.85
    },
    snow: {
      pace: "slow",
      footstep: "snow",
      season: "Dec\u2013Mar",
      grip: 0.4
    },
    ice: {
      pace: "skate",
      footstep: "ice",
      season: "Jan\u2013Feb",
      where: "stillwater",
      grip: 0.2
    },
    stone: {
      pace: "threshold",
      footstep: "stone",
      grip: 1,
      note: "threshold pads, station slabs and the Tideline park"
    }
  },
  paces: {
    fast: {
      roll: 0.12,
      pushGrip: 1,
      meaning: "open line"
    },
    flow: {
      roll: 0.25,
      pushGrip: 0.9,
      meaning: "banked or boarded ground that wants a carve"
    },
    slow: {
      roll: 0.6,
      pushGrip: 0.8,
      meaning: "a neighbourhood, a chicane"
    },
    threshold: {
      roll: 1.8,
      pushGrip: 0.5,
      meaning: "every pad and the square: stops a board arriving under ~4.6 m/s in a pad's 6 m"
    },
    skate: {
      roll: 0.03,
      pushGrip: null,
      meaning: "pass 4's ice; the skates' pace"
    },
    "n/a": {
      roll: null,
      pushGrip: null,
      note: "not a bed for this mover; the kernel's offbed class applies (roll 6.0, pushGrip 0)"
    }
  },
  roads: {
    V01: {
      label: "Horizon Drive",
      pts: [
        [
          1400,
          1060
        ],
        [
          1480,
          1040
        ],
        [
          1543.2,
          1001.4
        ],
        [
          1600,
          860
        ],
        [
          1590,
          700
        ],
        [
          1560,
          500
        ],
        [
          1546,
          472
        ],
        [
          1520.4,
          439.7
        ],
        [
          1493.5,
          406.5
        ],
        [
          1461.6,
          373.9
        ],
        [
          1433.3,
          335.6
        ],
        [
          1397.2,
          306.5
        ],
        [
          1353.8,
          295.8
        ],
        [
          1300,
          260
        ],
        [
          1120,
          250
        ],
        [
          900,
          290
        ],
        [
          720,
          300
        ],
        [
          560,
          360
        ],
        [
          400,
          470
        ],
        [
          360,
          650
        ],
        [
          390,
          850
        ],
        [
          460,
          1030
        ],
        [
          660,
          1170
        ],
        [
          760,
          1250
        ],
        [
          900,
          1360
        ],
        [
          1100,
          1400
        ],
        [
          1300,
          1380
        ],
        [
          1350,
          1345
        ],
        [
          1370,
          1260
        ],
        [
          1360,
          1160
        ],
        [
          1400,
          1060
        ]
      ],
      closed: true,
      profile: "road",
      length_m: 3896,
      structures: [
        "prowTunnel",
        "quayBridge",
        "bightBridge"
      ],
      v1_8_pts: [
        [
          1400,
          1060
        ],
        [
          1480,
          1040
        ],
        [
          1540,
          1e3
        ],
        [
          1600,
          860
        ],
        [
          1590,
          700
        ],
        [
          1560,
          500
        ],
        [
          1500,
          340
        ],
        [
          1300,
          260
        ],
        [
          1120,
          250
        ],
        [
          900,
          290
        ],
        [
          720,
          300
        ],
        [
          560,
          360
        ],
        [
          400,
          470
        ],
        [
          360,
          650
        ],
        [
          390,
          850
        ],
        [
          460,
          1030
        ],
        [
          660,
          1170
        ],
        [
          760,
          1250
        ],
        [
          900,
          1360
        ],
        [
          1100,
          1400
        ],
        [
          1300,
          1380
        ],
        [
          1350,
          1345
        ],
        [
          1370,
          1260
        ],
        [
          1360,
          1160
        ],
        [
          1400,
          1060
        ]
      ],
      note_v1_9: "north-east corner re-laid on the cliff 10 m inside its top (was a chord over the sea through [1500,340]); Crown Road starts at [1433.3,335.6]"
    },
    VG: {
      label: "Green Road",
      pts: [
        [
          1400,
          1060
        ],
        [
          1330,
          1090
        ],
        [
          1240,
          1105
        ],
        [
          1120,
          1080
        ],
        [
          1e3,
          1e3
        ],
        [
          960,
          860
        ],
        [
          980,
          700
        ],
        [
          1e3,
          600
        ],
        [
          940,
          460
        ],
        [
          930,
          330
        ],
        [
          900,
          290
        ]
      ],
      profile: "road",
      length_m: 1176,
      structures: [
        "highSpan",
        "hollowBridge"
      ]
    },
    VBS: {
      label: "Bight Shore spur",
      pts: [
        [
          960,
          860
        ],
        [
          905,
          885
        ],
        [
          875,
          940
        ],
        [
          840,
          1e3
        ],
        [
          800,
          1065
        ],
        [
          775,
          1125
        ]
      ],
      profile: "spur",
      length_m: 334
    },
    spurs: {
      upperStreet: [
        [
          1480,
          1040
        ],
        [
          1480,
          1060
        ]
      ],
      library: [
        [
          900,
          290
        ],
        [
          760,
          360
        ]
      ],
      glasshouse: [
        [
          960,
          860
        ],
        [
          1e3,
          830
        ]
      ],
      studio: [
        [
          974,
          540
        ],
        [
          1e3,
          540
        ]
      ],
      cottage: [
        [
          980,
          700
        ],
        [
          930,
          650
        ]
      ],
      boathouse: [
        [
          1300,
          1380
        ],
        [
          1290,
          1345
        ]
      ]
    },
    V03: {
      label: "Mountain Road",
      pts: [
        [
          1599.5,
          790.8
        ],
        [
          1575,
          791
        ],
        [
          1540,
          790.5
        ],
        [
          1505,
          790
        ],
        [
          1478,
          790
        ],
        [
          1441.5,
          789.5
        ],
        [
          1405,
          789
        ],
        [
          1389,
          787
        ],
        [
          1365,
          778
        ],
        [
          1340,
          766
        ],
        [
          1315,
          755
        ],
        [
          1295,
          746
        ],
        [
          1281.5,
          742
        ]
      ],
      profile: "road",
      grade_max_pct: 10,
      length_m: 327,
      structures: [
        "mountainRoadTunnel",
        "mountainRoadCanalBridge"
      ],
      from: "Horizon Drive (V01) on the Prow cliff drive at [1599.5,790.8], north of the Terraces lay-bys (the plots stand 15 m apart between them)",
      to: "Mountain v2 town lane 22 m south of the road foot [1282, 54.65, 720] (the funicular town station and its viaduct stand east of the foot); the lane carries wheels on to the foot",
      levels: [
        {
          xy: [
            1478,
            790
          ],
          h: 45,
          why: "the tunnel east portal"
        },
        {
          xy: [
            1405,
            789
          ],
          h: 52.3,
          why: "the tunnel west portal"
        },
        {
          xy: [
            1389,
            787
          ],
          h: 53.8,
          why: "the Foot terrace edge (the island, r 84)"
        },
        {
          xy: [
            1300.5,
            748
          ],
          h: 56,
          why: "the canal bridge over v2 town channel (54.18): 1.25 clear under its deck"
        },
        {
          xy: [
            1281.5,
            742
          ],
          h: 55.3,
          why: "v2 town lane (course point 326)"
        }
      ],
      decided: "D-M4 (design lead; confirm)",
      note: "v2.6: the only wheeled way onto the mountain. East of the Foot terrace the Shoulder remnant (97-99) stands between the Prow drive and the Foot: the spur crosses the Terraces hollow on an embankment and passes under the ridge in the Mountain Road Tunnel (73 m), then crosses the Foot terrace and v2 town channel on a short bridge."
    }
  },
  skate: {
    S1: {
      label: "Summit to Sea",
      pts: [
        [
          1325,
          470.5
        ],
        [
          1331.54,
          473
        ],
        [
          1339.99,
          476.08
        ],
        [
          1348.81,
          477.43
        ],
        [
          1357.52,
          475.22
        ],
        [
          1366.21,
          472.97
        ],
        [
          1375.14,
          471.85
        ],
        [
          1384.08,
          472.2
        ],
        [
          1391.5,
          477.08
        ],
        [
          1390.88,
          485.13
        ],
        [
          1383.56,
          490.06
        ],
        [
          1374.75,
          491.82
        ],
        [
          1365.77,
          492.32
        ],
        [
          1357.47,
          495.64
        ],
        [
          1352.61,
          502.61
        ],
        [
          1356.6,
          510.27
        ],
        [
          1365.09,
          513.11
        ],
        [
          1374,
          513.98
        ],
        [
          1382.74,
          515.3
        ],
        [
          1390.21,
          520.21
        ],
        [
          1395.48,
          527.46
        ],
        [
          1397.01,
          536.18
        ],
        [
          1394.19,
          544.66
        ],
        [
          1388.47,
          551.55
        ],
        [
          1380.61,
          555.72
        ],
        [
          1371.65,
          556.06
        ],
        [
          1362.74,
          554.9
        ],
        [
          1354.15,
          552.21
        ],
        [
          1345.29,
          551.04
        ],
        [
          1336.45,
          552.68
        ],
        [
          1327.51,
          553.53
        ],
        [
          1318.52,
          553.24
        ],
        [
          1309.59,
          552.2
        ],
        [
          1300.86,
          550.05
        ],
        [
          1292.54,
          546.64
        ],
        [
          1284.48,
          542.66
        ],
        [
          1276.38,
          538.74
        ],
        [
          1268.31,
          534.77
        ],
        [
          1260.07,
          531.14
        ],
        [
          1251.6,
          528.12
        ],
        [
          1242.73,
          526.82
        ],
        [
          1233.78,
          527.6
        ],
        [
          1225.14,
          530.07
        ],
        [
          1217.15,
          534.14
        ],
        [
          1211.31,
          540.91
        ],
        [
          1208.15,
          549.27
        ],
        [
          1209.52,
          558.05
        ],
        [
          1214.49,
          565.47
        ],
        [
          1222.44,
          569.55
        ],
        [
          1231.2,
          571.57
        ],
        [
          1240.17,
          571.91
        ],
        [
          1248.93,
          570.06
        ],
        [
          1257.27,
          566.7
        ],
        [
          1266.01,
          564.57
        ],
        [
          1274.95,
          564.11
        ],
        [
          1283.46,
          566.95
        ],
        [
          1291.92,
          569.98
        ],
        [
          1300.85,
          570.99
        ],
        [
          1309.83,
          571.58
        ],
        [
          1318.62,
          573.44
        ],
        [
          1327.23,
          576.04
        ],
        [
          1335.39,
          579.78
        ],
        [
          1339.25,
          587.29
        ],
        [
          1342.36,
          595.43
        ],
        [
          1349.05,
          601.41
        ],
        [
          1357.22,
          605.1
        ],
        [
          1366.09,
          605.63
        ],
        [
          1374.19,
          601.75
        ],
        [
          1382.61,
          598.62
        ],
        [
          1391.46,
          598.82
        ],
        [
          1398.43,
          604.09
        ],
        [
          1400.79,
          612.74
        ],
        [
          1401.41,
          621.7
        ],
        [
          1400.54,
          630.65
        ],
        [
          1398.3,
          639.33
        ],
        [
          1393.69,
          647.04
        ],
        [
          1387.3,
          653.33
        ],
        [
          1379.45,
          657.69
        ],
        [
          1371.13,
          661.12
        ],
        [
          1362.51,
          663.63
        ],
        [
          1353.55,
          663.87
        ],
        [
          1344.6,
          663
        ],
        [
          1335.61,
          663
        ],
        [
          1328.27,
          667.6
        ],
        [
          1329.4,
          675.63
        ],
        [
          1336.93,
          680.32
        ],
        [
          1345.76,
          681.93
        ],
        [
          1354.75,
          681.99
        ],
        [
          1363.74,
          681.59
        ],
        [
          1372.54,
          682.88
        ],
        [
          1378.48,
          688.95
        ],
        [
          1375.09,
          696.85
        ],
        [
          1366.84,
          700.35
        ],
        [
          1357.95,
          701.53
        ],
        [
          1349.03,
          700.51
        ],
        [
          1340.62,
          697.41
        ],
        [
          1332.83,
          692.92
        ],
        [
          1324.54,
          689.43
        ],
        [
          1316.06,
          686.41
        ],
        [
          1307.18,
          685.36
        ],
        [
          1298.33,
          686.89
        ],
        [
          1290.18,
          690.62
        ],
        [
          1283.75,
          696.82
        ],
        [
          1280.51,
          705.14
        ],
        [
          1281.07,
          714.08
        ],
        [
          1281.91,
          721.5
        ],
        [
          1281.66,
          726
        ],
        [
          1281.49,
          730.51
        ],
        [
          1281.43,
          735.02
        ],
        [
          1281.46,
          739.53
        ],
        [
          1281.54,
          744.04
        ],
        [
          1281.68,
          748.55
        ],
        [
          1281.93,
          753.05
        ],
        [
          1282.3,
          757.54
        ],
        [
          1282.8,
          762.02
        ],
        [
          1283.6,
          766.46
        ],
        [
          1284.76,
          770.82
        ],
        [
          1286.22,
          775.09
        ],
        [
          1288.01,
          779.22
        ],
        [
          1290.13,
          783.2
        ],
        [
          1292.68,
          786.91
        ],
        [
          1295.63,
          790.32
        ],
        [
          1299.75,
          791.8
        ],
        [
          1304.17,
          790.95
        ],
        [
          1308.23,
          789
        ],
        [
          1312.54,
          787.89
        ],
        [
          1316.97,
          788.58
        ],
        [
          1320.77,
          790.95
        ],
        [
          1323.81,
          794.27
        ],
        [
          1326.36,
          797.99
        ],
        [
          1328.48,
          801.97
        ],
        [
          1305,
          822
        ],
        [
          1275,
          830
        ],
        [
          1225,
          905
        ],
        [
          1160,
          935
        ],
        [
          1150,
          1e3
        ],
        [
          1195,
          1075
        ],
        [
          1204,
          1080
        ],
        [
          1204,
          1133
        ],
        [
          1225,
          1150
        ],
        [
          1250,
          1230
        ],
        [
          1265,
          1290
        ],
        [
          1270,
          1330
        ]
      ],
      profile: "skateMain",
      length_m: 1712,
      segments: [
        {
          name: "Summit start",
          pace: "fast",
          surface: "paved",
          spot: "the summit gate",
          start: [
            1325,
            470.5
          ],
          mountainV2: "summit-start"
        },
        {
          name: "Alpine bends",
          pace: "flow",
          surface: "paved",
          spot: "switchback carves",
          start: [
            1351.77,
            476.92
          ],
          mountainV2: "alpine-bends"
        },
        {
          name: "Dam overlook",
          pace: "flow",
          surface: "paved",
          spot: "the glass dam below",
          start: [
            1355.03,
            497.39
          ],
          mountainV2: "dam-overlook"
        },
        {
          name: "Meadow sweep",
          pace: "flow",
          surface: "paved",
          spot: "terraced meadows",
          start: [
            1359.86,
            554.06
          ],
          mountainV2: "meadow-sweep"
        },
        {
          name: "Woodland bridges",
          pace: "fast",
          surface: "paved",
          spot: "the gorge bridges",
          start: [
            1283.46,
            566.95
          ],
          mountainV2: "woodland-bridges"
        },
        {
          name: "Library balcony",
          pace: "slow",
          surface: "paved",
          spot: "the Library balcony",
          start: [
            1351.65,
            602.9
          ],
          mountainV2: "library-balcony"
        },
        {
          name: "Neighbourhood switchbacks",
          pace: "flow",
          surface: "paved",
          spot: "hairpins",
          start: [
            1400.79,
            612.74
          ],
          mountainV2: "neighbourhood-switchbacks"
        },
        {
          name: "Town canal crossing",
          pace: "slow",
          surface: "cobble",
          spot: "the canal bridge",
          start: [
            1310.18,
            685.35
          ],
          mountainV2: "town-canal-crossing"
        },
        {
          name: "Waterfront finish",
          pace: "fast",
          surface: "paved",
          spot: "the quay finish gate",
          start: [
            1319.62,
            789.99
          ],
          mountainV2: "waterfront-finish"
        },
        {
          name: "Sill",
          pace: "flow",
          surface: "paved",
          spot: "the rock shelf beside Stillwater falls (was the Dam apron)",
          start: [
            1305,
            822
          ]
        },
        {
          name: "Notch shelf",
          pace: "fast",
          surface: "paved",
          spot: "shelf rail grind under the High Span",
          start: [
            1150,
            1e3
          ]
        },
        {
          name: "Reach boardwalk",
          pace: "slow",
          surface: "cobble",
          spot: "reed chicane",
          start: [
            1250,
            1230
          ]
        },
        {
          name: "Quay finish",
          pace: "fast",
          surface: "paved",
          spot: "bollards; 25 m run-out",
          start: [
            1265,
            1290
          ]
        }
      ],
      gates: 17,
      finish: [
        1270,
        1330
      ],
      time_target_s: [
        70,
        130
      ],
      steep: "v2.6: the upper half is Mountain v2 race course (its own grades); the Horizon stretch falls from the quay finish (54.7) to the sill shelf (31) at <= 18 %",
      v1_8_pts: [
        [
          1310,
          500
        ],
        [
          1300,
          570
        ],
        [
          1305,
          640
        ],
        [
          1300,
          700
        ],
        [
          1355,
          745
        ],
        [
          1310,
          800
        ],
        [
          1275,
          830
        ],
        [
          1225,
          905
        ],
        [
          1160,
          935
        ],
        [
          1150,
          1e3
        ],
        [
          1195,
          1075
        ],
        [
          1225,
          1150
        ],
        [
          1250,
          1230
        ],
        [
          1265,
          1290
        ],
        [
          1270,
          1330
        ]
      ],
      v2_5_pts: [
        [
          1310,
          500
        ],
        [
          1300,
          570
        ],
        [
          1305,
          640
        ],
        [
          1300,
          700
        ],
        [
          1355,
          745
        ],
        [
          1310,
          800
        ],
        [
          1275,
          830
        ],
        [
          1225,
          905
        ],
        [
          1160,
          935
        ],
        [
          1150,
          1e3
        ],
        [
          1195,
          1075
        ],
        [
          1204,
          1080
        ],
        [
          1204,
          1133
        ],
        [
          1225,
          1150
        ],
        [
          1250,
          1230
        ],
        [
          1265,
          1290
        ],
        [
          1270,
          1330
        ]
      ],
      v2_5_segments: [
        {
          name: "Crown drop",
          pace: "fast",
          surface: "paved",
          spot: "parapets"
        },
        {
          name: "Shoulder sweep",
          pace: "flow",
          surface: "bankedTurf",
          spot: "rock lip (optional jump)"
        },
        {
          name: "Dam apron",
          pace: "flow",
          surface: "apron",
          spot: "half-pipe wall ride; level line beside"
        },
        {
          name: "Notch shelf",
          pace: "fast",
          surface: "paved",
          spot: "shelf rail grind under the High Span"
        },
        {
          name: "Reach boardwalk",
          pace: "slow",
          surface: "cobble",
          spot: "reed chicane"
        },
        {
          name: "Quay finish",
          pace: "fast",
          surface: "paved",
          spot: "bollards; 25 m run-out"
        }
      ],
      v2_5_length_m: 971,
      mountainV2: {
        upperPts: 131,
        course: "land/mountainV2/v2-data.json course.points (Mountain v2 MOUNTAIN_COURSE_POINTS + offset, summit start to the quay finish gate); the builder lays these exact 3-D points, the first upperPts plan points above are their every-third copy",
        finish: [
          1328.48,
          54.72,
          801.97
        ],
        gates: [
          {
            id: "mountain-gate-start",
            name: "Summit start",
            segment: "summit-start",
            at: [
              1325,
              158.2,
              470.5
            ]
          },
          {
            id: "mountain-gate-alpine-1",
            name: "Alpine bends \xB7 crown",
            segment: "alpine-bends",
            at: [
              1381.13,
              152.92,
              471.72
            ]
          },
          {
            id: "mountain-gate-alpine-2",
            name: "Alpine bends \xB7 high terrace",
            segment: "alpine-bends",
            at: [
              1388.83,
              150.56,
              487.31
            ]
          },
          {
            id: "mountain-gate-alpine-3",
            name: "Alpine bends \xB7 Reservoir Heights",
            segment: "alpine-bends",
            at: [
              1362.87,
              147.41,
              493.05
            ]
          },
          {
            id: "mountain-gate-dam-overlook",
            name: "Dam overlook",
            segment: "dam-overlook",
            at: [
              1352.61,
              145.59,
              502.61
            ]
          },
          {
            id: "mountain-gate-meadow-1",
            name: "Meadow sweep \xB7 upper terrace",
            segment: "meadow-sweep",
            at: [
              1257.28,
              119.79,
              530.06
            ]
          },
          {
            id: "mountain-gate-meadow-2",
            name: "Meadow sweep \xB7 the turn",
            segment: "meadow-sweep",
            at: [
              1212.97,
              113.09,
              538.41
            ]
          },
          {
            id: "mountain-gate-meadow-3",
            name: "Meadow sweep \xB7 lower terrace",
            segment: "meadow-sweep",
            at: [
              1251.69,
              103.5,
              568.88
            ]
          },
          {
            id: "mountain-gate-woodland-bridge",
            name: "Woodland bridge",
            segment: "woodland-bridges",
            at: [
              1315.72,
              96.21,
              572.68
            ]
          },
          {
            id: "mountain-gate-library",
            name: "Library Woods",
            segment: "library-balcony",
            at: [
              1396.68,
              84.51,
              601.68
            ]
          },
          {
            id: "mountain-gate-east-arm",
            name: "East arm sweep",
            segment: "neighbourhood-switchbacks",
            at: [
              1401.23,
              81.33,
              624.69
            ]
          },
          {
            id: "mountain-gate-hearth",
            name: "Hearth Terrace",
            segment: "neighbourhood-switchbacks",
            at: [
              1376.7,
              75.48,
              658.89
            ]
          },
          {
            id: "mountain-gate-switchback-2",
            name: "Second switchback",
            segment: "neighbourhood-switchbacks",
            at: [
              1354.75,
              66.48,
              681.99
            ]
          },
          {
            id: "mountain-gate-switchback-1",
            name: "First switchback",
            segment: "neighbourhood-switchbacks",
            at: [
              1360.94,
              62.21,
              701.38
            ]
          },
          {
            id: "mountain-gate-road-foot",
            name: "Road foot",
            segment: "town-canal-crossing",
            at: [
              1282,
              54.65,
              720
            ]
          },
          {
            id: "mountain-gate-canal",
            name: "Canal bridge",
            segment: "town-canal-crossing",
            at: [
              1304.17,
              55.1,
              790.95
            ]
          },
          {
            id: "mountain-gate-finish",
            name: "Quay finish",
            segment: "waterfront-finish",
            at: [
              1328.48,
              54.72,
              801.97
            ]
          }
        ],
        decided: "D-M5 (design lead; confirm)"
      },
      segmentRule_v2_6: "each segment runs from its start (the nearest point of the built line) to the next start; the v2 segments are MOUNTAIN_RACE_SEGMENTS",
      gatesNote_v2_6: "the 17 gates are Mountain v2 MOUNTAIN_GATES (mountainV2.gates); the Horizon stretch below the quay finish is ungated",
      note_v2_6: "D-M5: upper half = Mountain v2 MOUNTAIN_COURSE_POINTS + offset (summit start [1325,470.5] to the quay finish [1328.5,802]); then the sill, the Notch shelf, the Reach and the Landing quay. The Shoulder sweep, the Crown drop and the Dam apron are retired."
    },
    S2: {
      label: "The Wash Run",
      pts: [
        [
          480,
          480
        ],
        [
          475,
          580
        ],
        [
          465,
          700
        ],
        [
          485,
          800
        ],
        [
          510,
          900
        ],
        [
          480,
          985
        ],
        [
          466.1,
          1021.3
        ],
        [
          490.7,
          1038.5
        ],
        [
          548,
          1078.7
        ],
        [
          556.1,
          1095
        ],
        [
          564.1,
          1111.4
        ],
        [
          621.5,
          1151.6
        ],
        [
          655.9,
          1175.7
        ],
        [
          672,
          1192
        ],
        [
          690,
          1210
        ],
        [
          712,
          1230
        ],
        [
          750,
          1265
        ],
        [
          880,
          1375
        ],
        [
          1e3,
          1405
        ],
        [
          1020,
          1430
        ]
      ],
      profile: "skateMain",
      length_m: 1259,
      segments: [
        {
          name: "Strip rim",
          pace: "fast",
          surface: "ochre"
        },
        {
          name: "The Wash bowl",
          pace: "flow",
          surface: "ochre",
          spot: "bowl walls both sides; hip at the bend; centre [465,700]"
        },
        {
          name: "Bight Bridge",
          pace: "flow",
          surface: "boardwalk",
          spot: "S2.archCrown, S2.westAbutmentBank, S2.eastAbutmentBank, S2.deckRail (skate.S2.spots)",
          v1_9_spot: "full-length rail"
        },
        {
          name: "Landing road",
          pace: "slow",
          surface: "gravel",
          spot: "dune-ridge hip into the park"
        }
      ],
      v1_9_pts: [
        [
          480,
          480
        ],
        [
          475,
          580
        ],
        [
          465,
          700
        ],
        [
          485,
          800
        ],
        [
          510,
          900
        ],
        [
          480,
          985
        ],
        [
          470,
          1030
        ],
        [
          560,
          1100
        ],
        [
          650,
          1185
        ],
        [
          750,
          1265
        ],
        [
          880,
          1375
        ],
        [
          1e3,
          1405
        ],
        [
          1020,
          1430
        ]
      ],
      levels: [
        {
          xy: [
            485,
            800
          ],
          h: 23.7,
          why: "the Wash rim: the top of the west ramp"
        },
        {
          xy: [
            466.1,
            1021.3
          ],
          h: 12,
          why: "the west abutment's deck end"
        },
        {
          xy: [
            490.7,
            1038.5
          ],
          h: 12,
          why: "the lagoon lane starts its 8 % climb to the flyover"
        },
        {
          xy: [
            548,
            1078.7
          ],
          h: 17.6,
          why: "the flyover's west end"
        },
        {
          xy: [
            564.1,
            1111.4
          ],
          h: 17.6,
          why: "the flyover's east end"
        },
        {
          xy: [
            621.5,
            1151.6
          ],
          h: 12,
          why: "back on the sea lane at deck height"
        },
        {
          xy: [
            655.9,
            1175.7
          ],
          h: 12,
          why: "the east abutment's deck end: the banked descent starts"
        },
        {
          xy: [
            712,
            1230
          ],
          h: 6.5,
          why: "the foot of the banked descent on the sea-side shelf"
        }
      ],
      westRamp: {
        from: [
          485,
          800
        ],
        from_h: 23.7,
        to: [
          466.1,
          1021.3
        ],
        to_h: 12,
        grade_pct: 5,
        carried: "one even grade from the Wash down to the deck: a timber trestle over the Wash mouth (x 495-515, z 830-925, up to 18.6 over the dry bed, under the Bight pier stair) and a cutting of at most 4 eu through the spit knoll [480-492, 950-1010]",
        why: "D-A1: S2 could not descend from the Wash to the deck at 18 % (it dipped to 11.9 in the Wash mouth and climbed 18.5 again, v1.8 open item); within profiles.skateMain (grade_max_pct 18, typical 8-14)"
      },
      deckLanes: {
        structure: "bightBridge",
        lagoon: {
          from_s: 0,
          to_s: 100,
          offset_m: 10.6
        },
        flyover: "bightBridge.s2Flyover (s 100 \u2192 132)",
        sea: {
          from_s: 132,
          to_s: 244,
          offset_m: -7
        },
        note: "offsets from the V01 axis (+ toward the Bight); S2 never rides the road's shoulder and never crosses it at grade"
      },
      eastDescent: {
        kind: "bankedDescent",
        from: [
          655.9,
          1175.7
        ],
        from_h: 12,
        to: [
          712,
          1230
        ],
        to_h: 6.5,
        via: [
          [
            672,
            1192
          ],
          [
            690,
            1210
          ]
        ],
        bank_deg: [
          12,
          20
        ],
        radius_m: 45,
        grade_pct: 7.1,
        why: "D-A1: S2 left the deck at [606.6,1144.1] and came down over the lagoon with nothing under it (the island's worst drop, 24.0 eu); it now stays on the deck to the east abutment and carves a right-hand banked descent down the headland's sea-side shelf onto its old line to [750,1265]",
        bank: "the outside of the curve is the east abutment's wing wall battered to a bank (spot S2.eastAbutmentBank)"
      },
      spots: [
        {
          id: "S2.archCrown",
          kind: "rail",
          bed: "S2",
          on: "bightBridge.s2Flyover",
          xy: [
            556.1,
            1095
          ],
          h: 17.6,
          length_m: 24,
          groundLine: "the flyover deck beside the rail: roll over the crown without touching it",
          requiredJump: false,
          note: "the flyover's crown parapet rail under the steel arch, 5.6 above the road deck"
        },
        {
          id: "S2.westAbutmentBank",
          kind: "bank lip",
          bed: "S2",
          on: "bightBridge west abutment",
          xy: [
            461.5,
            1015.7
          ],
          h: 12,
          length_m: 14,
          groundLine: "the lagoon lane itself (the bank is its outer wing wall, battered to 30\xB0)",
          requiredJump: false
        },
        {
          id: "S2.eastAbutmentBank",
          kind: "bank lip",
          bed: "S2",
          on: "bightBridge east abutment",
          xy: [
            664,
            1184
          ],
          h: 11,
          length_m: 20,
          groundLine: "the descent's inside line",
          requiredJump: false
        },
        {
          id: "S2.deckRail",
          kind: "rail",
          bed: "S2",
          on: "bightBridge deck edge",
          xy: [
            516.4,
            1054.1
          ],
          h: 12,
          length_m: 244,
          groundLine: "the lane beside the rail",
          requiredJump: false,
          note: "the deck-edge rail, full length on the lagoon side to the flyover and on the sea side after it"
        }
      ],
      spotsRule: "Pass 02 M1 'Spots': rails, kerbs, walls, bollards, stairs and bank lips from pass 1's beds only; kind is one of those words; every spot names its groundLine and requiredJump is always false"
    },
    S3: {
      label: "Town Weave",
      pts: [
        [
          1480,
          1060
        ],
        [
          1500,
          1120
        ],
        [
          1470,
          1160
        ],
        [
          1440,
          1200
        ],
        [
          1470,
          1260
        ],
        [
          1430,
          1300
        ],
        [
          1390,
          1330
        ],
        [
          1350,
          1345
        ],
        [
          1290,
          1400
        ],
        [
          1200,
          1425
        ],
        [
          1100,
          1440
        ],
        [
          1020,
          1430
        ]
      ],
      profile: "skateMain",
      length_m: 736,
      segments: [
        {
          name: "Upper street",
          pace: "fast",
          surface: "paved"
        },
        {
          name: "Market stair",
          pace: "flow",
          surface: "paved",
          spot: "three flights, a rail each; ground line: park at stairTop and carry (stairs only, D-C11)",
          v1_9_spot: "three flights, a rail each; ramp = ground line"
        },
        {
          name: "The square",
          pace: "threshold",
          surface: "plaza",
          spot: "park, or the cobbled edge lane"
        },
        {
          name: "The quay",
          pace: "fast",
          surface: "paved",
          spot: "lantern posts, bollards"
        },
        {
          name: "Long Sands boardwalk",
          pace: "flow",
          surface: "boardwalk",
          spot: "kicker at each beach stair"
        }
      ]
    },
    S4: {
      label: "Hollow Line",
      pts: [
        [
          1e3,
          520
        ],
        [
          940,
          560
        ],
        [
          893,
          600
        ],
        [
          915,
          665
        ],
        [
          920,
          740
        ],
        [
          945,
          820
        ],
        [
          870,
          930
        ],
        [
          905,
          1015
        ],
        [
          900,
          1120
        ],
        [
          950,
          1230
        ],
        [
          990,
          1330
        ],
        [
          1005,
          1375
        ],
        [
          1020,
          1430
        ]
      ],
      profile: "skateMain",
      length_m: 1025,
      segments: [
        {
          name: "Studio terrace",
          pace: "flow",
          surface: "packedEarth",
          spot: "kiln retaining wall grind"
        },
        {
          name: "Orchard wall",
          pace: "slow",
          surface: "cobble",
          spot: "stone wall gap; covered-bridge rail"
        },
        {
          name: "The Green",
          pace: "fast",
          surface: "packedEarth",
          spot: "fallen-log kickers"
        },
        {
          name: "Dune ridge",
          pace: "flow",
          surface: "bankedTurf",
          spot: "last bank onto sand"
        }
      ]
    },
    park: {
      label: "Tideline park",
      xy: [
        1020,
        1430
      ],
      size: [
        60,
        32
      ],
      note: "Skate v2 park; forgiving landings only (RIDE D40); no race"
    },
    rules: [
      "no required jumps",
      "ground alternative for every spot",
      "run-out before every door",
      "board never past a threshold"
    ]
  },
  walks: {
    garden: {
      pts: [
        [
          740,
          400
        ],
        [
          800,
          480
        ],
        [
          880,
          560
        ],
        [
          930,
          660
        ],
        [
          990,
          780
        ]
      ],
      profile: "walk",
      length_m: 459
    },
    lakerim: {
      pts: [
        [
          990,
          780
        ],
        [
          1030,
          740
        ],
        [
          1130,
          720
        ],
        [
          1235,
          755
        ],
        [
          1250,
          840
        ],
        [
          1200,
          900
        ],
        [
          1166,
          905
        ]
      ],
      profile: "trail",
      length_m: 494,
      v2_1_surface_m: 5.2,
      v2_1_shoulder_m: 1.2,
      v2_1_surfaceNote: "the Year Walk's February share rides this trail at offset 0: the trail takes the Year Walk's section (5.2 m + 1.2 m shoulders; profile trail 2.5 elsewhere; design lead, Stage A Wave 5 integration 2026-09-27)",
      sectionNote_v2_3: "D-D8 (design lead, Stage A Wave 7 (W7-A) 2026-09-27, reversible): the trail keeps its profile section (2.5 m); on the February share the Year Walk's own 5.2 m + 1.2 m section carries the trail, so the widening stops where the share stops ([1251,836]) and never reaches the dam end",
      v2_2_pts: [
        [
          990,
          780
        ],
        [
          1030,
          740
        ],
        [
          1130,
          720
        ],
        [
          1235,
          755
        ],
        [
          1250,
          840
        ],
        [
          1200,
          900
        ],
        [
          1140,
          905
        ]
      ],
      v2_2_crossing: {
        a: "walk lakerim",
        b: "river lower",
        at: [
          1140,
          905
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "",
        retired_v2_3: "the trail ends at the gallery exit [1166,905] (D-D8): walk damCrest \xD7 river lower [1140.2,903] is the rim's crossing"
      }
    },
    prow: {
      pts: [
        [
          1590,
          998
        ],
        [
          1606,
          950
        ],
        [
          1616,
          928
        ],
        [
          1641,
          924
        ],
        [
          1641,
          880
        ],
        [
          1640,
          812
        ],
        [
          1633,
          790
        ]
      ],
      profile: "trail",
      length_m: 466,
      v1_8_pts: [
        [
          1560,
          1e3
        ],
        [
          1600,
          880
        ],
        [
          1620,
          760
        ],
        [
          1590,
          640
        ],
        [
          1540,
          560
        ]
      ],
      note_v1_9: "re-laid on the Prow top east of V01's cutting (was along the cutting's lip, over it twice); joins the Year Walk's west Prow lane at [1630,790], short of the sea stair's head"
    },
    bight: {
      pts: [
        [
          840,
          880
        ],
        [
          790,
          950
        ],
        [
          745,
          1010
        ],
        [
          720,
          1090
        ],
        [
          700,
          1150
        ]
      ],
      profile: "trail",
      length_m: 308,
      v1_8_pts: [
        [
          840,
          880
        ],
        [
          790,
          950
        ],
        [
          745,
          1010
        ],
        [
          720,
          1090
        ],
        [
          700,
          1150
        ]
      ],
      footwayOf: {
        host: "VBS",
        offset_m: 4.2,
        side_xy: [
          1100,
          1100
        ],
        why: "D-2 (v1.9): the four Bight plots and their 6 m margins fill the land between the spur and the shore; the trail walks the spur's landward verge at the spur's height"
      }
    },
    bightPier: {
      pts: [
        [
          350,
          880
        ],
        [
          430,
          900
        ],
        [
          498,
          896
        ]
      ],
      profile: "walk",
      length_m: 213,
      v1_8_pts: [
        [
          350,
          880
        ],
        [
          430,
          900
        ],
        [
          520,
          895
        ],
        [
          560,
          890
        ]
      ]
    },
    coveWalk: {
      pts: [
        [
          740,
          400
        ],
        [
          700,
          330
        ],
        [
          650,
          270
        ],
        [
          630,
          240
        ]
      ],
      profile: "walk",
      length_m: 195
    },
    dune: {
      pts: [
        [
          1148,
          1463
        ],
        [
          1125,
          1481
        ],
        [
          1e3,
          1480
        ],
        [
          870,
          1460
        ],
        [
          810,
          1420
        ]
      ],
      profile: "trail",
      length_m: 355,
      v1_8_pts: [
        [
          1150,
          1458
        ],
        [
          1e3,
          1478
        ],
        [
          870,
          1460
        ],
        [
          810,
          1420
        ]
      ]
    },
    crown: {
      profile: "walk",
      footwayOf: {
        host: "mountainV2.road",
        offset_m: 2.4,
        side: "left",
        from_s: 228.81,
        to_s: 945.86
      },
      pts: [
        [
          1359.54,
          664.04
        ],
        [
          1387.3,
          653.33
        ],
        [
          1400.92,
          627.67
        ],
        [
          1394.23,
          599.96
        ],
        [
          1366.09,
          605.63
        ],
        [
          1340.59,
          593.02
        ],
        [
          1321.51,
          574.24
        ],
        [
          1291.92,
          569.98
        ],
        [
          1263.08,
          565.21
        ],
        [
          1234.18,
          571.88
        ],
        [
          1209.52,
          558.05
        ],
        [
          1219.68,
          532.53
        ],
        [
          1248.69,
          527.41
        ],
        [
          1276.38,
          538.74
        ],
        [
          1303.73,
          550.93
        ],
        [
          1333.5,
          553.2
        ],
        [
          1362.74,
          554.9
        ],
        [
          1390.63,
          549.47
        ],
        [
          1392.22,
          522.44
        ],
        [
          1365.09,
          513.11
        ],
        [
          1360.11,
          494.23
        ],
        [
          1388.83,
          487.31
        ],
        [
          1375.14,
          471.85
        ],
        [
          1345.82,
          477.43
        ],
        [
          1325,
          470.5
        ]
      ],
      length_m: 717,
      joinsYearWalk: {
        at: [
          1359.5,
          661.64
        ],
        h: 73.29,
        note: "v2.6: the summit walk continues the Year Walk January lane up v2 road (left side) from the Hearth terrace to the summit"
      },
      note: "v2.6 (D-M4/D-M5): the Crown walk is Mountain v2 road, left side on the carriageway, from the Hearth terrace to the summit (pts is the road centreline for reference)",
      v2_5: {
        pts: [
          [
            1417.7,
            677.4
          ],
          [
            1445,
            665
          ],
          [
            1425,
            605
          ],
          [
            1340,
            620
          ],
          [
            1400,
            540
          ],
          [
            1360,
            470
          ],
          [
            1310,
            500
          ]
        ],
        profile: "walk",
        length_m: 418,
        v1_9_pts: [
          [
            1370,
            690
          ],
          [
            1330,
            600
          ],
          [
            1310,
            500
          ]
        ],
        joinsYearWalk: {
          at: [
            1417.7,
            677.4
          ],
          h: 110.1,
          note: "D-C7 (recommended, accepted Jonathan 2026-09-27): from the turning circle [1370,690] the Crown walk is the Year Walk's January lane (one bed at 110); its own bed starts here, a flush junction"
        }
      }
    },
    glasshouseSteps: {
      pts: [
        [
          990,
          830
        ],
        [
          1e3,
          805
        ],
        [
          1010,
          790
        ]
      ],
      profile: "walk",
      length_m: 45
    },
    flats: {
      pts: [
        [
          340,
          520
        ],
        [
          320,
          700
        ],
        [
          350,
          880
        ]
      ],
      profile: "trail",
      length_m: 364
    },
    reach: {
      pts: [
        [
          1400,
          1290
        ],
        [
          1330,
          1250
        ],
        [
          1270,
          1200
        ],
        [
          1240,
          1130
        ]
      ],
      profile: "walk",
      length_m: 235
    },
    square: {
      pts: [
        [
          1420,
          1210
        ],
        [
          1455,
          1175
        ],
        [
          1490,
          1130
        ],
        [
          1480,
          1060
        ]
      ],
      profile: "walk",
      length_m: 177
    },
    footQuay: {
      pts: [
        [
          1281.5,
          742
        ],
        [
          1276,
          760
        ],
        [
          1279,
          785
        ],
        [
          1283,
          800
        ],
        [
          1282,
          810
        ]
      ],
      profile: "walk",
      length_m: 70,
      note: "v2.6 (D-M6): from the Mountain Road's end on v2's town lane to the gondola's Waterfront station point on the Foot terrace (G1.from; the boarding threshold is the platform beside it), between v2's town lane and the rope; v2's own paths are the region's (T2 graph)"
    }
  },
  cable: {
    G1: {
      label: "Gondola (Mountain v2)",
      from: [
        1282,
        810
      ],
      to: [
        1300,
        480
      ],
      fromH: 54.53,
      toH: 158.05,
      towers: [
        [
          1250,
          710
        ],
        [
          1228,
          614
        ],
        [
          1370,
          550
        ]
      ],
      towerNote: "three towers at ~150 m spacing; heights solved in pass 1 so the cable clears terrain (the Shoulder band from [1425,848]) by profiles.cable.clear_m and passes \u2265 12 m over plot.terraces.*",
      clear_eu: 8,
      length_m: 474,
      speed: 7,
      note: "v2.6 (D-M6): Mountain v2 GONDOLA_LINE + offset: Waterfront (quay, [1282,810]) -> three towers -> Summit Commons ([1300,480]); cable = platform + hang_eu at the stations, tower tops authored, 3.2 % sag; the region draws towers, ropes, terminals and cabins (T3 rides it). The Little Harbour -> v2 quay lower leg is D-M6b (not built).",
      v1_9: {
        to: [
          1360,
          560
        ],
        toH: 112,
        towers: [
          [
            1450,
            958
          ],
          [
            1420,
            825
          ],
          [
            1390,
            693
          ]
        ],
        length_m: 543
      },
      towerSolve: "v2.6 (D-M6): the tower tops are Mountain v2 authored tops (authoredTowers, cable height); the Horizon does not re-solve them. Clearance over the baked ground is measured and reported per span. v2.5: solved (D-A3).",
      decided: "D-M6 (design lead; confirm)",
      v2_5: {
        from: [
          1480,
          1090
        ],
        to: [
          1335,
          535
        ],
        fromH: 18,
        toH: 150,
        towers: [
          [
            1445.8,
            959
          ],
          [
            1411.3,
            827.1
          ],
          [
            1380.9,
            710.7
          ]
        ],
        length_m: 574,
        towerDistances_m: [
          135.4,
          271.7,
          392
        ],
        towerMin_h_reference: {
          at_m: [
            135,
            272,
            407
          ],
          top_h: [
            83,
            110,
            151
          ],
          source: "proposals/gondola-top-station.md (Option 2 solver, no terraces rule); tower 3 now stands at 392 m, so re-solve"
        }
      },
      authoredTowers: [
        100,
        128,
        158
      ],
      hang_eu: 3.1,
      sag_pct: 3.2,
      drawnBy: "mountainV2",
      throat_m: 30,
      throatNote: "v2.6: Mountain v2's cabins leave the Waterfront platform on v2's own climb and reach the Horizon's 8 eu clearance 26-30 m out (7.5 eu over the Foot's lawn at 26 m): the station throat for the authored line is 30 m (25 m for a solved line)"
    },
    ZIP: {
      label: "Zipline",
      from: [
        1610,
        640
      ],
      to: [
        1130,
        1440
      ],
      fromH: 100,
      toH: 12,
      sag_pct: 1,
      length_m: 933,
      speed: 12,
      minClearAboveRoof_eu: 12,
      note: "the Prow tower (30 m tower, deck at h 100) \u2192 Long Sands 44 m inland, skirting the town's west edge over the Reach; at 1 % sag it overflies no roof, clears V01 by 9 m, S1 by 23 m, the Reach walk by 26 m, and crosses under the gondola cable at [1437.5,927.5], 15.0 m beneath it (D-A2: zip under gondola)",
      v1_9_note: "the Prow tower (30 m tower, deck at h 100) \u2192 Long Sands 44 m inland, skirting the town's west edge over the Reach; at 1 % sag it overflies no roof, clears V01 by 9 m, S1 by 23 m, the Reach walk by 26 m, and crosses above the gondola cable at [1442,921] with 10.7 m between cables"
    }
  },
  rail: {
    ORE: {
      label: "Ore Line",
      pts: [
        [
          1090,
          540
        ],
        [
          1160,
          520
        ],
        [
          1225,
          490
        ],
        [
          1270,
          450
        ],
        [
          1300,
          420
        ],
        [
          1360,
          480
        ],
        [
          1375,
          625
        ],
        [
          1345,
          680
        ]
      ],
      profile: "rail",
      length_m: 540,
      stations: [
        "the Adit [1090,540] h40",
        "the South Portal [1345,680] h67.5 (Mountain v2 ground, on v2 road lower switchback leg)"
      ],
      drop: {
        at: [
          1270,
          450
        ],
        fall_m: 28,
        siding: true
      },
      splash: "the Deep [1300,420]",
      note: "climbs after the Deep inside the rock, leaves the footprint at [1398,576] and runs a 119 m tunnel to the South Portal; v2.6 (D-M7): the portal drops to v2 ground (67.5): the chain-lift climbs 27.5 from the Deep, the controls [1360,480] and [1375,625] at 50 and 62",
      v2_5_stations: [
        "the Adit [1090,540] h40",
        "the South Portal [1345,680] h110 (29 m from Crown Road's turning circle)"
      ],
      heights_v2_6: [
        40,
        42,
        68,
        68,
        40,
        50,
        62,
        67.5
      ]
    }
  },
  water_routes: {
    FERRY: {
      label: "The Ferry",
      pts: [
        [
          1470,
          1340
        ],
        [
          1250,
          1540
        ],
        [
          900,
          1530
        ],
        [
          760,
          1480
        ],
        [
          640,
          1300
        ],
        [
          560,
          1100
        ],
        [
          580,
          980
        ],
        [
          560,
          890
        ],
        [
          560,
          1100
        ],
        [
          540,
          1230
        ],
        [
          380,
          1200
        ],
        [
          250,
          1150
        ],
        [
          230,
          900
        ],
        [
          285,
          720
        ],
        [
          280,
          450
        ],
        [
          450,
          250
        ],
        [
          625,
          212
        ],
        [
          900,
          110
        ],
        [
          1200,
          120
        ],
        [
          1500,
          300
        ],
        [
          1720,
          650
        ],
        [
          1712,
          790
        ],
        [
          1700,
          1e3
        ],
        [
          1560,
          1250
        ],
        [
          1470,
          1340
        ]
      ],
      closed: false,
      note: "clockwise (north up: west along Long Sands, in and out of the Bight under the bridge, round the Lamp and the Wreck, up the west, along the north, down the Prow, home); doubles back at the Bight pier",
      length_m: 5357,
      piers: {
        landing: [
          1470,
          1340
        ],
        bight: [
          560,
          890
        ],
        flats: [
          285,
          720
        ],
        scholarsCove: [
          630,
          235
        ],
        seaDoor: [
          1705,
          775
        ]
      },
      slowsAt: [
        "the Wreck [250,1150] (no stop)"
      ],
      headway_s: 370,
      hulls: 2,
      boarding: "walk the gangway (the deliberate action); the Ferry waits 20 s at each pier",
      beam_m: 8,
      beamNote: "v2.0 (D-A1): each hull's beam, authored so the Bight Bridge's navigable opening is provable (along-axis opening needed = beam / sin(angle) + deck width / tan(angle); 27.6 m at the inbound 46\xB0, the steel arch gives 34 m clear)"
    },
    ROW: {
      label: "Rowboat / canoe / dinghy water",
      area: "the Bight, the harbour, the coast to the Sea Door, the river below the Notch, the Deep",
      docks: [
        "boathouse [1320,1320]",
        "bight pier [560,890]",
        "lamp [540,1250]",
        "bightShore jetty [735,955]",
        "seaDoor jetty [1705,775]",
        "deep jetty [1300,440]"
      ],
      range: "the Wreck is reached only by Ferry (it slows there)"
    },
    RIVER_RUN: {
      label: "River Run (canoe)",
      pts: [
        [
          1160,
          740
        ],
        [
          1140,
          905
        ],
        [
          1170,
          980
        ],
        [
          1220,
          1060
        ],
        [
          1250,
          1140
        ],
        [
          1280,
          1220
        ],
        [
          1330,
          1290
        ],
        [
          1350,
          1345
        ],
        [
          1364,
          1390
        ]
      ],
      gates: 9,
      note: "starts at the lake inlet [1160,740] (the Cup's outflow is a 62 % cascade, scenery only) \u2192 lake \u2192 dam portage \u2192 Notch \u2192 Reach \u2192 harbour",
      note_v2_6: "v2.6 (D-M3): the lake inlet is v2 river mouth; the dam portage is retired, so the run crosses the sill falls with no carry: a sill portage is an open item for Jonathan"
    },
    DEEP_RUN: {
      label: "Deep Run (canoe)",
      from: "the Deep [1300,420]",
      to: "the Sea Door [1690,770]",
      pts: [
        [
          1300,
          420
        ],
        [
          1380,
          470
        ],
        [
          1470,
          540
        ],
        [
          1560,
          640
        ],
        [
          1620,
          720
        ],
        [
          1690,
          770
        ]
      ],
      length_m: 529,
      drop: "the Steps: 3 \xD7 12 m chutes in the first 120 m; then level to the sea",
      note: "the underground river through the Sea Passage; out under the Prow into daylight, then paddle round to the Landing"
    }
  },
  structures: {
    highSpan: {
      xy: [
        1240,
        1105
      ],
      kind: "bridge",
      deck: "VG road",
      h_deck: 24,
      shelf: "S1 skate shelf on the west wall, h 12",
      water: "Reach walk at river level, h 9",
      gate: "Ring Run gate 3 under the deck at h 16",
      riverbed_h: 8
    },
    quayBridge: {
      xy: [
        1350,
        1345
      ],
      kind: "bridge",
      deck: "V01 + S3 separated lane",
      h_deck: 9,
      under: "river mouth, rowboat clearance 4 m"
    },
    apronBridge: {
      xy: [
        1158,
        949
      ],
      kind: "bridge",
      deck: "S1",
      under: "the tailrace below the dam and the River Run"
    },
    bightBridge: {
      xy: [
        560,
        1100
      ],
      kind: "bridge",
      deck: "V01, the Year Walk's lagoon-side footways, and S2 as a separated skate ribbon (lagoon lane, flyover, sea lane), every deck edge railed",
      span_m: 245,
      h_deck: 12,
      clear_m: 8,
      under: "the Ferry (twice per lap), Ring Run gate 5",
      ends: {
        west: [
          460,
          1030
        ],
        east: [
          660,
          1170
        ],
        axis_m: 244.1,
        abutments: "both on the headlands and down to the ground: west a 14 \xD7 24 m embankment from the Flats spit tip [460,1020] to the deck end (it carries S2's lagoon lane and its bank), east on the shore; no bed raises the seabed under the deck"
      },
      section: {
        from_axis_m: [
          -9,
          12.6
        ],
        width_m: 21.6,
        lanes: {
          "S2 sea lane": [
            -8.75,
            -5.25
          ],
          V01: [
            -4,
            4
          ],
          "V01 shoulders": 1,
          "Year Walk footways (centres)": [
            5.2,
            7.4
          ],
          "S2 lagoon lane": [
            8.85,
            12.35
          ]
        },
        rails: "a rail on both deck edges the whole length, and a kerb rail between each S2 lane and its neighbour",
        note: "offsets from the V01 axis, + toward the Bight; the deck widens from 17 m (v1.9) to carry S2 as a lane of its own (3.5 m, profiles.skateMain.surface_m 3-4); the width is held to 21.6 so the 36 m opening still proves for the ferry (opening.needAlongAxis_m)"
      },
      opening: {
        at_s: [
          103,
          143
        ],
        centre_s: 123,
        centre: [
          560.8,
          1100.5
        ],
        width_m: 40,
        kind: "steel-arch",
        clear_eu: 11.4,
        clearWidth_m: 38,
        needAlongAxis_m: {
          beam_m: 8,
          deckWidth_m: 21.6,
          at_46deg: 32,
          at_58deg: 22.9,
          rule: "beam / sin(angle) + deck width / tan(angle) \u2264 clearWidth_m (proposals/bight-bridge.md)"
        },
        arch: "a steel through-arch above the deck (rise \u2265 10 over the deck, crown \u2265 22), its ribs on the deck edges and hangers to the deck",
        why: "36 m is past the 30 eu masonry-arch limit (STYLE \xA71.6.3), so the arch is steel; the opening covers the ferry lane (the hull crosses the deck edges at s \u2248 113-131, in at 46\xB0, out at 58\xB0) and Ring Run gate 5 (s 111); a hull of water_routes.FERRY.beam_m 8 at 46\xB0 needs 27.6 m along the axis (proposals/bight-bridge.md)",
        v2_0: {
          at_s: [
            98,
            134
          ],
          centre_s: 116,
          centre: [
            555,
            1096.5
          ],
          width_m: 36,
          clearWidth_m: 34
        },
        decided: "D-A1 (Jonathan 2026-09-27: 36 m); widened to 40 m by the design lead, Stage A Wave 5 integration 2026-09-27, reversible (opening.v2_0)",
        hullClearance_eu: {
          v2_0_36m_s98_134: -3.99,
          v2_1_40m_s103_143: 1.37,
          best_36m_s105_141: 0.15,
          rule: "an 8 m hull (water_routes.FERRY.beam_m) on the FERRY line against the arch piers' and bents' footings"
        }
      },
      bents: {
        west: {
          count: 8,
          bay_m: 11.4,
          from_s: 0,
          to_s: 103
        },
        east: {
          count: 9,
          bay_m: 10.1,
          from_s: 143,
          to_s: 244
        },
        "arch piers": [
          103,
          143
        ],
        note: "timber paired bents, every bay under the 12 eu timber limit; no bent in the opening or in S2's east descent",
        v2_0: {
          west: {
            count: 8,
            bay_m: 10.9,
            from_s: 0,
            to_s: 98
          },
          east: {
            count: 9,
            bay_m: 11,
            from_s: 134,
            to_s: 244
          },
          "arch piers": [
            98,
            134
          ]
        }
      },
      lookout: {
        id: "bightBridge.lookout",
        s: 116,
        xy: [
          562.1,
          1086.4
        ],
        deck_h: 12,
        size_m: [
          24,
          7.2
        ],
        side: "lagoon",
        from_s: 104,
        to_s: 128,
        reach: "off the Year Walk's lagoon footway at deck level, under the arch, railed on its three open sides",
        note: "a bay of the deck (a structure), not a pad: no register pad stands on the deck (D-A1); it spans o +8.8 to +16 where S2 has left the lagoon lane for the flyover, which passes 5.6 above its inner corner; its underside keeps the deck's 11.4 over the water and it stands between the arch piers, not on them"
      },
      s2Flyover: {
        id: "bightBridge.s2Flyover",
        from: [
          548,
          1078.7
        ],
        to: [
          564.1,
          1111.4
        ],
        h: 17.6,
        overRoad: [
          557.7,
          1098.4
        ],
        clear_eu: 5,
        carried: "hung from the arch between its ribs",
        note: "S2 crosses the road and the Year Walk footways once, over them, at the arch crown (register S2 \xD7 V01 'over'); ramps of 8 % up the lagoon lane (s 30 \u2192 100) and down the sea lane (s 132 \u2192 202)"
      },
      v1_9: {
        span_m: 230,
        deck: "V01 + S2 separated lane with a full-length rail",
        h_deck: 12
      },
      decided: "D-A1 option 1 (Jonathan 2026-09-27)"
    },
    hollowBridge: {
      xy: [
        893,
        600
      ],
      kind: "coveredFootbridge",
      deck: "garden walk + S4 (separated lane)",
      under: "Orchard Brook",
      note: "a covered footbridge, not on Green Road; the ninth disc-golf basket; S4 rail if you dare"
    },
    prowTunnel: {
      xy: [
        1592,
        890
      ],
      kind: "gallery",
      length_m: 90,
      route: "V01",
      section: {
        hillSide: "east (the Prow top's flank is the wall)",
        openSide: "west, a colonnade of columns on footings to the ground, open to the sea",
        roof: "a slab from the hill wall to the colonnade beam, lined and ceiled",
        headroom_eu: 5,
        carries: "Horizon Drive and its Year Walk verges (December seaward, January inland)"
      },
      cover: "report the ground over the roof as measured (a gallery needs none); no fill is made to fake a tunnel",
      grade: "V01 unchanged: 25.6 \u2192 30.9 over the 90 m on the candidate-3 bed (\u2248 6 %)",
      v1_9: {
        xy: [
          1600,
          780
        ],
        kind: "tunnel",
        length_m: 90
      },
      decided: "D-A4 candidate A as a gallery (Jonathan 2026-09-27)",
      why: "the v1.9 box at [1600,780] stood on V01's side-hill cut with no hill over it: its roof 3 eu out of the ground, V01 8.4 under its floor at the north portal and 4.977 < 5 headroom (proposals/prow-tunnel.md)",
      kindNote: "gallery (new kind, v2.0, D-A4): a covered road on a hillside: the hill is one wall, a roof slab on a colonnade forms the other, open to the view; ceiling and lining as a tunnel, cover not required"
    },
    gondolaStations: {
      base: [
        1279.71,
        810.73
      ],
      crownStation: [
        1298.3,
        481.7
      ],
      base_deck_h: 54.53,
      crownStation_deck_h: 158.05,
      drawnBy: "mountainV2",
      note: "v2.6 (D-M6): the stations are Mountain v2 GONDOLA_LINE Waterfront (quay) and Summit Commons platforms + offset; the region draws their terminals",
      v2_5: {
        base: [
          1480,
          1090
        ],
        crownStation: [
          1335,
          535
        ],
        v1_9_crownStation: [
          1360,
          560
        ],
        crownStation_deck_h: 150,
        note: "v2.0 (D-A3): the Crown station stands at grade on the summit's south shoulder (ground 148.5, deck 150); it was in a notch 17 m below the 129.7 ridge at [1360,560] (deck 112), which forced a 275 eu tower"
      }
    },
    reachFootbridge: {
      xy: [
        1274,
        1203
      ],
      kind: "footbridge on piles",
      deck: "Reach walk",
      under: "the river"
    },
    duneCulvert: {
      xy: [
        1005,
        1375
      ],
      kind: "underpass",
      deck: "V01 (Long Sands road)",
      under: "S4, 3 m clear",
      note: "a dune tunnel; the last surprise before the sand"
    },
    southPortal: {
      xy: [
        1345,
        680
      ],
      kind: "tunnel portal",
      note: "v2.6 (D-M7): the Ore Line top station stands at Mountain v2 ground at its position (67.5, on v2 road lower switchback leg); was h 110 by Crown Road turning circle",
      h: 67.5
    },
    zipPlatforms: {
      top: [
        1610,
        640
      ],
      topH: 100,
      topNote: "deck of a 30 m tower at the Prow; the glider launch is the same deck",
      landing: [
        1130,
        1440
      ],
      landingH: 12,
      landingNote: "a landing tower on the dune crest, deck 8 m above the Town Weave boardwalk which passes beneath it; a stair and a ramp down to the sand"
    },
    oreStations: [
      [
        1090,
        540
      ],
      [
        1345,
        680
      ]
    ],
    strip: {
      from: [
        425,
        520
      ],
      to: [
        445,
        860
      ],
      width_m: 30,
      hangar: [
        455,
        600
      ],
      windsock: [
        440,
        500
      ],
      balloonMooring: [
        520,
        470
      ],
      runwayLamps: true
    },
    floatplaneDock: [
      1520,
      1275
    ],
    jetties: {
      bightShore: [
        728,
        946
      ],
      deep: [
        1300,
        440
      ],
      lamp: [
        540,
        1250
      ],
      seaDoor: [
        1705,
        775
      ],
      boathouse: [
        1320,
        1320
      ],
      bightPier: [
        560,
        896
      ]
    },
    landingQuay: {
      xy: [
        1270,
        1330
      ],
      note: "the race finish on the islet between the Reach's west channel and the river; 25 m run-out along the bank; kerb-separated from V01 which passes 45 m south; the Boathouse dock is across the west channel by the Reach boardwalk",
      v2_3_finish_h: 3,
      finish_h: 4.7,
      finishNote_v2_4: "the paved finish and its pad at the islet's natural ground (\u2248 4.7) instead of 3 (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-S request)"
    },
    townQuay: {
      from: [
        1420,
        1335
      ],
      to: [
        1497,
        1265
      ],
      note: "Lantern Row, 8 m inside the waterline; pedestrian; the floatplane dock at its east end"
    },
    gardenWalkBridge: {
      xy: [
        965.7,
        761.1
      ],
      kind: "footbridge",
      route: "walk garden",
      span_m: 40,
      opening_m: 26,
      width_m: 5.6,
      deck: "the Garden Walk on its own grade (51-55)",
      under: "Green Road (37) and its May/September footway lanes, 15 eu below",
      note: "v1.9: the Garden Walk hung 16.7 eu over Green Road at [971,765] with no structure (the generated span found no footing within 20 m); the reserved at-grade threshold row VG x walk garden (R-A7) is unchanged",
      register_v2_0: "D-A7: this footbridge is the register's VG \xD7 walk garden crossing (over), at [969.5,764.2]"
    },
    jettiesV1_8: {
      bightShore: [
        735,
        955
      ],
      why: "v1.9: the Bight Shore jetty moved 17 m north-west, out of plot bight.2's 6 m margin"
    },
    bightPierStair: {
      kind: "stair",
      from: [
        498,
        896
      ],
      to: [
        557.5,
        896
      ],
      note: "v1.9: from the Flats' cliff top (the pier walk's end) down to the Bight ferry jetty"
    },
    seaStairWestLaneBridge: {
      xy: [
        1630.9,
        762.8
      ],
      kind: "footbridge",
      route: "yearWalk",
      span_m: 14,
      opening_m: 7,
      width_m: 5.4,
      deck: "the Year Walk's west Prow lane (54)",
      under: "the sea stair's cutting (49)",
      note: "v1.9: the lane crossed the stair 4.9 eu over it with no structure"
    },
    seaStairEastLaneBridge: {
      xy: [
        1650.3,
        766.8
      ],
      kind: "footbridge",
      route: "yearWalk",
      span_m: 16,
      opening_m: 8,
      width_m: 5.4,
      deck: "the Year Walk's east Prow lane (50.6)",
      under: "the sea stair's cutting (36)",
      note: "v1.9: the lane crossed the stair 14.2 eu over it with no structure"
    },
    bightSpurTrestle: {
      xy: [
        904.9,
        891.5
      ],
      kind: "trestle",
      carries: "VBS",
      length_m: 68,
      width_m: 5,
      from: [
        923.6,
        874.5
      ],
      to: [
        881,
        926.5
      ],
      deck: "VBS on its own grade (27.4 \u2192 24.4)",
      beside: "S4 at 17.3-18.2, 4.5-7 m from VBS's centreline on the east side",
      bents: "one line on the west (away from S4) and one under the centreline; none in S4's corridor",
      decided: "D-C9 (recommended, accepted Jonathan 2026-09-27)",
      note: "v2.0: VBS hung 6-9 eu over the ground beside S4 with nothing under it (R2-04; the dropped v1.9 bightSpurBridge put its bents in S4)",
      v2_0_to: [
        891.6,
        906
      ],
      v2_0_length_m: 44,
      v2_3_from: [
        918.1,
        877
      ],
      v2_3_to: [
        886.7,
        916
      ],
      v2_3_length_m: 56,
      note_v2_4: "extended along VBS (north +6, south +12) over the 8.5 / 1.49 eu voids at its ends (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-S request 4)"
    },
    marketStair: {
      xy: [
        1472,
        1124.5
      ],
      kind: "town stair",
      foot: [
        1472,
        12,
        1134
      ],
      head: [
        1472,
        18,
        1115
      ],
      flights: 3,
      twin: "none (stairs only)",
      stepFree: {
        route: [
          "walk square"
        ],
        length_eu: 94,
        grade_pct: {
          mean: 6.4,
          max: 8
        },
        from: "the square [1478,12,1150]",
        to: "the upper street spur's end [1480,18,1062]",
        note: "the square walk climbs beside the upper-street terrace (narrowed to x 1463-1480, TOWN_TIERS) at \u2264 8 %, level with both pads (W5-A); the 295 eu detour (walk square \u2192 town.bankLink \u2192 town.northLink \u2192 V01 \u2192 spur upperStreet) is superseded and comes back if TOWN_TIERS is restored",
        decided: "D-C11 stairs only (Jonathan 2026-09-27); the square walk as the step-free way by the design lead, Stage A Wave 5 integration 2026-09-27"
      },
      decided: "D-C11 stairs only (Jonathan 2026-09-27)",
      note: "v2.0: the ramp twin (marketRamp, land/town/build.ts) is retired; no step-free 75 m run at 8 % fits beside Our home",
      v2_0_stepFree: {
        route: [
          "walk square",
          "town.bankLink",
          "town.northLink",
          "V01",
          "spur upperStreet"
        ],
        length_eu: 295,
        from: "the square",
        to: "the upper street spur's end [1480,18,1060]",
        note: "the recorded step-free way between the square and the upper street (review 2 route walk: 295.5 eu, 123 s at 2.4 m/s)"
      },
      v2_2_xy: [
        1480,
        1160
      ],
      v2_2_head: [
        1480,
        18,
        1150
      ],
      v2_2_foot: [
        1480,
        12,
        1171
      ],
      placeNote_v2_3: "the head on the upper street's south edge (was 6 m over the square at [1480,18,1150]); a level walk (town.upperStreetWalk) joins it to the gondola base walk and a level foot landing (marketStair.foot) to the square walk (design lead, Stage A Wave 7 (W7-A) 2026-09-27)"
    },
    coveStair: {
      kind: "cliff-stair",
      from: [
        631.2,
        241.9
      ],
      from_h: 34.1,
      to: [
        630,
        235
      ],
      to_h: 1,
      rise_m: 33.1,
      along: "cut into the cliff face west of the pier: two flights of \u2248 55 m run with a landing at \u2248 17, between [631,240] and [604,252] and back",
      parapet: "on the sea side, posted to the rock",
      decided: "D-C14 cliff stair (recommended, accepted Jonathan 2026-09-27)",
      note: "v2.0: the cove walk ended 32.8 above the pier; kind cliff-stair (not stair: the tower-stair builder does not apply)",
      v2_0_to_h: 1.8,
      toNote_v2_1: "the foot is the dock deck's own height (ferry.scholarsCove, 1.0); 1.8 would leave a 0.8 lip (W5-S)"
    },
    prowLoopFootbridge: {
      kind: "footbridge",
      carries: "yearWalk",
      over: "the Year Walk's own lower lane (the November loop on the Prow)",
      from: [
        1603.5,
        674.6
      ],
      to: [
        1609.8,
        702.9
      ],
      length_m: 29,
      width_m: 6,
      note: "v2.4: the Year Walk's upper pass over its own lower lane at the Prow (5.6 eu apart) on a named footbridge (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-A \u2192 W7-S request; OPEN_VOIDS yearWalk [1605,690] closed)"
    },
    mountainRoadTunnel: {
      xy: [
        1441.5,
        789.5
      ],
      kind: "tunnel",
      route: "V03",
      length_m: 73,
      width_m: 17,
      note: "v2.6 (D-M4): V03 under the Shoulder remnant east of the Foot terrace (ridge 93-99 over a road at 45-52); the Year Walk January footway rides its south side at 6.5"
    },
    mountainRoadCanalBridge: {
      xy: [
        1300.5,
        748
      ],
      kind: "footbridge",
      route: "V03",
      span_m: 18,
      width_m: 17,
      note: "v2.6: V03 over v2 town channel (water.river.mountain) on the Foot terrace; span 18 so the deck covers the Year Walk January lane's carried run (its share is carried within span/2 + 2 of the centre)"
    },
    s1InflowBridge: {
      xy: [
        1270.5,
        836.5
      ],
      kind: "footbridge",
      route: "S1",
      span_m: 12,
      width_m: 5,
      note: "v2.6: S1 over the mountain river where it runs west from the Foot into Stillwater"
    },
    inflowFootbridge: {
      xy: [
        1249,
        835.5
      ],
      kind: "footbridge",
      route: "walk lakerim",
      span_m: 10,
      width_m: 3.2,
      note: "v2.6: the lake-rim trail over the mountain river at its mouth"
    }
  },
  underground: {
    doors: {
      adit: {
        xy: [
          1090,
          540
        ],
        h: 40,
        mode: "feet, cart"
      },
      throat: {
        xy: [
          1300,
          300
        ],
        h: 110,
        mode: "glider only",
        mouth_m: [
          26,
          18
        ],
        note: "a diving entry: 139 m of sloping throat at 30\xB0 down to the Deep at h 40; flare over the water",
        collarAperture_m: 10.8,
        apertureNote: "v2.0 (D-C3, recommended, accepted Jonathan 2026-09-27): mouth_m [26,18] is the mouth's aperture on the north face; the passage opens into the Deep below its ceiling under the collar (68-76.7) with 10.8 clear (built 10.79); the clearance report checks the passage against collarAperture_m"
      },
      seaDoor: {
        xy: [
          1690,
          770
        ],
        h: 0,
        mode: "boat",
        jetty: [
          1705,
          775
        ],
        passage: "the Sea Passage: a 504 m boat tunnel from the Deep to the sea, glow-worm lit, with the Steps (three 12 m chute drops in the first 120 m; the Deep Run rides them down like a flume; reduced motion cuts them). Upstream travel: boats tie up at the foot of the Steps [1420,505] and a portage stair (threshold stepsFoot) climbs beside the chutes to the Deep's jetty; nobody paddles up. The Sea Door pier has a cliff stair (the Sea Stair) up to the Prow walk, and the Ferry as its step-free way back"
      },
      southPortal: {
        xy: [
          1345,
          680
        ],
        h: 67.5,
        mode: "feet, cart",
        note: "the Ore Line's top; a walk-in door too. v2.6 (D-M7): at Mountain v2 ground (67.45) on v2 road lower switchback leg",
        v2_5_h: 110
      }
    },
    footprint: {
      cx: 1300,
      cy: 470,
      rx: 170,
      ry: 130,
      note: "all rooms inside; doors on its rim or reached by a listed tunnel"
    },
    rooms: {
      lanternCave: {
        xy: [
          1220,
          480
        ],
        h: 42
      },
      deep: {
        xy: [
          1300,
          420
        ],
        h: 40,
        water: true,
        skylight: {
          to: [
            1320,
            400
          ],
          topH: 138,
          shaft_m: 98,
          note: "opens on the north slope 20 m east of the Throat's centreline (so the Throat's mouth of daylight reads from the Deep's jetty); sun shaft when the sun is above 20\xB0"
        }
      },
      bellGallery: {
        xy: [
          1310,
          470
        ],
        h: 90,
        note: "directly under the summit; the bell rope is 68 m"
      },
      sealedDrift: {
        xy: [
          1180,
          500
        ],
        reserve: "plot.under.1"
      }
    },
    light: "glow-worms (cool), found lanterns (warm), skylight (sun/moon)"
  },
  sky: {
    ceiling_m: 300,
    launches: {
      crown: {
        xy: [
          1322,
          472
        ],
        h: 170,
        note: "the run-off deck of the summit lookout (L02), a structure on the summit's south-west lip; the terrain summit (landforms.crown.summitH 158) stays the island's highest ground and no bed may raise the ground above it",
        v2_5_xy: [
          1305,
          482
        ],
        note_v2_6: "v2.6 (integrator, D-M6): moved 17 m east and 10 m north, clear of Mountain v2's Summit Commons gondola terminal [1300,480] and its rope (which arrives from tower 3 at [1370,550]); the deck keeps h 170 over the summit terrace, east of the observatory [1306,466]"
      },
      prow: {
        xy: [
          1610,
          640
        ],
        h: 100,
        note: "the zip tower's deck"
      },
      lampGallery: {
        xy: [
          540,
          1195
        ],
        h: 25
      },
      plane: "anywhere under the ceiling"
    },
    lift: {
      thermals: [
        {
          xy: [
            380,
            600
          ],
          r: 150,
          hours: [
            12,
            18
          ],
          note: "the Flats' ochre"
        },
        {
          xy: [
            1610,
            850
          ],
          r: 120,
          hours: [
            8,
            18
          ],
          note: "the Prow face"
        }
      ],
      ridge: {
        along: "the Crown's south face",
        wind: "south"
      },
      sink: [
        {
          xy: [
            600,
            760
          ],
          r: 200,
          note: "the Bight"
        },
        {
          xy: [
            1210,
            1010
          ],
          r: 90,
          note: "the Notch"
        }
      ]
    },
    landings: {
      green: {
        xy: [
          1028,
          1112
        ],
        r: 60,
        target: true,
        note: "the Drop Zone target is ground paint inside the protected centre, clear of Green Road (its edge 65 m north-east) and the Year Walk",
        modes: [
          "glider",
          "parachute"
        ]
      },
      reachMeadow: {
        xy: [
          1195,
          1205
        ],
        r: 40,
        modes: [
          "glider",
          "parachute"
        ],
        v2_3_xy: [
          1143,
          1167
        ],
        note_v2_4: "the nearest clear 40 m field on the low ground south of the High Span (h 4.7): the Dam Run lands 17.3 m from the centre; Prow \u2192 meadow 23.1 m in hand, 1.9 short of the 25 asked ([1230,1190] kept 25.5 but S1, the Reach walk and the spring stand in its field) (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T A6)"
      },
      sands: {
        xy: [
          1095,
          1362
        ],
        r: 60,
        modes: [
          "glider",
          "parachute"
        ],
        note_v2_4: "accepted: Prow \u2192 Sands arrives +3.5 m at 10:00 and 15:30 alike (no thermal needed); label 'Long Sands' (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T A8)"
      },
      strip: "see structures.strip",
      water: [
        "harbour",
        "bight"
      ],
      deep: "via the Throat, glider only"
    },
    gates: [
      {
        n: 1,
        id: "needle",
        xy: [
          1790,
          680
        ],
        h: 14,
        aperture_m: [
          22,
          16
        ],
        note: "the Needle's Eye; sunrise gate"
      },
      {
        n: 2,
        id: "stacks",
        xy: [
          1780,
          905
        ],
        h: 12
      },
      {
        n: 3,
        id: "highSpan",
        xy: [
          1240,
          1095
        ],
        h: 17,
        aperture_m: [
          40,
          12
        ],
        note: "under the deck (deck h 24, riverbed h 8): 40 \xD7 12 at h 17 (11\u201323), clear of the river pools (\u2264 10.8) and the bank lip; the Notch is \u2265 54 m wide there (T1)",
        v1_7: {
          h: 16,
          aperture_m: [
            40,
            14
          ]
        }
      },
      {
        n: 4,
        id: "damArch",
        xy: [
          1140,
          925
        ],
        h: 45,
        note: "the spillway arch"
      },
      {
        n: 5,
        id: "bightBridge",
        xy: [
          560,
          1080
        ],
        h: 6,
        aperture_m: [
          11,
          8
        ],
        note: "under the deck"
      },
      {
        n: 6,
        id: "lamp",
        xy: [
          540,
          1260
        ],
        h: 20.5,
        note: "round the lighthouse"
      },
      {
        n: 7,
        id: "wreck",
        xy: [
          250,
          1150
        ],
        h: 15
      },
      {
        n: 8,
        id: "flatsRim",
        xy: [
          330,
          700
        ],
        h: 60
      },
      {
        n: 9,
        id: "scholarsCove",
        xy: [
          640,
          280
        ],
        h: 48
      },
      {
        n: 10,
        id: "northFace",
        xy: [
          1300,
          200
        ],
        h: 139,
        v2_3_h: 130,
        note_v2_4: "re-seated with the lookout launch (+10 \u2192 +9): the Throat Run at trim crosses +0.2 (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T A7)"
      },
      {
        n: 11,
        id: "crown",
        xy: [
          1310,
          470
        ],
        h: 190,
        note: "over the summit"
      },
      {
        n: 12,
        id: "throat",
        xy: [
          1300,
          300
        ],
        h: 119,
        aperture_m: [
          24,
          16
        ],
        note: "into the mountain; glider only; centred on the mouth (110\u2013128), 24 \xD7 16 inside the 26 \xD7 18 mouth"
      }
    ],
    plane: {
      speed_ms: 45,
      stall_ms: 18,
      floats: true,
      wheels: true,
      swapAt: "hangar",
      oneButtonRing: true,
      cannot: [
        "enter the Throat",
        "land on a neighbourhood",
        "collide with a person"
      ]
    },
    glider: {
      speed_ms: 11,
      sink_ms: 1.2,
      flare: true
    },
    balloon: {
      xy: [
        520,
        470
      ],
      mooringH: 40,
      tether_m: 250,
      note: "the Look camera made physical; you ride it up and back down, there is no stepping out at the top"
    },
    courses: {
      ringRun: {
        mode: "plane",
        gates: [
          1,
          2,
          3,
          4,
          5,
          6,
          7,
          8,
          9,
          10,
          11
        ],
        note: "the tour, in order"
      },
      damRun: {
        mode: "glider",
        launch: "crown",
        gates: [
          4,
          3
        ],
        land: "reach meadow [1143,1167]",
        note: "514 m to the arch with 115 m of height in hand at a 9:1 glide; under the High Span, then a west turn onto the Reach meadow, 115 m past it"
      },
      throatRun: {
        mode: "glider",
        launch: "crown",
        gates: [
          10,
          12
        ],
        land: "deep",
        note: "out over the north sea, turn, dive in"
      },
      lampHop: {
        mode: "glider",
        launch: "lampGallery",
        gates: [
          5
        ],
        land: "the Bight water beside the sandbar (fade to the sandbar)",
        note: "the short one"
      }
    },
    rules: [
      "no collisions with people: pass through + gust",
      "reduced motion: cuts between the twelve pages",
      "nothing in the sky reads a balance"
    ],
    waterLandings: {
      bight: {
        xy: [
          592,
          804
        ],
        r: 60,
        note: "the inner Bight, clear of the ferry pier and the Year Walk; the landing field is wet below level \u2212 2 all round"
      },
      deep: {
        xy: [
          1278,
          423
        ],
        r: 8,
        note: "the only clear water in the Deep: the west lobe beside the Throat's foot; an r 20 field needs the Ore Line's splash moved \u2265 20 m east or the Deep widened 15 m west (underground track)"
      },
      harbour: {
        note: "found by the envelope beside the floatplane dock (world/sky.ts); unchanged"
      },
      rule: "the envelope reads these centres; before v1.7 it used the water outline's centroid"
    },
    gliderPolar: [
      [
        8,
        1.3
      ],
      [
        9,
        1.05
      ],
      [
        11,
        1.2
      ],
      [
        14,
        1.8
      ],
      [
        17,
        3
      ]
    ],
    gliderPolarRule: "[airspeed m/s, still-air sink m/s] from bar pushed out full to pulled in full; a smooth piecewise cubic between points; trim [11,1.2] is sky.glider; stall below 7.5 (FLIGHT.md \xA72.2)",
    parachute: {
      forward_ms: 6,
      sink_ms: 3,
      freefallCap_ms: 30,
      autoPull_agl_m: 45,
      minBail_agl_m: 60,
      canopy_m: [
        7,
        3
      ],
      note: "reached only by jumping from the plane (carriedThresholds.bailOut); the chute always opens (D37)"
    },
    corridors: {
      throat: {
        gate: 12,
        to: [
          1300,
          420
        ],
        slope_deg: 30,
        level_m: 25,
        splashH: 42,
        coneDeg: 25,
        maxBankDeg: 20,
        note: "glider only: enter gate 12's aperture heading within coneDeg of south and banked at most maxBankDeg; follow the chute at slope_deg; the last level_m run over the Deep at splashH; a miss passes beside the mouth, never a wall"
      }
    },
    dropZone: {
      xy: [
        1028,
        1112
      ],
      rings_m: [
        5,
        10,
        25
      ],
      note: "ground paint inside the Green's protected centre at sky.landings.green; bullseye, inner, outer, then 'on the Green'",
      v1_7_xy: [
        1040,
        1065
      ],
      xyNote_v2_2: "follows sky.landings.green (v2.1 [1028,1112]); FLIGHT v1.7 placed it at the v1.6 green landing [1040,1065]"
    },
    landingModes: {
      strip: [
        "plane",
        "glider",
        "parachute"
      ],
      water: [
        "plane",
        "glider",
        "parachute"
      ],
      deep: [
        "glider"
      ],
      rule: "modes per non-field landing; every landing takes the parachute except water.deep (the Deep is reached only through the Throat, by glider)"
    }
  },
  reserves: {
    rotRule: "rot_deg is the bearing of the 64 m axis, degrees clockwise from +x (east) with y south",
    terraces: {
      plots: [
        [
          1552,
          832
        ],
        [
          1528,
          896
        ],
        [
          1512,
          952
        ]
      ],
      rot_deg: [
        -67,
        23,
        23
      ],
      size_m: [
        64,
        44
      ],
      placeIds: [
        "plot.terraces.1",
        "plot.terraces.2",
        "plot.terraces.3"
      ],
      served: "plots 1\u20133 uphill (west) of the Prow cliff drive between [1600,860] and [1540,1000] with a lay-by each; the Prow walk above; the town below. D12 confirmed 2026-09-25: three uphill plots only; no seaward plot.",
      v2_2_plots: [
        [
          1552,
          832
        ],
        [
          1528,
          896
        ],
        [
          1512,
          952
        ]
      ],
      plot1Note_v2_3: "R3-32: 1.0 m WNW off the Prow walk's corner (margin 5.83 \u2192 \u2265 6.6); design lead, Stage A Wave 7 (W7-A) 2026-09-27",
      v2_3_plots: [
        [
          1551.1,
          832.5
        ],
        [
          1528,
          896
        ],
        [
          1512,
          952
        ]
      ],
      plot1Note_v2_4: "back to v2.2 (design lead, Stage A Wave 7 integrator 4 2026-09-27): the v2.3 move put the service drive's bed 0.47 over the Year Walk at [1594.7,837.9] and blocked the walk to L02; R3-32 open (5.83 of 6), owner W7-A"
    },
    bightShore: {
      plots: [
        [
          813,
          918.8
        ],
        [
          771,
          973
        ],
        [
          729,
          1032
        ],
        [
          705,
          1107
        ]
      ],
      rot_deg: [
        39,
        45,
        24,
        11
      ],
      size_m: [
        64,
        44
      ],
      spacing_m: "\u2265 62 (centres), \u2265 17.5 edge to edge",
      placeIds: [
        "plot.bight.1",
        "plot.bight.2",
        "plot.bight.3",
        "plot.bight.4"
      ],
      served: "VBS spur; jetty [735,955]; all four outside protected.green (r 160)",
      v1_9_plots: [
        [
          836,
          907
        ],
        [
          771,
          973
        ],
        [
          729,
          1032
        ],
        [
          705,
          1107
        ]
      ],
      plot1Note_v2_0: "D-C8 (recommended, accepted Jonathan 2026-09-27): plot bight.1 moved 25 m west-south-west, the nearest spot clear of the June lane and S4 (the \u2248 12 m estimate did not clear); the plot's service drive follows",
      v2_2_plots: [
        [
          814,
          919
        ],
        [
          771,
          973
        ],
        [
          729,
          1032
        ],
        [
          705,
          1107
        ]
      ],
      plot1Note_v2_3: "D-D2: 1.0 m WSW off the June lane's corner (margin 5.79 \u2192 \u2265 6.6 with the Year Walk's shoulder); the service drive meets the June lane at grade (design lead, Stage A Wave 7 (W7-A) 2026-09-27)"
    },
    small: {
      sealedDrift: {
        xy: [
          1180,
          500
        ],
        placeId: "plot.under.1"
      },
      hangarBay: {
        xy: [
          458.2,
          600
        ],
        placeId: "plot.flats.1",
        v1_8_xy: [
          455,
          600
        ],
        size_m: [
          11,
          18
        ],
        door: "west, on the strip edge; its access walk is plot.flats.1.service",
        note_v1_9: "an 11 m bay facing the strip, 18 m deep, between the strip's 6 m margin and S2's (the 18 m face did not fit the 26 m between them)"
      }
    },
    plotRule: "1.5 \xD7 Library footprint + 6 m clear; graded, walled, served, reserved placeId; no lantern spot inside; no view depends on it being empty",
    retiredPlaceIds: [
      "plot.terraces.4"
    ]
  },
  neighbourhoods: [
    {
      id: "harbour",
      label: "Little Harbour",
      centre: [
        1470,
        1180
      ],
      r: 120,
      hosts: [
        "home",
        "bank"
      ],
      places: [
        "court"
      ],
      porch: "the square's edge facing the dam; the quay wall at night"
    },
    {
      id: "hollow",
      label: "The Hollow",
      centre: [
        970,
        590
      ],
      r: 100,
      hosts: [
        "studio",
        "cottage"
      ],
      porch: "picnic table under the apples by the covered bridge"
    },
    {
      id: "scholars",
      label: "Scholars' Edge",
      centre: [
        760,
        420
      ],
      r: 110,
      hosts: [
        "library"
      ],
      porch: "the reading courtyard facing the Bight"
    },
    {
      id: "flats",
      label: "The Flats",
      centre: [
        440,
        680
      ],
      r: 150,
      hosts: [],
      porch: "the hangar's bench"
    },
    {
      id: "landing",
      label: "The Landing & Long Sands",
      centre: [
        1170,
        1380
      ],
      r: 200,
      hosts: [
        "boathouse"
      ],
      places: [
        "campfire"
      ],
      porch: "the Boathouse dock; the log ring"
    },
    {
      id: "lakeside",
      label: "Lakeside",
      centre: [
        1130,
        830
      ],
      r: 130,
      hosts: [
        "glasshouse"
      ],
      places: [],
      porch: "the sill"
    },
    {
      id: "crown",
      label: "The Crown & the Undercroft",
      centre: [
        1310,
        500
      ],
      r: 150,
      hosts: [],
      places: [
        "L02",
        "L01"
      ],
      porch: "the lookout wall; the Deep's jetty"
    }
  ],
  viewRule: {
    landscape: "each pose: xy is the eye position on the ground; eye height 1.6 eu above ground unless eyeH given; target is the look-at point; fov_deg horizontal at 16:9 (the Sketchbook lens; STYLE's 42\xB0/52\xB0 lenses are the walking and ride cameras); radius_eu is the acceptance streaming radius; pageTrigger_eu is how close the player must stand (and face within 25\xB0) for the page to draw; target_h is the look-at height in engine units (it replaces the per-page constants and the terrain-height default); frames lists the Pass 1 subjects the page must hold, deferred the props that arrive in Pass 2/2b/3",
    portrait: "on a portrait capture (width < height, e.g. 390 \xD7 844) the camera holds the page's HORIZONTAL field of view, never its vertical one: horizontal FOV = portrait.fov_deg (never below 45\xB0), aimed at portrait.target at portrait.target_h (the page's target when absent), from the landscape eye unless portrait.xy / portrait.eyeH are given; portrait.frames names the subjects that must be legible on the phone \u2014 the other landscape subjects may fall outside the portrait crop"
  },
  pageTrigger_eu: 6,
  views: [
    {
      id: "A",
      target: [
        1175,
        960
      ],
      fov_deg: 60,
      radius_eu: 480,
      label: "The square, looking north-west",
      xy: [
        1470,
        1186
      ],
      frames: "the High Span's deck line and the Shoulder; Mountain v2's face stands beyond the square's fog (page E holds the Crown)",
      bestHour: "golden hour",
      also: "noon",
      target_h: 30,
      deferred: [
        "the Reach (outside any lens that holds the dam from the square; page I carries it)",
        "the Crown (hidden from the square by the Shoulder's own rim, 4\u201316 eu over the sight line inside its band; page E holds it)"
      ],
      portrait: {
        fov_deg: 45,
        target: [
          1195,
          1005
        ],
        frames: [
          "the High Span"
        ],
        v1_8_fov_deg: 50,
        v2_5_frames: [
          "the High Span",
          "the dam's glass face"
        ]
      },
      v1_6: {
        xy: [
          1455,
          1200
        ],
        target: [
          1200,
          700
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the High Span",
        "the Shoulder"
      ],
      v1_7_frames: "the High Span's deck line, the dam's glass face, the Shoulder and the Crown behind",
      lightRule: "at the page's best hour (golden hour) the dam's glass face reads lit OR emissive: the dam.glassFace light card is on from golden hour (D-A5); P25's golden-hour check is 'the square lit and the dam's face lit or emissive'",
      v2_5_subjects: [
        "the High Span",
        "the dam's glass face",
        "the Shoulder"
      ],
      v2_5_frames: "the High Span's deck line, the dam's glass face, the Shoulder",
      note_v2_6: "D-M10: the Stillwater dam is retired (D-M3): the page keeps its eye, target and lens and loses the dam's glass face from its subjects (landscape: the High Span, the Shoulder; portrait: the High Span). Mountain v2's face shows from the square only between the Shoulder remnant and the Foot plain's rim (bearings 15-25 deg W of N, 700 m, past the fog's legible limit): its silhouette is for Jonathan's eye, not a proof subject (deferred, as the Crown was)"
    },
    {
      id: "B",
      target: [
        515,
        880
      ],
      fov_deg: 55,
      radius_eu: 520,
      label: "The Lamp gallery",
      xy: [
        540,
        1195
      ],
      frames: "the Bight Bridge with its steel arch and the lookout at its crown, the Flats, the whole hook",
      bestHour: "sunset",
      also: "noon",
      target_h: 20,
      portrait: {
        fov_deg: 50,
        target: [
          522,
          940
        ],
        target_h: 18,
        frames: [
          "the Bight Bridge",
          "the hook"
        ]
      },
      deferred: [],
      v1_6: {
        xy: [
          540,
          1195
        ],
        target: [
          900,
          700
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the Bight Bridge",
        "the Flats",
        "the hook"
      ],
      v1_9_frames: "the Bight Bridge, the Flats, the whole hook",
      framesNote_v2_0: "D-A1: the arch and the lookout are parts of the Bight Bridge (bightBridge.* solids), so the machine subject stays 'the Bight Bridge'"
    },
    {
      id: "C",
      target: [
        1210,
        1098
      ],
      fov_deg: 55,
      radius_eu: 220,
      label: "High Span, three speeds",
      xy: [
        1268,
        1145
      ],
      frames: "road above, shelf within, water beside",
      bestHour: "morning",
      also: "night",
      target_h: 16,
      portrait: {
        fov_deg: 50,
        target: [
          1222,
          1102
        ],
        target_h: 16,
        frames: [
          "the road deck",
          "the skate shelf",
          "the walk at the water"
        ]
      },
      deferred: [],
      v1_6: {
        xy: [
          1245,
          1125
        ],
        target: [
          1240,
          1105
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the road deck",
        "the skate shelf",
        "the walk at the water"
      ]
    },
    {
      id: "D",
      target: [
        700,
        1462
      ],
      fov_deg: 55,
      radius_eu: 720,
      label: "Long Sands",
      xy: [
        1185,
        1445
      ],
      frames: "surf, the zipline landing",
      bestHour: "afternoon",
      also: "night",
      target_h: 6,
      deferred: [
        "a bench (Pass 3 dressing)",
        "the Lamp (Pass 2b subject: 670 eu from the eye, 9 px of 13 at 1440 \xD7 900 by size; the Pass 2b lighthouse and its 25 m gallery make it legible; design lead, Stage A Wave 5 integration 2026-09-27)"
      ],
      portrait: {
        fov_deg: 50,
        target: [
          700,
          1454
        ],
        target_h: 5,
        frames: [
          "surf",
          "the zipline landing"
        ],
        v1_7_frames: [
          "surf",
          "the Lamp",
          "the zipline landing"
        ]
      },
      v1_6: {
        xy: [
          900,
          1470
        ],
        target: [
          540,
          1230
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "surf",
        "the zipline landing"
      ],
      v2_0_frames: "surf, the Lamp, the zipline landing",
      v2_0_subjects: [
        "surf",
        "the Lamp",
        "the zipline landing"
      ],
      ground: {
        xy: [
          1181,
          1401
        ],
        h: 3
      },
      groundNote_v2_4: "the beach verge south of Horizon Drive, 5.1 eu off the Drive (Long Sands' dune walk and zip landing are not reachable from the square yet: R3-119) (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
    },
    {
      id: "E",
      target: [
        870,
        860
      ],
      fov_deg: 55,
      radius_eu: 900,
      label: "The Crown",
      xy: [
        1317.5,
        475.5
      ],
      frames: "from the lookout's run-off deck: Stillwater, the Green, the Hollow, the Flats and the Bight, the sea beyond (the harbour, the Reach, Long Sands and the Prow lie behind the Shoulder from here)",
      bestHour: "noon",
      also: "night",
      target_h: 20,
      portrait: {
        fov_deg: 55,
        target: [
          1e3,
          880
        ],
        target_h: 20,
        frames: [
          "the Green",
          "Stillwater",
          "the sea"
        ]
      },
      deferred: [],
      v1_6: {
        xy: [
          1310,
          430
        ],
        target: [
          1e3,
          1e3
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "Stillwater",
        "the Green",
        "the Hollow",
        "the Flats",
        "the Bight",
        "the sea"
      ],
      v1_8_xy: [
        1305,
        482
      ],
      ground: {
        xy: [
          1306,
          482
        ],
        h: 170
      },
      groundNote_v2_4: "on the Crown launch deck (lookout run-off deck), 5.1 eu from crownLaunch.stair's head (design lead, Stage A Wave 7 integrator 4 2026-09-27)",
      v2_5_xy_launch: [
        1300.5,
        485.5
      ],
      note_v2_6: "the eye follows the run-off deck (thresholds.crownLaunch v2.6)"
    },
    {
      id: "F",
      target: [
        1150,
        720
      ],
      fov_deg: 55,
      radius_eu: 420,
      label: "Dam crest (Mountain v2)",
      xy: [
        1332.23,
        533.27
      ],
      frames: "from the east end of Mountain v2's glass dam crest: L01 on the crest plaques, Stillwater and the Foot terrace below (the reservoir is behind the camera)",
      bestHour: "morning",
      also: "dusk",
      target_h: 100,
      portrait: {
        fov_deg: 45,
        target: [
          1150,
          760
        ],
        target_h: 101.4,
        frames: [
          "L01",
          "Stillwater"
        ]
      },
      deferred: [],
      v1_6: {
        xy: [
          1150,
          905
        ],
        target: [
          1450,
          1180
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "L01",
        "Stillwater"
      ],
      v2_5: {
        xy: [
          1158,
          905
        ],
        target: [
          1400,
          1150
        ],
        fov_deg: 55,
        label: "Dam crest",
        frames: "the plaques and L01 on the crest, the town below (the lake is behind the camera)",
        target_h: 14,
        portrait: {
          fov_deg: 45,
          target: [
            1260,
            990
          ],
          target_h: 30,
          frames: [
            "L01",
            "the town below"
          ]
        },
        subjects: [
          "L01",
          "the town below"
        ],
        bestHour: "morning",
        also: "dusk"
      },
      eyeH: 143.7,
      ground: {
        xy: [
          1316,
          539.2
        ],
        h: 142
      },
      note_v2_6: "D-M10 (re-posed; confirm by eye): L01 is on Mountain v2's dam crest (D-M3); from the crest the Little Harbour lies behind v2's south slopes and the Shoulder remnant, so the page holds L01 with Stillwater below instead of 'the town below'. eyeH: the promenade is v2's deck (the region's), not Horizon ground; ground is the L01 bay (place.L01.deck)",
      v2_6a: {
        xy: [
          1337.86,
          526.54
        ],
        target: [
          1119,
          731
        ],
        eyeH: 143.6,
        target_h: 101.4
      },
      note_v2_6b: "integrator: the east-end eye stood inside the abutment (the capture showed paper grain); the eye now stands on promenade[10] at crest + 1.7 looking west-south-west along the crest over L01 to Stillwater and the Foot"
    },
    {
      id: "G",
      target: [
        1320,
        380
      ],
      fov_deg: 55,
      radius_eu: 220,
      label: "The Deep, looking up the skylight shaft",
      xy: [
        1320,
        404
      ],
      frames: "from the Deep's floor up the skylight shaft to its square of daylight; the Throat dark behind (D-B5)",
      bestHour: "noon (sun shaft)",
      also: "night (moon shaft)",
      target_h: 110,
      portrait: {
        fov_deg: 45,
        target: [
          1320,
          380
        ],
        target_h: 110,
        frames: [
          "the skylight shaft"
        ]
      },
      deferred: [],
      v1_6: {
        xy: [
          1300,
          440
        ],
        target: [
          1300,
          300
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the skylight shaft"
      ],
      v2_3: {
        xy: [
          1300,
          440
        ],
        target: [
          1300,
          300
        ],
        target_h: 110,
        label: "The Deep, looking up the Throat",
        frames: "from the Deep's jetty north up the Throat to its mouth of daylight, the skylight shaft overhead, a glider flaring onto the water",
        subjects: [
          "the Throat's mouth of daylight",
          "the skylight shaft"
        ],
        portrait: {
          fov_deg: 45,
          target: [
            1300,
            300
          ],
          target_h: 110,
          frames: [
            "the Throat's mouth of daylight",
            "the skylight shaft"
          ]
        }
      },
      ground: {
        xy: [
          1300,
          440
        ],
        h: 40.6
      },
      decided_v2_4: "D-D7 option 1 (design lead rules, reversible: v2_3), W7-T request A4 (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
    },
    {
      id: "H",
      target: [
        100,
        560
      ],
      fov_deg: 55,
      radius_eu: 260,
      label: "The Flats at golden hour",
      xy: [
        440,
        760
      ],
      frames: "the strip in copper, the west sea under the low sun",
      bestHour: "golden hour",
      also: "dawn",
      target_h: 20,
      deferred: [
        "the windsock (Pass 2b kit: mast and sock; only its footing is built)",
        "the balloon at its mooring (Pass 2 mover and 2b kit)"
      ],
      portrait: {
        fov_deg: 50,
        target: [
          100,
          560
        ],
        target_h: 20,
        frames: [
          "the strip",
          "the west sea"
        ],
        v2_0_xy: null,
        xy: [
          428,
          760
        ],
        poseNote_v2_1: "the portrait eye on the strip 12 m west of the landscape eye (west sea 1 \u2192 14 px at 390 \xD7 844; design lead, Stage A Wave 5 integration 2026-09-27)",
        eyeH: 48
      },
      v1_6: {
        xy: [
          330,
          800
        ],
        target: [
          435,
          690
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the strip",
        "the west sea"
      ],
      v1_9_bestHour: "sunset",
      v1_9_label: "The Flats at sunset",
      v1_9_frames: "the strip in copper, the west sea under the sunset",
      decided: "D-B3 (recommended, accepted Jonathan 2026-09-27)",
      v2_3: {
        eyeH: null,
        eyeH_measured: 39.6,
        target_h: 30,
        portrait: {
          target_h: 30,
          xy: [
            428,
            760
          ]
        }
      },
      eyeH: 48,
      ground: {
        xy: [
          440,
          760
        ],
        h: 38
      },
      poseNote_v2_4: "an aerial eye 10 m over the strip (eye 39.6 \u2192 48, target_h 30 \u2192 20): west sea 0 \u2192 350 / 94 px (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T request A5)"
    },
    {
      id: "I",
      target: [
        1250,
        1180
      ],
      fov_deg: 55,
      radius_eu: 220,
      label: "Reach boardwalk",
      xy: [
        1275,
        1226
      ],
      frames: "the spring and the Reach water",
      bestHour: "morning",
      also: "dusk",
      target_h: 5,
      deferred: [
        "reeds at hand height",
        "the heron"
      ],
      portrait: {
        fov_deg: 45,
        target: [
          1250,
          1180
        ],
        target_h: 5,
        frames: [
          "the spring"
        ]
      },
      v1_6: {
        xy: [
          1270,
          1240
        ],
        target: [
          1280,
          1150
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the spring",
        "the Reach water"
      ],
      subjectDefs: {
        "the Reach water": "water.reach.* (the Reach channels) OR water.river.lower where the hit lies inside landforms.reach (the river crossing the Reach)"
      },
      decided: "D-C5 (recommended, accepted Jonathan 2026-09-27)",
      ground: {
        xy: [
          1284.8,
          1215
        ],
        h: 9.5
      },
      groundNote_v2_4: "on the Reach walk beside the boardwalk footbridge, 0.04 eu off the path (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
    },
    {
      id: "J",
      target: [
        1790,
        681
      ],
      fov_deg: 55,
      radius_eu: 340,
      eyeH: 51.6,
      label: "The Needle's Eye at dawn, from the Prow",
      xy: [
        1665,
        695
      ],
      frames: "the arch, the sea through it at dawn, the Prow underfoot",
      bestHour: "dawn",
      also: "noon",
      target_h: 20,
      portrait: {
        fov_deg: 50,
        target: [
          1790,
          681
        ],
        target_h: 20,
        frames: [
          "the arch",
          "the Prow"
        ]
      },
      deferred: [
        "the Stacks (not on J's east line through the arch, 60-65\xB0 to its right; D-D6)"
      ],
      v1_6: {
        xy: [
          1790,
          720
        ],
        target: [
          1790,
          680
        ],
        fov_deg: 55,
        radius_eu: 220,
        eyeH: 60
      },
      subjects: [
        "the arch",
        "the Prow"
      ],
      v2_2: {
        xy: [
          1840,
          1e3
        ],
        target: [
          1780,
          700
        ],
        target_h: 14,
        eyeH: 60,
        label: "The Needle's Eye, from the plane",
        frames: "the arch ahead of the wing, the Stacks, the Prow",
        subjects: [
          "the arch",
          "the Stacks",
          "the Prow"
        ],
        portrait: {
          fov_deg: 50,
          target: [
            1760,
            760
          ],
          target_h: 14,
          frames: [
            "the arch",
            "the Stacks",
            "the Prow"
          ]
        }
      },
      ground: {
        xy: [
          1607.3,
          690.9
        ],
        h: 48.5
      },
      decided_v2_3: "D-D6 re-pose (recommended; design lead, Stage A Wave 7 (W7-A) 2026-09-27, reversible: v2_2), W7-T's measured pose",
      v2_3: {
        xy: [
          1665,
          680
        ],
        eyeH: 51.5,
        target_h: 25,
        portrait: {
          fov_deg: 50,
          target: [
            1790,
            681
          ],
          target_h: 25,
          frames: [
            "the arch",
            "the Prow"
          ]
        }
      },
      poseNote_v2_4: "15 m south on the Prow cliff so the Prow is in the 16:9 frame (0 \u2192 1,250 px); opening 37.7 % of the arch's face (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
    },
    {
      id: "K",
      target: [
        1120,
        815
      ],
      fov_deg: 55,
      radius_eu: 220,
      label: "The Glasshouse at dusk",
      xy: [
        994,
        770
      ],
      frames: "the Glasshouse in front of Stillwater",
      bestHour: "dusk",
      also: "noon",
      target_h: 52,
      deferred: [
        "lit from inside",
        "seed pots in silhouette"
      ],
      portrait: {
        fov_deg: 45,
        target: [
          1120,
          815
        ],
        target_h: 52,
        frames: [
          "the Glasshouse",
          "Stillwater"
        ]
      },
      v1_6: {
        xy: [
          990,
          810
        ],
        target: [
          1130,
          820
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "the Glasshouse",
        "Stillwater"
      ],
      v1_8_xy: [
        1e3,
        758
      ],
      v1_9: {
        xy: [
          1006,
          762
        ],
        target: [
          1120,
          812
        ],
        target_h: 52,
        portrait: {
          fov_deg: 45,
          target: [
            1060,
            800
          ],
          target_h: 55,
          frames: [
            "the Glasshouse",
            "Stillwater"
          ]
        }
      },
      decided: "D-B2 re-pose (recommended, accepted Jonathan 2026-09-27)"
    },
    {
      id: "L",
      target: [
        1285,
        1315
      ],
      fov_deg: 55,
      radius_eu: 240,
      label: "The quay at night",
      xy: [
        1484,
        1295
      ],
      frames: "Lantern Row along the quay, the Boathouse across the water",
      bestHour: "night",
      also: "dawn",
      target_h: 4,
      deferred: [
        "the floatplane rocking (Pass 2 mover; its dock is at the quay's east end, behind this pose)",
        "lantern cards"
      ],
      portrait: {
        fov_deg: 45,
        target: [
          1285,
          1315
        ],
        target_h: 4,
        frames: [
          "Lantern Row",
          "the Boathouse"
        ],
        v1_8_xy: null,
        xy: [
          1460,
          1300
        ]
      },
      v1_6: {
        xy: [
          1430,
          1290
        ],
        target: [
          1285,
          1315
        ],
        fov_deg: 55,
        radius_eu: 220
      },
      subjects: [
        "Lantern Row",
        "the Boathouse"
      ],
      ground: {
        xy: [
          1477,
          1289
        ],
        h: 3
      },
      groundNote_v2_4: "on the town quay (Lantern Row), 4.3 eu off its walk (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
    }
  ],
  crossings: [
    {
      a: "VG",
      b: "river lower",
      at: [
        1240,
        1105
      ],
      resolution: "over",
      structure: "highSpan",
      kind: "crossing"
    },
    {
      a: "S1",
      b: "VG",
      at: [
        1204,
        1098
      ],
      resolution: "under",
      structure: "highSpan (shelf, west wall)",
      kind: "crossing"
    },
    {
      a: "walk reach",
      b: "river lower",
      at: [
        1274,
        1203
      ],
      resolution: "over",
      structure: "reachFootbridge",
      kind: "crossing"
    },
    {
      a: "walk garden",
      b: "brook",
      at: [
        898,
        611
      ],
      resolution: "over",
      structure: "hollowBridge",
      movedFrom: [
        893,
        600
      ],
      note: "the Hollow Bridge carries the Garden Walk over the brook 12 m north of the v1.7 point",
      kind: "crossing"
    },
    {
      a: "S4",
      b: "brook",
      at: [
        899,
        591
      ],
      resolution: "over",
      structure: "hollowBridge (separated lane; the rail)",
      movedFrom: [
        893,
        600
      ],
      note: "S4's lane on the Hollow Bridge crosses the brook 10 m south-east of the v1.7 point",
      kind: "crossing"
    },
    {
      a: "S4",
      b: "walk garden",
      at: [
        893,
        600
      ],
      resolution: "threshold",
      note: "the covered Hollow Bridge is shared: boards to the rail side at walking pace; the Hollow neck stays reserved (D-C10, Jonathan 2026-09-27: keep reserved until the other crossings are done; one P16 row, a hollowBridge beam 0.05 over the brook)",
      reserved: "D-C10",
      kind: "crossing",
      v1_9_note: "the covered bridge is shared: boards to the rail side at walking pace"
    },
    {
      a: "V01",
      b: "river mouth",
      at: [
        1350,
        1345
      ],
      resolution: "over",
      structure: "quayBridge",
      kind: "crossing"
    },
    {
      a: "S3",
      b: "river mouth",
      at: [
        1350,
        1345
      ],
      resolution: "over",
      structure: "quayBridge (separated lane)",
      kind: "crossing"
    },
    {
      a: "S1",
      b: "Reach west channel",
      at: [
        1255,
        1251
      ],
      resolution: "over",
      structure: "Reach boardwalk on piles; the finish sits on the islet between the west channel and the river",
      kind: "crossing"
    },
    {
      a: "V01+S2",
      b: "Bight mouth",
      at: [
        560,
        1100
      ],
      resolution: "over",
      structure: "bightBridge",
      kind: "crossing",
      decided: "D-A1 (Jonathan 2026-09-27)",
      note: "245 m viaduct with one 40 m steel through-arch (s 103-143; D-A1's 36 m widened by the design lead for the ferry hull, reversible); abutments on both headlands to the ground",
      v1_9_note: "245 m viaduct with one 36 m steel through-arch (s 98-134); abutments on both headlands to the ground"
    },
    {
      a: "S2",
      b: "V01",
      at: "[460,1030] to [660,1170] and the Wash to the bridge",
      resolution: "over",
      note: "v2.0 (D-A1): S2 rides the deck's lagoon lane from the west abutment, crosses over V01 and the Year Walk footways once on bightBridge.s2Flyover at the arch crown (17.6, 5.6 above the deck), then the sea lane to the east abutment and a banked descent onto its line; never the shoulder, never at grade",
      kind: "crossing",
      v1_9_note: "S2 rides a separated lane 4 m from the carriageway with a kerb, then the bridge's rail-side lane; never the shoulder"
    },
    {
      a: "S2",
      b: "water wash",
      at: "[465,700] to [485,800]",
      resolution: "threshold",
      note: "S2 shares the dry Wash bed; on almanac drizzle days the bowl is wet and the line closes at a marker for six hours",
      kind: "crossing"
    },
    {
      a: "S4",
      b: "VBS",
      at: [
        874,
        941
      ],
      resolution: "threshold",
      note: "at grade: dismount marker + kerb gap",
      district: "green",
      districtNote: "belongs to district green (Lakeside) unless pass 1 draws the bight district over it",
      kind: "crossing"
    },
    {
      a: "S4",
      b: "VG",
      at: [
        973,
        538
      ],
      resolution: "threshold",
      note: "flush at-grade threshold at the studio terrace (dismount marker + kerb gap): S4 (37.07) rises 2.8 to VG (39.87) at \u2264 12 % over \u2265 24 m on either side; regrade owed (beds)",
      kind: "crossing",
      decided: "D-A7 (Jonathan 2026-09-27)",
      v1_9_note: "at grade at the studio terrace: dismount marker + kerb gap"
    },
    {
      a: "VG",
      b: "walk garden",
      at: [
        969.5,
        764.2
      ],
      resolution: "over",
      kind: "crossing",
      v1_9_at: [
        974,
        748
      ],
      movedFrom: [
        974,
        748
      ],
      v1_9_resolution: "threshold",
      structure: "gardenWalkBridge",
      decided: "D-A7 (Jonathan 2026-09-27)",
      note: "the Garden Walk crosses Green Road on the named gardenWalkBridge, 17.65 over the road (regrading would need \u2248 147 m of 12 % ramp each side)"
    },
    {
      a: "V01",
      b: "walk reach",
      at: [
        1367,
        1271
      ],
      resolution: "threshold",
      kind: "crossing"
    },
    {
      a: "DEEP_RUN",
      b: "V01",
      at: [
        1587,
        677
      ],
      resolution: "under",
      note: "the Sea Passage runs 60+ m below the coast drive; the Deep run passes under the Prow cliff drive 23 m north-east of the v1.7 point",
      movedFrom: [
        1574,
        658
      ],
      kind: "crossing"
    },
    {
      a: "S4",
      b: "V01",
      at: [
        1009,
        1388
      ],
      resolution: "under",
      structure: "duneCulvert",
      movedFrom: [
        1005,
        1375
      ],
      note: "the dune culvert: V01 over S4 13 m south of the v1.7 point",
      kind: "crossing"
    },
    {
      a: "S1",
      b: "river lower",
      at: [
        1158,
        949
      ],
      resolution: "over",
      structure: "apronBridge",
      kind: "crossing"
    },
    {
      a: "ZIP",
      b: "V01",
      at: [
        1157,
        1394
      ],
      resolution: "over",
      note: "\u2265 9 m clear over the Long Sands road",
      kind: "crossing"
    },
    {
      a: "ZIP",
      b: "VG",
      at: [
        1343,
        1084
      ],
      resolution: "over",
      note: "\u2248 24 m clear over Green Road",
      kind: "crossing"
    },
    {
      a: "ZIP",
      b: "S3",
      at: [
        1133,
        1435
      ],
      resolution: "over",
      structure: "landing tower deck 8 m above the boardwalk",
      kind: "crossing"
    },
    {
      a: "V01",
      b: "walk bightPier",
      at: [
        402.3,
        894.5
      ],
      resolution: "threshold",
      kind: "crossing",
      v1_9_at: [
        407,
        894
      ],
      movedFrom: [
        407,
        894
      ],
      decided: "D-A7 (Jonathan 2026-09-27)",
      note: "flush at-grade threshold (a marked crossing on the Drive): the pier walk (34.47) comes down 3.9 to the Drive (30.55) over \u2248 33 m at \u2264 12 %; regrade owed (beds)"
    },
    {
      a: "V01",
      b: "walk coveWalk",
      at: [
        686,
        313
      ],
      resolution: "threshold",
      kind: "crossing"
    },
    {
      a: "FERRY",
      b: "bightBridge",
      at: [
        560,
        1100
      ],
      resolution: "under",
      note: "twice per lap, through the steel-arch opening (s 103-143, 38 m \xD7 11.4 clear; beam 8, +1.37 eu past each pier; v2.0 had s 98-134, 36 m)",
      kind: "crossing",
      decided: "D-A1 (Jonathan 2026-09-27)",
      v1_9_note: "twice per lap"
    },
    {
      a: "crownLaunch.stair",
      b: "underground.bellGallery",
      at: [
        1313,
        480.5
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
    },
    {
      a: "DEEP_RUN",
      b: "ZIP",
      at: [
        1587.5,
        677.4
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ferry.bight",
      b: "FERRY",
      at: [
        560,
        898
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "bake v1.8",
      note: "boarding threshold; mover pending"
    },
    {
      a: "ferry.flats",
      b: "FERRY",
      at: [
        285,
        720
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "bake v1.8",
      note: "boarding threshold; mover pending"
    },
    {
      a: "ferry.landing",
      b: "FERRY",
      at: [
        1470,
        1340
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "bake v1.8",
      note: "boarding threshold; mover pending"
    },
    {
      a: "ferry.seaDoor",
      b: "seaStair",
      at: [
        1705,
        775
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "highSpan.overlook",
      b: "river lower",
      at: [
        1251.2,
        1143.3
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 2.2 eu apart: regrade owed"
    },
    {
      a: "homestead.lane",
      b: "town quay",
      at: [
        1497,
        1265
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "jetty.boathouse",
      b: "reachChannel.2",
      at: [
        1320,
        1318.5
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 0.8 eu apart: regrade owed"
    },
    {
      a: "jetty.deep",
      b: "stepsPortage",
      at: [
        1300,
        440
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "jetty.deep",
      b: "underground.deepAccess",
      at: [
        1300,
        440
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "jetty.lamp",
      b: "lampGallery.ramp",
      at: [
        540,
        1250
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "jetty.lamp",
      b: "lampGallery.stair",
      at: [
        540,
        1250
      ],
      resolution: "threshold",
      kind: "sharedStretch",
      source: "bake v1.8",
      note: "shared stretch 6 eu at one height"
    },
    {
      a: "jetty.seaDoor",
      b: "ferry.seaDoor",
      at: [
        1705,
        781
      ],
      resolution: "threshold",
      kind: "sharedStretch",
      source: "bake v1.8",
      note: "shared stretch 12 eu at one height"
    },
    {
      a: "jetty.seaDoor",
      b: "seaStair",
      at: [
        1705,
        775
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "lampGallery.ramp",
      b: "FERRY",
      at: [
        510.4,
        1224.4
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 3.2 eu apart: regrade owed"
    },
    {
      a: "lampGallery.ramp",
      b: "FERRY",
      at: [
        546.1,
        1190.6
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 6.1 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "lampGallery.ramp",
      b: "lampGallery.stair",
      at: [
        540,
        1195
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "lampGallery.ramp",
      b: "lampGallery.stair",
      at: [
        540,
        1250
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "lampGallery.stair",
      b: "FERRY",
      at: [
        540,
        1230
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ORE",
      b: "DEEP_RUN",
      at: [
        1300,
        420
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ORE",
      b: "ORE.siding",
      at: [
        1270,
        450
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ORE",
      b: "southPortal.link",
      at: [
        1345,
        680
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "bake v1.8",
      note: "boarding threshold; mover pending"
    },
    {
      a: "ORE",
      b: "stepsPortage",
      at: [
        1343.6,
        463.6
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 25.1 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "ORE",
      b: "underground.bellGallery",
      at: [
        1225.5,
        489.6
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ORE",
      b: "underground.deepAccess",
      at: [
        1280,
        440
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 17.4 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "ORE",
      b: "underground.lanternCave",
      at: [
        1160,
        520
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ORE",
      b: "underground.throat",
      at: [
        1300,
        420
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "reachChannel.1",
      b: "reachChannel.2",
      at: [
        1280,
        1220
      ],
      resolution: "threshold",
      kind: "waterConfluence",
      source: "bake v1.8",
      note: "one waterway"
    },
    {
      a: "river lower",
      b: "reachChannel.1",
      at: [
        1280,
        1220
      ],
      resolution: "threshold",
      kind: "waterConfluence",
      source: "bake v1.8",
      note: "one waterway"
    },
    {
      a: "river lower",
      b: "reachChannel.2",
      at: [
        1280,
        1220
      ],
      resolution: "threshold",
      kind: "waterConfluence",
      source: "bake v1.8",
      note: "one waterway"
    },
    {
      a: "river lower",
      b: "reachChannel.2",
      at: [
        1320,
        1276
      ],
      resolution: "threshold",
      kind: "waterConfluence",
      source: "bake v1.8",
      note: "one waterway"
    },
    {
      a: "S1",
      b: "landingQuay",
      at: [
        1270,
        1330
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S1",
      b: "ZIP",
      at: [
        1251.5,
        1237.5
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S1",
      b: "ZIP",
      at: [
        1251.9,
        1236.8
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S2",
      b: "FERRY",
      at: [
        560,
        1100
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "v2.0 (D-A1): on the flyover under the arch crown, through the navigable opening",
      v1_9_note: ""
    },
    {
      a: "S2",
      b: "S3",
      at: [
        1020,
        1430
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S2",
      b: "S4",
      at: [
        1020,
        1430
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S2",
      b: "yearWalk",
      at: [
        551.9,
        1086.7
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "v2.0 (D-A1): S2's flyover passes over the Year Walk's lagoon footways (was a crossing on the deck)",
      v1_9_at: [
        553.9,
        1095
      ],
      v1_9_resolution: "threshold",
      structure: "bightBridge.s2Flyover",
      v1_9_note: ""
    },
    {
      a: "S2",
      b: "yearWalk",
      at: [
        742,
        1258.5
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S2",
      b: "yearWalk",
      at: [
        944.8,
        1393.7
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 1.6 eu apart: regrade owed"
    },
    {
      a: "S3",
      b: "gondolaBase.walk",
      at: [
        1480,
        1060
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S3",
      b: "host.home.approach",
      at: [
        1456,
        1175.3
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S3",
      b: "S4",
      at: [
        1020,
        1430
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S3",
      b: "town.quayLink",
      at: [
        1406,
        1319.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S3",
      b: "V01",
      at: [
        1321.9,
        1372.3
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S3",
      b: "V01",
      at: [
        1350,
        1345
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S3",
      b: "walk square",
      at: [
        1480,
        1060
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S4",
      b: "brook",
      at: [
        896.4,
        617.8
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S4",
      b: "plot.bight.1.service",
      at: [
        874.4,
        919.5
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S4",
      b: "walk garden",
      at: [
        897.5,
        620.6
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 1.7 eu apart: regrade owed"
    },
    {
      a: "S4",
      b: "walk garden",
      at: [
        905.9,
        640.6
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "under by 2.7 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under); v2.0 (D-A7): flush threshold confirmed (it was 2.75 apart in v1.8)",
      v1_8_resolution: "under",
      decided: "D-A7 (Jonathan 2026-09-27)",
      v1_9_note: "under by 2.7 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)"
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        880.4,
        909.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        884.8,
        903.6
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 0.9 eu apart: regrade owed"
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        900.7,
        882.8
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "under by 2.6 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        901.2,
        629.8
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        902.6,
        632.9
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        918.6,
        574.8
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        957.9,
        1248.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "at-grade meeting 0.6 eu apart: regrade owed"
    },
    {
      a: "spur boathouse",
      b: "host.boathouse.approach",
      at: [
        1290,
        1345
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur cottage",
      b: "walk garden",
      at: [
        930,
        650
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur cottage",
      b: "yearWalk",
      at: [
        971.9,
        691.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur cottage",
      b: "yearWalk",
      at: [
        974.4,
        694.4
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur library",
      b: "walk coveWalk",
      at: [
        760.1,
        359.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur library",
      b: "yearWalk",
      at: [
        806.1,
        337
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur studio",
      b: "host.studio.approach",
      at: [
        1e3,
        540
      ],
      resolution: "threshold",
      kind: "sharedStretch",
      source: "bake v1.8",
      note: "shared stretch 1 eu at one height"
    },
    {
      a: "spur upperStreet",
      b: "gondolaBase.walk",
      at: [
        1480,
        1060
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur upperStreet",
      b: "S3",
      at: [
        1480,
        1060
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "spur upperStreet",
      b: "walk square",
      at: [
        1480,
        1060
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "town.bankLink",
      b: "host.bank.approach",
      at: [
        1440,
        1134
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.bankLink",
      b: "host.home.approach",
      at: [
        1455,
        1175
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.bankLink",
      b: "town.northLink",
      at: [
        1420,
        1138
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.bankLink",
      b: "town.quayLink",
      at: [
        1455,
        1175
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.quayLink",
      b: "host.home.approach",
      at: [
        1455,
        1175
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.quayLink",
      b: "town quay",
      at: [
        1420,
        1335
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.quayLink",
      b: "town.riverLink",
      at: [
        1400,
        1290
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.storefront",
      b: "homestead.lane",
      at: [
        1497,
        1265
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "town.storefront",
      b: "homestead.lane",
      at: [
        1498,
        1250.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "town.storefront",
      b: "town quay",
      at: [
        1497,
        1265
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "underground.bellGallery",
      b: "underground.deepAccess",
      at: [
        1220,
        480
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.deepAccess",
      b: "stepsPortage",
      at: [
        1300,
        440
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.lanternCave",
      b: "underground.bellGallery",
      at: [
        1220,
        480
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.lanternCave",
      b: "underground.deepAccess",
      at: [
        1220,
        480
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.lanternCave",
      b: "underground.sealedDrift",
      at: [
        1187.3,
        498.2
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.lanternCave",
      b: "underground.sealedDrift",
      at: [
        1220,
        480
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.sealedDrift",
      b: "underground.bellGallery",
      at: [
        1220,
        480
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.sealedDrift",
      b: "underground.deepAccess",
      at: [
        1220,
        480
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "underground.throat",
      b: "DEEP_RUN",
      at: [
        1300,
        420
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "FERRY",
      at: [
        559.3,
        1104.8
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "FERRY",
      at: [
        560,
        1100
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "FERRY",
      at: [
        562.8,
        1107.1
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "plot.terraces.1.service",
      at: [
        1601.6,
        831.4
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "plot.terraces.2.service",
      at: [
        1580.5,
        918.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "plot.terraces.3.service",
      at: [
        1554.6,
        973.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "spur boathouse",
      at: [
        1300,
        1380
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "spur library",
      at: [
        900,
        290
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "spur upperStreet",
      at: [
        1480,
        1040
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "town.northLink",
      at: [
        1370.9,
        1126.3
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "town.riverLink",
      at: [
        1370,
        1260
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "VG",
      at: [
        900,
        290
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "VG",
      at: [
        1400,
        1060
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "yearWalk",
      at: [
        756.4,
        1247.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "yearWalk",
      at: [
        810.8,
        294.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "yearWalk",
      at: [
        952.7,
        1376.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "V01",
      b: "ZIP",
      at: [
        1587.4,
        677.7
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "plot.bight.1.service",
      at: [
        880.8,
        928.6
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "plot.bight.2.service",
      at: [
        832.6,
        1011.9
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "plot.bight.3.service",
      at: [
        799.1,
        1066.7
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "plot.bight.4.service",
      at: [
        775,
        1125
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "spur glasshouse",
      at: [
        960,
        860
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "yearWalk",
      at: [
        855,
        974.6
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "yearWalk",
      at: [
        904.2,
        885.9
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "yearWalk",
      at: [
        951.2,
        863.4
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VBS",
      b: "yearWalk",
      at: [
        954.1,
        862.3
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "highSpan.walk",
      at: [
        1228.8,
        1104.1
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "spur cottage",
      at: [
        980,
        700
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "spur glasshouse",
      at: [
        960,
        860
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "spur library",
      at: [
        900,
        290
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "spur studio",
      at: [
        975.5,
        540
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "VBS",
      at: [
        960,
        860
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "VG",
      b: "walk garden",
      at: [
        969.5,
        764.2
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: "under by 16.5 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "VG",
      b: "yearWalk",
      at: [
        943.6,
        471
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "walk bightPier",
      b: "walk flats",
      at: [
        350,
        880
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "under by 3.9 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "walk bightPier",
      b: "yearWalk",
      at: [
        415.5,
        897.6
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 6.2 eu: a named structure (footbridge, deck or passage) is owed; v2.0: re-check after the D-A7 regrade of the pier walk at V01 (the pier walk falls to the Drive's height here)",
      v1_9_note: "over by 6.2 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk bightPier",
      b: "yearWalk",
      at: [
        422.8,
        899
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 6.6 eu: a named structure (footbridge, deck or passage) is owed; v2.0: re-check after the D-A7 regrade of the pier walk at V01 (the pier walk falls to the Drive's height here)",
      v1_9_note: "over by 6.6 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk coveWalk",
      b: "ferry.scholarsCove",
      at: [
        630,
        235
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "bake v1.8",
      note: "the cove walk comes down the cliff stair to the pier: feet \u2192 ferry (D-C14)",
      v1_9_at: [
        630,
        240
      ],
      v1_9_resolution: "over",
      v1_9_kind: "crossing",
      structure: "coveStair",
      v1_9_note: "over by 32.8 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk coveWalk",
      b: "host.library.approach",
      at: [
        762,
        422
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "host.cottage.approach",
      at: [
        916.5,
        638.7
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "host.glasshouse.approach",
      at: [
        990,
        780
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "host.library.approach",
      at: [
        762,
        422
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "walk coveWalk",
      at: [
        762,
        422
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "walk lakerim",
      at: [
        990,
        780
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "yearWalk",
      at: [
        780.9,
        443.7
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk garden",
      b: "yearWalk",
      at: [
        899.6,
        638.9
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "under by 3.9 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "walk garden",
      b: "yearWalk",
      at: [
        900,
        640
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "walk garden",
      b: "yearWalk",
      at: [
        902.3,
        641.1
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "v1.9: now a flush path junction (was under)",
      v1_8_resolution: "under"
    },
    {
      a: "walk garden",
      b: "yearWalk",
      at: [
        961,
        757
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 14.6 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk garden",
      b: "yearWalk",
      at: [
        963.7,
        759.4
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 15.2 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk glasshouseSteps",
      b: "host.glasshouse.approach",
      at: [
        997.1,
        811.8
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: "under by 4.6 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk lakerim",
      b: "host.glasshouse.approach",
      at: [
        990,
        780
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk lakerim",
      b: "yearWalk",
      at: [
        1250.5,
        837.6
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk reach",
      b: "highSpan.walk",
      at: [
        1240,
        1130
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk reach",
      b: "town.quayLink",
      at: [
        1400,
        1290
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk reach",
      b: "town.riverLink",
      at: [
        1400,
        1290
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk reach",
      b: "ZIP",
      at: [
        1272.3,
        1202.8
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "walk reach",
      b: "ZIP",
      at: [
        1272.9,
        1201.8
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "walk square",
      b: "gondolaBase.walk",
      at: [
        1480,
        1060
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk square",
      b: "host.bank.approach",
      at: [
        1466.3,
        1162.9
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk square",
      b: "host.home.approach",
      at: [
        1455,
        1175
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk square",
      b: "town.bankLink",
      at: [
        1455,
        1175
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk square",
      b: "town.quayLink",
      at: [
        1455,
        1175
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1450.1,
        522.8
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1575.7,
        660.7
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1579.4,
        666
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1580.8,
        667.8
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1600.5,
        695.7
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1611.3,
        710
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "DEEP_RUN",
      at: [
        1649.9,
        743.2
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "FERRY",
      at: [
        560,
        1096.4
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "FERRY",
      at: [
        560,
        1099
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "FERRY",
      at: [
        560.2,
        1099.1
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "FERRY",
      at: [
        560.5,
        1096.7
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "plot.bight.1.service",
      at: [
        856.7,
        935
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: "v2.3: at grade (the June lane rises to the moved plot's service drive (D-D2); design lead, Stage A Wave 7 (W7-A) 2026-09-27)",
      v2_2_resolution: "under",
      v2_2_at: [
        871.2,
        914.9
      ]
    },
    {
      a: "yearWalk",
      b: "plot.terraces.1.service",
      at: [
        1594.9,
        834
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "plot.terraces.2.service",
      at: [
        1575.6,
        912.8
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "plot.terraces.3.service",
      at: [
        1547,
        974.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "seaStair",
      at: [
        1630.8,
        761.9
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 5.6 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "yearWalk",
      b: "seaStair",
      at: [
        1650.3,
        765.4
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: "over by 15.2 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "yearWalk",
      b: "town.storefront",
      at: [
        1494.5,
        1211.8
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "yearWalk",
      b: "town.storefront",
      at: [
        1495,
        1212.4
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "yearWalk",
      b: "ZIP",
      at: [
        1577.6,
        693.9
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "ZIP",
      at: [
        1579.6,
        690.7
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "ZIP",
      at: [
        1581.9,
        686.8
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "yearWalk",
      b: "ZIP",
      at: [
        1596.1,
        663.2
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "ZIP",
      b: "river lower",
      at: [
        1273.1,
        1201.5
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "zipLanding.ramp",
      b: "ZIP",
      at: [
        1130,
        1440
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "bake v1.8",
      note: "boarding threshold; mover pending"
    },
    {
      a: "zipLanding.stair",
      b: "ZIP",
      at: [
        1130,
        1440
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.8",
      note: ""
    },
    {
      a: "zipLanding.stair",
      b: "zipLanding.ramp",
      at: [
        1130,
        1440
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "zipLanding.stair",
      b: "zipLanding.ramp",
      at: [
        1145,
        1460
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.8",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "bightPierStair",
      b: "wash",
      at: [
        513.8,
        896
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.9",
      note: ""
    },
    {
      a: "jetty.bightPier",
      b: "FERRY",
      at: [
        560,
        902
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.9",
      note: "at-grade meeting 1 eu apart: regrade owed"
    },
    {
      a: "jetty.bightPier",
      b: "ferry.bight",
      at: [
        560,
        898
      ],
      resolution: "threshold",
      kind: "sharedStretch",
      source: "bake v1.9",
      note: "shared stretch 8 eu at one height"
    },
    {
      a: "S2",
      b: "bightPierStair",
      at: [
        509.9,
        896
      ],
      resolution: "under",
      kind: "crossing",
      source: "bake v1.9",
      note: ""
    },
    {
      a: "S4",
      b: "walk bight",
      at: [
        873.5,
        951.1
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.9",
      note: "at-grade meeting 1 eu apart: regrade owed"
    },
    {
      a: "S4",
      b: "yearWalk",
      at: [
        968.6,
        540.5
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.9",
      note: "v2.3: at grade (S4 holds VG's level across the September lane (flush landing, D-A7 #17); design lead, Stage A Wave 7 (W7-A) 2026-09-27)",
      v2_2_resolution: "under"
    },
    {
      a: "VG",
      b: "walk bight",
      at: [
        960.4,
        864.4
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.9",
      note: ""
    },
    {
      a: "walk bight",
      b: "yearWalk",
      at: [
        858.5,
        977
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.9",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk bight",
      b: "yearWalk",
      at: [
        907.3,
        888.6
      ],
      resolution: "over",
      kind: "crossing",
      source: "bake v1.9",
      note: "over by 8.6 eu: a named structure (footbridge, deck or passage) is owed"
    },
    {
      a: "walk bight",
      b: "yearWalk",
      at: [
        951.6,
        867.7
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.9",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk bight",
      b: "yearWalk",
      at: [
        954.5,
        866.6
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.9",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "walk bightPier",
      b: "bightPierStair",
      at: [
        498,
        896
      ],
      resolution: "threshold",
      kind: "crossing",
      source: "bake v1.9",
      note: "at-grade meeting 0.9 eu apart: regrade owed"
    },
    {
      a: "walk prow",
      b: "yearWalk",
      at: [
        1641,
        881.6
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.9",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "yearWalk",
      b: "southPortal.link",
      at: [
        1369.7,
        689.9
      ],
      resolution: "threshold",
      kind: "junction",
      source: "bake v1.9",
      note: "flush path junction: no marker, no mode change"
    },
    {
      a: "S2",
      b: "V01",
      at: [
        557.7,
        1098.4
      ],
      resolution: "over",
      kind: "crossing",
      structure: "bightBridge.s2Flyover",
      source: "design lead v2.0",
      note: "D-A1: 5.6 over the road deck at the arch crown (road clear 5 + 0.6)"
    },
    {
      a: "jetty.bightPier",
      b: "FERRY",
      at: [
        560,
        890
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      source: "integrator 3 (P15, R2-116)",
      note: "boarding threshold at the pier head (the ferry's second pass); mover pending"
    },
    {
      a: "S1",
      b: "water.river.mountain",
      at: [
        1270.5,
        836.5
      ],
      resolution: "over",
      structure: "s1InflowBridge",
      kind: "crossing",
      note: "v2.6: S1 over the mountain brook below the Foot (D-M3, D-M5)"
    },
    {
      a: "walk lakerim",
      b: "water.river.mountain",
      at: [
        1250.9,
        834.2
      ],
      resolution: "over",
      structure: "inflowFootbridge",
      kind: "crossing",
      note: "v2.6: the lake-rim trail over the mountain brook at its mouth"
    },
    {
      a: "walk footQuay",
      b: "G1",
      at: [
        1282,
        810
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      note: "v2.6 (D-M6): boarding threshold at Mountain v2's Waterfront station (threshold.gondolaBase on its platform; the region draws the terminal)"
    },
    {
      a: "walk summitStation",
      b: "G1",
      at: [
        1300,
        480
      ],
      resolution: "threshold",
      kind: "modeTransfer",
      note: "v2.6 (D-M6): boarding threshold at Mountain v2's Summit Commons station (threshold.gondolaTop on its platform; the region draws the terminal)"
    }
  ],
  thresholds: [
    {
      id: "stairTop",
      xy: [
        1480,
        1150
      ],
      modes: [
        "board\u2192feet"
      ],
      action: "park"
    },
    {
      id: "quayWest",
      xy: [
        1453,
        1277
      ],
      modes: [
        "board\u2192feet"
      ],
      action: "park (Lantern Row is pedestrian)"
    },
    {
      id: "upperStreetSpur",
      xy: [
        1480,
        1060
      ],
      modes: [
        "wheels\u2192feet"
      ],
      action: "park"
    },
    {
      id: "gondolaBase",
      xy: [
        1279.71,
        810.73
      ],
      modes: [
        "feet\u2192cable"
      ],
      action: "Ride the gondola \u2191 Summit Commons",
      v2_5_xy: [
        1480,
        1090
      ],
      action_v2_5: "board by offer"
    },
    {
      id: "adit",
      xy: [
        1090,
        540
      ],
      modes: [
        "feet\u2192cart"
      ],
      action: "sit, lever"
    },
    {
      id: "prowPlatform",
      xy: [
        1610,
        640
      ],
      modes: [
        "feet\u2192zip",
        "feet\u2192glider"
      ],
      action: "clip in / run off"
    },
    {
      id: "crownLaunch",
      xy: [
        1322,
        472
      ],
      modes: [
        "feet\u2192glider"
      ],
      action: "run off",
      v2_5_xy: [
        1305,
        482
      ],
      note_v2_6: "v2.6 (integrator, D-M6): moved 17 m east and 10 m north, clear of Mountain v2's Summit Commons gondola terminal [1300,480] and its rope (which arrives from tower 3 at [1370,550]); the deck keeps h 170 over the summit terrace, east of the observatory [1306,466]"
    },
    {
      id: "strip",
      xy: [
        435,
        690
      ],
      modes: [
        "feet\u2192plane"
      ],
      action: "climb in"
    },
    {
      id: "floatDock",
      xy: [
        1520,
        1275
      ],
      modes: [
        "feet\u2192plane"
      ],
      action: "climb in"
    },
    {
      id: "balloon",
      xy: [
        520,
        470
      ],
      modes: [
        "feet\u2192balloon"
      ],
      action: "step in"
    },
    {
      id: "boathouseDock",
      xy: [
        1320,
        1320
      ],
      modes: [
        "feet\u2192boat"
      ],
      action: "untie"
    },
    {
      id: "ferryPiers",
      xy: "see water_routes.FERRY.piers",
      modes: [
        "feet\u2192ferry"
      ],
      action: "walk the gangway (the offer appears by proximity)"
    },
    {
      id: "skateLineStarts",
      xy: [
        [
          1325,
          470.5
        ],
        [
          480,
          480
        ],
        [
          1480,
          1060
        ],
        [
          1e3,
          520
        ]
      ],
      modes: [
        "feet\u2192board"
      ],
      action: "pick up",
      v2_5_xy: [
        [
          1310,
          500
        ],
        [
          480,
          480
        ],
        [
          1480,
          1060
        ],
        [
          1e3,
          520
        ]
      ]
    },
    {
      id: "landingQuay",
      xy: [
        1270,
        1330
      ],
      modes: [
        "board\u2192feet"
      ],
      action: "park (race run-out)"
    },
    {
      id: "gondolaTop",
      xy: [
        1298.3,
        481.7
      ],
      modes: [
        "cable\u2192feet",
        "feet\u2192cable"
      ],
      action: "step off onto the platform \xB7 board by offer to ride down",
      v1_9_xy: [
        1360,
        560
      ],
      v2_5_xy: [
        1335,
        535
      ],
      v2_5_modes: [
        "cable\u2192feet"
      ],
      action_v2_6: "board by offer (ride down) / step off"
    },
    {
      id: "southPortal",
      xy: [
        1345,
        680
      ],
      modes: [
        "cart\u2192feet"
      ],
      action: "climb out"
    },
    {
      id: "zipLanding",
      xy: [
        1130,
        1440
      ],
      modes: [
        "zip\u2192feet"
      ],
      action: "unclip on the landing tower; stair or ramp to the sand"
    },
    {
      id: "lampGallery",
      xy: [
        540,
        1195
      ],
      modes: [
        "feet\u2192glider"
      ],
      action: "run off the gallery"
    },
    {
      id: "deepJetty",
      xy: [
        1300,
        440
      ],
      modes: [
        "glider\u2192feet",
        "boat\u2192feet"
      ],
      action: "flare onto the water, swim to the jetty (fade)"
    },
    {
      id: "seaDoorJetty",
      xy: [
        1705,
        775
      ],
      modes: [
        "boat\u2192feet",
        "ferry\u2192feet"
      ],
      action: "tie up / gangway"
    },
    {
      id: "bightShoreJetty",
      xy: [
        735,
        955
      ],
      modes: [
        "boat\u2192feet"
      ],
      action: "tie up"
    },
    {
      id: "lampDock",
      xy: [
        540,
        1250
      ],
      modes: [
        "boat\u2192feet"
      ],
      action: "tie up"
    },
    {
      id: "stepsFoot",
      xy: [
        1420,
        505
      ],
      modes: [
        "boat\u2192feet"
      ],
      action: "tie up at the foot of the Steps; portage stair to the Deep"
    },
    {
      id: "funicular.town.to.hearth",
      xy: [
        1291.1,
        728.1
      ],
      h: 55.65,
      modes: [
        "feet\u2192funicular"
      ],
      action: "Ride the funicular \u2191 Lower neighbourhood",
      source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
    },
    {
      id: "funicular.hearth.to.library",
      xy: [
        1314.41,
        677.19
      ],
      h: 69.6,
      modes: [
        "feet\u2192funicular"
      ],
      action: "Ride the funicular \u2191 Library Woods",
      source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
    },
    {
      id: "funicular.hearth.to.town",
      xy: [
        1314.41,
        677.19
      ],
      h: 69.6,
      modes: [
        "feet\u2192funicular"
      ],
      action: "Ride the funicular \u2193 The square",
      source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
    },
    {
      id: "funicular.library.to.reservoir",
      xy: [
        1325.44,
        607.53
      ],
      h: 93.6,
      modes: [
        "feet\u2192funicular"
      ],
      action: "Ride the funicular \u2191 Reservoir Heights",
      source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
    },
    {
      id: "funicular.library.to.hearth",
      xy: [
        1325.44,
        607.53
      ],
      h: 93.6,
      modes: [
        "feet\u2192funicular"
      ],
      action: "Ride the funicular \u2193 Lower neighbourhood",
      source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
    },
    {
      id: "funicular.reservoir.to.library",
      xy: [
        1344.86,
        536.53
      ],
      h: 141.6,
      modes: [
        "feet\u2192funicular"
      ],
      action: "Ride the funicular \u2193 Library Woods",
      source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
    }
  ],
  journeys: {
    note: "Straight-segment lengths between control points at assumed speeds; calibration estimates, not measured journeys. at_active_scale uses the confirmed scale.factor (1.0); the two at_factor tables are comparison scenarios.",
    "square\u2192library by bicycle": {
      length_m: 1455,
      mode: "bicycle"
    },
    "square\u2192summit by gondola + walk": {
      legs: [
        {
          length_m: 830,
          mode: "walk"
        },
        {
          length_m: 474,
          mode: "gondola"
        },
        {
          length_m: 14,
          mode: "walk"
        }
      ],
      note: "v2.6 (D-M6): the gondola is Mountain v2's (Waterfront quay on the Foot terrace -> Summit Commons); the first walk is the square -> the Prow drive -> V03 -> the Foot -> the quay (plan estimate; the Little Harbour -> v2 quay lower leg is D-M6b, not built); the last walk is the summit station -> L02 (v2's observatory). v2.0: time = sum of legs; v2.0 (D-A3): the gondola runs to the shoulder station [1335,535] and the last walk is the station \u2192 L02 leg",
      v1_9_legs: [
        {
          length_m: 158,
          mode: "walk"
        },
        {
          length_m: 543,
          mode: "gondola"
        },
        {
          length_m: 78,
          mode: "walk"
        }
      ],
      v2_5_legs: [
        {
          length_m: 158,
          mode: "walk"
        },
        {
          length_m: 574,
          mode: "gondola"
        },
        {
          length_m: 70,
          mode: "walk"
        }
      ]
    },
    "crown\u2192quay on the board (S1)": {
      length_m: 1712,
      mode: "board",
      v2_5_length_m: 971,
      note_v2_6: "D-M5: Mountain v2 course (summit start to its quay finish, 1059 m) then the Horizon stretch to the Landing"
    },
    "crown\u2192lamp by glider": {
      length_m: 1103,
      mode: "glider"
    },
    "ring by plane": {
      length_m: 3896,
      mode: "plane"
    },
    "ring by bicycle": {
      length_m: 3896,
      mode: "bicycle"
    },
    "square\u2192green on foot": {
      length_m: 562,
      mode: "walk"
    },
    "square\u2192boathouse on foot": {
      length_m: 274,
      mode: "walk"
    },
    "adit\u2192south portal by cart": {
      length_m: 540,
      mode: "cart"
    },
    "prow\u2192sands by zip": {
      length_m: 933,
      mode: "zip"
    },
    at_factor_1_0: {
      "square\u2192library by bicycle": {
        engine_u: 1455,
        time_s: 182
      },
      "square\u2192summit by gondola + walk": {
        engine_u: 802,
        time_s: 177
      },
      "crown\u2192quay on the board (S1)": {
        engine_u: 971,
        time_s: 97
      },
      "crown\u2192lamp by glider": {
        engine_u: 1103,
        time_s: 100
      },
      "ring by plane": {
        engine_u: 3896,
        time_s: 87
      },
      "ring by bicycle": {
        engine_u: 3896,
        time_s: 487
      },
      "square\u2192green on foot": {
        engine_u: 562,
        time_s: 234,
        run_s: 112
      },
      "square\u2192boathouse on foot": {
        engine_u: 274,
        time_s: 114,
        run_s: 55
      },
      "adit\u2192south portal by cart": {
        engine_u: 540,
        time_s: 68
      },
      "prow\u2192sands by zip": {
        engine_u: 933,
        time_s: 78
      }
    },
    at_factor_0_6: {
      "square\u2192library by bicycle": {
        engine_u: 873,
        time_s: 109
      },
      "square\u2192summit by gondola + walk": {
        engine_u: 481,
        time_s: 106
      },
      "crown\u2192quay on the board (S1)": {
        engine_u: 583,
        time_s: 58
      },
      "crown\u2192lamp by glider": {
        engine_u: 662,
        time_s: 60
      },
      "ring by plane": {
        engine_u: 2338,
        time_s: 52
      },
      "ring by bicycle": {
        engine_u: 2338,
        time_s: 292
      },
      "square\u2192green on foot": {
        engine_u: 337,
        time_s: 140,
        run_s: 67
      },
      "square\u2192boathouse on foot": {
        engine_u: 164,
        time_s: 68,
        run_s: 33
      },
      "adit\u2192south portal by cart": {
        engine_u: 324,
        time_s: 40
      },
      "prow\u2192sands by zip": {
        engine_u: 560,
        time_s: 47
      }
    },
    targets_s: {
      "square\u2192library by bicycle": 243,
      "square\u2192green running": 125,
      "square\u2192summit by gondola + walk": 465,
      "crown\u2192quay on the board (S1)": [
        150,
        200
      ],
      "crown\u2192lamp by glider": [
        85,
        120
      ],
      "ring by plane": [
        60,
        120
      ],
      "square\u2192home/bank on foot, walking": 60,
      "square\u2192boathouse on foot, walking": 180,
      note: "v1.7 targets at scale 1.0: each is achievable with \u2265 10 % margin on the Stage A path graph (README v1.7 table); the summit target is 205 s (D-A3, Jonathan 2026-09-27: option 2 gives \u2248 185 s; 205 keeps the \u2265 10 % margin; it was 375 while reserved)",
      decisions: {
        "crown\u2192lamp by glider": "D34 applied pending Jonathan's confirmation: FLIGHT retargeted from [50,90] to [70,110] (~98 s at 11 m/s trim in still air, FLIGHT.md \xA712) on the v1.6 launch. v2.2: the Stage A v1.7 target [85,120] (measured on the Stage A graph from the v2.1 lookout launch [1305,482] h 170: 96.0 s on candidate 5) contains the same flight and stands; D34's [70,110] is kept in v2_2_d34",
        v2_2_d34: [
          70,
          110
        ],
        "square\u2192library by bicycle": "v2.3 (design lead, Stage A Wave 7 (W7-A) 2026-09-27, reversible): planned at the bicycle's 6.0 m/s cap, the ride measures 220.6 s (1,324 eu, Stage A W7-A scratch bake); target = measured + 10 % = 243 s (v2.2: 185 s at 8 m/s)",
        "v2_2_square\u2192library by bicycle": 185
      },
      "v2_5_crown\u2192quay on the board (S1)": [
        110,
        150
      ],
      "v2_5_square\u2192summit by gondola + walk": 205,
      note_v2_6: "v2.6: S1 is Mountain v2 course + the Horizon stretch (1721 m, measured 172 s on the v2.6 bake: target [150,200]); the summit journey walks the square -> the Prow drive -> V03 -> the Foot -> v2 quay (measured 420.6 s: 1321 m; target 465 keeps the 10 % margin) until the Little Harbour lower leg (D-M6b) exists"
    },
    at_active_scale: {
      "square\u2192library by bicycle": {
        engine_u: 1455,
        time_s: 182
      },
      "square\u2192summit by gondola + walk": {
        engine_u: 802,
        time_s: 177
      },
      "crown\u2192quay on the board (S1)": {
        engine_u: 971,
        time_s: 97
      },
      "crown\u2192lamp by glider": {
        engine_u: 1103,
        time_s: 100
      },
      "ring by plane": {
        engine_u: 3896,
        time_s: 87
      },
      "ring by bicycle": {
        engine_u: 3896,
        time_s: 487
      },
      "square\u2192green on foot": {
        engine_u: 562,
        time_s: 234,
        run_s: 112
      },
      "square\u2192boathouse on foot": {
        engine_u: 274,
        time_s: 114,
        run_s: 55
      },
      "adit\u2192south portal by cart": {
        engine_u: 540,
        time_s: 68
      },
      "prow\u2192sands by zip": {
        engine_u: 933,
        time_s: 78
      }
    },
    anchors: {
      "square\u2192green running": [
        1053.9,
        1043.4
      ],
      note: "the Green's edge on Green Road (the centre has no bed within the snap distance); measurements snap to this point"
    },
    targets_v1_6: {
      "square\u2192library by bicycle": 150,
      "square\u2192green running": 100,
      "square\u2192summit by gondola + walk": 120,
      "crown\u2192quay on the board (S1)": [
        70,
        130
      ],
      "crown\u2192lamp by glider": [
        50,
        90
      ],
      "ring by plane": [
        60,
        120
      ],
      "square\u2192home/bank on foot, walking": 60,
      "square\u2192boathouse on foot, walking": 100
    },
    targets_v1_9: {
      "square\u2192summit by gondola + walk": 375
    }
  },
  speeds_ms: {
    walk: 2.4,
    run: 5,
    board: 10,
    bicycle: 6,
    gondola: 7,
    cart: 8,
    zip: 12,
    glider: 11,
    plane: 45,
    ferry: 5,
    row: 1.8,
    v2_2_bicycle: 8
  },
  pastimeData: {
    nineBaskets: [
      [
        1189,
        1151
      ],
      [
        1118,
        1218
      ],
      [
        1022,
        1236
      ],
      [
        932,
        1199
      ],
      [
        876,
        1118
      ],
      [
        874,
        1020
      ],
      [
        913,
        924
      ],
      [
        1022,
        894
      ],
      [
        893,
        600
      ]
    ],
    nineBasketsNote: "baskets 1\u20138 ring the protected centre at 172\u2013190 m; the ninth is on the Hollow Bridge",
    mailDayTargets: "the seven hosts' roofs (MANIFEST.hosts)",
    riverRunGates: [
      [
        1140,
        760
      ],
      [
        1100,
        850
      ],
      [
        1200,
        880
      ],
      [
        1150,
        935
      ],
      [
        1170,
        980
      ],
      [
        1220,
        1060
      ],
      [
        1250,
        1140
      ],
      [
        1290,
        1225
      ],
      [
        1350,
        1320
      ]
    ],
    bocce: {
      xy: [
        1455,
        1150
      ],
      note: "the square's small green; single device vs. the ghost until a presence change is trust-reviewed"
    },
    lanternQuotas: {
      harbour: 6,
      landing: 6,
      reach: 3,
      green: 5,
      hollow: 5,
      scholars: 5,
      flats: 6,
      bight: 4,
      lakeside: 5,
      notch: 3,
      prow: 4,
      crown: 4,
      undercroft: 4,
      offshore: 4,
      total: 64,
      rule: "64 placed, 60 required to fill the Lantern Cave; never inside a reserve; \u2265 8 reachable only by air, \u2265 6 only by water, \u2265 4 only underground"
    },
    skating: {
      where: "stillwater",
      months: [
        1,
        2
      ]
    },
    sledding: {
      where: "Mountain v2 meadow terraces (the meadow sweep); no Horizon bed: T2/T3 place it",
      months: [
        1,
        2
      ],
      note: "v2.6 (D-M5): the Shoulder meadow sledding bed is retired",
      v2_5: {
        where: "the Shoulder's south-east meadow [1400,760]",
        months: [
          1,
          2
        ],
        note: "inside the Jan\u2013Feb snowline; 90 m east of S1"
      }
    }
  },
  journey: {
    principle: "one household state and history \u2192 one WorldOverlay (derived on read, never stored) \u2192 the Journey renderer (L0\u2013L1) and the world renderer (L2\u2013L3) and the Desk; see SCALES.md",
    stations: [
      {
        month: 1,
        id: "jan",
        label: "Hearth Terrace (the mountain)",
        xy: [
          1364,
          650
        ],
        why: "snow on the mountain, the summit walk (v2 road) and the sledding meadows",
        v2_5_xy: [
          1330,
          640
        ],
        v2_5_label: "the Shoulder",
        moveWhy_v2_6: "D-M1/D-M5: the Shoulder is Mountain v2; the station stands on v2 Hearth terrace (level 73.2, an open shelf: D-M9) beside v2 road, 229 m up from the road foot; its pad is carried (a deck): the region draws the terrace"
      },
      {
        month: 2,
        id: "feb",
        label: "Lakeside",
        xy: [
          1100,
          721
        ],
        why: "ice on Stillwater, the skipping shelf",
        movedFrom: [
          1255,
          860
        ],
        moveWhy: "the old pad sat on S1 (0.7 m) and walk lakerim; now on the north-shore lake rim at the rim trail's own height (the skipping shelf)"
      },
      {
        month: 3,
        id: "mar",
        label: "Scholars\u2019 floor",
        xy: [
          700,
          470
        ],
        why: "the woodland floor thaws first; bloodroot"
      },
      {
        month: 4,
        id: "apr",
        label: "the Green (west)",
        xy: [
          932,
          995
        ],
        why: "first grass; dandelions; kites nearby",
        movedFrom: [
          860,
          980
        ],
        moveWhy: "the old pad sat across the Bight Shore spur (VBS 7 m) and S4; moved 72 m east onto open Green (west)"
      },
      {
        month: 5,
        id: "may",
        label: "the Hollow (west rows)",
        xy: [
          960,
          640
        ],
        why: "apple blossom"
      },
      {
        month: 6,
        id: "jun",
        label: "Long Sands",
        xy: [
          950,
          1445
        ],
        why: "lupines; the Campfire is here"
      },
      {
        month: 7,
        id: "jul",
        label: "the Flats",
        xy: [
          401,
          745
        ],
        why: "coneflower, thermals, the strip",
        movedFrom: [
          380,
          800
        ],
        moveWhy: "the old pad sat on Horizon Drive (V01 1.0 m); moved 59 m to the gap between V01 and the strip"
      },
      {
        month: 8,
        id: "aug",
        label: "the Reach",
        xy: [
          1203,
          1292
        ],
        why: "monarchs, Joe-Pye, the boardwalk",
        movedFrom: [
          1230,
          1290
        ],
        moveWhy: "the old pad reached into the Reach west channel (3.1 m); moved 27 m west onto dry Reach meadow"
      },
      {
        month: 9,
        id: "sep",
        label: "the Hollow (east rows)",
        xy: [
          1032,
          652
        ],
        why: "apples",
        v1_8_xy: [
          1040,
          650
        ],
        moveWhy_v1_9: "8 m west so February passes east of the pad on the 45 shelf (the pad's level pins held February at 35 there); the pad sits at 40, a 5 m terrace cut into the shelf's edge"
      },
      {
        month: 10,
        id: "oct",
        label: "the north pass",
        xy: [
          790,
          322
        ],
        why: "maples red",
        movedFrom: [
          800,
          300
        ],
        moveWhy: "the old pad sat on Horizon Drive (V01 5.7 m); moved 24 m south into the north pass"
      },
      {
        month: 11,
        id: "nov",
        label: "the Prow",
        xy: [
          1626,
          904
        ],
        why: "the first storms, the Lamp\u2019s beam",
        movedFrom: [
          1570,
          940
        ],
        moveWhy: "the old pad sat on the Prow cliff drive (V01 0.8 m) in its 34 m cutting; moved onto the Prow top beside the Prow walk",
        v1_9_xy: [
          1622,
          912
        ],
        pad_rot_deg: 90,
        moveWhy_v2_0: "D-A8 (Jonathan 2026-09-27): off the Prow cliff overhang; turned 90\xB0 along the Prow top, ground 54.0-56.7 under the pad (it fell to 26.3 under the v1.9 pad)"
      },
      {
        month: 12,
        id: "dec",
        label: "Little Harbour",
        xy: [
          1488,
          1228
        ],
        why: "Lantern Row, the Chapter at home",
        movedFrom: [
          1475,
          1230
        ],
        moveWhy: "the old pad overlapped Town Weave (S3); moved 13 m east onto the storefront lane"
      }
    ],
    yearWalk: {
      profile: "walk",
      note: "a trail through the twelve stations in calendar order, entirely on land: it never goes below sea level or into Stillwater, the Bight, a river or a channel except across a named bridge, never through a reserve plot, and never stacked on another bed at a different height; where it shares a corridor it shares the host bed's alignment and height (shares); the walk ahead of the current month is dressed as stakes and string",
      pts: [
        [
          1364,
          650
        ],
        [
          1359.58,
          666.44
        ],
        [
          1353.32,
          666.26
        ],
        [
          1347.38,
          665.58
        ],
        [
          1341.56,
          665.37
        ],
        [
          1335.92,
          665.38
        ],
        [
          1331.81,
          667.12
        ],
        [
          1329.46,
          670.59
        ],
        [
          1331.2,
          674.04
        ],
        [
          1335.18,
          677.11
        ],
        [
          1340.36,
          678.72
        ],
        [
          1345.92,
          679.54
        ],
        [
          1351.74,
          679.61
        ],
        [
          1357.67,
          679.58
        ],
        [
          1363.64,
          679.19
        ],
        [
          1370.24,
          679.58
        ],
        [
          1376.54,
          682.24
        ],
        [
          1380.86,
          688.63
        ],
        [
          1379.2,
          696.02
        ],
        [
          1373.51,
          700.48
        ],
        [
          1367.47,
          702.67
        ],
        [
          1361.16,
          703.77
        ],
        [
          1354.77,
          703.83
        ],
        [
          1348.48,
          702.85
        ],
        [
          1342.38,
          700.94
        ],
        [
          1336.81,
          697.94
        ],
        [
          1331.77,
          695.07
        ],
        [
          1326.43,
          692.74
        ],
        [
          1320.9,
          690.65
        ],
        [
          1315.38,
          688.71
        ],
        [
          1310.05,
          687.75
        ],
        [
          1304.51,
          688.03
        ],
        [
          1299.02,
          689.19
        ],
        [
          1293.87,
          691.25
        ],
        [
          1289.3,
          694.23
        ],
        [
          1285.75,
          698.15
        ],
        [
          1283.46,
          702.92
        ],
        [
          1282.74,
          708.09
        ],
        [
          1283.44,
          713.7
        ],
        [
          1284.37,
          719.65
        ],
        [
          1276,
          728
        ],
        [
          1262,
          742
        ],
        [
          1248,
          750
        ],
        [
          1235,
          755
        ],
        [
          1219.3,
          745.4
        ],
        [
          1189,
          733.8
        ],
        [
          1155.8,
          724.5
        ],
        [
          1145,
          720
        ],
        [
          1100,
          720
        ],
        [
          1080,
          725
        ],
        [
          1055,
          710
        ],
        [
          1052,
          662
        ],
        [
          1060,
          600
        ],
        [
          1062,
          540
        ],
        [
          1060,
          505
        ],
        [
          1050,
          487
        ],
        [
          1e3,
          480
        ],
        [
          960,
          470
        ],
        [
          930,
          480
        ],
        [
          895,
          480
        ],
        [
          905,
          470
        ],
        [
          885,
          465
        ],
        [
          872,
          461.7
        ],
        [
          857,
          441.3
        ],
        [
          789.3,
          436.5
        ],
        [
          769.2,
          446.5
        ],
        [
          715,
          446.5
        ],
        [
          700,
          470
        ],
        [
          715,
          450
        ],
        [
          770,
          450
        ],
        [
          790,
          440
        ],
        [
          855,
          445
        ],
        [
          870,
          465
        ],
        [
          905,
          470
        ],
        [
          895,
          475
        ],
        [
          905,
          475
        ],
        [
          895,
          480
        ],
        [
          915,
          480
        ],
        [
          900,
          500
        ],
        [
          905,
          545
        ],
        [
          910,
          565
        ],
        [
          935,
          585
        ],
        [
          905,
          610
        ],
        [
          900,
          640
        ],
        [
          900,
          628
        ],
        [
          899,
          660
        ],
        [
          898,
          700
        ],
        [
          895,
          740
        ],
        [
          892,
          780
        ],
        [
          887,
          815
        ],
        [
          890,
          870
        ],
        [
          920,
          900
        ],
        [
          915,
          910
        ],
        [
          930,
          995
        ],
        [
          990,
          1010
        ],
        [
          997,
          1006.7
        ],
        [
          977.4,
          967.2
        ],
        [
          966.1,
          929.6
        ],
        [
          957.3,
          889.1
        ],
        [
          953.3,
          848.9
        ],
        [
          956.7,
          808.9
        ],
        [
          962.3,
          768.6
        ],
        [
          969.2,
          725.7
        ],
        [
          975.4,
          689.6
        ],
        [
          986.5,
          649.9
        ],
        [
          994.1,
          612.3
        ],
        [
          970,
          625
        ],
        [
          960,
          640
        ],
        [
          930,
          605
        ],
        [
          910,
          605
        ],
        [
          903,
          628
        ],
        [
          902,
          660
        ],
        [
          901,
          700
        ],
        [
          898,
          740
        ],
        [
          895,
          780
        ],
        [
          890,
          815
        ],
        [
          870,
          835
        ],
        [
          870,
          870
        ],
        [
          885,
          905
        ],
        [
          865,
          920
        ],
        [
          845,
          965
        ],
        [
          865,
          985
        ],
        [
          885,
          1065
        ],
        [
          885,
          1120
        ],
        [
          900,
          1180
        ],
        [
          920,
          1220
        ],
        [
          960,
          1355
        ],
        [
          970,
          1365
        ],
        [
          945,
          1385
        ],
        [
          950,
          1445
        ],
        [
          925,
          1440
        ],
        [
          870,
          1385
        ],
        [
          790,
          1325
        ],
        [
          735,
          1270
        ],
        [
          765,
          1235
        ],
        [
          710,
          1190
        ],
        [
          701.9,
          1195.9
        ],
        [
          679.4,
          1178.1
        ],
        [
          645.9,
          1154.1
        ],
        [
          613.3,
          1133.2
        ],
        [
          579.3,
          1111.5
        ],
        [
          546.3,
          1090
        ],
        [
          512.6,
          1067
        ],
        [
          482.5,
          1044.2
        ],
        [
          454.9,
          1014
        ],
        [
          437.3,
          979.5
        ],
        [
          423.4,
          943.6
        ],
        [
          410.5,
          904
        ],
        [
          425,
          890
        ],
        [
          400,
          745
        ],
        [
          425,
          770
        ],
        [
          440,
          860
        ],
        [
          440,
          870
        ],
        [
          412.6,
          903.3
        ],
        [
          425.5,
          942.8
        ],
        [
          439.3,
          978.6
        ],
        [
          456.7,
          1012.8
        ],
        [
          483.9,
          1042.5
        ],
        [
          513.9,
          1065.2
        ],
        [
          547.5,
          1088.2
        ],
        [
          580.5,
          1109.6
        ],
        [
          614.5,
          1131.3
        ],
        [
          647.1,
          1152.2
        ],
        [
          680.8,
          1176.4
        ],
        [
          703.3,
          1194.2
        ],
        [
          730,
          1180
        ],
        [
          930,
          1265
        ],
        [
          950,
          1265
        ],
        [
          970,
          1245
        ],
        [
          1120,
          1270
        ],
        [
          1160,
          1300
        ],
        [
          1205,
          1290
        ],
        [
          1160,
          1245
        ],
        [
          1120,
          1250
        ],
        [
          1100,
          1245
        ],
        [
          975,
          1155
        ],
        [
          960,
          1130
        ],
        [
          955,
          1095
        ],
        [
          990,
          1010
        ],
        [
          994.6,
          1008.6
        ],
        [
          974.6,
          968.2
        ],
        [
          963.2,
          930.4
        ],
        [
          954.3,
          889.7
        ],
        [
          950.3,
          848.9
        ],
        [
          953.7,
          808.6
        ],
        [
          959.3,
          768.2
        ],
        [
          966.2,
          725.2
        ],
        [
          972.5,
          688.9
        ],
        [
          983.6,
          649
        ],
        [
          991.1,
          612
        ],
        [
          1010,
          615
        ],
        [
          1032,
          652
        ],
        [
          1025,
          626
        ],
        [
          1010,
          604
        ],
        [
          991.3,
          592.5
        ],
        [
          974.3,
          552.6
        ],
        [
          956.4,
          515.5
        ],
        [
          938.9,
          476.8
        ],
        [
          929.5,
          433.8
        ],
        [
          927.1,
          388
        ],
        [
          915,
          370
        ],
        [
          820,
          345
        ],
        [
          790,
          320
        ],
        [
          810,
          305
        ],
        [
          810,
          280
        ],
        [
          815,
          275
        ],
        [
          895,
          275
        ],
        [
          899.2,
          283.6
        ],
        [
          940,
          276.6
        ],
        [
          980,
          268.6
        ],
        [
          1017.4,
          261
        ],
        [
          1056.8,
          253.2
        ],
        [
          1096.5,
          246.3
        ],
        [
          1136.3,
          242.6
        ],
        [
          1178.5,
          242.2
        ],
        [
          1216.7,
          243.5
        ],
        [
          1259.2,
          246.9
        ],
        [
          1297.7,
          252.8
        ],
        [
          1320.2,
          260.7
        ],
        [
          1338.9,
          296.4
        ],
        [
          1382.5,
          312.2
        ],
        [
          1413.8,
          330.5
        ],
        [
          1439.8,
          360
        ],
        [
          1467.2,
          393.5
        ],
        [
          1494.8,
          422.8
        ],
        [
          1521.4,
          455.9
        ],
        [
          1546.9,
          487.5
        ],
        [
          1553.8,
          519.4
        ],
        [
          1561,
          556.4
        ],
        [
          1567.4,
          598.5
        ],
        [
          1572.5,
          635.5
        ],
        [
          1577.9,
          678.4
        ],
        [
          1581,
          705
        ],
        [
          1570,
          665
        ],
        [
          1575,
          670
        ],
        [
          1600,
          665
        ],
        [
          1615,
          725
        ],
        [
          1630,
          745
        ],
        [
          1630,
          855
        ],
        [
          1626,
          904
        ],
        [
          1645,
          875
        ],
        [
          1650,
          855
        ],
        [
          1650,
          745
        ],
        [
          1645,
          725
        ],
        [
          1615,
          685
        ],
        [
          1596.9,
          703.2
        ],
        [
          1601.8,
          746.3
        ],
        [
          1606,
          790.3
        ],
        [
          1608,
          832
        ],
        [
          1602.7,
          877.6
        ],
        [
          1588.6,
          919
        ],
        [
          1572.7,
          957.4
        ],
        [
          1553.6,
          996.8
        ],
        [
          1523,
          1027.7
        ],
        [
          1498.6,
          1039.6
        ],
        [
          1510,
          1050
        ],
        [
          1510,
          1100
        ],
        [
          1525,
          1175
        ],
        [
          1500,
          1200
        ],
        [
          1490,
          1230
        ],
        [
          1500,
          1200
        ],
        [
          1545,
          1160
        ],
        [
          1535,
          1120
        ],
        [
          1540,
          1085
        ],
        [
          1530,
          1055
        ],
        [
          1505,
          1015
        ],
        [
          1495,
          1015
        ],
        [
          1490,
          1020
        ],
        [
          1493.6,
          1027.6
        ],
        [
          1528.6,
          1007.9
        ],
        [
          1549.8,
          975.8
        ],
        [
          1567.7,
          936.2
        ],
        [
          1582.4,
          898.3
        ],
        [
          1593.6,
          859
        ],
        [
          1593.5,
          820
        ],
        [
          1593.1,
          803
        ],
        [
          1574.97,
          797.5
        ],
        [
          1539.91,
          797
        ],
        [
          1504.95,
          796.5
        ],
        [
          1477.95,
          796.5
        ],
        [
          1441.41,
          796
        ],
        [
          1404.69,
          795.49
        ],
        [
          1387.28,
          793.27
        ],
        [
          1362.44,
          783.97
        ],
        [
          1337.28,
          771.91
        ],
        [
          1312.36,
          760.94
        ],
        [
          1292.65,
          752.06
        ],
        [
          1279.65,
          748.23
        ],
        [
          1285.5,
          736
        ],
        [
          1279.4,
          727.5
        ],
        [
          1278.7,
          714.46
        ],
        [
          1277.94,
          708.17
        ],
        [
          1278.88,
          701.5
        ],
        [
          1281.75,
          695.49
        ],
        [
          1286.22,
          690.55
        ],
        [
          1291.67,
          686.99
        ],
        [
          1297.64,
          684.59
        ],
        [
          1303.87,
          683.27
        ],
        [
          1310.31,
          682.95
        ],
        [
          1316.74,
          684.11
        ],
        [
          1322.54,
          686.15
        ],
        [
          1328.23,
          688.3
        ],
        [
          1333.89,
          690.77
        ],
        [
          1339.27,
          693.82
        ],
        [
          1344.24,
          696.52
        ],
        [
          1349.58,
          698.17
        ],
        [
          1355.13,
          699.05
        ],
        [
          1360.72,
          698.99
        ],
        [
          1366.21,
          698.03
        ],
        [
          1371.45,
          696.14
        ],
        [
          1375.16,
          693.42
        ],
        [
          1376.1,
          689.27
        ],
        [
          1373.88,
          686.24
        ],
        [
          1369.16,
          684.26
        ],
        [
          1363.84,
          683.99
        ],
        [
          1357.83,
          684.38
        ],
        [
          1351.76,
          684.41
        ],
        [
          1345.6,
          684.32
        ],
        [
          1339.3,
          683.4
        ],
        [
          1333.06,
          681.41
        ],
        [
          1327.6,
          677.22
        ],
        [
          1324.68,
          670.05
        ],
        [
          1328.61,
          663.54
        ],
        [
          1335.3,
          660.62
        ],
        [
          1341.64,
          660.57
        ],
        [
          1347.8,
          660.8
        ],
        [
          1353.78,
          661.48
        ],
        [
          1359.5,
          661.64
        ],
        [
          1364,
          650
        ]
      ],
      ptsRule: "centreline control points, solved as the other beds are (Catmull-Rom, 5 m samples) and graded at profiles.walk.grade_max_pct; the builder uses these points verbatim (no inserted controls) and places each station pad at the walk height at its station",
      pins: [
        {
          station: "jan",
          xy: [
            1364,
            650
          ],
          h: 73.2,
          v1_8_h: 117,
          v2_5_xy: [
            1330,
            640
          ],
          v2_5_h: 112.8
        },
        {
          station: "feb",
          xy: [
            1100,
            721
          ],
          h: 53
        },
        {
          station: "mar",
          xy: [
            700,
            470
          ],
          h: 48
        },
        {
          station: "apr",
          xy: [
            932,
            995
          ],
          h: 19.5
        },
        {
          station: "may",
          xy: [
            960,
            640
          ],
          h: 37,
          v1_8_h: 31.5
        },
        {
          station: "jun",
          xy: [
            950,
            1445
          ],
          h: 2
        },
        {
          station: "jul",
          xy: [
            401,
            745
          ],
          h: 36
        },
        {
          station: "aug",
          xy: [
            1203,
            1292
          ],
          h: 4
        },
        {
          station: "sep",
          xy: [
            1040,
            650
          ],
          h: 40,
          v1_8_h: 33
        },
        {
          station: "oct",
          xy: [
            790,
            322
          ],
          h: 45.5
        },
        {
          station: "nov",
          xy: [
            1626,
            904
          ],
          h: 56,
          v1_9_xy: [
            1622,
            912
          ],
          v1_9_h: 56.5
        },
        {
          station: "dec",
          xy: [
            1488,
            1228
          ],
          h: 8
        }
      ],
      shares: [
        {
          stretch: "may",
          host: "VG",
          side: "west",
          offset_m: 6.5,
          from: [
            997,
            1006.7
          ],
          to: [
            994.1,
            612.3
          ],
          note: "Green Road's west footway"
        },
        {
          stretch: "sep",
          host: "VG",
          side: "west",
          offset_m: 9.5,
          from: [
            994.6,
            1008.6
          ],
          to: [
            991.1,
            612
          ],
          note: "the same footway's outer lane"
        },
        {
          stretch: "jul",
          host: "V01",
          via: "structure.bightBridge",
          side: "lagoon (north-east)",
          offset_m: 5.2,
          from: [
            701.9,
            1195.9
          ],
          to: [
            410.5,
            904
          ],
          note: "the Bight Bridge's lagoon-side footway and the Drive's verge down the Flats arm; deck height 12 on the bridge"
        },
        {
          stretch: "aug",
          host: "V01",
          via: "structure.bightBridge",
          side: "lagoon (north-east)",
          offset_m: 7.4,
          from: [
            412.6,
            903.3
          ],
          to: [
            703.3,
            1194.2
          ],
          note: "the same footway's outer lane, walked back east a month later"
        },
        {
          stretch: "nov",
          host: "V01",
          side: "seaward (north)",
          offset_m: 6.5,
          from: [
            899.2,
            283.6
          ],
          to: [
            1320.2,
            260.7
          ],
          note: "the north coast drive's seaward verge",
          v1_8_to: [
            1319.7,
            258.5
          ]
        },
        {
          stretch: "nov",
          host: "V01",
          side: "inland",
          offset_m: 9.5,
          from: [
            1338.9,
            296.4
          ],
          to: [
            1581,
            705
          ],
          note: "crosses the Drive at grade at [1330,270] and takes the inland verge round the north-east corner (the seaward verge there is off the outline) up onto the Prow",
          v1_8_from: [
            1340.4,
            281.3
          ]
        },
        {
          stretch: "dec",
          host: "V01",
          side: "seaward (east)",
          offset_m: 6.5,
          from: [
            1596.9,
            703.2
          ],
          to: [
            1498.6,
            1039.6
          ],
          note: "down the Prow cliff drive's seaward verge to the harbour",
          v1_8_from: [
            1596.9,
            703.2
          ],
          v1_8_to: [
            1500.3,
            1038.1
          ]
        },
        {
          stretch: "apr",
          host: "S4",
          side: "east",
          offset_m: 6,
          from: [
            905,
            610
          ],
          to: [
            899,
            660
          ],
          note: "v1.9: the April lane is S4's east footway through the Hollow neck, at S4's height"
        },
        {
          stretch: "jun",
          host: "S4",
          side: "east",
          offset_m: 8,
          from: [
            903,
            628
          ],
          to: [
            902,
            660
          ],
          note: "v1.9: the June lane, 3 m further out on the same footway"
        },
        {
          stretch: "sep",
          host: "VG",
          side: "west",
          offset_m: 6.5,
          from: [
            991.3,
            592.5
          ],
          to: [
            927.1,
            388
          ],
          note: "v1.9: Green Road's west footway from the September pad's return to the north pass"
        },
        {
          stretch: "feb",
          host: "walk lakerim",
          side: "on the rim trail",
          offset_m: 0,
          from: [
            1235,
            755
          ],
          to: [
            1100,
            721
          ],
          note: "v2.6: the February stretch walks the lake rim trail from the north-east shore by the Foot terrace to the station; the Inlet Footbridge is retired",
          v1_8_from: [
            1250,
            800
          ],
          v2_5_from: [
            1251,
            836
          ]
        },
        {
          stretch: "jan",
          host: "V01",
          side: "inland (west)",
          offset_m: 6.5,
          from: [
            1493.6,
            1027.6
          ],
          to: [
            1593.1,
            803
          ],
          note: "up the Prow cliff drive inland verge to the Mountain Road junction (v2.6: was on to the north-east corner and Crown Road)",
          v1_8_to: [
            1495.4,
            344.6
          ],
          v1_8_from: [
            1494.7,
            1026.4
          ],
          v2_5_to: [
            1456.6,
            378.1
          ]
        },
        {
          stretch: "jan",
          host: "V03",
          side: "south",
          offset_m: 6.5,
          from: [
            1574.97,
            797.5
          ],
          to: [
            1279.65,
            748.23
          ],
          via: "structure.mountainRoadTunnel",
          note: "v2.6: the Mountain Road south footway, through the Mountain Road Tunnel as its footway and over the town channel bridge"
        },
        {
          stretch: "jan",
          host: "mountainV2.road",
          side: "left (uphill)",
          offset_m: 2.4,
          from: [
            1278.7,
            714.46
          ],
          to: [
            1359.5,
            661.64
          ],
          note: "v2.6: up Mountain v2 road on its carriageway, left side, to the Hearth terrace (the region draws the road)"
        },
        {
          stretch: "feb",
          host: "mountainV2.road",
          side: "right (uphill)",
          offset_m: 2.4,
          from: [
            1359.58,
            666.44
          ],
          to: [
            1284.37,
            719.65
          ],
          note: "v2.6: back down v2 road right side to the road foot"
        }
      ],
      sharesRule: "a shared stretch is a footway of its host bed: the same alignment at offset_m from the host centreline, the host's solved height at every point (the builder copies it, it does not re-grade), no separate terrain override, retaining or kerb between host and footway; tunnels and bridges on the host carry the footway inside their own section",
      ownTrails: [
        {
          stretch: "apr",
          name: "the Hollow lane (west lane)",
          from: [
            900,
            628
          ],
          to: [
            887,
            815
          ],
          note: "a new trail on the valley floor between Orchard Brook and S4; the April and June stretches walk two lanes 3 m apart"
        },
        {
          stretch: "jun",
          name: "the Hollow lane (east lane)",
          from: [
            903,
            628
          ],
          to: [
            890,
            815
          ]
        },
        {
          stretch: "feb",
          name: "the Foot lane",
          from: [
            1276,
            728
          ],
          to: [
            1235,
            755
          ],
          note: "v2.6: from the road foot west across the Foot terrace to the lake rim trail"
        }
      ],
      crossings: "v2.6: the walk no longer crosses S1 on the Horizon (it walks v2 road beside the course); every other crossing is at grade on a walk, a spur or a road (thresholds) or on a named bridge (the Mountain Road canal bridge, the Hollow Bridge, the Bight Bridge). v2.5: the walk crosses S1 once, at grade, at [1267,842] (v1.9: flush, where S1 stands at the lake terrace height); every other crossing is at grade on a walk, a spur or a road (thresholds) or on a named bridge (the Inlet Footbridge, the Hollow Bridge, the Bight Bridge)",
      retired_v1_6_pts: [
        [
          1330,
          640
        ],
        [
          1255,
          860
        ],
        [
          1130,
          720
        ],
        [
          990,
          780
        ],
        [
          930,
          660
        ],
        [
          880,
          560
        ],
        [
          740,
          400
        ],
        [
          700,
          470
        ],
        [
          760,
          700
        ],
        [
          860,
          980
        ],
        [
          960,
          640
        ],
        [
          893,
          600
        ],
        [
          950,
          1445
        ],
        [
          740,
          1432
        ],
        [
          560,
          1100
        ],
        [
          470,
          1030
        ],
        [
          380,
          800
        ],
        [
          430,
          900
        ],
        [
          560,
          890
        ],
        [
          840,
          880
        ],
        [
          1240,
          1130
        ],
        [
          1230,
          1290
        ],
        [
          1040,
          650
        ],
        [
          900,
          290
        ],
        [
          800,
          300
        ],
        [
          1300,
          260
        ],
        [
          1500,
          340
        ],
        [
          1590,
          700
        ],
        [
          1570,
          940
        ],
        [
          1480,
          1060
        ],
        [
          1475,
          1230
        ],
        [
          1370,
          690
        ],
        [
          1330,
          640
        ]
      ],
      levels: [],
      levelsRule: "levels are extra height pins on the Year Walk's own (unshared) stretches: the builder pins the nearest walk sample to h, so the grade between two pins can use the walk maximum where the ground demands it",
      s1Crossing: null,
      v1_9_edits: [
        {
          was: [
            [
              885,
              465
            ],
            [
              815,
              470
            ],
            [
              800,
              480
            ],
            [
              755,
              480
            ],
            [
              700,
              470
            ]
          ],
          now: [
            [
              885,
              465
            ],
            [
              872,
              461.7
            ],
            [
              857,
              441.3
            ],
            [
              789.3,
              436.5
            ],
            [
              769.2,
              446.5
            ],
            [
              715,
              446.5
            ],
            [
              700,
              470
            ]
          ],
          why: "the March in-leg is the out-leg's north lane (3.5 m, one height) instead of a second line 3-4 eu over the Garden Walk at [802,468]"
        },
        {
          was: [
            [
              910,
              565
            ],
            [
              925,
              585
            ],
            [
              905,
              610
            ]
          ],
          now: [
            [
              910,
              565
            ],
            [
              935,
              585
            ],
            [
              905,
              610
            ]
          ],
          why: "the April lane swings 10 m further east above the Hollow so its 18 eu band-face descent to the S4 footway fits 12 % (148 \u2192 164 m)"
        },
        {
          was: [
            [
              1330,
              885
            ],
            [
              1320,
              880
            ],
            [
              1315,
              865
            ],
            [
              1320,
              885
            ],
            [
              1305,
              845
            ],
            [
              1305,
              875
            ],
            [
              1300,
              855
            ],
            [
              1300,
              880
            ],
            [
              1295,
              860
            ],
            [
              1295,
              880
            ],
            [
              1290,
              860
            ],
            [
              1290,
              885
            ],
            [
              1285,
              870
            ],
            [
              1285,
              880
            ],
            [
              1245,
              855
            ],
            [
              1250,
              845
            ]
          ],
          now: [
            [
              1330,
              885
            ],
            [
              1325,
              880
            ],
            [
              1325,
              852
            ],
            [
              1321.3,
              848.5
            ],
            [
              1317.6,
              852
            ],
            [
              1317.6,
              880
            ],
            [
              1313.9,
              883.5
            ],
            [
              1310.2,
              880
            ],
            [
              1310.2,
              852
            ],
            [
              1306.5,
              848.5
            ],
            [
              1302.8,
              852
            ],
            [
              1302.8,
              880
            ],
            [
              1299.1,
              883.5
            ],
            [
              1295.4,
              880
            ],
            [
              1295.4,
              852
            ],
            [
              1291.7,
              848.5
            ],
            [
              1288,
              852
            ],
            [
              1288,
              880
            ],
            [
              1284.3,
              883.5
            ],
            [
              1280.6,
              880
            ],
            [
              1280.6,
              852
            ],
            [
              1276,
              846
            ],
            [
              1267,
              842
            ],
            [
              1251,
              836
            ]
          ],
          why: "the Lakeside switchback: seven 28 m legs on a 7.4 m pitch (walk surfaces 2.2 m apart, shoulders meeting as the walls between legs) at <= 12 %, leaving at grade across S1 at [1267,842] to the rim trail"
        },
        {
          was: [
            [
              1319.7,
              258.5
            ],
            [
              1340.4,
              281.3
            ],
            [
              1379.9,
              294.4
            ],
            [
              1415.6,
              307.5
            ],
            [
              1453.6,
              323.6
            ],
            [
              1487.1,
              341.9
            ],
            [
              1508.5,
              367.9
            ],
            [
              1524.1,
              404.6
            ],
            [
              1535.4,
              441.5
            ],
            [
              1545.7,
              481.6
            ],
            [
              1554.7,
              520.2
            ]
          ],
          now: [
            [
              1320.2,
              260.7
            ],
            [
              1338.9,
              296.4
            ],
            [
              1382.5,
              312.2
            ],
            [
              1413.8,
              330.5
            ],
            [
              1439.8,
              360
            ],
            [
              1467.2,
              393.5
            ],
            [
              1494.8,
              422.8
            ],
            [
              1521.4,
              455.9
            ],
            [
              1546.9,
              487.5
            ],
            [
              1553.8,
              519.4
            ]
          ],
          why: "November's inland verge re-laid 9.5 m inside the re-aligned Drive round the north-east corner"
        },
        {
          was: [
            [
              1555.2,
              508.1
            ],
            [
              1546.3,
              471.5
            ],
            [
              1536.1,
              432.7
            ],
            [
              1524.2,
              396
            ],
            [
              1506.8,
              358.9
            ],
            [
              1495.4,
              344.6
            ],
            [
              1505.5,
              343.5
            ],
            [
              1482.9,
              377.2
            ],
            [
              1461,
              411.8
            ],
            [
              1449.5,
              447.4
            ]
          ],
          now: [
            [
              1555,
              508.6
            ],
            [
              1538.9,
              473.1
            ],
            [
              1513,
              440.8
            ],
            [
              1486.4,
              408.4
            ],
            [
              1456.6,
              378.1
            ],
            [
              1451.4,
              371.3
            ],
            [
              1445.5,
              364.7
            ],
            [
              1444.8,
              372.2
            ],
            [
              1446.4,
              383.9
            ],
            [
              1451.2,
              425.9
            ],
            [
              1452.6,
              447.1
            ]
          ],
          why: "January's inland verge and Crown Road's east verge re-laid on the re-aligned corner and junction"
        },
        {
          was: [
            [
              1055,
              710
            ],
            [
              1100,
              600
            ],
            [
              1085,
              555
            ],
            [
              1070,
              535
            ],
            [
              960,
              470
            ]
          ],
          now: [
            [
              1055,
              710
            ],
            [
              1052,
              662
            ],
            [
              1060,
              600
            ],
            [
              1062,
              540
            ],
            [
              1060,
              505
            ],
            [
              1050,
              487
            ],
            [
              1e3,
              480
            ],
            [
              960,
              470
            ]
          ],
          why: "February leaves the Crown's flank for the 45 shelf (September no longer uses it)"
        },
        {
          was: [
            [
              1010,
              615
            ],
            [
              1040,
              650
            ],
            [
              1045,
              550
            ],
            [
              1055,
              505
            ],
            [
              1045,
              490
            ],
            [
              995,
              470
            ],
            [
              980,
              415
            ],
            [
              945,
              370
            ]
          ],
          now: [
            [
              1010,
              615
            ],
            [
              1032,
              652
            ],
            [
              1025,
              626
            ],
            [
              1010,
              604
            ],
            [
              991.3,
              592.5
            ],
            [
              974.3,
              552.6
            ],
            [
              956.4,
              515.5
            ],
            [
              938.9,
              476.8
            ],
            [
              929.5,
              433.8
            ],
            [
              927.1,
              388
            ]
          ],
          why: "September returns from its pad across Green Road and walks its west footway north to the pass (it ran up the shelf beside February, 24 eu apart)"
        },
        {
          was: [
            [
              1596.9,
              703.2
            ],
            [
              1601.5,
              743.6
            ],
            [
              1605.7,
              784.8
            ],
            [
              1608.1,
              827.2
            ],
            [
              1605.7,
              864.9
            ],
            [
              1592.8,
              905.1
            ],
            [
              1576.5,
              943.3
            ],
            [
              1558.6,
              980.4
            ],
            [
              1536.4,
              1014.4
            ],
            [
              1502.6,
              1037
            ],
            [
              1500.3,
              1038.1
            ]
          ],
          now: [
            [
              1596.9,
              703.2
            ],
            [
              1601.8,
              746.3
            ],
            [
              1606,
              790.3
            ],
            [
              1608,
              832
            ],
            [
              1602.7,
              877.6
            ],
            [
              1588.6,
              919
            ],
            [
              1572.7,
              957.4
            ],
            [
              1553.6,
              996.8
            ],
            [
              1523,
              1027.7
            ],
            [
              1498.6,
              1039.6
            ]
          ],
          why: "December's seaward verge re-laid on the Prow cliff drive after its [1540,1000] control moved 3.5 m off the Terraces plots"
        },
        {
          was: [
            [
              1494.7,
              1026.4
            ],
            [
              1527.3,
              1005.1
            ],
            [
              1548.8,
              970.9
            ],
            [
              1564.7,
              937.9
            ],
            [
              1580.6,
              900.4
            ],
            [
              1593,
              862.2
            ],
            [
              1595,
              822.6
            ],
            [
              1592.7,
              785.9
            ],
            [
              1588.9,
              747.7
            ],
            [
              1584,
              704.7
            ],
            [
              1579.2,
              664
            ],
            [
              1574.3,
              626.7
            ],
            [
              1568.7,
              586.5
            ],
            [
              1562.7,
              548
            ]
          ],
          now: [
            [
              1493.6,
              1027.6
            ],
            [
              1528.6,
              1007.9
            ],
            [
              1549.8,
              975.8
            ],
            [
              1567.7,
              936.2
            ],
            [
              1582.4,
              898.3
            ],
            [
              1593.6,
              859
            ],
            [
              1594.6,
              817.6
            ],
            [
              1591.6,
              774.9
            ],
            [
              1587.1,
              732.1
            ],
            [
              1582.3,
              690.2
            ],
            [
              1576.2,
              645.9
            ],
            [
              1570.1,
              604.3
            ],
            [
              1561.2,
              546.4
            ]
          ],
          why: "January's inland verge re-laid on the moved Prow cliff drive (6.5 m, now 6 m clear of Terraces plot 3's margin)"
        },
        {
          was: [
            [
              1330,
              640
            ],
            [
              1355,
              660
            ],
            [
              1350,
              685
            ],
            [
              1375,
              690
            ]
          ],
          now: [
            [
              1330,
              640
            ],
            [
              1339,
              662
            ],
            [
              1344,
              684
            ],
            [
              1375,
              690
            ]
          ],
          why: "January's first leg leaves the pad west of the Ore Line's approach cut"
        },
        {
          was: [
            [
              1345,
              680
            ],
            [
              1355,
              675
            ],
            [
              1330,
              660
            ],
            [
              1345,
              650
            ],
            [
              1330,
              640
            ]
          ],
          now: [
            [
              1340.5,
              687.5
            ],
            [
              1335.5,
              663
            ],
            [
              1330,
              640
            ]
          ],
          why: "January's last leg returns as the first leg's west lane (3.5 m), west of the Ore Line"
        }
      ],
      v2_0_edits: [
        {
          was: [
            [
              1630,
              855
            ],
            [
              1620,
              910
            ],
            [
              1645,
              875
            ]
          ],
          now: [
            [
              1630,
              855
            ],
            [
              1626,
              904
            ],
            [
              1645,
              875
            ]
          ],
          why: "v2.0 (D-A8): the November loop's tip on the moved pad's centre"
        }
      ],
      v2_5_pts: [
        [
          1330,
          640
        ],
        [
          1339,
          662
        ],
        [
          1344,
          684
        ],
        [
          1375,
          690
        ],
        [
          1415,
          680
        ],
        [
          1445,
          690
        ],
        [
          1445,
          695
        ],
        [
          1465,
          685
        ],
        [
          1460,
          705
        ],
        [
          1470,
          700
        ],
        [
          1460,
          755
        ],
        [
          1405,
          865
        ],
        [
          1390,
          870
        ],
        [
          1395,
          870
        ],
        [
          1330,
          885
        ],
        [
          1325,
          880
        ],
        [
          1325,
          852
        ],
        [
          1321.3,
          848.5
        ],
        [
          1317.6,
          852
        ],
        [
          1317.6,
          880
        ],
        [
          1313.9,
          883.5
        ],
        [
          1310.2,
          880
        ],
        [
          1310.2,
          852
        ],
        [
          1306.5,
          848.5
        ],
        [
          1302.8,
          852
        ],
        [
          1302.8,
          880
        ],
        [
          1299.1,
          883.5
        ],
        [
          1295.4,
          880
        ],
        [
          1295.4,
          852
        ],
        [
          1291.7,
          848.5
        ],
        [
          1288,
          852
        ],
        [
          1288,
          880
        ],
        [
          1284.3,
          883.5
        ],
        [
          1280.6,
          880
        ],
        [
          1280.6,
          852
        ],
        [
          1276,
          846
        ],
        [
          1267,
          842
        ],
        [
          1251,
          836
        ],
        [
          1250,
          800
        ],
        [
          1235,
          755
        ],
        [
          1145,
          720
        ],
        [
          1100,
          720
        ],
        [
          1080,
          725
        ],
        [
          1055,
          710
        ],
        [
          1052,
          662
        ],
        [
          1060,
          600
        ],
        [
          1062,
          540
        ],
        [
          1060,
          505
        ],
        [
          1050,
          487
        ],
        [
          1e3,
          480
        ],
        [
          960,
          470
        ],
        [
          930,
          480
        ],
        [
          895,
          480
        ],
        [
          905,
          470
        ],
        [
          885,
          465
        ],
        [
          872,
          461.7
        ],
        [
          857,
          441.3
        ],
        [
          789.3,
          436.5
        ],
        [
          769.2,
          446.5
        ],
        [
          715,
          446.5
        ],
        [
          700,
          470
        ],
        [
          715,
          450
        ],
        [
          770,
          450
        ],
        [
          790,
          440
        ],
        [
          855,
          445
        ],
        [
          870,
          465
        ],
        [
          905,
          470
        ],
        [
          895,
          475
        ],
        [
          905,
          475
        ],
        [
          895,
          480
        ],
        [
          915,
          480
        ],
        [
          900,
          500
        ],
        [
          905,
          545
        ],
        [
          910,
          565
        ],
        [
          935,
          585
        ],
        [
          905,
          610
        ],
        [
          900,
          640
        ],
        [
          900,
          628
        ],
        [
          899,
          660
        ],
        [
          898,
          700
        ],
        [
          895,
          740
        ],
        [
          892,
          780
        ],
        [
          887,
          815
        ],
        [
          890,
          870
        ],
        [
          920,
          900
        ],
        [
          915,
          910
        ],
        [
          930,
          995
        ],
        [
          990,
          1010
        ],
        [
          997,
          1006.7
        ],
        [
          977.4,
          967.2
        ],
        [
          966.1,
          929.6
        ],
        [
          957.3,
          889.1
        ],
        [
          953.3,
          848.9
        ],
        [
          956.7,
          808.9
        ],
        [
          962.3,
          768.6
        ],
        [
          969.2,
          725.7
        ],
        [
          975.4,
          689.6
        ],
        [
          986.5,
          649.9
        ],
        [
          994.1,
          612.3
        ],
        [
          970,
          625
        ],
        [
          960,
          640
        ],
        [
          930,
          605
        ],
        [
          910,
          605
        ],
        [
          903,
          628
        ],
        [
          902,
          660
        ],
        [
          901,
          700
        ],
        [
          898,
          740
        ],
        [
          895,
          780
        ],
        [
          890,
          815
        ],
        [
          870,
          835
        ],
        [
          870,
          870
        ],
        [
          885,
          905
        ],
        [
          865,
          920
        ],
        [
          845,
          965
        ],
        [
          865,
          985
        ],
        [
          885,
          1065
        ],
        [
          885,
          1120
        ],
        [
          900,
          1180
        ],
        [
          920,
          1220
        ],
        [
          960,
          1355
        ],
        [
          970,
          1365
        ],
        [
          945,
          1385
        ],
        [
          950,
          1445
        ],
        [
          925,
          1440
        ],
        [
          870,
          1385
        ],
        [
          790,
          1325
        ],
        [
          735,
          1270
        ],
        [
          765,
          1235
        ],
        [
          710,
          1190
        ],
        [
          701.9,
          1195.9
        ],
        [
          679.4,
          1178.1
        ],
        [
          645.9,
          1154.1
        ],
        [
          613.3,
          1133.2
        ],
        [
          579.3,
          1111.5
        ],
        [
          546.3,
          1090
        ],
        [
          512.6,
          1067
        ],
        [
          482.5,
          1044.2
        ],
        [
          454.9,
          1014
        ],
        [
          437.3,
          979.5
        ],
        [
          423.4,
          943.6
        ],
        [
          410.5,
          904
        ],
        [
          425,
          890
        ],
        [
          400,
          745
        ],
        [
          425,
          770
        ],
        [
          440,
          860
        ],
        [
          440,
          870
        ],
        [
          412.6,
          903.3
        ],
        [
          425.5,
          942.8
        ],
        [
          439.3,
          978.6
        ],
        [
          456.7,
          1012.8
        ],
        [
          483.9,
          1042.5
        ],
        [
          513.9,
          1065.2
        ],
        [
          547.5,
          1088.2
        ],
        [
          580.5,
          1109.6
        ],
        [
          614.5,
          1131.3
        ],
        [
          647.1,
          1152.2
        ],
        [
          680.8,
          1176.4
        ],
        [
          703.3,
          1194.2
        ],
        [
          730,
          1180
        ],
        [
          930,
          1265
        ],
        [
          950,
          1265
        ],
        [
          970,
          1245
        ],
        [
          1120,
          1270
        ],
        [
          1160,
          1300
        ],
        [
          1205,
          1290
        ],
        [
          1160,
          1245
        ],
        [
          1120,
          1250
        ],
        [
          1100,
          1245
        ],
        [
          975,
          1155
        ],
        [
          960,
          1130
        ],
        [
          955,
          1095
        ],
        [
          990,
          1010
        ],
        [
          994.6,
          1008.6
        ],
        [
          974.6,
          968.2
        ],
        [
          963.2,
          930.4
        ],
        [
          954.3,
          889.7
        ],
        [
          950.3,
          848.9
        ],
        [
          953.7,
          808.6
        ],
        [
          959.3,
          768.2
        ],
        [
          966.2,
          725.2
        ],
        [
          972.5,
          688.9
        ],
        [
          983.6,
          649
        ],
        [
          991.1,
          612
        ],
        [
          1010,
          615
        ],
        [
          1032,
          652
        ],
        [
          1025,
          626
        ],
        [
          1010,
          604
        ],
        [
          991.3,
          592.5
        ],
        [
          974.3,
          552.6
        ],
        [
          956.4,
          515.5
        ],
        [
          938.9,
          476.8
        ],
        [
          929.5,
          433.8
        ],
        [
          927.1,
          388
        ],
        [
          915,
          370
        ],
        [
          820,
          345
        ],
        [
          790,
          320
        ],
        [
          810,
          305
        ],
        [
          810,
          280
        ],
        [
          815,
          275
        ],
        [
          895,
          275
        ],
        [
          899.2,
          283.6
        ],
        [
          940,
          276.6
        ],
        [
          980,
          268.6
        ],
        [
          1017.4,
          261
        ],
        [
          1056.8,
          253.2
        ],
        [
          1096.5,
          246.3
        ],
        [
          1136.3,
          242.6
        ],
        [
          1178.5,
          242.2
        ],
        [
          1216.7,
          243.5
        ],
        [
          1259.2,
          246.9
        ],
        [
          1297.7,
          252.8
        ],
        [
          1320.2,
          260.7
        ],
        [
          1338.9,
          296.4
        ],
        [
          1382.5,
          312.2
        ],
        [
          1413.8,
          330.5
        ],
        [
          1439.8,
          360
        ],
        [
          1467.2,
          393.5
        ],
        [
          1494.8,
          422.8
        ],
        [
          1521.4,
          455.9
        ],
        [
          1546.9,
          487.5
        ],
        [
          1553.8,
          519.4
        ],
        [
          1561,
          556.4
        ],
        [
          1567.4,
          598.5
        ],
        [
          1572.5,
          635.5
        ],
        [
          1577.9,
          678.4
        ],
        [
          1581,
          705
        ],
        [
          1570,
          665
        ],
        [
          1575,
          670
        ],
        [
          1600,
          665
        ],
        [
          1615,
          725
        ],
        [
          1630,
          745
        ],
        [
          1630,
          855
        ],
        [
          1626,
          904
        ],
        [
          1645,
          875
        ],
        [
          1650,
          855
        ],
        [
          1650,
          745
        ],
        [
          1645,
          725
        ],
        [
          1615,
          685
        ],
        [
          1596.9,
          703.2
        ],
        [
          1601.8,
          746.3
        ],
        [
          1606,
          790.3
        ],
        [
          1608,
          832
        ],
        [
          1602.7,
          877.6
        ],
        [
          1588.6,
          919
        ],
        [
          1572.7,
          957.4
        ],
        [
          1553.6,
          996.8
        ],
        [
          1523,
          1027.7
        ],
        [
          1498.6,
          1039.6
        ],
        [
          1510,
          1050
        ],
        [
          1510,
          1100
        ],
        [
          1525,
          1175
        ],
        [
          1500,
          1200
        ],
        [
          1490,
          1230
        ],
        [
          1500,
          1200
        ],
        [
          1545,
          1160
        ],
        [
          1535,
          1120
        ],
        [
          1540,
          1085
        ],
        [
          1530,
          1055
        ],
        [
          1505,
          1015
        ],
        [
          1495,
          1015
        ],
        [
          1490,
          1020
        ],
        [
          1493.6,
          1027.6
        ],
        [
          1528.6,
          1007.9
        ],
        [
          1549.8,
          975.8
        ],
        [
          1567.7,
          936.2
        ],
        [
          1582.4,
          898.3
        ],
        [
          1593.6,
          859
        ],
        [
          1594.6,
          817.6
        ],
        [
          1591.6,
          774.9
        ],
        [
          1587.1,
          732.1
        ],
        [
          1582.3,
          690.2
        ],
        [
          1576.2,
          645.9
        ],
        [
          1570.1,
          604.3
        ],
        [
          1561.2,
          546.4
        ],
        [
          1555,
          508.6
        ],
        [
          1538.9,
          473.1
        ],
        [
          1513,
          440.8
        ],
        [
          1486.4,
          408.4
        ],
        [
          1456.6,
          378.1
        ],
        [
          1451.4,
          371.3
        ],
        [
          1445.5,
          364.7
        ],
        [
          1444.8,
          372.2
        ],
        [
          1446.4,
          383.9
        ],
        [
          1451.2,
          425.9
        ],
        [
          1452.6,
          447.1
        ],
        [
          1452,
          485.4
        ],
        [
          1449.1,
          529
        ],
        [
          1433.5,
          565.6
        ],
        [
          1417,
          599.6
        ],
        [
          1400.2,
          635.7
        ],
        [
          1383.7,
          674.4
        ],
        [
          1376.8,
          690.6
        ],
        [
          1340.5,
          687.5
        ],
        [
          1335.5,
          663
        ],
        [
          1330,
          640
        ]
      ],
      v2_5_shares: [
        {
          stretch: "feb",
          host: "walk lakerim",
          via: "structure.inletFootbridge",
          side: "on the rim trail",
          offset_m: 0,
          from: [
            1251,
            836
          ],
          to: [
            1100,
            721
          ],
          note: "the February stretch walks the lake rim trail round the east and north shore and crosses the upper river on the Inlet Footbridge; one bed, the rim trail's",
          v1_8_from: [
            1250,
            800
          ]
        },
        {
          stretch: "may",
          host: "VG",
          side: "west",
          offset_m: 6.5,
          from: [
            997,
            1006.7
          ],
          to: [
            994.1,
            612.3
          ],
          note: "Green Road's west footway"
        },
        {
          stretch: "sep",
          host: "VG",
          side: "west",
          offset_m: 9.5,
          from: [
            994.6,
            1008.6
          ],
          to: [
            991.1,
            612
          ],
          note: "the same footway's outer lane"
        },
        {
          stretch: "jul",
          host: "V01",
          via: "structure.bightBridge",
          side: "lagoon (north-east)",
          offset_m: 5.2,
          from: [
            701.9,
            1195.9
          ],
          to: [
            410.5,
            904
          ],
          note: "the Bight Bridge's lagoon-side footway and the Drive's verge down the Flats arm; deck height 12 on the bridge"
        },
        {
          stretch: "aug",
          host: "V01",
          via: "structure.bightBridge",
          side: "lagoon (north-east)",
          offset_m: 7.4,
          from: [
            412.6,
            903.3
          ],
          to: [
            703.3,
            1194.2
          ],
          note: "the same footway's outer lane, walked back east a month later"
        },
        {
          stretch: "nov",
          host: "V01",
          side: "seaward (north)",
          offset_m: 6.5,
          from: [
            899.2,
            283.6
          ],
          to: [
            1320.2,
            260.7
          ],
          note: "the north coast drive's seaward verge",
          v1_8_to: [
            1319.7,
            258.5
          ]
        },
        {
          stretch: "nov",
          host: "V01",
          side: "inland",
          offset_m: 9.5,
          from: [
            1338.9,
            296.4
          ],
          to: [
            1581,
            705
          ],
          note: "crosses the Drive at grade at [1330,270] and takes the inland verge round the north-east corner (the seaward verge there is off the outline) up onto the Prow",
          v1_8_from: [
            1340.4,
            281.3
          ]
        },
        {
          stretch: "dec",
          host: "V01",
          side: "seaward (east)",
          offset_m: 6.5,
          from: [
            1596.9,
            703.2
          ],
          to: [
            1498.6,
            1039.6
          ],
          note: "down the Prow cliff drive's seaward verge to the harbour",
          v1_8_from: [
            1596.9,
            703.2
          ],
          v1_8_to: [
            1500.3,
            1038.1
          ]
        },
        {
          stretch: "jan",
          host: "V01",
          side: "inland (west)",
          offset_m: 6.5,
          from: [
            1493.6,
            1027.6
          ],
          to: [
            1456.6,
            378.1
          ],
          note: "up the Prow cliff drive's inland verge, through the Prow Tunnel as its footway",
          v1_8_to: [
            1495.4,
            344.6
          ],
          v1_8_from: [
            1494.7,
            1026.4
          ]
        },
        {
          stretch: "jan",
          host: "V02",
          side: "east",
          offset_m: 6.5,
          from: [
            1446.4,
            383.9
          ],
          to: [
            1376.8,
            690.6
          ],
          note: "up Crown Road's east verge, through the Shoulder Tunnel as its footway, to the turning circle",
          v1_8_from: [
            1505.5,
            343.5
          ]
        },
        {
          stretch: "apr",
          host: "S4",
          side: "east",
          offset_m: 6,
          from: [
            905,
            610
          ],
          to: [
            899,
            660
          ],
          note: "v1.9: the April lane is S4's east footway through the Hollow neck, at S4's height"
        },
        {
          stretch: "jun",
          host: "S4",
          side: "east",
          offset_m: 8,
          from: [
            903,
            628
          ],
          to: [
            902,
            660
          ],
          note: "v1.9: the June lane, 3 m further out on the same footway"
        },
        {
          stretch: "sep",
          host: "VG",
          side: "west",
          offset_m: 6.5,
          from: [
            991.3,
            592.5
          ],
          to: [
            927.1,
            388
          ],
          note: "v1.9: Green Road's west footway from the September pad's return to the north pass"
        }
      ],
      v2_5_levels: [
        {
          xy: [
            1350,
            687
          ],
          h: 110,
          r: 9,
          why: "the south portal forecourt: both January legs cross the ORE station's link walk (110) there at its height",
          v1_9_first_xy: [
            1358,
            685
          ]
        }
      ],
      v2_5_ownTrails: [
        {
          stretch: "apr",
          name: "the Hollow lane (west lane)",
          from: [
            900,
            628
          ],
          to: [
            887,
            815
          ],
          note: "a new trail on the valley floor between Orchard Brook and S4; the April and June stretches walk two lanes 3 m apart"
        },
        {
          stretch: "jun",
          name: "the Hollow lane (east lane)",
          from: [
            903,
            628
          ],
          to: [
            890,
            815
          ]
        },
        {
          stretch: "feb",
          name: "the Lakeside zig-zag",
          from: [
            1330,
            885
          ],
          to: [
            1285,
            875
          ],
          note: "from the Shoulder's south-west corner down to the lake terrace: seven short switchback legs on the band face (x 1285\u20131330, z 845\u2013885), outside S1's loop; built as a ramp with retaining walls between legs (the only step-free way off the Shoulder that does not cross S1)"
        }
      ],
      v2_5_s1Crossing: [
        1267,
        842
      ]
    },
    stretch: {
      rule: "a month is the stretch of the Year Walk from the previous station to its own; one paving stone per day (28\u201331); every seventh stone a flagstone with a lantern post; the camp stands on today\u2019s stone; scheduled items stand on their stone as explicit markers (slip, pennant, stake, chairs); the next stretch is stakes and string until its month begins",
      stone_m: [
        2.4,
        1.6
      ],
      flagstone_m: [
        3.2,
        2.4
      ],
      markers: [
        "bill slip on a post (name, amount)",
        "payday pennant",
        "task or plan-step stake (card name)",
        "goal-deadline stake with ribbon",
        "two chairs (Sitdown)",
        "station gate ajar (Chapter close due)"
      ]
    },
    station: {
      pad_m: [
        36,
        14
      ],
      bed_m: [
        3,
        2
      ],
      bedsPerRow: 10,
      rows: 2,
      identity: "site(monthOrdinal) = station(month) + bed(yearIndex); appending never moves a bed",
      maxHeight: "a bench (0.85 eu)",
      waymark: "post with the month name and the year count; lit at the camp",
      padRotRule: "v2.0: a station may carry pad_rot_deg (default 0; 90 turns the 36 m side north-south); the builder lays the pad and its beds rotated"
    },
    camp: {
      rule: "the current month\u2019s bed: lit waymark + tent card; the camp card docks to it on the map",
      moves: "on Chapter/books close; 1 s card animation, a cut under reduced motion"
    },
    eraGates: {
      rule: "a gate (two posts + lantern) on the Year Walk at the bed where the era ended; lantern from the existing finish rules"
    },
    homestead: {
      where: "the land around Our home in Little Harbour: the yard behind the house, the lane down to the quay, the household\u2019s footbridge over the town channel, the Boathouse dock",
      centre: [
        1520,
        1190
      ],
      sites: [
        {
          id: "home",
          label: "the home anchor",
          note: "Our home; never wears, never moves"
        },
        {
          id: "kitchenGarden",
          label: "the kitchen garden",
          xy: [
            1535,
            1160
          ],
          category: "food",
          maturity: [
            "none",
            "trace",
            "cluster",
            "established",
            "district"
          ],
          rule: "qualifying weeks in the trailing 24; one credit per week"
        },
        {
          id: "landing",
          label: "the landing (cargo)",
          xy: [
            1320,
            1322
          ],
          category: "income",
          note: "cargo on the Boathouse dock when income arrives; never a beauty score"
        },
        {
          id: "workbench",
          label: "the workbench",
          xy: [
            1545,
            1200
          ],
          category: "making",
          note: "cosmetic; fired pieces as today"
        },
        {
          id: "pavilion",
          label: "a place in the making \u2192 the ready pavilion",
          xy: [
            1510,
            1215
          ],
          category: "goal",
          rule: "stakes while backing; finished at 100 % backed; a memory only when a kept memory exists"
        },
        {
          id: "reserveBasin",
          label: "the reserve basin",
          note: "= L01 [1172,912]; using the buffer shows as water, never damage"
        },
        {
          id: "timberCrossing",
          label: "the timber crossing",
          xy: [
            1500,
            1250
          ],
          category: "connection",
          note: "the household\u2019s footbridge on the lane over the town channel; the one site with physical wear (D19, D24)"
        }
      ]
    },
    kittyPlaza: {
      xy: [
        1440,
        1145
      ],
      max: 6,
      note: "Kitty Bank sculptures, step 0\u201310, beside the Fund bank"
    },
    lod: {
      L0: {
        tris: [
          4e4,
          25e3
        ],
        drawCalls: [
          60,
          40
        ],
        coastVerts: 400,
        heightfieldDecimation: 8
      },
      L1: {
        tris: [
          8e4,
          45e3
        ]
      },
      note: "[full, lite]; L2\u2013L3 are the world\u2019s budgets (CONTRACT \xA76)"
    },
    camera: {
      tiers: {
        sky: "the island\u2019s diagonal",
        region: 250,
        stop: 80,
        upClose: 25
      },
      handoff: "below upClose the target snaps to the nearest apron or bed and the controller hands to the world\u2019s Look camera, then Walk; one orbit controller, same north",
      fallback: "the #543 cloud crossfade for reduced motion, no WebGL, or a tier load over 400 ms"
    },
    focus: {
      fields: [
        "target xy",
        "tier",
        "radius",
        "heading",
        "period (day/week/month/era) + date",
        "selected object",
        "active filters",
        "unsent draft"
      ],
      rule: "tools open over it and restore it exactly; the world always shows now (entering from a past month lands at that bed with a banner)"
    },
    retired: [
      "weather-from-money (bills\u2192clouds, storm, mist, payday sunrise) \u2192 explicit strip markers (D18)",
      "grow.ts landform generation (coast, coves, noise)",
      "the harbour islet miniature",
      "past eras as separate islands"
    ]
  },
  names: {
    island: "The Horizon",
    landformRule: "polygons are clipped to the island outline; the Hollow, the Stillwater terrace and the Cup are cut INTO the Shoulder (their own band wins inside them); elsewhere where polygons overlap the innermost (higher) band wins; band edges blend over 60 m; a bed (road, skate, rail, walk) overrides the bands within its profile width + 15 m each side and holds its own grade limits, so band steps never appear as cliffs on a route",
    districts: [
      {
        id: "harbour",
        neighbourhood: "harbour",
        note: "town + the Terraces + the town quay"
      },
      {
        id: "landing",
        neighbourhood: "landing",
        note: "Long Sands, the Landing quay, the Boathouse, Campfire, Tideline park"
      },
      {
        id: "reach",
        neighbourhood: "landing",
        note: "the wetland and the river mouth"
      },
      {
        id: "green",
        neighbourhood: "lakeside",
        note: "the Green and the Glasshouse steps"
      },
      {
        id: "hollow",
        neighbourhood: "hollow",
        note: "the orchard bowl, the Adit"
      },
      {
        id: "scholars",
        neighbourhood: "scholars",
        note: "the woodland rise and the north pass"
      },
      {
        id: "flats",
        neighbourhood: "flats",
        note: "the arm: strip, hangar, balloon, the Wash"
      },
      {
        id: "bight",
        neighbourhood: "flats",
        note: "the lagoon, the sandbar, Bight Shore, the Bight Bridge"
      },
      {
        id: "lakeside",
        neighbourhood: "lakeside",
        note: "Stillwater, the dam, L01"
      },
      {
        id: "notch",
        neighbourhood: "lakeside",
        note: "the gorge, the High Span"
      },
      {
        id: "prow",
        neighbourhood: "crown",
        note: "the cliffs, the zip tower, the Sea Door"
      },
      {
        id: "crown",
        neighbourhood: "crown",
        note: "the Shoulder and the summit; the Undercroft is its underground child district"
      },
      {
        id: "offshore",
        neighbourhood: null,
        note: "the Lamp, the Needle's Eye, the Stacks, the Wreck; the sky ring streams by the districts beneath it"
      }
    ],
    landforms: [
      "Little Harbour",
      "Long Sands",
      "the Landing",
      "the Reach",
      "the Green",
      "the Hollow",
      "Scholars' Edge",
      "the Flats",
      "the Bight",
      "Stillwater",
      "the Cup",
      "the Notch",
      "the Prow",
      "the Shoulder",
      "the Crown",
      "the Undercroft",
      "the Lamp",
      "the Needle's Eye",
      "the Stacks",
      "the Wreck",
      "the Terraces",
      "Bight Shore"
    ],
    roads: [
      "Horizon Drive",
      "Green Road",
      "Crown Road",
      "Bight Shore spur"
    ],
    skate: [
      "Summit to Sea",
      "the Wash Run",
      "Town Weave",
      "Hollow Line",
      "Tideline park"
    ],
    underground: [
      "the Adit",
      "the Throat",
      "Dam Gallery",
      "the Sea Door",
      "Ore Line",
      "Lantern Cave",
      "the Deep",
      "Bell Gallery"
    ],
    structures: [
      "High Span",
      "Quay Bridge",
      "Bight Bridge",
      "Hollow Bridge",
      "Apron Bridge",
      "Inlet Footbridge",
      "Reach Footbridge",
      "Dune Culvert",
      "Prow Tunnel",
      "Shoulder Tunnel",
      "Lantern Row",
      "the Landing quay",
      "the town quay",
      "the Glasshouse steps",
      "the Sea Stair",
      "Crown station",
      "the South Portal",
      "the Sea Passage",
      "the Steps"
    ],
    water: [
      "Orchard Brook",
      "the Wash (streambed)",
      "the Bight sandbar",
      "the Steps"
    ],
    idRule: "ids are camelCase keys in this manifest (e.g. highSpan, plot.terraces.1); display names above are their labels; STYLE and the guide map use labels, code uses ids",
    journey: [
      "the Year Walk",
      "the camp",
      "the homestead",
      "the kitchen garden",
      "the landing",
      "the workbench",
      "the ready pavilion",
      "the reserve basin",
      "the timber crossing",
      "the home anchor",
      "the Kitty plaza",
      "era gates"
    ],
    pastimes: [
      "Lantern Hunt",
      "Summit to Sea",
      "Ring Run",
      "Drop Zone",
      "Mail Day",
      "River Run",
      "Deep Run",
      "Nine Baskets",
      "Bocce",
      "Ring Race",
      "Ore Line ride",
      "the Sketchbook",
      "Campfire",
      "Winter (skating, sledding)"
    ]
  },
  scale: {
    factor: 1,
    status: "confirmed by Jonathan 2026-09-25",
    rule: "engine_units = concept_metres \xD7 factor, applied to x, y and height alike; speeds in m/s are engine units per second",
    why: "Jonathan selected full concept scale. Journey estimates use factor 1.0; the 0.6 table remains a comparison scenario, not the active scale.",
    decision: "D13 \u2014 Jonathan: \u201C1.0 \u2014 full concept scale\u201D, confirmed 2026-09-25; applies to x, y and height."
  },
  crossingRule: "crossings contains physical resolutions only (over, under, threshold) at authored point, corridor or area locations; Pass 1 resolves these into numeric WorldDefinition geometry. District metadata belongs to its crossing. routePairNotes preserves coordination evidence for Pass 1 verification, including shared plan points; it never exempts a computed intersection from the crossing register.. v1.8: every computed intersection of the Stage A build has a row; kind names the proof class (crossing, junction, sharedStretch, footway, waterBody, waterConfluence, modeTransfer) and resolution stays over / under / threshold; rows with source 'bake v1.8' are the design lead's acceptance of the computed resolution and never create a register pad or a dismount threshold; reserved names the decision a row waits on",
  routePairNotes: [
    {
      a: "ORE",
      b: "Crown Road",
      note: "the South Portal [1345,680] is 29 m from the turning circle; a path links them",
      kind: "nearby-endpoints",
      sharedPlanPoints: [],
      verification: "Verify the South Portal link against the built Crown Road turning circle; register any actual intersection found in Pass 1."
    },
    {
      a: "DEEP_RUN",
      b: "ORE",
      note: "the Sea Passage leaves the Deep east; the rail leaves north-east and climbs; separated by 20 m of rock",
      kind: "shared-plan-point",
      sharedPlanPoints: [
        [
          1300,
          420
        ]
      ],
      verification: "Both centrelines include [1300,420] at the Deep. The original 20 m rock-separation note describes the departing passages, not proven clearance at this shared point. Pass 1 must compute their vertical profiles and register and build every actual crossing; this note is not an exclusion."
    },
    {
      a: "walk reach",
      b: "VG",
      kind: "retired register row (v1.8)",
      verification: "the Reach walk runs under the High Span gallery beside the river; the two centrelines never cross in plan (the High Span's walk-level gallery is the Reach walk's own stretch)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk reach",
        b: "VG",
        at: [
          1240,
          1110
        ],
        resolution: "under",
        structure: "highSpan (water level)"
      }
    },
    {
      a: "S1 finish",
      b: "V01",
      kind: "retired register row (v1.8)",
      verification: "S1 finishes on the quay without crossing V01 near [1270,1330]; S1 \xD7 V01 has no plan intersection in the v1.8 build",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S1 finish",
        b: "V01",
        at: [
          1270,
          1330
        ],
        resolution: "threshold",
        note: "kerb-separated; the run-out ends 20 m before the Long Sands road"
      }
    },
    {
      a: "S2",
      b: "V01",
      kind: "retired register row (v1.8)",
      verification: "S2 is a lane of the Bight Bridge deck (row 13); it passes 17.9 m from the [660,1170] dismount, which does not exist (T2 D-3: S2 cannot descend from the Wash to the deck at 18 %; Jonathan decides)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S2",
        b: "V01",
        at: [
          660,
          1170
        ],
        resolution: "threshold",
        note: "after the bridge S2 leaves the road at a dismount marker onto its own bed 18\u201345 m from the carriageway"
      }
    },
    {
      a: "S3",
      b: "town quay",
      kind: "retired register row (v1.8)",
      verification: "S3 runs beside the town quay, never across it (T0 request 4: S3 at [1433,1298] should come down \u2264 3.5 eu)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S3",
        b: "town quay",
        at: [
          1453,
          1277
        ],
        resolution: "threshold",
        note: "quayWest: park here; Lantern Row is pedestrian"
      }
    },
    {
      a: "S3",
      b: "walk dune",
      kind: "retired register row (v1.8)",
      verification: '"none": S3 and the dune walk do not cross',
      sharedPlanPoints: [],
      retiredRow: {
        a: "S3",
        b: "walk dune",
        at: "none",
        resolution: "over",
        note: "S3's boardwalk runs the dune crest; the dune walk runs the beach foot 30 m south; they never meet"
      }
    },
    {
      a: "S3",
      b: "V01",
      kind: "retired register row (v1.8)",
      verification: "S3 never reaches [1480,1050]; it meets V01 only on the river-mouth bridge decks ([1350,1345], [1322,1372]), carried below as rows accepted from the bake: a threshold there needs a widened, guarded deck (a register pad would stand in the river)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S3",
        b: "V01",
        at: [
          1480,
          1050
        ],
        resolution: "threshold",
        note: "the upper-street spur end is the board pick-up"
      }
    },
    {
      a: "ZIP",
      b: "town",
      kind: "retired register row (v1.8)",
      verification: "an area rule, not an intersection: the zip line passes over the town's roofs with \u2265 12 eu clearance (checked as cable.ZIP.roofs)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "ZIP",
        b: "town",
        at: "overhead",
        resolution: "over",
        note: "\u2265 12 m above every roof, sag included; the line skirts the town's west edge"
      }
    },
    {
      a: "S4",
      b: "spur studio",
      kind: "retired register row (v1.8)",
      verification: "S4 starts at [1000,520]; it never meets the Studio spur at [974,540] (the spur meets VG there, listed below)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S4",
        b: "spur studio",
        at: [
          974,
          540
        ],
        resolution: "threshold",
        note: "S4 starts at the studio terrace; the spur ends there"
      }
    },
    {
      a: "plane",
      b: "everything",
      kind: "retired register row (v1.8)",
      verification: "an area rule, not an intersection: planes fly over everything under the sky ceiling",
      sharedPlanPoints: [],
      retiredRow: {
        a: "plane",
        b: "everything",
        at: "sky",
        resolution: "over",
        note: "ceiling 300 m; no landing on a neighbourhood"
      }
    },
    {
      a: "DEEP_RUN",
      b: "walk prow",
      kind: "retired register row (v1.9)",
      verification: "the Prow walk (v1.9) keeps to the Prow top east of V01's cutting and no longer crosses the Deep run's line at [1611,710]",
      sharedPlanPoints: [],
      retiredRow: {
        a: "DEEP_RUN",
        b: "walk prow",
        at: [
          1611,
          710
        ],
        resolution: "under",
        movedFrom: [
          1605,
          700
        ],
        note: "the Deep run passes under the Prow walk 11 m east of the v1.7 point",
        kind: "crossing"
      }
    },
    {
      a: "S2",
      b: "walk bightPier",
      kind: "retired register row (v1.9)",
      verification: "the pier walk (v1.9) ends at the Flats' cliff top; S2 now passes under the Bight pier stair (a row accepted from the v1.9 bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S2",
        b: "walk bightPier",
        at: [
          509,
          896
        ],
        resolution: "threshold",
        note: "the pier walk crosses the Wash Run bed at a marked gap",
        kind: "crossing"
      }
    },
    {
      a: "walk bightPier",
      b: "water wash",
      kind: "retired register row (v1.9)",
      verification: "the pier walk (v1.9) ends at the Flats' cliff top; the wash footbridge is retired and the Bight pier stair crosses the dry wash mouth",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk bightPier",
        b: "water wash",
        at: [
          514,
          895
        ],
        resolution: "over",
        structure: "a plank footbridge at the Wash mouth",
        kind: "crossing"
      }
    },
    {
      a: "damGallery.flight.1",
      b: "damGallery.exit",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "damGallery.flight.1",
        b: "damGallery.exit",
        at: [
          1165,
          898
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 7 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "damGallery.flight.1",
      b: "water.stillwater",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "damGallery.flight.1",
        b: "water.stillwater",
        at: [
          1165,
          898
        ],
        resolution: "threshold",
        kind: "waterBody",
        source: "bake v1.8",
        note: "bed inside the water outline below its surface: a bridge, causeway or re-route is owed (diagnostic)"
      }
    },
    {
      a: "damGallery.flight.2",
      b: "damGallery.exit",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "damGallery.flight.2",
        b: "damGallery.exit",
        at: [
          1165,
          886
        ],
        resolution: "threshold",
        kind: "sharedStretch",
        source: "bake v1.8",
        note: "shared stretch 10 eu at one height"
      }
    },
    {
      a: "damGallery.flight.2",
      b: "water.stillwater",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "damGallery.flight.2",
        b: "water.stillwater",
        at: [
          1165,
          892
        ],
        resolution: "threshold",
        kind: "waterBody",
        source: "bake v1.8",
        note: "bed inside the water outline below its surface: a bridge, causeway or re-route is owed (diagnostic)"
      }
    },
    {
      a: "highSpan.overlook",
      b: "river lower",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "highSpan.overlook",
        b: "river lower",
        at: [
          1251.2,
          1143.3
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: "at-grade meeting 2.1 eu apart: regrade owed"
      }
    },
    {
      a: "jetty.lamp",
      b: "lampGallery.ramp",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "jetty.lamp",
        b: "lampGallery.ramp",
        at: [
          540,
          1250
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 9.6 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "jetty.lamp",
      b: "lampGallery.ramp",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "jetty.lamp",
        b: "lampGallery.ramp",
        at: [
          540,
          1250
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 19.2 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "lampGallery.ramp",
      b: "FERRY",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "lampGallery.ramp",
        b: "FERRY",
        at: [
          510.4,
          1224.4
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 12.8 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "lampGallery.ramp",
      b: "FERRY",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "lampGallery.ramp",
        b: "FERRY",
        at: [
          510.4,
          1224.4
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 22.4 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "lampGallery.ramp",
      b: "FERRY",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "lampGallery.ramp",
        b: "FERRY",
        at: [
          546.1,
          1190.6
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "lampGallery.ramp",
      b: "lampGallery.stair",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "lampGallery.ramp",
        b: "lampGallery.stair",
        at: [
          540,
          1250
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 9.6 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "lampGallery.ramp",
      b: "lampGallery.stair",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "lampGallery.ramp",
        b: "lampGallery.stair",
        at: [
          540,
          1250
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 19.2 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "river lower",
      b: "reachChannel.2",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "river lower",
        b: "reachChannel.2",
        at: [
          1320,
          1276
        ],
        resolution: "threshold",
        kind: "waterConfluence",
        source: "bake v1.8",
        note: "one waterway"
      }
    },
    {
      a: "S1",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S1",
        b: "yearWalk",
        at: [
          1254.7,
          862
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "V01",
      b: "S3",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V01",
        b: "S3",
        at: [
          1321.9,
          1372.3
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "V01",
      b: "S3",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V01",
        b: "S3",
        at: [
          1350,
          1345
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "V01",
      b: "V02",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V01",
        b: "V02",
        at: [
          1500,
          340
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "V01",
      b: "walk prow",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V01",
        b: "walk prow",
        at: [
          1580.1,
          620.7
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 11.5 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "VG",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "VG",
        b: "yearWalk",
        at: [
          933,
          369.1
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 5.5 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk bight",
      b: "plot.bight.3.service",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk bight",
        b: "plot.bight.3.service",
        at: [
          729.5,
          1056.6
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "walk bight",
      b: "plot.bight.4.service",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk bight",
        b: "plot.bight.4.service",
        at: [
          706.4,
          1131.1
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "walk bightPier",
      b: "FERRY",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk bightPier",
        b: "FERRY",
        at: [
          560,
          890
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "walk bightPier",
      b: "ferry.bight",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk bightPier",
        b: "ferry.bight",
        at: [
          560,
          890
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "walk crownFromGondola",
      b: "V02",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "V02",
        at: [
          1443.1,
          526.5
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk dune",
      b: "zipLanding.ramp",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk dune",
        b: "zipLanding.ramp",
        at: [
          1079.2,
          1469
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 6.6 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk dune",
      b: "zipLanding.stair",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk dune",
        b: "zipLanding.stair",
        at: [
          1144.1,
          1458.9
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 2.7 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk garden",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk garden",
        b: "yearWalk",
        at: [
          807.5,
          474.1
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "under by 3.9 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk lakerim",
      b: "damGallery.flight.1",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk lakerim",
        b: "damGallery.flight.1",
        at: [
          1165,
          905.2
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "walk lakerim",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk lakerim",
        b: "yearWalk",
        at: [
          1244.4,
          852.1
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: "at-grade meeting 2.3 eu apart: regrade owed"
      }
    },
    {
      a: "walk lakerim",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk lakerim",
        b: "yearWalk",
        at: [
          1244.5,
          851.9
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: "at-grade meeting 2.3 eu apart: regrade owed"
      }
    },
    {
      a: "walk prow",
      b: "seaStair",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "seaStair",
        at: [
          1620,
          760
        ],
        resolution: "threshold",
        kind: "junction",
        source: "bake v1.8",
        note: "flush path junction: no marker, no mode change"
      }
    },
    {
      a: "walk prow",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "yearWalk",
        at: [
          1567.7,
          600.9
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 11.2 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk prow",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "yearWalk",
        at: [
          1571.6,
          606.8
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 11.3 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk prow",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "yearWalk",
        at: [
          1591.5,
          908.6
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 33.9 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk prow",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "yearWalk",
        at: [
          1598.3,
          664
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 10.8 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk prow",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "yearWalk",
        at: [
          1605.7,
          689.4
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 13.6 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk prow",
      b: "yearWalk",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "yearWalk",
        at: [
          1607.5,
          847.7
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 26.7 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "walk prow",
      b: "ZIP",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk prow",
        b: "ZIP",
        at: [
          1597.3,
          661.1
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "yearWalk",
      b: "ORE",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "yearWalk",
        b: "ORE",
        at: [
          1345,
          680
        ],
        resolution: "threshold",
        kind: "modeTransfer",
        source: "bake v1.8",
        note: "boarding threshold; mover pending"
      }
    },
    {
      a: "yearWalk",
      b: "ORE",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "yearWalk",
        b: "ORE",
        at: [
          1349.6,
          671.6
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "yearWalk",
      b: "ORE",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "yearWalk",
        b: "ORE",
        at: [
          1355.1,
          661.5
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "yearWalk",
      b: "southPortal.link",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "yearWalk",
        b: "southPortal.link",
        at: [
          1345,
          680
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 3 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "yearWalk",
      b: "southPortal.link",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "yearWalk",
        b: "southPortal.link",
        at: [
          1347.7,
          681.4
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 2.8 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "yearWalk",
      b: "southPortal.link",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "yearWalk",
        b: "southPortal.link",
        at: [
          1349.7,
          682.4
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 2.9 eu: a named structure (footbridge, deck or passage) is owed"
      }
    },
    {
      a: "ZIP",
      b: "river lower",
      kind: "retired register row (v1.9)",
      verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "ZIP",
        b: "river lower",
        at: [
          1273.1,
          1201.5
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: ""
      }
    },
    {
      a: "S2",
      b: "yearWalk",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A1): S2 comes onto the deck's lagoon lane outboard of the Year Walk footways (+10.6 against +5.2/+7.4); they run side by side and never meet",
      sharedPlanPoints: [],
      retiredRow: {
        a: "S2",
        b: "yearWalk",
        at: [
          468.2,
          1026.4
        ],
        resolution: "threshold",
        kind: "crossing",
        source: "bake v1.8",
        note: "at-grade meeting 0.7 eu apart: regrade owed"
      }
    },
    {
      a: "V02",
      b: "walk crownFromGondola",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V02",
        b: "walk crownFromGondola",
        at: [
          1412.8,
          593.4
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "V02",
      b: "walk crownFromGondola",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V02",
        b: "walk crownFromGondola",
        at: [
          1443.1,
          526.5
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crown",
      b: "walk crownFromGondola",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crown",
        b: "walk crownFromGondola",
        at: [
          1376,
          574.7
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 19.8 eu: a named structure (footbridge, deck or passage) is owed; RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "crownLaunch.stair",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "crownLaunch.stair",
        at: [
          1320.4,
          479.2
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "DEEP_RUN",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "DEEP_RUN",
        at: [
          1341.3,
          445.2
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "DEEP_RUN",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "DEEP_RUN",
        at: [
          1437.6,
          512.9
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "ORE",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "ORE",
        at: [
          1334.3,
          454.3
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "ORE",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "ORE",
        at: [
          1369.1,
          568.4
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "stepsPortage",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "stepsPortage",
        at: [
          1332.3,
          457.5
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "over by 117.5 eu: a named structure (footbridge, deck or passage) is owed; RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "underground.bellGallery",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "underground.bellGallery",
        at: [
          1315.5,
          489.2
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "yearWalk",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "yearWalk",
        at: [
          1422.1,
          589.2
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crownFromGondola",
      b: "yearWalk",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crownFromGondola",
        b: "yearWalk",
        at: [
          1446.4,
          537.2
        ],
        resolution: "over",
        kind: "crossing",
        source: "bake v1.8",
        note: "RESERVED R-A3: waits on the gondola top station"
      }
    },
    {
      a: "walk crown",
      b: "yearWalk",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crown",
        b: "yearWalk",
        at: [
          1371.2,
          689.7
        ],
        resolution: "threshold",
        kind: "junction",
        source: "bake v1.8",
        note: "flush path junction: no marker, no mode change"
      }
    },
    {
      a: "walk crown",
      b: "G1",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crown",
        b: "G1",
        at: [
          1375.1,
          688.6
        ],
        resolution: "under",
        kind: "crossing",
        source: "bake v1.8",
        note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
        v1_9_at: [
          1388.3,
          685.3
        ]
      }
    },
    {
      a: "walk crown",
      b: "southPortal.link",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "walk crown",
        b: "southPortal.link",
        at: [
          1370,
          690
        ],
        resolution: "threshold",
        kind: "junction",
        source: "bake v1.8",
        note: "flush path junction: no marker, no mode change"
      }
    },
    {
      a: "V02",
      b: "walk crown",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "V02",
        b: "walk crown",
        at: [
          1370,
          690
        ],
        resolution: "threshold",
        note: "turning circle is the wheels' end; the Crown walk begins",
        kind: "crossing"
      }
    },
    {
      a: "marketRamp",
      b: "host.home.approach",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-C11, Jonathan 2026-09-27): the market stair is stairs only; the ramp twin is retired (it ran into Our home's walls, R2-09)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "marketRamp",
        b: "host.home.approach",
        at: [
          1482.4,
          1181.8
        ],
        resolution: "threshold",
        kind: "junction",
        source: "bake v1.8",
        note: "flush path junction: no marker, no mode change"
      }
    },
    {
      a: "marketStair.flight.0",
      b: "marketRamp",
      kind: "retired register row (v2.0)",
      verification: "v2.0 (D-C11, Jonathan 2026-09-27): the market stair is stairs only; the ramp twin is retired (it ran into Our home's walls, R2-09)",
      sharedPlanPoints: [],
      retiredRow: {
        a: "marketStair.flight.0",
        b: "marketRamp",
        at: [
          1480,
          1150
        ],
        resolution: "threshold",
        kind: "junction",
        source: "bake v1.8",
        note: "flush path junction: no marker, no mode change"
      }
    }
  ],
  lights: [
    {
      id: "dam.glassFace",
      kind: "card",
      anchor: "structures.dam",
      face: "south",
      on: "golden hour \u2192 dawn (sunset \u2212 1 h to sunrise); off by day",
      colour: "warm interior glow (the kit pass picks the swatch)",
      note: "v2.0 (D-A5, Jonathan 2026-09-27): an emissive card on the dam's glass band, no dynamic light; the square sees it lit at golden hour and dusk; LIGHT \xA72"
    }
  ],
  lightsRule: "lights lists the manifest-authored light cards (LIGHT \xA73 WorldDefinition.lights); the bake's door and threshold lamps are derived and not listed here",
  carriedThresholds: [
    {
      id: "bailOut",
      carriedBy: "plane",
      xy: "carried",
      modes: [
        "plane\u2192parachute"
      ],
      action: "jump",
      minAgl_m: 60,
      hold_s: 0.5,
      note: "the plane's door: its place is the plane's each frame; offered only at >= minAgl_m above the ground under the plane; never inside the Throat"
    }
  ],
  carriedThresholdRule: "A carried threshold moves with a vehicle and has no pad, marker or fixed xy. It is listed apart from thresholds so the land pass never grades a pad for it; WorldDefinition.thresholds carries it with carried = carriedBy.",
  moverAnchors_v2_5: {
    source: "main #554 parachute, #555 cruiser, #556 fall rescue (Little Harbour), #557 fleet + yacht, #558 fleet water, #559 Yacht Kitchen, #560 personal homes \u2014 anchors are code-owned (movers/fleet/model.ts, movers/cruiser/*, kitchen/geometry.ts, home/site.ts); reconciliation 2, 2026-09-27",
    fleet: {
      launch: "structures.floatplaneDock [1520,1275]: the dock's bed at h 1.2 (the fleet's launchBody [1523,1.2,1276] stands on it, dry)",
      moorings: {
        kayak: [
          1527,
          1269
        ],
        dinghy: [
          1527,
          1276
        ],
        motorboat: [
          1528,
          1283
        ]
      },
      yacht: [
        1620,
        1340
      ],
      measured: "every hull navigable at its mooring (seabed \u22123.5 / \u22124.3 / \u22125.3 / \u221212); the three small hulls' approach to the yacht's stern clear 40/40 each; identical on candidate 5 and candidate 6 (the land there did not move)"
    },
    pedestrianWater: {
      deep: [
        1315,
        420
      ],
      floor_h: 38,
      pool_h: 40,
      note: "main's swimmer test stands in the Deep under the skylight shaft; candidate 6's page G eye [1320,404] is 16 m north of it (the floor unchanged)"
    },
    fallRescue: {
      rule: "a fall that ends in water or off walkable ground fades to a path node that is never submerged (FLIGHT \xA72.4: fadeShore / fadeApron / the Deep jetty)",
      measured: "1,618 touchdowns on a 40 m grid (water and > 40\xB0 ground): 0 submerged returns on candidate 6 (0 on candidate 5); 26 returns stand against a rail or support or 0.4\u20130.8 off the node's deck (22 on candidate 5), listed in final8/probes"
    },
    rideChunkRule: "v2.2's rule (every chunk resident before a feet \u2192 mover boarding) now covers the cruiser (V), every boat and the yacht's helm; no hull moves while any chunk is missing; a fall (never refused) puts every missing chunk first and the canopy holds at an unloaded boundary",
    kitchen: {
      board: "kitchen/geometry.ts KITCHEN_BOARD, yacht-local [-2.6, main deck 3.85, -10.6]: it sails with the yacht, no land anchor",
      measured: "at the yacht's mooring the menu board stands at [1617.4,3.85,1329.4] over the harbour water (seabed -12), district harbour; the yacht's whole 14 x 44 hull is inside the harbour chunk and the galley opens only aboard, so it needs the harbour chunk resident like the fleet",
      rule: "an open service holds the body: a chosen page while cooking returns to the galley on Walk (main: Choose Walk and Resume); after Exit a chosen page is a visit again (Stage A walk-out)"
    },
    homes: {
      plots: "home/ownership.ts HOME_PLOTS: plot.terraces.1-3, plot.bight.1-4 (one per member, first come); home/site.ts reads each plot from the bake (outline centre, door xy and height), so the homes follow these reserves",
      measured: "on the candidate-6 bake all seven plots are graded pads: ground within 0.05 of the door height over the whole 52 x 32 home plot, dry, the door on a path node, no path node inside the 16 x 22 cottage; plot.terraces.3 has one path node at its plot corner (local [25.4,13.7]); plot.terraces.1 is the v2.2 plot (R3-32 margin 5.83 of 6 still open)"
    },
    comfort: "one comfort source: reduced motion and calm reach the fleet (wind off, no bob), the cruiser (no lean, camera cut) and the parachute (comfort camera) through the registry; the stricter rule wins"
  },
  regions: [
    {
      id: "mountainV2",
      kind: "placedWorld",
      label: "Mountain v2",
      offset: {
        x: 1308,
        y: 54,
        z: 764
      },
      footprint: {
        minX: 1108,
        maxX: 1508,
        minZ: 368,
        maxZ: 848
      },
      source: "src/harbour/mountain/** (geography hearth-mountain-geo-2), placed by src/harbour/horizon/regions/mountainV2/placement.ts: horizon = native + offset",
      ground: "land/mountainV2/ground.ts mountainV2Height: v2 land wins south of native z -294, the higher of v2 and the Crown north of it; the harbour island is the Foot terrace (53.95 + the lawn hump); v2 sea inside 40 m of v2 land is an apron from 53.95 to the Horizon; the Horizon elsewhere",
      data: "land/mountainV2/v2-data.json (scripts/horizon/dump-mountain-v2.mjs)",
      decisions: [
        "D-M1",
        "D-M2",
        "D-M3",
        "D-M4",
        "D-M5",
        "D-M6",
        "D-M7",
        "D-M8",
        "D-M9",
        "D-M10"
      ],
      summitNote: "v2's summit crest (native (-11,109.24,-312), Horizon [1297,452] h 163.24) stands 5.2 eu above landforms.crown.summitH 158 at the Crown summit [1310,470]: north of native z -294 D-M2 keeps the higher of v2 and the Crown, and v2 is the higher there (pass-5 deviation, recorded in docs/horizon/HANDOFF-notes/land.md); the observatory and L02 stay at 158"
    }
  ],
  retired_v2_6: {
    "roads.V02": {
      value: {
        label: "Crown Road",
        pts: [
          [
            1433.3,
            335.6
          ],
          [
            1445,
            430
          ],
          [
            1445,
            520
          ],
          [
            1400,
            620
          ],
          [
            1370,
            690
          ]
        ],
        profile: "road",
        length_m: 381,
        structures: [
          "shoulderTunnel"
        ],
        end: "turning circle at [1370,690]",
        v1_8_pts: [
          [
            1500,
            340
          ],
          [
            1445,
            430
          ],
          [
            1445,
            520
          ],
          [
            1400,
            620
          ],
          [
            1370,
            690
          ]
        ]
      },
      why: "D-M4: Crown Road retired; v2 road is the mountain road"
    },
    "structures.shoulderTunnel": {
      value: {
        xy: [
          1445,
          480
        ],
        kind: "tunnel",
        length_m: 110
      },
      why: "D-M4 (Crown Road retired)"
    },
    "structures.dam": {
      value: {
        xy: [
          1140,
          905
        ],
        kind: "dam",
        face: "south",
        spillwayArch: "Ring Run gate 4",
        apron: "S1 half-pipe",
        crest: "walk with plaques",
        gallery: "stair in the east abutment from the apron to the crest, past the plaques (does not enter the Undercroft)",
        faceLight: "dam.glassFace"
      },
      why: "D-M3: v2 glass dam is the one Fund picture; Stillwater drains over a natural rock sill"
    },
    "structures.lakesideSwitchback": {
      value: {
        kind: "switchbackRamp",
        route: "yearWalk",
        bbox: [
          [
            1274,
            843
          ],
          [
            1331,
            889
          ]
        ],
        legs: 7,
        pitch_m: 7.4,
        note: "v1.9 (T0 #16): the Year Walk's seven legs down the Shoulder's south-west corner to the lake terrace; each leg's downhill shoulder is carried to the leg below as a masonry retaining wall (the builder grounds it: no leg hangs over the next)"
      },
      why: "D-M5 (the Year Walk leaves the Foot terrace on v2 road and V03; the Lakeside zig-zag is not laid)"
    },
    "structures.s1Flyover": {
      value: {
        xy: [
          1345,
          744
        ],
        kind: "skateFlyover",
        carries: "S1 (the upper pass)",
        length_m: 44,
        width_m: 4,
        from: [
          1363.5,
          752.2
        ],
        to: [
          1326.6,
          735.7
        ],
        deck: "S1's own grade, 89.8 \u2192 83.4",
        over: "S1's lower pass at [1353.6,747.9] (76.9), 11.5 below",
        opening_m: 12,
        rails: "both edges",
        bents: "outside the lower pass's corridor (2 m + 1 m margin either side of its centreline)",
        decided: "D-C15 (recommended, accepted Jonathan 2026-09-27)",
        note: "v2.0: a route's self-crossing is not a register pair; P12 proves it (was a 13.4 eu unsupported run at [1358,750])"
      },
      why: "D-M5 (the Shoulder sweep and its self-crossing are retired)"
    },
    "structures.crownWalkBridge": {
      value: {
        xy: [
          1410.1,
          605.8
        ],
        kind: "footbridge",
        route: "walk crown",
        span_m: 36,
        opening_m: 24,
        width_m: 3.2,
        deck: "the Crown walk on its own grade (119-122)",
        under: "Crown Road's cutting (99) and its January footway lane",
        note: "v1.9: the Crown walk hung 21 eu over Crown Road at [1400-1417,605] (span refused: no footing outside the corridors)"
      },
      why: "D-M4/D-M5 (the Crown walk rides v2 road verge; Crown Road retired)"
    },
    "structures.inletFootbridge": {
      value: {
        xy: [
          1161,
          731
        ],
        kind: "footbridge",
        deck: "lake rim walk",
        under: "the upper river at the lake inlet",
        deck_h: 55,
        note: "v1.9 (integrator 2): deck 55 over the inlet pool at the lake level 50 (clear 4.4, a river's 4); was 52 over a pool at 58-60"
      },
      why: "D-M3/D-M5: water.cup and water.river.upper retired; the inlet it crossed is v2 ground"
    },
    "underground.damGallery": {
      value: {
        xy: [
          1165,
          895
        ],
        note: "a stair inside the dam's east abutment from the apron to the crest past the plaques; it does NOT enter the Undercroft"
      },
      why: "D-M3 (the Stillwater dam is removed)"
    },
    "water.cup": {
      value: {
        cx: 1170,
        cy: 660,
        rx: 22,
        ry: 14,
        surface: 100,
        note: "tarn; paper-boat and River Run launch"
      },
      why: "D-M5 (the Cup tarn is Mountain v2 ground; v2 reservoir is the mountain water)"
    },
    "water.river.upper": {
      value: [
        [
          1170,
          660
        ],
        [
          1165,
          700
        ],
        [
          1160,
          740
        ]
      ],
      why: "D-M3/D-M5 (v2 gorge river replaces the upper river)"
    },
    "water.dam": {
      value: {
        xy: [
          1140,
          905
        ],
        facing: "south (toward the square)",
        crestLength: 44,
        instrument: "L01 at [1172,912]"
      },
      why: "D-M3 (the Stillwater dam is removed; L01 is on v2 dam crest)"
    },
    "walks.crownFromGondola": {
      value: {
        pts: [
          [
            1335,
            535
          ],
          [
            1322,
            517
          ],
          [
            1310,
            500
          ]
        ],
        profile: "walk",
        length_m: 43,
        v1_9_pts: [
          [
            1360,
            560
          ],
          [
            1330,
            520
          ],
          [
            1310,
            500
          ]
        ],
        levels: [
          {
            xy: [
              1335,
              535
            ],
            h: 150,
            why: "the station deck"
          },
          {
            xy: [
              1310,
              500
            ],
            h: 154,
            why: "the summit junction (walk summit on to L02 [1310,470] at 158)"
          }
        ],
        note_v2_0: "D-A3: a 43 m leg at 9 % from the station at grade to the summit junction (the station \u2192 L02 walk is \u2248 70 m of plan and 8 m of climb, step-free); the builder's hard-coded switchback via [1405,595], [1450,565], [1430,500], [1350,440] goes"
      },
      why: "D-M6 (the Summit Commons station joins v2 summit paths; T2 graph)"
    },
    "thresholds.damPortage": {
      value: {
        id: "damPortage",
        xy: [
          1150,
          910
        ],
        modes: [
          "canoe\u2192feet\u2192canoe"
        ],
        action: "carry the canoe down the portage steps beside the apron"
      },
      why: "D-M3 (the dam portage is removed)"
    },
    crossings: {
      value: [
        {
          a: "walk lakerim",
          b: "river upper",
          at: [
            1161,
            731
          ],
          resolution: "over",
          structure: "inletFootbridge",
          kind: "crossing"
        },
        {
          a: "DEEP_RUN",
          b: "V02",
          at: [
            1445,
            520
          ],
          resolution: "under",
          note: "the Sea Passage passes \u2265 40 m beneath Crown Road and its tunnel",
          kind: "crossing"
        },
        {
          a: "S1",
          b: "damPortage",
          at: [
            1160.8,
            940.1
          ],
          resolution: "threshold",
          note: "dam apron: boards on the apron, the canoe portage meets it flush: the portage stair's foot (35.81) comes down to the apron (31) at the threshold; regrade owed (beds/structures)",
          movedFrom: [
            1160,
            935
          ],
          kind: "crossing",
          decided: "D-A7 (Jonathan 2026-09-27)",
          v1_9_note: "dam apron: boards on the apron; walkers on the crest above; RESERVED R-A7: S1 meets the dam portage stair (was the lake-rim walk) 4.8 eu apart; physically separated until Jonathan rules"
        },
        {
          a: "ZIP",
          b: "G1",
          at: [
            1437.5,
            927.4
          ],
          resolution: "under",
          note: "zip under gondola: 15.0 m below the gondola cable where they cross (profiles.cable.clear_eu 8); riders on the zip pass beneath the cabins",
          kind: "crossing",
          v1_9_resolution: "over",
          decided: "D-A2 option A (Jonathan 2026-09-27)",
          measured: {
            at: [
              1437.5,
              927.5
            ],
            separation_eu: 15,
            bake: "Stage A candidate 4 (the W5-A tower solve: the lowest tops keeping 8 eu over the ground at 1 % sag)"
          },
          v1_9_note: "zip 10.7 m above the gondola chord at 1 % sag",
          v1_9_at: [
            1442,
            921
          ],
          predicted_v2_0: {
            separation_eu: 29,
            g1_h: 88.8,
            zip_h: 59.8,
            source: "proposals/zip-over-g1.md, with the station at [1335,535]"
          },
          v2_0_measured: {
            at: [
              1441.5,
              920.8
            ],
            zip_h: 60.6,
            g1_h: 91.1,
            separation_eu: 30.45,
            bake: "candidate 3 (f1a1ec1)"
          },
          v2_0_note: "zip under gondola: 30.45 m below the gondola cable where they cross (profiles.cable.clear_eu 8); riders on the zip pass beneath the cabins"
        },
        {
          a: "walk crown",
          b: "ORE",
          at: [
            1374,
            615
          ],
          resolution: "over",
          note: "the Ore Line is in its tunnel here; the Crown walk crosses over the Ore Line 48 m north of the v1.7 point (two more crossings are listed below)",
          movedFrom: [
            1356,
            659
          ],
          kind: "crossing"
        },
        {
          a: "G1",
          b: "ORE",
          at: [
            1363.9,
            645.4
          ],
          resolution: "over",
          note: "cable above, rail in its tunnel",
          kind: "crossing",
          v1_9_at: [
            1375,
            625
          ]
        },
        {
          a: "G1",
          b: "V01",
          at: [
            1468,
            1044
          ],
          resolution: "over",
          structure: "cable clear \u2265 8 m; tower 1 beside the road",
          kind: "crossing",
          v1_9_at: [
            1469,
            1043
          ]
        },
        {
          a: "G1",
          b: "Crown Road",
          at: [
            1373.4,
            682
          ],
          resolution: "over",
          structure: "cable clear \u2265 8 m",
          kind: "crossing",
          v1_9_at: [
            1385,
            655
          ]
        },
        {
          a: "gondolaBase.walk",
          b: "G1",
          at: [
            1480,
            1090
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "river lower",
          b: "river upper",
          at: [
            1160,
            740
          ],
          resolution: "threshold",
          kind: "waterConfluence",
          source: "bake v1.8",
          note: "one waterway"
        },
        {
          a: "S1",
          b: "dam.apron.level",
          at: [
            1168,
            929.2
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 0.5 eu apart: regrade owed"
        },
        {
          a: "S1",
          b: "G1",
          at: [
            1378.6,
            701.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1391.9,
            701.5
          ]
        },
        {
          a: "S1",
          b: "G1",
          at: [
            1395.2,
            765.5
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1407.5,
            770.1
          ]
        },
        {
          a: "S1",
          b: "underground.bellGallery",
          at: [
            1308.2,
            510.9
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S1",
          b: "walk crown",
          at: [
            1310,
            500
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S1",
          b: "walk crownFromGondola",
          at: [
            1310,
            500
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "S1",
          b: "walk summit",
          at: [
            1310,
            500
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "V02",
          b: "southPortal.link",
          at: [
            1370,
            690
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V02",
          b: "walk crown",
          at: [
            1406.5,
            606.3
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "under by 21.5 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk crown",
          b: "crownLaunch.stair",
          at: [
            1343.7,
            474.9
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "walk crown",
          b: "G1",
          at: [
            1352.3,
            601.4
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1365.9,
            586.1
          ]
        },
        {
          a: "walk crown",
          b: "G1",
          at: [
            1357,
            619.2
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1372.4,
            615.2
          ]
        },
        {
          a: "walk crown",
          b: "ORE",
          at: [
            1351.2,
            471.2
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "walk crown",
          b: "ORE",
          at: [
            1370.4,
            581
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "walk crown",
          b: "stepsPortage",
          at: [
            1355.2,
            469.9
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 124.3 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk crown",
          b: "stepsPortage",
          at: [
            1367.8,
            476.7
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 126.6 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk crown",
          b: "underground.bellGallery",
          at: [
            1317,
            494.6
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "walk crown",
          b: "walk crownFromGondola",
          at: [
            1310,
            500
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "walk crown",
          b: "walk summit",
          at: [
            1310,
            500
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "walk crown",
          b: "yearWalk",
          at: [
            1417.7,
            677.4
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction where the Crown walk leaves the Year Walk's January lane (D-C7): no marker, no mode change",
          v1_9_at: [
            1379.9,
            687.4
          ],
          movedFrom: [
            1379.9,
            687.4
          ],
          v1_9_note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk crown",
          b: "yearWalk",
          at: [
            1414.5,
            604.8
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 21.1 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk crownFromGondola",
          b: "G1",
          at: [
            1335,
            535
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1360,
            560
          ]
        },
        {
          a: "walk crownFromGondola",
          b: "walk summit",
          at: [
            1310,
            500
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "walk damCrest",
          b: "damGallery.exit",
          at: [
            1162,
            903
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk damCrest",
          b: "river lower",
          at: [
            1140.2,
            903
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "walk summit",
          b: "stepsPortage",
          at: [
            1310.1,
            445.5
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 120.4 eu: a named structure (footbridge, deck or passage) is owed; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "walk summit",
          b: "underground.bellGallery",
          at: [
            1310,
            470
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "yearWalk",
          b: "G1",
          at: [
            1375.7,
            690.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1385.1,
            671.2
          ]
        },
        {
          a: "yearWalk",
          b: "G1",
          at: [
            1375.5,
            689.9
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1388.6,
            686.7
          ]
        },
        {
          a: "yearWalk",
          b: "G1",
          at: [
            1416,
            844.9
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
          v1_9_at: [
            1421.9,
            833.4
          ]
        },
        {
          a: "yearWalk",
          b: "river upper",
          at: [
            1161.9,
            725.2
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "v1.9 (integrator 2): over by 5 eu on its deck beside the Inlet Footbridge; the inlet pool is level with the lake (was under a pool at 58-60)",
          v1_8_resolution: "under"
        },
        {
          a: "damGallery.flight.2",
          b: "damGallery.exit",
          at: [
            1170.6,
            910.8
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "S1",
          b: "yearWalk",
          at: [
            1266.9,
            842
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: ""
        },
        {
          a: "V01",
          b: "V02",
          at: [
            1433.3,
            335.6
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: ""
        },
        {
          a: "V02",
          b: "yearWalk",
          at: [
            1436,
            355.4
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: ""
        },
        {
          a: "walk lakerim",
          b: "damGallery.exit",
          at: [
            1166.2,
            905.1
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        }
      ],
      why: "v2.6: rows on retired routes (V02, the Shoulder Tunnel, the dam, the portage, the upper river, the Crown walk, the old G1 line, S1 upper half); the re-bake measures the new meetings"
    }
  }
};

// src/harbour/horizon/world/manifest.ts
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function point(value) {
  return Array.isArray(value) && value.length === 2 && value.every(Number.isFinite);
}
function parseHorizonManifest(value) {
  if (!record(value) || !record(value.scale) || typeof value.scale.factor !== "number" || !Number.isFinite(value.scale.factor) || value.scale.factor <= 0 || typeof value.scale.status !== "string" || !record(value.names) || typeof value.names.idRule !== "string" || !Array.isArray(value.hosts) || !Array.isArray(value.places) || !Array.isArray(value.districts) || !Array.isArray(value.neighbourhoods) || !Array.isArray(value.views) || !Array.isArray(value.crossings) || !Array.isArray(value.routePairNotes) || !Array.isArray(value.thresholds) || !record(value.reserves) || !record(value.journey)) {
    throw new Error("Invalid Horizon manifest");
  }
  for (const crossing of value.crossings) {
    if (!record(crossing) || typeof crossing.a !== "string" || typeof crossing.b !== "string" || typeof crossing.resolution !== "string" || !["over", "under", "threshold"].includes(crossing.resolution) || !(point(crossing.at) || typeof crossing.at === "string" && crossing.at.trim().length > 0)) {
      throw new Error("Invalid Horizon crossing");
    }
  }
  for (const note of value.routePairNotes) {
    if (!record(note) || typeof note.a !== "string" || typeof note.b !== "string" || typeof note.verification !== "string" || !Array.isArray(note.sharedPlanPoints) || !note.sharedPlanPoints.every(point) || "resolution" in note) {
      throw new Error("Invalid Horizon route-pair note");
    }
  }
  for (const threshold of value.thresholds) {
    if (!record(threshold) || !Array.isArray(threshold.modes) || !threshold.modes.length || threshold.modes.some((mode) => typeof mode !== "string" || mode.split("\u2192").length < 2 || mode.split("\u2192").some((step) => !step.trim()))) {
      throw new Error("Invalid Horizon threshold mode sequence");
    }
  }
  const carried = value.carriedThresholds ?? [];
  if (!Array.isArray(carried)) throw new Error("Invalid Horizon carried thresholds");
  for (const threshold of carried) {
    if (!record(threshold) || typeof threshold.id !== "string" || typeof threshold.carriedBy !== "string" || !threshold.carriedBy || typeof threshold.action !== "string" || !Array.isArray(threshold.modes) || !threshold.modes.length || threshold.modes.some((mode) => typeof mode !== "string" || mode.split("\u2192").length < 2 || mode.split("\u2192").some((step) => !step.trim()))) {
      throw new Error("Invalid Horizon carried threshold");
    }
  }
  const plotIds = /* @__PURE__ */ new Set();
  const retiredIds = value.reserves.retiredPlaceIds;
  if (!Array.isArray(retiredIds) || retiredIds.some((id) => typeof id !== "string")) {
    throw new Error("Invalid Horizon retired reserve IDs");
  }
  for (const area of ["terraces", "bightShore"]) {
    const reserve = value.reserves[area];
    if (!record(reserve) || !Array.isArray(reserve.plots) || !reserve.plots.every(point) || !Array.isArray(reserve.rot_deg) || !reserve.rot_deg.every(Number.isFinite) || !Array.isArray(reserve.placeIds) || reserve.plots.length !== reserve.rot_deg.length || reserve.plots.length !== reserve.placeIds.length) {
      throw new Error("Invalid Horizon reserve arrays");
    }
    for (const id of reserve.placeIds) {
      if (typeof id !== "string" || !id || plotIds.has(id) || retiredIds.includes(id)) {
        throw new Error("Invalid Horizon reserve ID");
      }
      plotIds.add(id);
    }
  }
  if (!record(value.reserves.small)) throw new Error("Invalid Horizon small reserves");
  for (const reserve of Object.values(value.reserves.small)) {
    if (!record(reserve) || !point(reserve.xy) || typeof reserve.placeId !== "string" || !reserve.placeId || plotIds.has(reserve.placeId) || retiredIds.includes(reserve.placeId)) {
      throw new Error("Invalid Horizon small reserve");
    }
    plotIds.add(reserve.placeId);
  }
  return value;
}
var HORIZON_MANIFEST = parseHorizonManifest(MANIFEST_default);
function requireScaleFactor(manifest = HORIZON_MANIFEST) {
  if (!manifest.scale.status.trim().toLowerCase().startsWith("confirmed")) throw new Error("D13 open");
  return manifest.scale.factor;
}

// src/harbour/horizon/land/terrain/geometry.ts
var clamp = (n, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, n));
function contains(poly, x, z) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if (a[1] > z !== b[1] > z && x < (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}
function segmentPoint(x, z, a, b) {
  const dx = b[0] - a[0], dz = b[1] - a[1];
  const t = clamp(((x - a[0]) * dx + (z - a[1]) * dz) / (dx * dx + dz * dz || 1));
  const px = a[0] + t * dx, pz = a[1] + t * dz;
  return { distance: Math.hypot(x - px, z - pz), t, x: px, z: pz };
}
function polygonDistance(poly, x, z) {
  let d = Infinity;
  for (let i = 0; i < poly.length; i++) d = Math.min(d, segmentPoint(x, z, poly[i], poly[(i + 1) % poly.length]).distance);
  return contains(poly, x, z) ? d : -d;
}
var arcs = /* @__PURE__ */ new WeakMap();
function polylineArcs(points) {
  let cached2 = arcs.get(points);
  if (!cached2) {
    const lengths = points.slice(1).map((b, i) => Math.hypot(b[0] - points[i][0], b[2] - points[i][2]));
    cached2 = { lengths, total: lengths.reduce((sum, length) => sum + length, 0) };
    arcs.set(points, cached2);
  }
  return cached2;
}

// src/harbour/horizon/land/coast/index.ts
var cached;
function buildCoastline(samplesPerSpan = 12) {
  const scale = requireScaleFactor(), points = HORIZON_MANIFEST.island.outline;
  const at = (i) => points[(i + points.length) % points.length];
  const result = [];
  for (let i = 0; i < points.length; i++) for (let j = 0; j < samplesPerSpan; j++) {
    const t = j / samplesPerSpan, t2 = t * t, t3 = t2 * t;
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const axis = (n) => 0.5 * (2 * p1[n] + (-p0[n] + p2[n]) * t + (2 * p0[n] - 5 * p1[n] + 4 * p2[n] - p3[n]) * t2 + (-p0[n] + 3 * p1[n] - 3 * p2[n] + p3[n]) * t3) * scale;
    result.push([axis(0), axis(1)]);
  }
  return result;
}
var outline = () => cached ??= buildCoastline();
var islandContains = (x, z) => contains(outline(), x, z);

// src/harbour/horizon/land/water/index.ts
function waterInfluence(water, x, z) {
  const p = water.points;
  if (p.length > 1) {
    const { lengths, total } = polylineArcs(p);
    let best = Infinity, level = 0, progress = 0, grade = 0, travelled = 0, segment = 0;
    for (let i = 1; i < p.length; i++) {
      const a = p[i - 1], b = p[i], length = lengths[i - 1], hit = segmentPoint(x, z, [a[0], a[2]], [b[0], b[2]]);
      if (hit.distance < best - 1e-9) {
        best = hit.distance;
        level = a[1] + (b[1] - a[1]) * hit.t;
        progress = (travelled + hit.t * length) / (total || 1);
        grade = Math.abs(a[1] - b[1]) / (length || 1);
        segment = i;
      }
      travelled += length;
    }
    let distance2 = best - water.width / 2;
    const ends = [[p[0], p[1], 1], [p[p.length - 1], p[p.length - 2], p.length - 1]];
    for (const [end, next, index] of ends) {
      if (segment !== index) continue;
      const dx = end[0] - next[0], dz = end[2] - next[2], l = Math.hypot(dx, dz) || 1, over = ((x - end[0]) * dx + (z - end[2]) * dz) / l;
      if (over > 0) distance2 = Math.max(distance2, over);
    }
    return { distance: distance2, level, progress, grade };
  }
  return { distance: -polygonDistance(water.outline, x, z), level: water.level, progress: 0, grade: 0 };
}
function waterHeightAt(water, x, z) {
  if ((water.kind === "sea" || water.kind === "lagoon") && islandContains(x, z)) return null;
  const p = waterInfluence(water, x, z);
  return p.distance <= 0 ? p.level : null;
}

// src/harbour/horizon/regions/mountainV2/placement.ts
var MOUNTAIN_V2_OFFSET = { x: 1308, y: 54, z: 764 };
var MOUNTAIN_V2_NATIVE_BOUNDS = { minX: -180, maxX: 180, minZ: -310, maxZ: 84, minY: -8, maxY: 150 };
var MOUNTAIN_V2_GRID_BOUNDS = { minX: -200, maxX: 200, minZ: -396, maxZ: -30 };
var MOUNTAIN_V2_FOOTPRINT = {
  minX: MOUNTAIN_V2_GRID_BOUNDS.minX + MOUNTAIN_V2_OFFSET.x,
  // 1108
  maxX: MOUNTAIN_V2_GRID_BOUNDS.maxX + MOUNTAIN_V2_OFFSET.x,
  // 1508
  minZ: MOUNTAIN_V2_GRID_BOUNDS.minZ + MOUNTAIN_V2_OFFSET.z,
  // 368
  maxZ: MOUNTAIN_V2_NATIVE_BOUNDS.maxZ + MOUNTAIN_V2_OFFSET.z
  // 848 (the town island's south edge)
};

// src/harbour/horizon/land/mountainV2/ground.ts
var MOUNTAIN_V2_ISLAND = { radius: 84, lawn: 58, terrace: 10.4, level: -0.05, sea: -0.45 };
var MOUNTAIN_V2_FOOT = MOUNTAIN_V2_ISLAND.level + MOUNTAIN_V2_OFFSET.y;

// src/harbour/horizon/land/underground/oreRoad.ts
var door = HORIZON_MANIFEST.underground.doors.southPortal;
var mouth = [door.xy[0] - 8, door.xy[0] + 8, door.xy[1] - 9, door.xy[1] + 9];

// src/harbour/horizon/land/terrain/index.ts
var GEOGRAPHY_REVISION = "horizon-geo-1";
var WALKABLE_DEGREES = HORIZON_MANIFEST.profiles.walkable.slope_max_deg;
var WALKABLE_SLOPE = Math.tan(WALKABLE_DEGREES * Math.PI / 180);
var TERRAIN_SURFACE_PALETTE = [
  { id: "sand", color: "#e0cfa5", night: "#6c7282" },
  { id: "bankedTurf", color: "#7d9a58", night: "#37453c" },
  { id: "duff", color: "#8a6f4f", night: "#37453c" },
  { id: "ochre", color: "#d7ac6b", night: "#5d5660" },
  { id: "rock.crown", color: "#a3998a", night: "#6c7282", strata: "Crown" },
  { id: "rock.crown.ledge", color: "#c4bba9", night: "#8991a1", strata: "Crown" },
  { id: "rock.notch", color: "#b3a58f", night: "#6c7282", strata: "Notch" },
  { id: "rock.notch.ledge", color: "#d3bf99", night: "#8991a1", strata: "Notch" },
  { id: "rock.ochre", color: "#8f6236", night: "#5d5660", strata: "Ochre" },
  { id: "rock.ochre.ledge", color: "#d7ac6b", night: "#8a5f45", strata: "Ochre" },
  { id: "rock.sea", color: "#9a9489", night: "#6c7282", strata: "Sea cliff" },
  { id: "rock.sea.ledge", color: "#c4bba9", night: "#8991a1", strata: "Sea cliff" },
  { id: "paved", color: "#c9b891", night: "#6c7282" },
  { id: "packedEarth", color: "#b39f78", night: "#5d5660" },
  { id: "apron", color: "#d9d2c2", night: "#6c7282" },
  { id: "boardwalk", color: "#b08a5e", night: "#3a2c26" },
  { id: "cobble", color: "#bfa982", night: "#6c7282" },
  { id: "gravel", color: "#cbbb98", night: "#6c7282" },
  { id: "plaza", color: "#d3bf99", night: "#6c7282" },
  { id: "snow", color: "#f1f1ec", night: "#8fa3c7" },
  { id: "scree", color: "#b8ad98", night: "#6c7282" }
];
var BIOME_GROUNDS = ["sand", "bankedTurf", "duff", "ochre", "scree"].map((id) => TERRAIN_SURFACE_PALETTE.findIndex((p) => p.id === id));
var ROAD_BATTER = 1 / 1.5;
var PAINT = Object.fromEntries(TERRAIN_SURFACE_PALETTE.map((p, i) => [p.id, i]));
function sampleTerrain(field, x, z) {
  const gx = clamp(x / field.step, 0, field.columns - 1), gz = clamp(z / field.step, 0, field.rows - 1);
  const i = Math.min(field.columns - 2, Math.floor(gx)), j = Math.min(field.rows - 2, Math.floor(gz));
  const tx = gx - i, tz = gz - j, n = j * field.columns + i;
  const nw = field.heights[n], ne = field.heights[n + 1], sw = field.heights[n + field.columns], se = field.heights[n + field.columns + 1];
  return tx + tz <= 1 ? nw + tx * (ne - nw) + tz * (sw - nw) : se + (1 - tx) * (sw - se) + (1 - tz) * (ne - se);
}
function terrainNormal(field, x, z) {
  const gx = clamp(x / field.step, 0, field.columns - 1), gz = clamp(z / field.step, 0, field.rows - 1);
  const i = Math.min(field.columns - 2, Math.floor(gx)), j = Math.min(field.rows - 2, Math.floor(gz)), n = j * field.columns + i;
  const nw = field.heights[n], ne = field.heights[n + 1], sw = field.heights[n + field.columns], se = field.heights[n + field.columns + 1];
  const first = gx - i + gz - j <= 1;
  const dx = (first ? ne - nw : se - sw) / field.step, dz = (first ? sw - nw : se - ne) / field.step;
  const length = Math.hypot(dx, 1, dz);
  return [-dx / length, 1 / length, -dz / length];
}
function terrainTriangleVisible(x, z, cuts) {
  return !cuts.mouths.some((m) => contains(m.outline, x, z));
}

// src/harbour/horizon/runtime/geography.ts
var HORIZON_BODY_HEIGHT = 1.25;
var HORIZON_STEP_HEIGHT = 0.48;
var CELL = 24;
var key = (x, z) => `${Math.floor(x / CELL)}:${Math.floor(z / CELL)}`;
function projection(t, x, z) {
  const { a, b, c } = t, det = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2]);
  if (Math.abs(det) < 1e-8) return null;
  const u = ((b[2] - c[2]) * (x - c[0]) + (c[0] - b[0]) * (z - c[2])) / det;
  const v = ((c[2] - a[2]) * (x - c[0]) + (a[0] - c[0]) * (z - c[2])) / det;
  return u >= -1e-6 && v >= -1e-6 && u + v <= 1.000001 ? u * a[1] + v * b[1] + (1 - u - v) * c[1] : null;
}
function touchesAtHeight(t, y, x, z, radius) {
  let count = 0, ax = 0, az = 0, bx = 0, bz = 0;
  for (let i = 0; i < 3; i++) {
    const a = i === 0 ? t.a : i === 1 ? t.b : t.c, b = i === 0 ? t.b : i === 1 ? t.c : t.a;
    if ((y - a[1]) * (y - b[1]) > 0 || Math.abs(b[1] - a[1]) < 1e-8) continue;
    const f2 = (y - a[1]) / (b[1] - a[1]), px = a[0] + f2 * (b[0] - a[0]), pz = a[2] + f2 * (b[2] - a[2]);
    if (count++ === 0) {
      ax = px;
      az = pz;
    } else {
      bx = px;
      bz = pz;
      break;
    }
  }
  if (count < 2) return false;
  const dx = bx - ax, dz = bz - az, d = dx * dx + dz * dz, f = d ? Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / d)) : 0;
  return Math.hypot(x - ax - f * dx, z - az - f * dz) < radius;
}
function createHorizonGeography(field, cuts) {
  const dynamic = /* @__PURE__ */ new Set();
  const solids = [], cells = /* @__PURE__ */ new Map();
  let owners = new Uint32Array(1024), offsets = new Uint32Array(1024), normals = new Float32Array(1024 * 3), bounds = new Float64Array(1024 * 4), count = 0, chunks = 0;
  function grow(need) {
    if (need <= owners.length) return;
    let size = owners.length;
    while (size < need) size *= 2;
    const o = new Uint32Array(size), f = new Uint32Array(size), n = new Float32Array(size * 3), b = new Float64Array(size * 4);
    o.set(owners);
    f.set(offsets);
    n.set(normals);
    b.set(bounds);
    owners = o;
    offsets = f;
    normals = n;
    bounds = b;
  }
  function addSolids(list) {
    const kept = list.filter((s) => s.role !== "marker");
    if (!kept.length) return;
    chunks++;
    grow(count + kept.reduce((n, s) => n + s.indices.length / 3, 0));
    for (const solid2 of kept) {
      const owner2 = solids.push(solid2) - 1, p = solid2.positions;
      for (let i = 0; i < solid2.indices.length; i += 3) {
        const vertex = (n) => {
          const j = solid2.indices[i + n] * 3;
          return [p[j], p[j + 1], p[j + 2]];
        };
        const a = vertex(0), b = vertex(1), c = vertex(2), u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
        const nx = u[1] * v[2] - u[2] * v[1], ny = u[2] * v[0] - u[0] * v[2], nz = u[0] * v[1] - u[1] * v[0], len = Math.hypot(nx, ny, nz);
        if (len < 1e-8) continue;
        const id = count++;
        owners[id] = owner2;
        offsets[id] = i;
        normals.set([nx / len, ny / len, nz / len], id * 3);
        const minX = Math.min(a[0], b[0], c[0]), maxX = Math.max(a[0], b[0], c[0]), minZ = Math.min(a[2], b[2], c[2]), maxZ = Math.max(a[2], b[2], c[2]);
        const span = Math.max(maxX - minX, maxZ - minZ), magnitude = Math.max(1, Math.abs(minX), Math.abs(maxX), Math.abs(minZ), Math.abs(maxZ));
        const det = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2]);
        const roundoff = 256 * Number.EPSILON * (magnitude + span + CELL + 1) ** 2;
        const pad = Math.abs(det) < 1e-8 ? roundoff : Math.abs(det) <= 16 * roundoff ? Infinity : 2e-6 * span + 8 * roundoff * (span + 1) / Math.abs(det);
        bounds.set([minX - pad, maxX + pad, minZ - pad, maxZ + pad], id * 4);
        for (let x = Math.floor(Math.min(a[0], b[0], c[0]) / CELL); x <= Math.floor(Math.max(a[0], b[0], c[0]) / CELL); x++)
          for (let z = Math.floor(Math.min(a[2], b[2], c[2]) / CELL); z <= Math.floor(Math.max(a[2], b[2], c[2]) / CELL); z++) {
            const k = `${x}:${z}`, bucket = cells.get(k) ?? [];
            bucket.push(id);
            cells.set(k, bucket);
          }
      }
    }
  }
  addSolids(cuts.solids);
  const nearby = (x, z) => cells.get(key(x, z)) ?? [];
  const face = { a: [0, 0, 0], b: [0, 0, 0], c: [0, 0, 0], normal: [0, 0, 0], solid: solids[0] };
  function triangle(id) {
    const solid2 = solids[owners[id]], offset = offsets[id], p = solid2.positions;
    for (let n = 0; n < 3; n++) {
      const j = solid2.indices[offset + n] * 3, v = n === 0 ? face.a : n === 1 ? face.b : face.c;
      v[0] = p[j];
      v[1] = p[j + 1];
      v[2] = p[j + 2];
      face.normal[n] = normals[id * 3 + n];
    }
    face.solid = solid2;
    return face;
  }
  function outside(id, x, z, radius = 0) {
    const i = id * 4;
    return x + radius < bounds[i] || x - radius > bounds[i + 1] || z + radius < bounds[i + 2] || z - radius > bounds[i + 3];
  }
  const contactFaces = /* @__PURE__ */ new Set();
  function owner(x, z) {
    for (const d of dynamic) if (d.owns?.(x, z)) return d;
    return null;
  }
  function groundAt(x, z) {
    const o = owner(x, z);
    return o?.ground ? o.ground(x, z) : sampleTerrain(field, x, z);
  }
  function surface(x, z, y, step = 0.48, staticOnly2 = false) {
    if (x < 0 || z < 0 || x > field.width || z > field.depth) return null;
    let best = null;
    if (staticOnly2 || !owner(x, z)) {
      const g = sampleTerrain(field, x, z), normal = terrainNormal(field, x, z);
      const n = Array.isArray(normal) ? normal : [0, 1, 0];
      best = terrainTriangleVisible(x, z, cuts) && (y === void 0 || g <= y + step) ? { id: "terrain", y: g, nx: n[0], ny: n[1], nz: n[2], material: "grass", slope: Math.acos(Math.min(1, n[1])) * 180 / Math.PI } : null;
    }
    for (const id of nearby(x, z)) {
      if (normals[id * 3 + 1] <= 1e-3 || !solids[owners[id]].walkable || outside(id, x, z)) continue;
      const t = triangle(id);
      const h = projection(t, x, z);
      if (h === null || y !== void 0 && h > y + step || best && h < best.y) continue;
      best = { id: t.solid.id, y: h, nx: t.normal[0], ny: t.normal[1], nz: t.normal[2], material: t.solid.surface, slope: Math.acos(Math.min(1, t.normal[1])) * 180 / Math.PI };
    }
    if (!staticOnly2) for (const d of dynamic) {
      const h = d.surface(x, z, y, step);
      if (h && (!best || h.y > best.y)) best = h;
    }
    return best;
  }
  function ceiling(x, z, y, staticOnly2 = false) {
    let value = Infinity;
    for (const id of nearby(x, z)) {
      if (normals[id * 3 + 1] >= -1e-3 || outside(id, x, z)) continue;
      const t = triangle(id);
      const h = projection(t, x, z);
      if (h !== null && h > y + 0.1) value = Math.min(value, h);
    }
    if (!staticOnly2) for (const d of dynamic) value = Math.min(value, d.ceiling(x, z, y));
    return value;
  }
  function contact(x, z, y, radius = 0.3, travel, ignoreDynamic = false, bodyHeight = HORIZON_BODY_HEIGHT) {
    if (x < radius || z < radius || x > field.width - radius || z > field.depth - radius) {
      const nx = x < radius ? 1 : x > field.width - radius ? -1 : 0, nz = z < radius ? 1 : z > field.depth - radius ? -1 : 0, n = Math.hypot(nx, nz);
      return { id: "world-boundary", nx: nx / n, nz: nz / n };
    }
    if (!ignoreDynamic) for (const d of dynamic) {
      const h = d.contact(x, z, y, radius, travel, bodyHeight);
      if (h && (!travel || h.nx * travel[0] + h.nz * travel[1] <= 1e-8)) return h;
    }
    const all = contactFaces;
    all.clear();
    for (let ix = -1; ix <= 1; ix++) for (let iz = -1; iz <= 1; iz++) for (const t of nearby(x + ix * radius, z + iz * radius)) all.add(t);
    for (const id of all) {
      if (Math.abs(normals[id * 3 + 1]) > 0.95 || outside(id, x, z, radius)) continue;
      const t = triangle(id);
      if (travel && t.normal[0] * travel[0] + t.normal[2] * travel[1] >= -1e-8) continue;
      if (Math.max(t.a[1], t.b[1], t.c[1]) <= y + HORIZON_STEP_HEIGHT || Math.min(t.a[1], t.b[1], t.c[1]) > y + bodyHeight) continue;
      for (let level = 0; level < 3; level++) {
        const h = y + (level === 0 ? 0.2 : level === 1 ? 0.65 : bodyHeight);
        if (touchesAtHeight(t, h, x, z, radius)) {
          const length = Math.hypot(t.normal[0], t.normal[2]);
          return { id: t.solid.id, nx: t.normal[0] / length, nz: t.normal[2] / length };
        }
      }
    }
    for (const id of nearby(x, z)) {
      if (normals[id * 3 + 1] >= -1e-3 || outside(id, x, z)) continue;
      const t = triangle(id);
      const h = projection(t, x, z);
      if (h !== null && h > y + 0.1 && h < y + bodyHeight) return { id: t.solid.id, nx: 0, nz: 0 };
    }
    return null;
  }
  const blocker = (x, z, y, radius = 0.3, travel, ignoreDynamic = false) => contact(x, z, y, radius, travel, ignoreDynamic)?.id ?? null;
  const blocked = (x, z, y, radius = 0.3) => blocker(x, z, y, radius) !== null;
  function ownedWater(x, z) {
    return owner(x, z)?.waterLevel?.(x, z) ?? null;
  }
  function waterLevel(x, z, feet) {
    const own = ownedWater(x, z);
    if (own !== null) return own;
    let level = null, underground = false;
    for (const w of cuts.waters) {
      if (w.kind === "dry") continue;
      const h = waterHeightAt(w, x, z);
      if (h === null) continue;
      if (w.underground) {
        underground = true;
        if (feet === void 0 || feet > h + 1) continue;
      }
      if (feet !== void 0 && h - feet > w.depth + HORIZON_BODY_HEIGHT) continue;
      if (level === null || (feet === void 0 ? h > level : Math.abs(h - feet) < Math.abs(level - feet) || Math.abs(h - feet) === Math.abs(level - feet) && h > level)) level = h;
    }
    return level ?? (sampleTerrain(field, x, z) < -0.2 && (feet === void 0 || !underground) ? 0 : null);
  }
  function submerged(x, z, feet) {
    const own = ownedWater(x, z);
    if (own !== null && own - feet > 0.35) return true;
    return cuts.waters.some((w) => {
      if (w.kind === "dry" || w.underground && feet > w.level + 1) return false;
      const level = waterHeightAt(w, x, z);
      return level !== null && level - feet > 0.35 && level - feet <= w.depth + HORIZON_BODY_HEIGHT;
    }) || feet < -0.65 && !cuts.waters.some((w) => w.underground && waterHeightAt(w, x, z) !== null);
  }
  function cameraBlocked(from, to, ignoreDynamic = false) {
    const length = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]), steps = Math.ceil(length / 0.75);
    for (let i = 1; i <= steps; i++) {
      const f = i / steps, x = from[0] + (to[0] - from[0]) * f, y = from[1] + (to[1] - from[1]) * f, z = from[2] + (to[2] - from[2]) * f;
      if (from[1] >= groundAt(from[0], from[2]) - 0.3 && groundAt(x, z) > y - 0.15) return true;
      if (blocker(x, z, y - 0.3, 0.18, void 0, ignoreDynamic)) return true;
    }
    return false;
  }
  const staticOnly = { surface: (x, z, y, step) => surface(x, z, y, step, true), ceiling: (x, z, y) => ceiling(x, z, y, true), blocked: (x, z, y, radius = 0.3) => blocker(x, z, y, radius, void 0, true) !== null };
  return { staticOnly, addDynamic(provider) {
    dynamic.add(provider);
    return () => dynamic.delete(provider);
  }, surface, ceiling, blocked, blocker, contact, waterLevel, submerged, cameraBlocked, get indexStats() {
    return { triangles: count, referenceBytes: (owners.byteLength + offsets.byteLength + normals.byteLength + bounds.byteLength) * count / Math.max(1, owners.length), cells: cells.size, chunks };
  }, addSolids, ground: groundAt };
}

// src/harbour/horizon/land/terrain/asset.ts
var MAGIC = "HZGEO001";
var HEADER = 96;
var ENTRIES = 32;
var LODS = ["full", "lite", "journey"];
function decodeTerrainAsset(buffer, lod = "full") {
  if (buffer.byteLength < HEADER + 3 * ENTRIES || buffer.byteLength > 25e5) throw new Error("Invalid terrain asset length");
  const view = new DataView(buffer), text = new TextDecoder();
  if (text.decode(new Uint8Array(buffer, 0, 8)) !== MAGIC) throw new Error("Invalid terrain asset magic");
  if (text.decode(new Uint8Array(buffer, 8, GEOGRAPHY_REVISION.length)) !== GEOGRAPHY_REVISION) throw new Error("Terrain revision mismatch");
  if (view.getUint32(32, true) !== buffer.byteLength || view.getUint32(36, true) !== 3) throw new Error("Invalid terrain asset header");
  const index = LODS.indexOf(lod);
  if (index < 0) throw new Error("Unknown terrain LOD");
  const entry = HEADER + index * ENTRIES;
  const columns = view.getUint32(entry, true), rows = view.getUint32(entry + 4, true), step = view.getFloat64(entry + 8, true);
  const offset = view.getUint32(entry + 16, true), count = view.getUint32(entry + 20, true);
  const width = view.getFloat64(40, true), depth = view.getFloat64(48, true);
  if (columns < 2 || rows < 2 || columns * rows !== count || !Number.isFinite(step) || step <= 0 || width !== (columns - 1) * step || depth !== (rows - 1) * step || offset < HEADER + 3 * ENTRIES || offset + count * 3 > buffer.byteLength) throw new Error("Invalid terrain lattice");
  const heights = new Float32Array(count), surfaces = new Uint8Array(count);
  for (let n = 0; n < count; n++) {
    heights[n] = view.getInt16(offset + n * 3, true) / 100;
    surfaces[n] = view.getUint8(offset + n * 3 + 2);
  }
  return { revision: GEOGRAPHY_REVISION, width, depth, step, columns, rows, heights, surfaces };
}
export {
  createHorizonGeography,
  decodeTerrainAsset
};
