import {funicularFootStationFloor} from '../../land/mountainV2/funicularFootStation.ts';
import {orchardJunctionAt} from '../../../mountain/orchardJunction.ts';
/**
 * Mountain v2 on the Horizon — the region's ground, decks, ceilings and solids (pass 5, T2).
 *
 * Every query converts Horizon → native on the way in and adds the offset back on the way out (placement.ts). The numbers
 * are v2's own: `scene/ground.ts groundHeightAt` (the island, the baked massif and the town channel), `mountain/surfaces.ts
 * queryWorldSurface` / `worldCeilingAt` over v2's deck list, and v2's solids — with the things this pass does not draw
 * (D-M8) taken out of the collision too, so nothing you cannot see stops you:
 *  - decks: every `WORLD_SURFACES` entry except the town race road's canal-bridge deck (the canal bridge is not drawn);
 *  - solids: `WORLD_SOLIDS` less the district fixtures (`district-art:*`: beds, logs, crates, rocks — not drawn);
 *  - edges: `EDGE_SOLIDS` (parapets, bridge rails, retaining walls), as v2 has them (north of native z −40 only).
 *
 * `contains` (the drawn footprint; the terrain tiles under it are hidden and the provider owns the ground there):
 *  - inside `insideMountainV2` (the grid rectangle, Horizon x 1108…1508, z 368…848), and
 *  - the massif (native −294 ≤ z < −48): v2's ground above −0.2 (land, not v2's sea) or `mountainContains` (a deck over low
 *    ground: the road, Orchard Lane, a skate branch);
 *  - north of the summit line (native z < −294, D-M2): v2's ground above −0.2 AND v2 at least as high as the Horizon's baked
 *    ground there (less `NORTH_TOLERANCE`) — where the Crown's own north face is higher it stays the Horizon's (the Throat,
 *    its collar, the skylight). Without a baked field (a test) this falls back to v2's walkable bound (native z ≥ −310);
 *  - the town island (native z ≥ −48): the Foot terrace, a disc of `FOOT_RADIUS` round v2's square (the terrace, the lawn
 *    and the channel; the shore that falls to v2's sea is the Horizon's lake shore);
 *  - never within `MOUTH_MARGIN` of a Horizon terrain mouth (`exclude`: the Ore Line's South Portal keeps its opening).
 */
import {walkingJoinGround} from './walkingJoinGround.ts';
import type {StructureSolid} from '../../land/interfaces.ts';
import {drawnRoadFloor} from './drawnRoadFloor.ts';
import {drawnRoadGroundCeiling} from './drawnRoadGround.ts';
import {groundHeightAt} from '../../../scene/ground.ts';
import {mountainContains,nearestOnRoute,MOUNTAIN_ROAD_LINE,ORCHARD_LANE_LINE,EDGE_SOLIDS,WORLD_BOUNDS,RIVER,RIVER_HALF_WIDTH,RESERVOIR_LEVEL_MAX,type Point3} from '../../../mountain/definition.ts';
import {reservoirOutline} from '../../../mountain/art/damArt.ts';
import {WORLD_SURFACES,WORLD_SOLIDS,queryWorldSurface,worldCeilingAt,worldDeckAt,type WorldSurface,type WorldSolid,type WorldSurfaceHit} from '../../../mountain/surfaces.ts';
import {MOUNTAIN_V2_OFFSET as O,MOUNTAIN_V2_MASSIF_Z,MOUNTAIN_V2_SUMMIT_Z,insideMountainV2} from './placement.ts';

/** The Foot terrace's radius (native, round v2's square): the terrace, the lawn and the channel; not the falling shore. */
export const FOOT_RADIUS=66;
/** North of the summit line v2 is drawn only where it is within this of (or above) the Horizon's baked ground. */
export const NORTH_TOLERANCE=1;
/** v2 land, not v2 sea (the rule `mountainContains` uses). */
const LAND=-.2;
/** The Horizon body (runtime/geography.ts): a solid above the step and below the head stops it. */
const STEP=.48,BODY=1.25;

/** The road's authored swept bands, before the 5cm paint lift. Projecting onto a coarse
 * centreline jumps between different heights at a hairpin's outside edge. These are the
 * same full-detail vertices/diagonals drawn by routeArt and bridgeArt, with no native edit. */
function drawnRoadSurface(line:typeof MOUNTAIN_ROAD_LINE):WorldSurface {
  return {...WORLD_SURFACES.find(s=>s.id===line.id)!,points:line.samples.map(s=>s.at),widths:line.samples.map(s=>s.halfWidth),
    landingRows:line.samples.map(s=>[-s.halfWidth,-s.halfWidth+.55,-.45,.45,s.halfWidth-.55,s.halfWidth].map(w=>
      [s.at[0]+s.normal[0]*w,s.at[1],s.at[2]+s.normal[2]*w] as Point3))};
}
export const REGION_ROAD=drawnRoadSurface(MOUNTAIN_ROAD_LINE);
export const REGION_ORCHARD=drawnRoadSurface(ORCHARD_LANE_LINE);
/** Both roads use their actual swept triangles: the orchard endpoint's nearest-point
 * projection extended an invisible round cap into the main road and stopped a bicycle wheel. */
export const REGION_SURFACES:readonly WorldSurface[]=WORLD_SURFACES.filter(s=>s.id!=='town-race-road').map(s=>s.id==='mountain-road'?REGION_ROAD:s.id==='orchard-lane'?REGION_ORCHARD:s);
const DRAWN_ROADS=[REGION_ROAD,REGION_ORCHARD] as const;
const REGION_OTHER_SURFACES=REGION_SURFACES.filter(s=>!DRAWN_ROADS.includes(s));
const exactRoadFloors=DRAWN_ROADS.map(surface=>{const original=drawnRoadFloor(surface.landingRows!);return {surface,floor:(x:number,z:number,ceiling=Infinity)=>{
  // Replaced prefix triangles cannot remain as a higher phantom road/slab.
  const local=surface.id==='orchard-lane'?orchardJunctionAt(x,z):null;
  return local?(local.y<=ceiling+1e-8?local:null):original(x,z,ceiling);
 }};});
const roadGroundCeiling=drawnRoadGroundCeiling(REGION_ROAD);
/** One road selector whether the surrounding ground is native terrain or a masked portal. */
function highestDrawnFloor(x:number,z:number,y:number|undefined,step:number,ground:(x:number,z:number)=>number,decks:readonly WorldSurface[]):WorldSurfaceHit{
  const ceiling=y===undefined?Infinity:y+step;
  const other=decks===REGION_SURFACES?REGION_OTHER_SURFACES:decks.filter(s=>!DRAWN_ROADS.includes(s));
  let hit=queryWorldSurface({x,z,y,stepHeight:step},ground,other);
  for(const {surface,floor} of exactRoadFloors){
    const road=decks.includes(surface)?floor(x,z,ceiling):null;
    if(road&&(hit.y>ceiling||road.y>hit.y)){
      const inv=1/Math.hypot(road.gx,1,road.gz);
      hit={id:surface.id,y:road.y,nx:-road.gx*inv,ny:inv,nz:-road.gz*inv,material:'path',slope:Math.hypot(road.gx,road.gz)};
    }
  }
  return hit;
}
/** No decks: the ground-only answer while the region's scene is not drawn (PR #566 Codex). */
const NO_DECKS:readonly WorldSurface[]=[];
/** v2's solids this pass draws (all but the district fixtures). */
export const REGION_SOLIDS:readonly WorldSolid[]=WORLD_SOLIDS.filter(s=>!s.id.startsWith('district-art:'));

export type RegionSurface={id:string;y:number;n:[number,number,number];material:string;slope:number};
export type RegionContact={id:string;nx:number;nz:number};
export type RegionGeographyOptions={
  walkingJoinSolids?:readonly StructureSolid[];
  /** The Horizon's baked ground (terrain only) at a Horizon point: decides the north face (D-M2). Omitted: native z ≥ −310. */
  horizonGround?:(hx:number,hz:number)=>number;
  /** Horizon points the region leaves to the Horizon (its terrain mouths: a portal's opening must stay open). */
  exclude?:(hx:number,hz:number)=>boolean;
  /** Points inside the drawn footprint whose ground, decks and solids the Horizon still answers (S1's own slab across the
   * Foot terrace): drawn as the region, felt as the Horizon (PR #566 CodeRabbit). */
  yield?:TerraceYield;
};
/** The margin (m) round a Horizon terrain mouth the region leaves to the Horizon's own (masked) terrain. */
export const MOUTH_MARGIN=6;
/** `exclude` for a list of mouth outlines (LandCuts.mouths): inside an outline's box grown by MOUTH_MARGIN. */
export function mouthExclusion(mouths:readonly {outline:readonly (readonly [number,number])[]}[]){
  const boxes=mouths.map(m=>{const xs=m.outline.map(p=>p[0]),zs=m.outline.map(p=>p[1]);return [Math.min(...xs)-MOUTH_MARGIN,Math.min(...zs)-MOUTH_MARGIN,Math.max(...xs)+MOUTH_MARGIN,Math.max(...zs)+MOUTH_MARGIN] as const;});
  return (hx:number,hz:number)=>boxes.some(b=>hx>=b[0]&&hz>=b[1]&&hx<=b[2]&&hz<=b[3]);
}

/** A v2 surface hit's material in the Horizon's vocabulary (MANIFEST `surfaces`): pace, grip and footsteps. */
export function regionMaterial(hit:Pick<WorldSurfaceHit,'id'|'material'>):string{
  if(hit.id==='terrain')return 'grass';
  if(hit.material==='wood')return 'boardwalk';
  return 'paved';
}

/** A coarse grid over the deck polylines so a contact touches only the decks near it. */
function deckIndex(surfaces:readonly WorldSurface[]){
  const CELL=12,cells=new Map<string,number[]>();
  surfaces.forEach((s,i)=>{for(let k=0;k<s.points.length;k++){const a=s.points[Math.max(0,k-1)]!,b=s.points[k]!,r=s.halfWidth+1;
    for(let x=Math.floor((Math.min(a[0],b[0])-r)/CELL);x<=Math.floor((Math.max(a[0],b[0])+r)/CELL);x++)for(let z=Math.floor((Math.min(a[2],b[2])-r)/CELL);z<=Math.floor((Math.max(a[2],b[2])+r)/CELL);z++){
      const key=`${x}:${z}`,list=cells.get(key);if(!list)cells.set(key,[i]);else if(list.at(-1)!==i)list.push(i);}}});
  return (x:number,z:number)=>cells.get(`${Math.floor(x/CELL)}:${Math.floor(z/CELL)}`)??[];
}
/** v2's junction rule (`surfaces.ts worldCeilingAt`): within 18 m of a skill branch's ends, a deck less than 3 m over the
 * feet is the branch's mouth or landing ramp — an open road junction — and stops nobody on the road under it. */
const BRANCH_ENDS=new Map(REGION_SURFACES.filter(s=>s.kind==='branch').map(s=>[s.id,[s.points[0]!,s.points[s.points.length-1]!] as const]));
function branchJunction(s:WorldSurface,over:number,x:number,z:number):boolean{
  const ends=BRANCH_ENDS.get(s.id);return !s.landingRows&&!!ends&&over<3&&ends.some(at=>Math.hypot(x-at[0],z-at[2])<18);
}

/**
 * PR #566 Codex: v2's rendered water as collision (native x, z → native water y, null when dry).
 *  - the reservoir: inside the drawn surface's outline (damArt `reservoirOutline` at `RESERVOIR_LEVEL_MAX`: the bowl, the
 *    shore where v2's ground rises over the level, and the dam's glass) and over ground below the level → `RESERVOIR_LEVEL_MAX`.
 *    The drawn water stands there until the app gives the dam a reading (`setWater`); a lower reading is not followed here;
 *  - the river (and the town channel): within `RIVER_HALF_WIDTH` of the `RIVER` line → the line's height there.
 */
let reservoirPlan:{outline:[number,number][];cx:number;cz:number;reach:number}|null=null;
function reservoirWater(x:number,z:number):number|null{
  if(!reservoirPlan){const outline=reservoirOutline(RESERVOIR_LEVEL_MAX),cx=outline.reduce((a,p)=>a+p[0],0)/outline.length,cz=outline.reduce((a,p)=>a+p[1],0)/outline.length;
    reservoirPlan={outline,cx,cz,reach:Math.max(...outline.map(p=>Math.hypot(p[0]-cx,p[1]-cz)))+1};}
  const {outline,cx,cz,reach}=reservoirPlan;if(Math.hypot(x-cx,z-cz)>reach)return null;
  let inside=false;for(let i=0,j=outline.length-1;i<outline.length;j=i++){const a=outline[i]!,b=outline[j]!;if((a[1]>z)!==(b[1]>z)&&x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0])inside=!inside;}
  return inside&&groundHeightAt(x,z)<RESERVOIR_LEVEL_MAX?RESERVOIR_LEVEL_MAX:null;
}
function riverWater(x:number,z:number):number|null{
  const p=nearestOnRoute(x,z,RIVER);return p.distance<=RIVER_HALF_WIDTH?p.point[1]:null;
}
/** v2's water surface at a native point (the reservoir, else the river); null when dry. */
export function regionWaterAt(x:number,z:number):number|null{return reservoirWater(x,z)??riverWater(x,z);}

/** `yield` for a Horizon bed's own corridor (width/2 + shoulder) where it crosses the Foot terrace (native z ≥ −48): S1
 * arrives there on the Horizon's slab, which the region's lawn stood a few centimetres over (grip 0.6 for 1.0). On v2's massif
 * the bed is region-carried (land/mountainV2/beds.ts regionCarryLand) and stays the region's (PR #566 CodeRabbit, tests.md §3).
 * road (L1): the Mountain Road (V03) crosses the Foot terrace on its own deck to the town lane: the region's lawn stood 0.56
 * over the carriageway at V03 246–274 (a buried road). The default now yields V03's corridor too. */
export const TERRACE_YIELD_BEDS=['S1','V03','spur stillwater','yearWalk'] as const;
/** A terrace yield, which may also carry the height the region's DRAWN ground must stay under (road L1): drawn as the region,
 * felt as the Horizon, and never drawn over the Horizon deck it yields to. */
export type TerraceYield=((hx:number,hz:number)=>boolean)&{ceiling?:(hx:number,hz:number)=>number|null};
/** road (L1): eu under a yielded deck the region's drawn ground is held (the Horizon's own bed clearance), and the steep 2 : 1
 * rise (2 eu up per eu out) back to v2's ground from BATTER_FROM beyond the corridor, so v2's authored lawn is lowered only in a
 * narrow band beside the deck. */
const DECK_CLEARANCE=.05,BATTER_FROM=1.5,BATTER=.5;
export function terraceBedExclusion(beds:readonly {id:string;points:readonly Point3[];width?:number;shoulder?:number;carried?:readonly (readonly (readonly number[])[])[]}[],ids:readonly string[]=TERRACE_YIELD_BEDS):TerraceYield{
  const from=O.z+MOUNTAIN_V2_MASSIF_Z;
  const runs=beds.filter(b=>ids.includes(b.id)).flatMap(b=>{
    // The Year Walk owns a visible ribbon on the Foot terrace too. Split at every
    // omitted/carried segment, using the emitter's midpoint/1m carry contract; joining
    // filtered points would lower native ground across gaps with no Horizon floor.
    const groups:Point3[][]=[];
    if(b.id==='yearWalk'){
      const carried=(b.carried??[]).map(line=>line.map(p=>[p[0]!,0,p[1]!] as Point3));
      let run:Point3[]=[];
      for(let i=1;i<b.points.length;i++){
        const a=b.points[i-1]!,p=b.points[i]!,mx=(a[0]+p[0])/2,mz=(a[2]+p[2])/2;
        const owns=a[2]>=from-2&&p[2]>=from-2&&!carried.some(line=>nearestOnRoute(mx,mz,line).distance<1);
        if(owns){if(!run.length)run.push(a);run.push(p);}else if(run.length){groups.push(run);run=[];}
      }
      if(run.length)groups.push(run);
    }else{const pts=b.points.filter(p=>p[2]>=from-2);if(pts.length>1)groups.push(pts);}
    return groups.map(pts=>{
    // A skate bed's shoulder is 0 in the bake (land/beds/profiles.ts); the published world carries the width only.
    const half=(b.width??4)/2+(b.shoulder??0),xs=pts.map(p=>p[0]),zs=pts.map(p=>p[2]),grow=half+BATTER_FROM+8;
    return {pts,half,box:[Math.min(...xs)-half,Math.min(...zs)-half,Math.max(...xs)+half,Math.max(...zs)+half] as const,wide:[Math.min(...xs)-grow,Math.min(...zs)-grow,Math.max(...xs)+grow,Math.max(...zs)+grow] as const};});
  });
  const test:TerraceYield=(hx:number,hz:number)=>hz>=from&&runs.some(r=>hx>=r.box[0]&&hz>=r.box[1]&&hx<=r.box[2]&&hz<=r.box[3]&&nearestOnRoute(hx,hz,r.pts).distance<=r.half);
  // road (L1): the drawn lawn keeps DECK_CLEARANCE under the deck across its corridor and BATTER_FROM beyond, then rises back to
  // v2's ground at 2 : 1 (the region's lawn was drawn 0.56 over V03's carriageway on the Foot terrace).
  test.ceiling=(hx,hz)=>{if(hz<from-8)return null;let best:number|null=null;
    for(const r of runs){if(hx<r.wide[0]||hz<r.wide[1]||hx>r.wide[2]||hz>r.wide[3])continue;const n=nearestOnRoute(hx,hz,r.pts),over=Math.max(0,n.distance-r.half-BATTER_FROM);
      const c=n.point[1]-DECK_CLEARANCE+over*BATTER/(1-BATTER)*2;if(best===null||c<best)best=c;}
    return best;};
  return test;
}
export function createRegionGeography(options:RegionGeographyOptions={}){
  const walkingGround=walkingJoinGround(options.walkingJoinSolids);
  const near=deckIndex(REGION_SURFACES);
  // A terrain mouth removes rock, not the road or repaired branch visibly crossing it.
  // Keep ground masking unchanged. Only explicit, physically drawn deck triangles span it.
  const mouthDecks=REGION_SURFACES.filter(s=>s.landingRows);
  const inMouth=(hx:number,hz:number)=>insideMountainV2(hx,hz)&&Boolean(options.exclude?.(hx,hz));
  const deckAcrossMouth=(hx:number,hz:number)=>inMouth(hx,hz)&&mouthDecks.some(s=>{
    const p=worldDeckAt(s,hx-O.x,hz-O.z);return p&&p.distance<=p.halfWidth+1e-6;
  });
  /** Inside the drawn footprint (see the module note). Horizon coordinates. */
  function contains(hx:number,hz:number):boolean{
    if(!insideMountainV2(hx,hz)||options.exclude?.(hx,hz))return false;
    const nx=hx-O.x,nz=hz-O.z;
    if(nz>=MOUNTAIN_V2_MASSIF_Z)return Math.hypot(nx,nz)<=FOOT_RADIUS;
    const g=groundHeightAt(nx,nz);
    if(nz<MOUNTAIN_V2_SUMMIT_Z){
      if(!(g>LAND))return false;
      return options.horizonGround?g+O.y>=options.horizonGround(hx,hz)-NORTH_TOLERANCE:nz>=WORLD_BOUNDS.minZ;
    }
    return g>LAND||mountainContains(nx,nz);
  }
  /** v2's ground (terrain only), Horizon height; null outside the footprint. */
  /** The region answers here: inside the drawn footprint and not yielded to a Horizon deck. */
  const owns=(hx:number,hz:number)=>contains(hx,hz)&&!options.yield?.(hx,hz);
  // road (L1): v2's ground as felt, held under a yielded Horizon deck's ceiling (TerraceYield.ceiling) exactly as it is drawn.
  const groundCeiling=(hx:number,hz:number):number|null=>{
    const yielded=options.yield?.ceiling?.(hx,hz)??null,road=roadGroundCeiling(hx-O.x,hz-O.z),drawn=road===null?null:road+O.y;
    const walking=walkingGround?.ceiling(hx,hz)??null,values=[yielded,drawn,walking].filter((v):v is number=>v!==null);return values.length?Math.min(...values):null;
  };
  // One height ceiling feeds the visible region ground and its collision authority.
  // Only ground is cut: native source data, road faces and bridge underpasses stay intact.
  const feltGround=(nx:number,nz:number)=>{const g=groundHeightAt(nx,nz),c=groundCeiling(nx+O.x,nz+O.z);return c===null?g:Math.min(g,c-O.y);};
  function groundAt(hx:number,hz:number):number|null{return owns(hx,hz)?feltGround(hx-O.x,hz-O.z)+O.y:null;}
  /** The highest v2 floor (ground or deck) at or under hy + step; null outside the footprint or when it is above that. */
  function surface(hx:number,hy:number|undefined,hz:number,step=STEP,decks:readonly WorldSurface[]=REGION_SURFACES):RegionSurface|null{
    // D-MR3: yielding lowers the lawn beneath a real Horizon slab; it must not erase all support. S1 is
    // region-carried at the road Foot, and its edge slivers have no static slab. The shared highest-floor
    // merge still chooses a Horizon deck over this lowered ground wherever that deck actually exists.
    if(!contains(hx,hz)){
      if(!decks.length||!inMouth(hx,hz))return null;
      const hit=highestDrawnFloor(hx-O.x,hz-O.z,hy===undefined?undefined:hy-O.y,step,()=>-1e6,mouthDecks);
      if(hit.id==='terrain')return null;
      return {id:`mountainV2:${hit.id}`,y:hit.y+O.y,n:[hit.nx,hit.ny,hit.nz],material:regionMaterial(hit),slope:Math.atan(hit.slope)*180/Math.PI};
    }
    let hit=highestDrawnFloor(hx-O.x,hz-O.z,hy===undefined?undefined:hy-O.y,step,feltGround,decks);
    // The existing native picture includes a5cm plank fringe outside its old
    // capsule floor. The repaired Horizon join subtracts that drawn rectangle
    // from its apron; these exact source-plan triangles remain its support.
    // No-option/native and unloaded-region queries retain their old behavior.
    const plank=walkingGround&&decks.some(s=>s.id==='station:funicular:town')?funicularFootStationFloor(hx,hz):null;
    if(plank!==null&&(hy===undefined||plank<=hy+step)&&plank>hit.y+O.y)hit={id:'station:funicular:town:planks',y:plank-O.y,nx:0,ny:1,nz:0,material:'wood',slope:0};
    const y=hit.y+O.y;
    if(hy!==undefined&&y>hy+step)return null;
    return {id:hit.id==='terrain'?'terrain':`mountainV2:${hit.id}`,y,n:[hit.nx,hit.ny,hit.nz],material:regionMaterial(hit),slope:Math.atan(hit.slope)*180/Math.PI};
  }
  /** The lowest v2 deck underside above the feet; null when none (or outside). */
  function ceiling(hx:number,hy:number,hz:number):number|null{
    const plank=walkingGround&&contains(hx,hz)?funicularFootStationFloor(hx,hz):null,under=plank!==null&&plank-.12>hy?plank-.12:null;
    const withPlank=(value:number|null)=>under===null?value:value===null?under:Math.min(value,under);
    if(!owns(hx,hz)){
      if(!inMouth(hx,hz))return withPlank(null);
      const c=worldCeilingAt(hx-O.x,hz-O.z,hy-O.y,.2,mouthDecks);return withPlank(Number.isFinite(c)?c+O.y:null);
    }
    const c=worldCeilingAt(hx-O.x,hz-O.z,hy-O.y,.2,REGION_SURFACES);
    return withPlank(Number.isFinite(c)?c+O.y:null);
  }
  /**
   * The first solid overlapping a body standing at `feet` (the span above its step and below its head): deck slabs
   * (0.28 under a deck to 0.08 over it), v2's boxes (dam plinths, station posts, the observatory and the pavilion's columns,
   * branch supports) and its edge slabs (parapets, bridge rails, retaining walls). The normal points from the solid to
   * the body (for sliding). Null outside the footprint.
   */
  function contact(hx:number,hz:number,feet:number,radius=.3,travel?:readonly [number,number],bodyHeight=BODY):RegionContact|null{
    if(!owns(hx,hz)&&!deckAcrossMouth(hx,hz))return null;
    const x=hx-O.x,z=hz-O.z,lo=feet-O.y+STEP,hi=feet-O.y+bodyHeight;
    const incoming=(nx:number,nz:number)=>!travel||nx*travel[0]+nz*travel[1]<=1e-8;
    for(const si of near(x,z)){const s=REGION_SURFACES[si]!,p=worldDeckAt(s,x,z);if(!p||p.distance>=p.halfWidth+radius)continue;
      const top=p.point[1]+.08,bottom=p.point[1]-.28;if(top<=lo||bottom>=hi)continue;
      // PR #566 CodeRabbit (R5-13): a skill branch's mouth is an open road junction, not a wall — v2's `worldCeilingAt` rule.
      // The library balcony's landing ramp rejoins the road 0.8–1.7 m over S1's bed (native x 79–85) and read as a blocker.
      if(branchJunction(s,p.point[1]-(feet-O.y),x,z))continue;
      const dx=x-p.point[0],dz=z-p.point[2],d=Math.hypot(dx,dz)||1;if(incoming(dx/d,dz/d))return {id:`mountainV2:${s.id}`,nx:dx/d,nz:dz/d};}
    for(const s of REGION_SOLIDS){
      if(s.max[1]<=lo||s.min[1]>=hi||x<=s.min[0]-radius||x>=s.max[0]+radius||z<=s.min[2]-radius||z>=s.max[2]+radius)continue;
      const px=Math.max(s.min[0],Math.min(s.max[0],x)),pz=Math.max(s.min[2],Math.min(s.max[2],z)),dx=x-px,dz=z-pz,d=Math.hypot(dx,dz);
      if(d>0){if(incoming(dx/d,dz/d))return {id:`mountainV2:${s.id}`,nx:dx/d,nz:dz/d};continue;}
      // Inside the box: out through its nearest face.
      const faces=[[x-s.min[0],-1,0],[s.max[0]-x,1,0],[z-s.min[2],0,-1],[s.max[2]-z,0,1]] as const,f=faces.reduce((a,b)=>b[0]<a[0]?b:a);
      if(incoming(f[1],f[2]))return {id:`mountainV2:${s.id}`,nx:f[1],nz:f[2]};
    }
    if(z<-40)for(const s of EDGE_SOLIDS){
      if(s.top<=lo||s.bottom>=hi)continue;
      const ax=s.a[0],az=s.a[1],dx=s.b[0]-ax,dz=s.b[1]-az,l=dx*dx+dz*dz,t=Math.max(0,Math.min(1,((x-ax)*dx+(z-az)*dz)/(l||1))),qx=x-ax-dx*t,qz=z-az-dz*t,d=Math.hypot(qx,qz);
      if(d<s.thickness/2+radius){if(d>1e-6){if(incoming(qx/d,qz/d))return {id:`mountainV2:${s.id}`,nx:qx/d,nz:qz/d};continue;}const n=Math.sqrt(l)||1;if(incoming(-dz/n,dx/n))return {id:`mountainV2:${s.id}`,nx:-dz/n,nz:dx/n};}
    }
    return null;
  }
  /** v2's point test (`worldCollisionAt`'s shape) over the drawn solids: is (hx, hy, hz) inside a solid, within r? */
  function blocked(hx:number,hy:number,hz:number,r=.2):boolean{
    if(!owns(hx,hz)&&!deckAcrossMouth(hx,hz))return false;
    const x=hx-O.x,y=hy-O.y,z=hz-O.z;
    for(const si of near(x,z)){const s=REGION_SURFACES[si]!,p=worldDeckAt(s,x,z);if(p&&p.distance<p.halfWidth+r&&y>p.point[1]-.28&&y<p.point[1]+.08)return true;}
    if(REGION_SOLIDS.some(s=>x>s.min[0]-r&&x<s.max[0]+r&&z>s.min[2]-r&&z<s.max[2]+r&&y>s.min[1]&&y<s.max[1]))return true;
    if(z<-40)for(const s of EDGE_SOLIDS){
      if(y<s.bottom||y>s.top)continue;
      const ax=s.a[0],az=s.a[1],dx=s.b[0]-ax,dz=s.b[1]-az,l=dx*dx+dz*dz,t=Math.max(0,Math.min(1,((x-ax)*dx+(z-az)*dz)/(l||1)));
      if(Math.hypot(x-ax-dx*t,z-az-dz*t)<s.thickness/2+r)return true;
    }
    return false;
  }
  /**
   * The provider `runtime/geography.ts addDynamic` takes. It OWNS the ground inside the footprint: there the baked 5 m
   * terrain is not a candidate at all (the walker and the board stand on v2's exact ground, not on the higher of the two),
   * `ground()` answers v2's ground and the camera tests v2's ground. Outside the footprint it answers nothing.
   */
  /** PR #566 Codex: v2's water (the reservoir, the river) at a Horizon point inside the footprint; null when dry or outside. */
  function waterLevel(hx:number,hz:number):number|null{if(!owns(hx,hz))return null;const w=regionWaterAt(hx-O.x,hz-O.z);return w===null?null:w+O.y;}
  const asHit=(s:RegionSurface|null)=>s?{id:s.id,y:s.y,nx:s.n[0],ny:s.n[1],nz:s.n[2],material:s.material,slope:s.slope}:null;
  const provider={
    owns:contains,
    // road (L1): where the region yields to a Horizon deck its ground answers under that deck (the drawn lawn does the same).
    ground:(x:number,z:number)=>feltGround(x-O.x,z-O.z)+O.y,
    waterLevel,
    surface(x:number,z:number,y?:number,step?:number){return asHit(surface(x,y,z,step));},
    ceiling(x:number,z:number,y:number){return ceiling(x,y,z)??Infinity;},
    contact(x:number,z:number,y:number,radius?:number,travel?:readonly [number,number],bodyHeight?:number){return contact(x,z,y,radius,travel,bodyHeight);},
  };
  /**
   * PR #566 Codex: the provider the runtime registers — its decks, solids and ceilings answer only while `drawn()` (the
   * region's scene is visible); `owns`, `ground` and `waterLevel` always answer, so the ground under the footprint is v2's
   * and nothing falls through it while the scene builds, rebuilds or is released.
   */
  function whileDrawn(drawn:()=>boolean){
    return {...provider,
      surface(x:number,z:number,y?:number,step?:number){return asHit(surface(x,y,z,step,drawn()?REGION_SURFACES:NO_DECKS));},
      ceiling(x:number,z:number,y:number){return drawn()?provider.ceiling(x,z,y):Infinity;},
      contact(x:number,z:number,y:number,radius?:number,travel?:readonly [number,number],bodyHeight?:number){return drawn()?contact(x,z,y,radius,travel,bodyHeight):null;},
    };
  }
  const requiresScene=(hx:number,hz:number)=>contains(hx,hz)||deckAcrossMouth(hx,hz);
  return {contains,requiresScene,groundAt,groundCeiling,capGroundLattice:walkingGround?.capLattice,surface,ceiling,contact,blocked,waterLevel,provider,whileDrawn};
}
export type RegionGeography=ReturnType<typeof createRegionGeography>;
