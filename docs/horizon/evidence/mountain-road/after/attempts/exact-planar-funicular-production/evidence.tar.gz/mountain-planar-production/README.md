# Funicular-only production planar reducer proposal

Root remains sole checkout writer. `production.patch` adds `src/harbour/horizon/land/mountainV2/reducePlanarJoin.ts` and calls it only for the funicular apron, after existing diagonal fairing and complete-source renderOrigin assignment. No checkout edits or reducer execution were performed here.

The typed helper ports `/tmp/mountain-planar-reduction/experiment.mjs`, whose root-executed exhausted result was16,036→6,704 faces,4666 removed vertices and maximum independent common-refinement error2.585e-10m. This typed port is **not yet verified equivalent**; run the bounded verifier before applying/baking.

```sh
node /tmp/mountain-planar-production/verify.mjs '/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book' /tmp/mountain-planar-production-port-proof
```

The verifier bundles only this pure helper, replays the exact unrounded production fixture, and requires the exact indices/positions of `/tmp/mountain-planar-reduction-study-2/candidate.json`,6704faces, unchanged input and position/origin references, deterministic repeat, fail-closed malformed input and rejection of unrelated logical IDs. It writes source/bundle/candidate/diagnostics. It does not regenerate the world. Source syntax is intended for the repository's strict TypeScript settings; root still runs configured typechecking after review.

## Contract

- Pure TypeScript: no filesystem, Node, timers, library simplifier, world-generation or runtime imports. Its only import is the erased StructureSolid type.
- Whitelisted logical identity: `mountainV2.funicularFoot.apron` only. No main Foot, native road, Stillwater or other solid adaptation.
- Original positions array and logical renderOrigin remain the exact original references. Only indices change; all metadata stays. Clear optional lite-only buffers on a reduced result so physical/full/lite geometry agrees.
- Remove a vertex only when its closed incident fan is coplanar, or two contiguous plane runs meet along a straight segment through that vertex. Boundary-collinear neighbours prevent invalid ears. Local ear-search2000-visit bound can decline an operation; it never truncates the global queue.
- One deterministic queue until exhaustion; no wall-clock cutoff, removal cap or attempt cap. Each successful operation removes a vertex and strictly reduces faces, requeueing only affected ring neighbours.
- Preserve oriented edge-count2/balance0 and forbid duplicate faces. Every proposed face passes original double,9-decimal and local-origin Float32 winding/runtime determinant/40-degree gates before mutation.
- Check local common refinement both directions before every replacement using the unchanged experiment's plane1e-11m/local4e-11m and area roundoff criteria. Final whole topology and all coordinate variants are checked again. Final failure returns the untouched input with explicit rejected diagnostics; the proposed caller throws and refuses a bake.
- Diagnostics include status, input/output faces, removed vertices, queue exhaustion, attempts, rejection counts, max local error and final topology/variant witnesses. Local vertex rejections are not whole-build errors; they retain the original fan.

## Differences from experimental driver

The production helper omits files, progress output, timing, operation-history arrays and independent whole-mesh proof. It checks all input coordinate variants and duplicate faces before reducing (the experiment checked source/double initially); the actual passing fixture already passes all variants. It exhausts the queue without driver's50k-attempt/10k-removal/time limits. It returns the original object on rejection and prohibits other logical solids.

Independent whole-mesh common refinement remains an offline/permanent-test obligation, as do exact host seams, true floor/ceiling/contact checks,14walkers, complete width/art, final baked/Float32 mesh checks and combined budgets. The primitive preserves geometric plane intersections; semantic constraints invisible in saved coplanar geometry cannot be inferred. Keep the caller funicular-only and retain native/host preservation tests.

The v3 reduced served runner remains frozen and unrun because the ground-v3 preflight was rejected. Once v4 passes, create a fresh runner targeting the frozen v4 map; do not mutate the rejected/unrun v3 artifact.
