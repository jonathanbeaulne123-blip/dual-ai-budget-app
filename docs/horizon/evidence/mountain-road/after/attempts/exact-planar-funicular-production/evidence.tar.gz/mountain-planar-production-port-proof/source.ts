import type {StructureSolid} from '../interfaces';

type V=[number,number,number];
type V2=[number,number];
type Face=[number,number,number];
type Edge={count:number;balance:number};
type Star={ids:number[];ring:number[];ordered:number[]};
type Replacement={faces:Face[];planes:number;seam:Face|null};
type Refinement={maxError:number;maxCoverageError:number;failures:number};
export interface PlanarJoinVariant {
  variant:'double'|'bake9'|'bake9-localFloat32';
  tops:number;maxTopDegrees:number;invalid:number;
  witnesses:{face:Face;normal:V;reason:string}[];
}
export interface PlanarJoinDiagnostics {
  status:'reduced'|'unchanged'|'rejected';
  reason?:string;
  sourceId:string;
  inputTriangles:number;outputTriangles:number;removedVertices:number;
  attempts:number;queueExhausted:boolean;maxLocalError:number;
  rejections:Record<string,number>;
  topologyFailures:{key:string;count:number;balance:number}[];
  duplicateFaces:number;
  variants:PlanarJoinVariant[];
}
export interface PlanarJoinReduction {solid:StructureSolid;diagnostics:PlanarJoinDiagnostics}

const PLANE=1e-11,AREA=1e-14;
const sub=(a:V,b:V):V=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
const dot=(a:V,b:V):number=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const cross=(a:V,b:V):V=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm=(a:V):number=>Math.hypot(...a);
const unit=(a:V):V=>{const l=norm(a);return[a[0]/l,a[1]/l,a[2]/l];};
const edgeKey=(a:number,b:number):string=>a<b?`${a}:${b}`:`${b}:${a}`;
const faceKey=(f:Face):string=>[...f].sort((a,b)=>a-b).join(':');
const area2=(a:V2,b:V2,c:V2):number=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const axes=(n:V):[number,number]=>Math.abs(n[0])>=Math.abs(n[1])&&Math.abs(n[0])>=Math.abs(n[2])?[1,2]:Math.abs(n[1])>=Math.abs(n[2])?[0,2]:[0,1];

/** Funicular only: remove redundant vertices on one plane or a collinear
 * intersection of two planes. No position/origin is changed. Every replacement
 * preserves its exact incident-fan boundary and passes local common refinement.
 * Queue exhaustion is deterministic; there is no clock or removal-count cutoff.
 * A rejected result returns the original object. The caller must refuse a bake
 * on rejection. Independent whole-mesh common refinement remains an offline test. */
export function reducePlanarJoin(source:StructureSolid):PlanarJoinReduction {
  if((source.sourceId??source.id.split('@')[0])!=='mountainV2.funicularFoot.apron')throw new Error('Planar join reduction is restricted to the funicular apron');
  const P=source.positions,origin=source.renderOrigin;
  const diagnostics:PlanarJoinDiagnostics={status:'unchanged',sourceId:source.id,inputTriangles:source.indices.length/3,outputTriangles:source.indices.length/3,removedVertices:0,attempts:0,queueExhausted:false,maxLocalError:0,rejections:{},topologyFailures:[],duplicateFaces:0,variants:[]};
  const rejectResult=(reason:string):PlanarJoinReduction=>{diagnostics.status='rejected';diagnostics.reason=reason;return{solid:source,diagnostics};};
  if(!origin||origin.length!==3||!origin.every(Number.isFinite)||P.length%3||!P.every(Number.isFinite)||source.indices.length%3||!source.indices.every(i=>Number.isInteger(i)&&i>=0&&i<P.length/3))return rejectResult('Invalid positions, indices or logical render origin');
  const point=(i:number,positions:readonly number[]=P):V=>[positions[i*3]!,positions[i*3+1]!,positions[i*3+2]!];
  const normal=(f:Face,positions:readonly number[]=P):V=>{const a=point(f[0],positions),b=point(f[1],positions),c=point(f[2],positions);return cross(sub(b,a),sub(c,a));};
  const positionsByVariant=[P,P.map(v=>Number(v.toFixed(9))),P.map((v,i)=>Math.fround(Number(v.toFixed(9))-origin[i%3]!)+origin[i%3]!)];
  const variantNames:PlanarJoinVariant['variant'][]=['double','bake9','bake9-localFloat32'];
  function faceGate(f:Face,referenceNormal:V):boolean {
    for(const positions of positionsByVariant){const n=normal(f,positions),length=norm(n);
      if(!Number.isFinite(length)||length<=AREA||dot(n,referenceNormal)<=0)return false;
      if(referenceNormal[1]>1e-9&&(n[1]<1e-8||Math.atan2(Math.hypot(n[0],n[2]),n[1])*180/Math.PI>40+1e-7))return false;
    }return true;
  }
  const faces=new Map<number,Face>(),incident=new Map<number,Set<number>>(),edges=new Map<string,Edge>(),faceKeys=new Map<string,number>();let nextId=0;
  function changeEdge(a:number,b:number,delta:number):void {const key=edgeKey(a,b),e=edges.get(key)??{count:0,balance:0};e.count+=delta;e.balance+=delta*(a<b?1:-1);if(e.count)edges.set(key,e);else edges.delete(key);}
  function add(f:Face):void {const id=nextId++;faces.set(id,f);for(const v of f){const s=incident.get(v)??new Set<number>();s.add(id);incident.set(v,s);}for(let j=0;j<3;j++)changeEdge(f[j]!,f[(j+1)%3]!,1);const key=faceKey(f);faceKeys.set(key,(faceKeys.get(key)??0)+1);}
  function remove(id:number):void {const f=faces.get(id)!;faces.delete(id);for(const v of f)incident.get(v)!.delete(id);for(let j=0;j<3;j++)changeEdge(f[j]!,f[(j+1)%3]!,-1);const key=faceKey(f),n=faceKeys.get(key)!-1;if(n)faceKeys.set(key,n);else faceKeys.delete(key);}
  for(let i=0;i<source.indices.length;i+=3)add([source.indices[i]!,source.indices[i+1]!,source.indices[i+2]!]);
  const topology=():PlanarJoinDiagnostics['topologyFailures']=>[...edges].filter(([,e])=>e.count!==2||e.balance!==0).map(([key,e])=>({key,...e}));
  function variantAudit(F:readonly Face[]):PlanarJoinVariant[] {return positionsByVariant.map((positions,k)=>{
    let maxTopDegrees=0,invalid=0,tops=0;const witnesses:PlanarJoinVariant['witnesses']=[];
    for(const f of F){const ref=normal(f),n=normal(f,positions),l=norm(n);let reason:string|null=null;
      if(l<=AREA||!Number.isFinite(l)||dot(ref,n)<=0)reason='collapsed or orientation changed';
      if(ref[1]>1e-9||unit(ref)[1]>.5){tops++;const grade=Math.atan2(Math.hypot(n[0],n[2]),n[1])*180/Math.PI;maxTopDegrees=Math.max(maxTopDegrees,grade);if(n[1]<1e-8)reason='top below runtime determinant';else if(grade>40+1e-7)reason='top exceeds40deg';}
      if(reason){invalid++;if(witnesses.length<10)witnesses.push({face:f,normal:n,reason});}
    }return{variant:variantNames[k]!,tops,maxTopDegrees,invalid,witnesses};
  });}
  diagnostics.topologyFailures=topology();diagnostics.duplicateFaces=[...faceKeys.values()].filter(n=>n>1).length;diagnostics.variants=variantAudit([...faces.values()]);
  if(diagnostics.topologyFailures.length||diagnostics.duplicateFaces||diagnostics.variants.some(v=>v.invalid))return rejectResult('Input fails topology or coordinate-variant gates');
  function star(v:number):Star|null {
    const ids=[...(incident.get(v)??[])];if(ids.length<3||ids.length>24)return null;
    const next=new Map<number,number>(),faceFor=new Map<number,number>();
    for(const id of ids){const f=faces.get(id)!,k=f.indexOf(v),a=f[(k+1)%3]!,b=f[(k+2)%3]!;if(next.has(a))return null;next.set(a,b);faceFor.set(a,id);}
    const first=Math.min(...next.keys()),ring=[first];let at=next.get(first);
    while(at!==undefined&&at!==first&&next.has(at)&&ring.length<=next.size){ring.push(at);at=next.get(at);}
    if(at!==first||ring.length!==next.size)return null;return{ids,ring,ordered:ring.map(a=>faceFor.get(a)!)};
  }
  function planeGroups(st:Star,v:number):{groups:{n:V;faces:number[]}[];labels:number[]}|null {
    const anchor=point(v),groups:{n:V;faces:number[]}[]=[],assignment=new Map<number,number>();
    const ordered=[...st.ids].sort((a,b)=>norm(normal(faces.get(b)!))-norm(normal(faces.get(a)!)));
    for(const id of ordered){const f=faces.get(id)!,n=normal(f);let g=groups.findIndex(q=>dot(n,q.n)>0&&f.every(i=>Math.abs(dot(q.n,sub(point(i),anchor)))<=PLANE));
      if(g<0){if(groups.length===2)return null;g=groups.length;groups.push({n:unit(n),faces:[]});}groups[g]!.faces.push(id);assignment.set(id,g);
    }return{groups,labels:st.ordered.map(id=>assignment.get(id)!)};
  }
  function triangulate(poly:number[],plane:V):Face[]|null {
    const ax=axes(plane),base=point(poly[0]!),xy=(i:number):V2=>[P[i*3+ax[0]]!-base[ax[0]]!,P[i*3+ax[1]]!-base[ax[1]]!],xyCache=new Map<number,V2>(poly.map(i=>[i,xy(i)]));
    const polygonSign=Math.sign(poly.reduce((s,a,i)=>{const b=poly[(i+1)%poly.length]!,A=xyCache.get(a)!,B=xyCache.get(b)!;return s+A[0]*B[1]-A[1]*B[0];},0));if(!polygonSign)return null;
    let visits=0;
    function solve(ids:number[]):Face[]|null {
      if(++visits>2000)return null; // A local operation may decline; the global queue still exhausts.
      if(ids.length===3){const f:Face=[ids[0]!,ids[1]!,ids[2]!],n=normal(f);return dot(n,plane)>AREA&&faceGate(f,plane)?[f]:null;}
      const ears:{k:number;f:Face;score:number}[]=[];
      for(let k=0;k<ids.length;k++){
        const f:Face=[ids[(k+ids.length-1)%ids.length]!,ids[k]!,ids[(k+1)%ids.length]!],q=f.map(i=>xyCache.get(i)!) as [V2,V2,V2],a=area2(...q)*polygonSign,n=normal(f);
        if(a<=AREA||dot(n,plane)<=AREA||!faceGate(f,plane))continue;
        if(ids.some(i=>!f.includes(i)&&q.every((p,j)=>area2(p,q[(j+1)%3]!,xyCache.get(i)!)*polygonSign>=-1e-14)))continue;
        const l=Math.max(...f.map((v,j)=>norm(sub(point(v),point(f[(j+1)%3]!)))));ears.push({k,f,score:norm(n)/(l*l)});
      }
      ears.sort((a,b)=>b.score-a.score||a.k-b.k);for(const e of ears){const rest=solve(ids.filter((_,i)=>i!==e.k));if(rest)return[e.f,...rest];}return null;
    }return solve(poly);
  }
  function replacement(st:Star,v:number):Replacement|null {
    const grouped=planeGroups(st,v);if(!grouped)return null;const{groups,labels}=grouped;
    if(groups.length===1){const f=triangulate(st.ring,groups[0]!.n);return f?{faces:f,planes:1,seam:null}:null;}
    const transitions=labels.map((g,i)=>g!==labels[(i+labels.length-1)%labels.length]?i:-1).filter(i=>i>=0);if(transitions.length!==2)return null;
    const ia=transitions[0]!,ib=transitions[1]!,a=st.ring[ia]!,b=st.ring[ib]!,A=point(a),B=point(b),V=point(v),d=sub(B,A),l2=dot(d,d),t=dot(sub(V,A),d)/l2;
    if(!(t>0&&t<1)||norm(sub(V,[A[0]+d[0]*t,A[1]+d[1]*t,A[2]+d[2]*t]))>PLANE)return null;
    const chain=(start:number,end:number):number[]=>{const p=[st.ring[start]!];for(let i=(start+1)%st.ring.length;i!==end;i=(i+1)%st.ring.length)p.push(st.ring[i]!);p.push(st.ring[end]!);return p;};
    const p=triangulate(chain(ia,ib),groups[labels[ia]!]!.n),q=triangulate(chain(ib,ia),groups[labels[ib]!]!.n);return p&&q?{faces:[...p,...q],planes:2,seam:[a,v,b]}:null;
  }
  function validTopology(oldIds:number[],newFaces:Face[]):boolean {
    const changes=new Map<string,Edge>(),oldKeys=new Map<string,number>();
    const collect=(f:Face,d:number):void=>{const fk=faceKey(f);oldKeys.set(fk,(oldKeys.get(fk)??0)+d);for(let k=0;k<3;k++){const a=f[k]!,b=f[(k+1)%3]!,key=edgeKey(a,b),e=changes.get(key)??{count:0,balance:0};e.count+=d;e.balance+=d*(a<b?1:-1);changes.set(key,e);}};
    for(const id of oldIds)collect(faces.get(id)!,-1);for(const f of newFaces)collect(f,1);
    for(const[key,d]of changes){const e=edges.get(key)??{count:0,balance:0},count=e.count+d.count;if(count!==0&&(count!==2||e.balance+d.balance!==0))return false;}
    for(const[key,d]of oldKeys)if((faceKeys.get(key)??0)+d>1)return false;return true;
  }
  function clip(poly:V2[],tri:[V2,V2,V2]):V2[] {let out=poly;const sign=Math.sign(area2(...tri));for(let k=0;k<3&&out.length;k++){
    const a=tri[k]!,b=tri[(k+1)%3]!,next:V2[]=[];for(let i=0;i<out.length;i++){const A=out[i]!,B=out[(i+1)%out.length]!,da=sign*area2(a,b,A),db=sign*area2(a,b,B);if(da>=0)next.push(A);if((da>=0)!==(db>=0)){const t=da/(da-db);next.push([A[0]+(B[0]-A[0])*t,A[1]+(B[1]-A[1])*t]);}}out=next;
  }return out;}
  const polyArea=(p:V2[]):number=>Math.abs(p.reduce((s,a,i)=>{const b=p[(i+1)%p.length]!;return s+a[0]*b[1]-a[1]*b[0];},0))/2;
  /** Exact affine plane difference on every positive-area local overlap. This
   * tests both directions, including coverage, before each mutation. */
  function refine(A:Face[],B:Face[],tolerance:number):Refinement {
    let maxError=0,maxCoverageError=0,failures=0;
    for(const f of A){const N=normal(f),ax=axes(N),drop=[0,1,2].find(k=>!ax.includes(k))!,base=point(f[0]),proj=(i:number):V2=>[P[i*3+ax[0]]!-base[ax[0]]!,P[i*3+ax[1]]!-base[ax[1]]!],poly=f.map(proj) as [V2,V2,V2],area=Math.abs(area2(...poly))/2;let covered=0;
      if(area<=AREA){failures++;continue;}
      const lift=(tri:Face,p:V2):number=>{const n=normal(tri),a=point(tri[0]);return a[drop]!-(n[ax[0]]!*(p[0]+base[ax[0]]!-a[ax[0]]!)+n[ax[1]]!*(p[1]+base[ax[1]]!-a[ax[1]]!))/n[drop]!;};
      for(const g of B){const n=normal(g);if(dot(N,n)<=0||Math.abs(n[drop]!)<AREA)continue;const other=g.map(proj) as [V2,V2,V2];
        if(Math.max(...other.map(p=>p[0]))<Math.min(...poly.map(p=>p[0]))||Math.min(...other.map(p=>p[0]))>Math.max(...poly.map(p=>p[0]))||Math.max(...other.map(p=>p[1]))<Math.min(...poly.map(p=>p[1]))||Math.min(...other.map(p=>p[1]))>Math.max(...poly.map(p=>p[1])))continue;
        const overlap=clip(poly,other);if(overlap.length<3)continue;const overlapArea=polyArea(overlap);if(overlapArea<=1e-20)continue;
        let error=0;for(const p of overlap)error=Math.max(error,Math.abs(lift(f,p)-lift(g,p)));if(error>tolerance)continue;covered+=overlapArea;maxError=Math.max(maxError,error);
      }
      const miss=Math.abs(covered-area);maxCoverageError=Math.max(maxCoverageError,miss);if(miss>Math.max(1e-15,area*1e-9))failures++;
    }return{maxError,maxCoverageError,failures};
  }
  const queue=[...incident.keys()].sort((a,b)=>a-b),queued=new Set(queue);let cursor=0;
  const reject=(reason:string):void=>{diagnostics.rejections[reason]=(diagnostics.rejections[reason]??0)+1;};
  while(cursor<queue.length){
    const v=queue[cursor++]!;queued.delete(v);diagnostics.attempts++;const st=star(v);if(!st){reject('star');continue;}const next=replacement(st,v);if(!next){reject('plane-or-triangulation');continue;}
    if(next.faces.length>=st.ids.length||!validTopology(st.ids,next.faces)){reject('topology');continue;}
    const old=st.ids.map(id=>faces.get(id)!),forward=refine(old,next.faces,PLANE*4),backward=refine(next.faces,old,PLANE*4);
    if(forward.failures||backward.failures){reject('local-common-refinement');continue;}
    for(const id of st.ids)remove(id);for(const f of next.faces)add(f);diagnostics.removedVertices++;diagnostics.maxLocalError=Math.max(diagnostics.maxLocalError,forward.maxError,backward.maxError);
    for(const n of st.ring)if(!queued.has(n)){queued.add(n);queue.push(n);}
  }
  diagnostics.queueExhausted=true;diagnostics.outputTriangles=faces.size;diagnostics.topologyFailures=topology();diagnostics.duplicateFaces=[...faceKeys.values()].filter(n=>n>1).length;const finalFaces=[...faces.values()];diagnostics.variants=variantAudit(finalFaces);
  if(diagnostics.topologyFailures.length||diagnostics.duplicateFaces||diagnostics.variants.some(v=>v.invalid))return rejectResult('Final topology or coordinate-variant audit failed; input retained');
  diagnostics.status=diagnostics.removedVertices?'reduced':'unchanged';
  if(!diagnostics.removedVertices)return{solid:source,diagnostics};
  const solid:StructureSolid={...source,indices:finalFaces.flat()};
  // One resulting physical mesh owns full/lite drawing and collision.
  delete solid.liteIndices;delete solid.litePositions;delete solid.liteErrorEu;
  return{solid,diagnostics};
}
