var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err2) => function __init() {
  if (err2) throw err2[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err2 = [e], e;
  }
};

// src/harbour/horizon/world/MANIFEST.json
var MANIFEST_default;
var init_MANIFEST = __esm({
  "src/harbour/horizon/world/MANIFEST.json"() {
    MANIFEST_default = {
      title: "The Horizon \u2014 MANIFEST",
      version: "2.6",
      date: "2026-09-28",
      status: "Design numbers for implementation. Control points are centreline intent to be solved into splines by the land pass; not navigation or collision data until baked into WorldDefinition v3. v2.2: paces and surface grip (RIDE D42) and the FLIGHT sky fields (D34\u2013D38), reconciled onto the v2.1 land \u2014 data only, no geometry change.",
      units: {
        x: "east, concept metres",
        y: "south, concept metres (engine z)",
        height: "metres above sea level (engine y)",
        scale: "engine units = concept metres \xD7 scale.factor (see scale)",
        north: "-z"
      },
      extent: {
        w: 2e3,
        h: 1800
      },
      seaLevel: 0,
      island: {
        outline: [
          [
            900,
            180
          ],
          [
            1200,
            190
          ],
          [
            1420,
            300
          ],
          [
            1600,
            500
          ],
          [
            1690,
            760
          ],
          [
            1620,
            1080
          ],
          [
            1440,
            1330
          ],
          [
            1150,
            1480
          ],
          [
            860,
            1480
          ],
          [
            720,
            1330
          ],
          [
            660,
            1180
          ],
          [
            700,
            1e3
          ],
          [
            820,
            860
          ],
          [
            860,
            720
          ],
          [
            780,
            560
          ],
          [
            640,
            520
          ],
          [
            520,
            620
          ],
          [
            500,
            800
          ],
          [
            540,
            940
          ],
          [
            460,
            1020
          ],
          [
            370,
            940
          ],
          [
            300,
            720
          ],
          [
            340,
            470
          ],
          [
            520,
            300
          ],
          [
            700,
            210
          ]
        ],
        note: "Closed smooth curve through these points (Catmull-Rom). Shore is 12 m of sand/rock stroke; shallows extend 50 m."
      },
      offshore: [
        {
          id: "lamp",
          label: "The Lamp",
          xy: [
            540,
            1230
          ],
          r: 40,
          heightMax: 8,
          holds: "lighthouse (25 m gallery: glider launch), rowboat dock"
        },
        {
          id: "needle",
          label: "The Needle's Eye",
          xy: [
            1790,
            680
          ],
          r: 34,
          heightMax: 30,
          holds: "natural arch (Ring Run gate 1, sunrise gate)"
        },
        {
          id: "stacks",
          label: "The Stacks",
          xy: [
            [
              1770,
              880
            ],
            [
              1810,
              930
            ],
            [
              1750,
              960
            ]
          ],
          heightMax: 24,
          holds: "Ring Run gate 2 between them"
        },
        {
          id: "wreck",
          label: "The Wreck",
          xy: [
            250,
            1150
          ],
          r: 30,
          heightMax: 4,
          holds: "a wreck on the reef; boat destination; nothing to do"
        },
        {
          id: "sandbar",
          label: "Bight sandbar",
          xy: [
            620,
            1e3
          ],
          note: "shows at full moon"
        }
      ],
      landformRule: "polygons are clipped to the island outline; the Hollow, the Stillwater terrace and the Cup are cut INTO the Shoulder (their own band wins inside them); elsewhere where polygons overlap the innermost (higher) band wins; band edges blend over 60 m; a bed (road, skate, rail, walk) overrides the bands within its profile width + 15 m each side and holds its own grade limits, so band steps never appear as cliffs on a route",
      districts: [
        {
          id: "harbour",
          neighbourhood: "harbour",
          note: "town + the Terraces + the town quay",
          heart: [
            1470,
            1170
          ]
        },
        {
          id: "landing",
          neighbourhood: "landing",
          note: "Long Sands, the Landing quay, the Boathouse, Campfire, Tideline park",
          heart: [
            1060,
            1410
          ]
        },
        {
          id: "reach",
          neighbourhood: "landing",
          note: "the wetland and the river mouth",
          heart: [
            1280,
            1260
          ]
        },
        {
          id: "green",
          neighbourhood: "lakeside",
          note: "the Green and the Glasshouse steps",
          heart: [
            1030,
            1060
          ]
        },
        {
          id: "hollow",
          neighbourhood: "hollow",
          note: "the orchard bowl, the Adit",
          heart: [
            985,
            580
          ]
        },
        {
          id: "scholars",
          neighbourhood: "scholars",
          note: "the woodland rise and the north pass",
          heart: [
            765,
            400
          ]
        },
        {
          id: "flats",
          neighbourhood: "flats",
          note: "the arm: strip, hangar, balloon, the Wash",
          heart: [
            420,
            685
          ]
        },
        {
          id: "bight",
          neighbourhood: "flats",
          note: "the lagoon, the sandbar, Bight Shore, the Bight Bridge",
          heart: [
            745,
            995
          ]
        },
        {
          id: "lakeside",
          neighbourhood: "lakeside",
          note: "Stillwater, the sill falls (v2.6: the dam and L01 moved to Mountain v2)",
          heart: [
            1130,
            820
          ]
        },
        {
          id: "notch",
          neighbourhood: "lakeside",
          note: "the gorge, the High Span",
          heart: [
            1205,
            1070
          ]
        },
        {
          id: "prow",
          neighbourhood: "crown",
          note: "the cliffs, the zip tower, the Sea Door",
          heart: [
            1600,
            780
          ]
        },
        {
          id: "crown",
          neighbourhood: "crown",
          note: "the Shoulder and the summit; the Undercroft is its underground child district v2.6: Mountain v2 stands here (regions.mountainV2), its glass dam and L01 on the crest",
          heart: [
            1310,
            470
          ]
        },
        {
          id: "offshore",
          neighbourhood: null,
          note: "the Lamp, the Needle's Eye, the Stacks, the Wreck; the sky ring streams by the districts beneath it"
        }
      ],
      landforms: [
        {
          id: "harbour",
          label: "Little Harbour",
          h: [
            0,
            18
          ],
          poly: [
            [
              1380,
              1060
            ],
            [
              1540,
              1040
            ],
            [
              1580,
              1160
            ],
            [
              1520,
              1280
            ],
            [
              1400,
              1300
            ],
            [
              1350,
              1180
            ]
          ],
          faces: "north-west (the dam) and south (the harbour)"
        },
        {
          id: "sands",
          label: "Long Sands & the Landing",
          h: [
            0,
            5
          ],
          poly: [
            [
              720,
              1360
            ],
            [
              1e3,
              1400
            ],
            [
              1350,
              1360
            ],
            [
              1400,
              1440
            ],
            [
              1150,
              1500
            ],
            [
              860,
              1480
            ],
            [
              740,
              1420
            ]
          ],
          faces: "south"
        },
        {
          id: "reach",
          label: "The Reach",
          h: [
            2,
            6
          ],
          poly: [
            [
              1180,
              1180
            ],
            [
              1320,
              1180
            ],
            [
              1370,
              1300
            ],
            [
              1300,
              1360
            ],
            [
              1200,
              1340
            ],
            [
              1160,
              1260
            ]
          ]
        },
        {
          id: "green",
          label: "The Green",
          h: [
            10,
            25
          ],
          poly: [
            [
              1e3,
              900
            ],
            [
              1150,
              960
            ],
            [
              1250,
              1040
            ],
            [
              1300,
              1180
            ],
            [
              1150,
              1200
            ],
            [
              950,
              1200
            ],
            [
              820,
              1100
            ],
            [
              830,
              960
            ]
          ],
          faces: "south, open"
        },
        {
          id: "hollow",
          label: "The Hollow",
          h: [
            30,
            45
          ],
          poly: [
            [
              880,
              500
            ],
            [
              1060,
              480
            ],
            [
              1090,
              600
            ],
            [
              1040,
              680
            ],
            [
              900,
              680
            ],
            [
              850,
              600
            ]
          ],
          faces: "south-facing bowl"
        },
        {
          id: "scholars",
          label: "Scholars' Edge",
          h: [
            35,
            60
          ],
          poly: [
            [
              640,
              300
            ],
            [
              900,
              260
            ],
            [
              960,
              420
            ],
            [
              880,
              520
            ],
            [
              700,
              520
            ],
            [
              600,
              420
            ]
          ],
          faces: "north-west rise, shaded"
        },
        {
          id: "flats",
          label: "The Flats",
          h: [
            30,
            45
          ],
          poly: [
            [
              330,
              480
            ],
            [
              520,
              340
            ],
            [
              560,
              620
            ],
            [
              520,
              900
            ],
            [
              430,
              1e3
            ],
            [
              320,
              850
            ]
          ],
          faces: "west, sunset"
        },
        {
          id: "stillwater",
          label: "Stillwater terrace",
          h: [
            45,
            55
          ],
          poly: [
            [
              1e3,
              720
            ],
            [
              1260,
              720
            ],
            [
              1280,
              900
            ],
            [
              1e3,
              900
            ]
          ]
        },
        {
          id: "notch",
          label: "The Notch",
          h: "cut 25\u201345 below the terrace",
          centreline: [
            [
              1140,
              905
            ],
            [
              1170,
              980
            ],
            [
              1220,
              1060
            ],
            [
              1250,
              1140
            ],
            [
              1280,
              1220
            ],
            [
              1330,
              1290
            ],
            [
              1350,
              1345
            ],
            [
              1364,
              1390
            ]
          ],
          width: [
            40,
            70
          ],
          walls: "strata"
        },
        {
          id: "prow",
          label: "The Prow",
          h: [
            40,
            70
          ],
          poly: [
            [
              1560,
              480
            ],
            [
              1640,
              560
            ],
            [
              1700,
              760
            ],
            [
              1660,
              960
            ],
            [
              1600,
              1080
            ],
            [
              1560,
              1e3
            ],
            [
              1620,
              780
            ],
            [
              1560,
              600
            ]
          ],
          faces: "east, dawn; sea cliffs"
        },
        {
          id: "shoulder",
          label: "The Shoulder",
          h: [
            90,
            110
          ],
          poly: [
            [
              1060,
              330
            ],
            [
              1400,
              300
            ],
            [
              1520,
              420
            ],
            [
              1500,
              680
            ],
            [
              1400,
              860
            ],
            [
              1180,
              900
            ],
            [
              1060,
              800
            ],
            [
              1e3,
              600
            ]
          ],
          cutInto: [
            "hollow",
            "stillwater",
            "cup"
          ],
          note: "stays \u2265 60 m inland of the north coast so the coast drive is not in its band"
        },
        {
          id: "crown",
          label: "The Crown",
          h: [
            110,
            160
          ],
          poly: [
            [
              1120,
              330
            ],
            [
              1330,
              280
            ],
            [
              1500,
              380
            ],
            [
              1520,
              560
            ],
            [
              1420,
              700
            ],
            [
              1240,
              700
            ],
            [
              1120,
              560
            ]
          ],
          summit: [
            1310,
            470
          ],
          summitH: 158,
          snow: "Dec\u2013Mar, longest on the north face"
        },
        {
          id: "undercroft",
          label: "The Undercroft",
          h: [
            30,
            95
          ],
          footprint: {
            cx: 1300,
            cy: 470,
            rx: 170,
            ry: 130
          }
        }
      ],
      protected: {
        green: {
          cx: 1040,
          cy: 1065,
          r: 160,
          rule: "no building, plot, or prop taller than a bench (0.85 eu); disc-golf baskets and lantern posts ring the outside of it"
        }
      },
      water: {
        stillwater: {
          cx: 1130,
          cy: 820,
          rx: 110,
          ry: 85,
          surface: 50,
          note: "natural lake; never encodes money; ice Jan\u2013Feb; v2.6 (D-M3): held by the natural sill at its south end (no dam)"
        },
        river: {
          lower: [
            [
              1140,
              905
            ],
            [
              1170,
              980
            ],
            [
              1220,
              1060
            ],
            [
              1250,
              1140
            ],
            [
              1280,
              1220
            ],
            [
              1330,
              1290
            ],
            [
              1350,
              1345
            ],
            [
              1364,
              1390
            ]
          ],
          note: "v2.6: mountain (v2 river through the Foot) feeds the lake; lower leaves the lake over the natural sill through the Notch to the Reach and the harbour. v2.5: upper feeds the lake; lower leaves the dam through the Notch to the Reach and the harbour",
          mountain: {
            pts: [
              [
                1317,
                833
              ],
              [
                1300,
                838
              ],
              [
                1270,
                836.5
              ],
              [
                1232,
                832
              ]
            ],
            levels: [
              53.9,
              51.2,
              50,
              50
            ],
            width_m: 5,
            depth_m: 0.8,
            note: "v2.6 (D-M3): Mountain v2 river runs its own town channel on the Foot terrace (the region draws it, the gorge mouth [1311,730] to v2 channel end [1317,833], native (9,-0.1,69)); from there the Horizon carries it west into Stillwater east shore as a brook (it replaces river.upper as the lake inflow)",
            kind: "brook"
          },
          sill: {
            xy: [
              1136,
              896
            ],
            level: 50,
            note: "v2.6 (D-M3): Stillwater drains over a natural rock sill into the Notch: river.lower begins in the lake at the sill lip (50) and falls to its old head [1140,905] at 22; no structure"
          }
        },
        brook: {
          pts: [
            [
              880,
              480
            ],
            [
              900,
              600
            ],
            [
              880,
              700
            ],
            [
              865,
              800
            ],
            [
              820,
              860
            ]
          ],
          note: "Orchard Brook: woodland to the Bight under the covered bridge"
        },
        wash: {
          pts: [
            [
              480,
              560
            ],
            [
              465,
              700
            ],
            [
              485,
              800
            ],
            [
              515,
              900
            ]
          ],
          note: "dry streambed on the Flats; runs only after almanac rain; the Wash skate bowl at [465,700]"
        },
        reachChannels: [
          [
            [
              1280,
              1220
            ],
            [
              1240,
              1270
            ],
            [
              1230,
              1330
            ]
          ],
          [
            [
              1280,
              1220
            ],
            [
              1320,
              1260
            ],
            [
              1320,
              1320
            ]
          ]
        ],
        deep: {
          cx: 1300,
          cy: 420,
          surface: 40,
          note: "cavern lake at the foot of the Throat, under the skylight shaft; the underground river leaves it east through the Sea Passage to the sea"
        },
        spring: {
          xy: [
            1250,
            1180
          ],
          note: "a decorative spring at the Reach; not the Deep's outflow"
        }
      },
      hostRule: "footprint_m is the building's plan (w \xD7 d, concept metres, scales); roofH_eu is ridge height above its ground in engine units (does not scale)",
      hosts: [
        {
          id: "home",
          footprint_m: [
            22,
            16
          ],
          roofH_eu: 9,
          label: "Our home",
          placeIds: [
            "kitchen",
            "tower",
            "cellar",
            "atlas"
          ],
          xy: [
            1505,
            1165
          ],
          h: 14,
          door: "west, onto the square; the kitchen window looks north-west at the dam",
          arrival: "square (walk); upper street spur (wheels)"
        },
        {
          id: "bank",
          footprint_m: [
            20,
            18
          ],
          roofH_eu: 10,
          label: "The Fund bank",
          placeIds: [
            "bank"
          ],
          xy: [
            1443,
            1125
          ],
          h: 16,
          door: "south, onto the square (the bank stands on the square's north side)",
          v2_0_footprint_m: [
            26,
            18
          ],
          v2_0_xy: [
            1440,
            1125
          ],
          massNote_v2_1: "page A: the south wall's west 6 m stood in the Shoulder's sight line from the square (design lead, Stage A Wave 5 integration 2026-09-27; reversible)"
        },
        {
          id: "library",
          footprint_m: [
            42,
            30
          ],
          roofH_eu: 14,
          label: "The Library",
          placeIds: [
            "library"
          ],
          xy: [
            740,
            400
          ],
          h: 48,
          door: "south-east, onto the reading courtyard",
          arrival: "garden walk; Green Road north pass spur"
        },
        {
          id: "glasshouse",
          footprint_m: [
            25,
            18
          ],
          roofH_eu: 9,
          label: "The Glasshouse",
          placeIds: [
            "glasshouse"
          ],
          xy: [
            1007.5,
            790
          ],
          h: 56,
          door: "south, onto the Glasshouse steps down to the Green (ramp twin); faces Stillwater across the terrace",
          arrival: "garden walk; Green Road spur",
          v1_7: {
            footprint_m: [
              30,
              18
            ],
            xy: [
              1010,
              790
            ]
          }
        },
        {
          id: "studio",
          footprint_m: [
            24,
            16
          ],
          roofH_eu: 8,
          label: "The Pottery Studio",
          placeIds: [
            "kiln"
          ],
          xy: [
            1020,
            540
          ],
          h: 40,
          door: "west, onto the studio terrace; the Adit is 70 m east along the terrace"
        },
        {
          id: "cottage",
          footprint_m: [
            18,
            14
          ],
          roofH_eu: 7,
          label: "Hercules's cottage",
          placeIds: [
            "cottage"
          ],
          xy: [
            920,
            620
          ],
          h: 36,
          door: "south, into the orchard"
        },
        {
          id: "boathouse",
          footprint_m: [
            20,
            14
          ],
          roofH_eu: 7,
          label: "The Boathouse",
          placeIds: [
            "boathouse"
          ],
          xy: [
            1285,
            1315
          ],
          h: 3,
          door: "east, onto its dock on the harbour's west bank beside the Landing quay; the floatplane dock is the town's, not this one"
        }
      ],
      places: [
        {
          id: "court",
          label: "Queen's Court (the square)",
          xy: [
            1455,
            1175
          ],
          h: 12
        },
        {
          id: "campfire",
          label: "Campfire",
          xy: [
            1200,
            1430
          ],
          h: 2
        },
        {
          id: "L01",
          label: "Fund instrument (the glass dam crest plaques)",
          xy: [
            1316,
            539.2
          ],
          h: 142,
          reads: "BasinReading only",
          v1_9_xy: [
            1172,
            912
          ],
          decided: "D-C6 (recommended, accepted Jonathan 2026-09-27)",
          v2_5_xy: [
            1173,
            912
          ],
          v2_5_h: 52,
          decided_v2_6: "D-M3 (Jonathan 2026-09-28): Mountain v2 DAM_PARTS.promenade[6] + offset; BasinReading only; the region draws the plaques, the Horizon keeps its place pad as a deck (no earth)"
        },
        {
          id: "L02",
          label: "Summit lookout, observatory, the bell",
          xy: [
            1310,
            470
          ],
          h: 158
        }
      ],
      profileRule: "widths and lengths of routes scale with scale.factor (they are concept metres); clearances, gauges, rises and anything sized to the body or a vehicle are engine units and never scale",
      profiles: {
        road: {
          surface_m: 8,
          shoulder_m: 1,
          clear_m: 5,
          grade_typ_pct: [
            4,
            6
          ],
          grade_review_pct: 8,
          grade_max_pct: 12,
          exception: "the Prow cliff drive may hold 13 % for \u2264 150 m with a passing place",
          kerb: true,
          parapet_on_drop: true,
          exceptions: [
            "the Prow cliff drive may hold 13 % for \u2264 150 m with a passing place",
            "Crown Road (V02) may hold 12 % continuously for its climb from [1454,411] to the Shoulder Tunnel (\u2248 300 m): the manifest geometry forces 36 m over 382 m; every other stretch over 8 % is listed in the bake report"
          ]
        },
        spur: {
          surface_m: 5,
          clear_m: 4
        },
        trail: {
          surface_m: 2.5,
          material: "gravel",
          modes: [
            "feet",
            "bicycle"
          ]
        },
        walk: {
          surface_m: [
            2,
            2.5
          ],
          modes: [
            "feet"
          ],
          grade_max_pct: 12,
          grade_typ_pct: [
            0,
            8
          ],
          note: "walks and trails, including the Year Walk: 12 % maximum, \u2264 8 % typical; a stair's step-free twin keeps \u2264 8 %"
        },
        walkable: {
          slope_max_deg: 40,
          lip_step_max_eu: 0.5,
          note: "the body cannot climb steeper than 40\xB0 (Mountain v2's kept body limit, CONTRACT); a lip above 0.5 eu is an edge, not a step"
        },
        skateMain: {
          surface_m: [
            3,
            4
          ],
          bank_deg_max: 30,
          runout_m: 25,
          grade_typ_pct: [
            8,
            14
          ],
          grade_max_pct: 18,
          note: "grades apply to the bed after the land pass solves it; S1 averages ~15 % with real gravity"
        },
        skatePocket: {
          surface_m: [
            5,
            6
          ]
        },
        boardwalk: {
          surface_m: 3,
          onPiles: true,
          pace: "flow"
        },
        stair: {
          width_m: 3,
          rise_m: 0.17,
          twin: "ramp \u2264 8 % or path",
          exceptions: [
            {
              stair: "marketStair",
              twin: "none",
              stepFree: "structures.marketStair.stepFree (walk square, 94 eu at \u2264 8 %)",
              why: "D-C11"
            }
          ]
        },
        rail: {
          gauge_m: 0.9,
          tunnel_clear_m: 3.2,
          grade_max_pct: 6,
          chainLift: {
            from: [
              1300,
              420
            ],
            to: [
              1345,
              680
            ],
            note: "the Ore Line's climb out of the Deep to the South Portal is a named chain-lift incline (ORE.chainLift) exempt from grade_max_pct; the drop at [1270,450] (rail.ORE.drop) is the other named exception"
          }
        },
        cable: {
          clear_eu: 8,
          towerSpacing_m: [
            120,
            200
          ],
          note: "clear_eu never scales; spacing is concept metres"
        },
        cave: {
          clear_m: [
            6,
            30
          ],
          throatMouth_m: [
            26,
            18
          ]
        }
      },
      surfaces: {
        paved: {
          pace: "fast",
          footstep: "stone",
          grip: 1
        },
        packedEarth: {
          pace: "fast",
          footstep: "earth",
          grip: 0.95
        },
        apron: {
          pace: "flow",
          footstep: "concrete",
          note: "the dam's spillway apron",
          grip: 1
        },
        bankedTurf: {
          pace: "flow",
          footstep: "grass",
          grip: 1.1
        },
        boardwalk: {
          pace: "flow",
          footstep: "plank",
          grip: 0.9
        },
        cobble: {
          pace: "slow",
          footstep: "cobble",
          grip: 0.7
        },
        gravel: {
          pace: "slow",
          footstep: "gravel",
          grip: 0.6
        },
        sand: {
          pace: "slow",
          footstep: "sand",
          prints: true,
          grip: 0.5
        },
        plaza: {
          pace: "threshold",
          footstep: "stone",
          grip: 1
        },
        duff: {
          pace: "n/a",
          footstep: "needles",
          grip: null
        },
        ochre: {
          pace: "fast",
          footstep: "dust",
          grip: 0.85
        },
        snow: {
          pace: "slow",
          footstep: "snow",
          season: "Dec\u2013Mar",
          grip: 0.4
        },
        ice: {
          pace: "skate",
          footstep: "ice",
          season: "Jan\u2013Feb",
          where: "stillwater",
          grip: 0.2
        },
        stone: {
          pace: "threshold",
          footstep: "stone",
          grip: 1,
          note: "threshold pads, station slabs and the Tideline park"
        }
      },
      paces: {
        fast: {
          roll: 0.12,
          pushGrip: 1,
          meaning: "open line"
        },
        flow: {
          roll: 0.25,
          pushGrip: 0.9,
          meaning: "banked or boarded ground that wants a carve"
        },
        slow: {
          roll: 0.6,
          pushGrip: 0.8,
          meaning: "a neighbourhood, a chicane"
        },
        threshold: {
          roll: 1.8,
          pushGrip: 0.5,
          meaning: "every pad and the square: stops a board arriving under ~4.6 m/s in a pad's 6 m"
        },
        skate: {
          roll: 0.03,
          pushGrip: null,
          meaning: "pass 4's ice; the skates' pace"
        },
        "n/a": {
          roll: null,
          pushGrip: null,
          note: "not a bed for this mover; the kernel's offbed class applies (roll 6.0, pushGrip 0)"
        }
      },
      roads: {
        V01: {
          label: "Horizon Drive",
          pts: [
            [
              1400,
              1060
            ],
            [
              1480,
              1040
            ],
            [
              1543.2,
              1001.4
            ],
            [
              1600,
              860
            ],
            [
              1590,
              700
            ],
            [
              1560,
              500
            ],
            [
              1546,
              472
            ],
            [
              1520.4,
              439.7
            ],
            [
              1493.5,
              406.5
            ],
            [
              1461.6,
              373.9
            ],
            [
              1433.3,
              335.6
            ],
            [
              1397.2,
              306.5
            ],
            [
              1353.8,
              295.8
            ],
            [
              1300,
              260
            ],
            [
              1120,
              250
            ],
            [
              900,
              290
            ],
            [
              720,
              300
            ],
            [
              560,
              360
            ],
            [
              400,
              470
            ],
            [
              360,
              650
            ],
            [
              390,
              850
            ],
            [
              460,
              1030
            ],
            [
              660,
              1170
            ],
            [
              760,
              1250
            ],
            [
              900,
              1360
            ],
            [
              1100,
              1400
            ],
            [
              1300,
              1380
            ],
            [
              1350,
              1345
            ],
            [
              1370,
              1260
            ],
            [
              1360,
              1160
            ],
            [
              1400,
              1060
            ]
          ],
          closed: true,
          profile: "road",
          length_m: 3896,
          structures: [
            "prowTunnel",
            "quayBridge",
            "bightBridge"
          ],
          v1_8_pts: [
            [
              1400,
              1060
            ],
            [
              1480,
              1040
            ],
            [
              1540,
              1e3
            ],
            [
              1600,
              860
            ],
            [
              1590,
              700
            ],
            [
              1560,
              500
            ],
            [
              1500,
              340
            ],
            [
              1300,
              260
            ],
            [
              1120,
              250
            ],
            [
              900,
              290
            ],
            [
              720,
              300
            ],
            [
              560,
              360
            ],
            [
              400,
              470
            ],
            [
              360,
              650
            ],
            [
              390,
              850
            ],
            [
              460,
              1030
            ],
            [
              660,
              1170
            ],
            [
              760,
              1250
            ],
            [
              900,
              1360
            ],
            [
              1100,
              1400
            ],
            [
              1300,
              1380
            ],
            [
              1350,
              1345
            ],
            [
              1370,
              1260
            ],
            [
              1360,
              1160
            ],
            [
              1400,
              1060
            ]
          ],
          note_v1_9: "north-east corner re-laid on the cliff 10 m inside its top (was a chord over the sea through [1500,340]); Crown Road starts at [1433.3,335.6]"
        },
        VG: {
          label: "Green Road",
          pts: [
            [
              1400,
              1060
            ],
            [
              1330,
              1090
            ],
            [
              1240,
              1105
            ],
            [
              1120,
              1080
            ],
            [
              1e3,
              1e3
            ],
            [
              960,
              860
            ],
            [
              980,
              700
            ],
            [
              1e3,
              600
            ],
            [
              940,
              460
            ],
            [
              930,
              330
            ],
            [
              900,
              290
            ]
          ],
          profile: "road",
          length_m: 1176,
          structures: [
            "highSpan",
            "hollowBridge"
          ]
        },
        VBS: {
          label: "Bight Shore spur",
          pts: [
            [
              960,
              860
            ],
            [
              905,
              885
            ],
            [
              875,
              940
            ],
            [
              840,
              1e3
            ],
            [
              800,
              1065
            ],
            [
              775,
              1125
            ]
          ],
          profile: "spur",
          length_m: 334
        },
        spurs: {
          upperStreet: [
            [
              1480,
              1040
            ],
            [
              1480,
              1060
            ]
          ],
          library: [
            [
              900,
              290
            ],
            [
              760,
              360
            ]
          ],
          glasshouse: [
            [
              960,
              860
            ],
            [
              1e3,
              830
            ]
          ],
          studio: [
            [
              974,
              540
            ],
            [
              1e3,
              540
            ]
          ],
          cottage: [
            [
              980,
              700
            ],
            [
              930,
              650
            ]
          ],
          boathouse: [
            [
              1300,
              1380
            ],
            [
              1290,
              1345
            ]
          ]
        },
        V03: {
          label: "Mountain Road",
          pts: [
            [
              1599.5,
              790.8
            ],
            [
              1575,
              791
            ],
            [
              1540,
              790.5
            ],
            [
              1505,
              790
            ],
            [
              1478,
              790
            ],
            [
              1441.5,
              789.5
            ],
            [
              1405,
              789
            ],
            [
              1389,
              787
            ],
            [
              1365,
              778
            ],
            [
              1340,
              766
            ],
            [
              1315,
              755
            ],
            [
              1295,
              746
            ],
            [
              1281.5,
              742
            ]
          ],
          profile: "road",
          grade_max_pct: 10,
          length_m: 327,
          structures: [
            "mountainRoadTunnel",
            "mountainRoadCanalBridge"
          ],
          from: "Horizon Drive (V01) on the Prow cliff drive at [1599.5,790.8], north of the Terraces lay-bys (the plots stand 15 m apart between them)",
          to: "Mountain v2 town lane 22 m south of the road foot [1282, 54.65, 720] (the funicular town station and its viaduct stand east of the foot); the lane carries wheels on to the foot",
          levels: [
            {
              xy: [
                1478,
                790
              ],
              h: 45,
              why: "the tunnel east portal"
            },
            {
              xy: [
                1405,
                789
              ],
              h: 52.3,
              why: "the tunnel west portal"
            },
            {
              xy: [
                1389,
                787
              ],
              h: 53.8,
              why: "the Foot terrace edge (the island, r 84)"
            },
            {
              xy: [
                1300.5,
                748
              ],
              h: 56,
              why: "the canal bridge over v2 town channel (54.18): 1.25 clear under its deck"
            },
            {
              xy: [
                1281.5,
                742
              ],
              h: 55.3,
              why: "v2 town lane (course point 326)"
            }
          ],
          decided: "D-M4 (design lead; confirm)",
          note: "v2.6: the only wheeled way onto the mountain. East of the Foot terrace the Shoulder remnant (97-99) stands between the Prow drive and the Foot: the spur crosses the Terraces hollow on an embankment and passes under the ridge in the Mountain Road Tunnel (73 m), then crosses the Foot terrace and v2 town channel on a short bridge."
        }
      },
      skate: {
        S1: {
          label: "Summit to Sea",
          pts: [
            [
              1325,
              470.5
            ],
            [
              1331.54,
              473
            ],
            [
              1339.99,
              476.08
            ],
            [
              1348.81,
              477.43
            ],
            [
              1357.52,
              475.22
            ],
            [
              1366.21,
              472.97
            ],
            [
              1375.14,
              471.85
            ],
            [
              1384.08,
              472.2
            ],
            [
              1391.5,
              477.08
            ],
            [
              1390.88,
              485.13
            ],
            [
              1383.56,
              490.06
            ],
            [
              1374.75,
              491.82
            ],
            [
              1365.77,
              492.32
            ],
            [
              1357.47,
              495.64
            ],
            [
              1352.61,
              502.61
            ],
            [
              1356.6,
              510.27
            ],
            [
              1365.09,
              513.11
            ],
            [
              1374,
              513.98
            ],
            [
              1382.74,
              515.3
            ],
            [
              1390.21,
              520.21
            ],
            [
              1395.48,
              527.46
            ],
            [
              1397.01,
              536.18
            ],
            [
              1394.19,
              544.66
            ],
            [
              1388.47,
              551.55
            ],
            [
              1380.61,
              555.72
            ],
            [
              1371.65,
              556.06
            ],
            [
              1362.74,
              554.9
            ],
            [
              1354.15,
              552.21
            ],
            [
              1345.29,
              551.04
            ],
            [
              1336.45,
              552.68
            ],
            [
              1327.51,
              553.53
            ],
            [
              1318.52,
              553.24
            ],
            [
              1309.59,
              552.2
            ],
            [
              1300.86,
              550.05
            ],
            [
              1292.54,
              546.64
            ],
            [
              1284.48,
              542.66
            ],
            [
              1276.38,
              538.74
            ],
            [
              1268.31,
              534.77
            ],
            [
              1260.07,
              531.14
            ],
            [
              1251.6,
              528.12
            ],
            [
              1242.73,
              526.82
            ],
            [
              1233.78,
              527.6
            ],
            [
              1225.14,
              530.07
            ],
            [
              1217.15,
              534.14
            ],
            [
              1211.31,
              540.91
            ],
            [
              1208.15,
              549.27
            ],
            [
              1209.52,
              558.05
            ],
            [
              1214.49,
              565.47
            ],
            [
              1222.44,
              569.55
            ],
            [
              1231.2,
              571.57
            ],
            [
              1240.17,
              571.91
            ],
            [
              1248.93,
              570.06
            ],
            [
              1257.27,
              566.7
            ],
            [
              1266.01,
              564.57
            ],
            [
              1274.95,
              564.11
            ],
            [
              1283.46,
              566.95
            ],
            [
              1291.92,
              569.98
            ],
            [
              1300.85,
              570.99
            ],
            [
              1309.83,
              571.58
            ],
            [
              1318.62,
              573.44
            ],
            [
              1327.23,
              576.04
            ],
            [
              1335.39,
              579.78
            ],
            [
              1339.25,
              587.29
            ],
            [
              1342.36,
              595.43
            ],
            [
              1349.05,
              601.41
            ],
            [
              1357.22,
              605.1
            ],
            [
              1366.09,
              605.63
            ],
            [
              1374.19,
              601.75
            ],
            [
              1382.61,
              598.62
            ],
            [
              1391.46,
              598.82
            ],
            [
              1398.43,
              604.09
            ],
            [
              1400.79,
              612.74
            ],
            [
              1401.41,
              621.7
            ],
            [
              1400.54,
              630.65
            ],
            [
              1398.3,
              639.33
            ],
            [
              1393.69,
              647.04
            ],
            [
              1387.3,
              653.33
            ],
            [
              1379.45,
              657.69
            ],
            [
              1371.13,
              661.12
            ],
            [
              1362.51,
              663.63
            ],
            [
              1353.55,
              663.87
            ],
            [
              1344.6,
              663
            ],
            [
              1335.61,
              663
            ],
            [
              1328.27,
              667.6
            ],
            [
              1329.4,
              675.63
            ],
            [
              1336.93,
              680.32
            ],
            [
              1345.76,
              681.93
            ],
            [
              1354.75,
              681.99
            ],
            [
              1363.74,
              681.59
            ],
            [
              1372.54,
              682.88
            ],
            [
              1378.48,
              688.95
            ],
            [
              1375.09,
              696.85
            ],
            [
              1366.84,
              700.35
            ],
            [
              1357.95,
              701.53
            ],
            [
              1349.03,
              700.51
            ],
            [
              1340.62,
              697.41
            ],
            [
              1332.83,
              692.92
            ],
            [
              1324.54,
              689.43
            ],
            [
              1316.06,
              686.41
            ],
            [
              1307.18,
              685.36
            ],
            [
              1298.33,
              686.89
            ],
            [
              1290.18,
              690.62
            ],
            [
              1283.75,
              696.82
            ],
            [
              1280.51,
              705.14
            ],
            [
              1281.07,
              714.08
            ],
            [
              1281.91,
              721.5
            ],
            [
              1281.66,
              726
            ],
            [
              1281.49,
              730.51
            ],
            [
              1281.43,
              735.02
            ],
            [
              1281.46,
              739.53
            ],
            [
              1281.54,
              744.04
            ],
            [
              1281.68,
              748.55
            ],
            [
              1281.93,
              753.05
            ],
            [
              1282.3,
              757.54
            ],
            [
              1282.8,
              762.02
            ],
            [
              1283.6,
              766.46
            ],
            [
              1284.76,
              770.82
            ],
            [
              1286.22,
              775.09
            ],
            [
              1288.01,
              779.22
            ],
            [
              1290.13,
              783.2
            ],
            [
              1292.68,
              786.91
            ],
            [
              1295.63,
              790.32
            ],
            [
              1299.75,
              791.8
            ],
            [
              1304.17,
              790.95
            ],
            [
              1308.23,
              789
            ],
            [
              1312.54,
              787.89
            ],
            [
              1316.97,
              788.58
            ],
            [
              1320.77,
              790.95
            ],
            [
              1323.81,
              794.27
            ],
            [
              1326.36,
              797.99
            ],
            [
              1328.48,
              801.97
            ],
            [
              1305,
              822
            ],
            [
              1275,
              830
            ],
            [
              1225,
              905
            ],
            [
              1160,
              935
            ],
            [
              1150,
              1e3
            ],
            [
              1195,
              1075
            ],
            [
              1204,
              1080
            ],
            [
              1204,
              1133
            ],
            [
              1225,
              1150
            ],
            [
              1250,
              1230
            ],
            [
              1265,
              1290
            ],
            [
              1270,
              1330
            ]
          ],
          profile: "skateMain",
          length_m: 1712,
          segments: [
            {
              name: "Summit start",
              pace: "fast",
              surface: "paved",
              spot: "the summit gate",
              start: [
                1325,
                470.5
              ],
              mountainV2: "summit-start"
            },
            {
              name: "Alpine bends",
              pace: "flow",
              surface: "paved",
              spot: "switchback carves",
              start: [
                1351.77,
                476.92
              ],
              mountainV2: "alpine-bends"
            },
            {
              name: "Dam overlook",
              pace: "flow",
              surface: "paved",
              spot: "the glass dam below",
              start: [
                1355.03,
                497.39
              ],
              mountainV2: "dam-overlook"
            },
            {
              name: "Meadow sweep",
              pace: "flow",
              surface: "paved",
              spot: "terraced meadows",
              start: [
                1359.86,
                554.06
              ],
              mountainV2: "meadow-sweep"
            },
            {
              name: "Woodland bridges",
              pace: "fast",
              surface: "paved",
              spot: "the gorge bridges",
              start: [
                1283.46,
                566.95
              ],
              mountainV2: "woodland-bridges"
            },
            {
              name: "Library balcony",
              pace: "slow",
              surface: "paved",
              spot: "the Library balcony",
              start: [
                1351.65,
                602.9
              ],
              mountainV2: "library-balcony"
            },
            {
              name: "Neighbourhood switchbacks",
              pace: "flow",
              surface: "paved",
              spot: "hairpins",
              start: [
                1400.79,
                612.74
              ],
              mountainV2: "neighbourhood-switchbacks"
            },
            {
              name: "Town canal crossing",
              pace: "slow",
              surface: "cobble",
              spot: "the canal bridge",
              start: [
                1310.18,
                685.35
              ],
              mountainV2: "town-canal-crossing"
            },
            {
              name: "Waterfront finish",
              pace: "fast",
              surface: "paved",
              spot: "the quay finish gate",
              start: [
                1319.62,
                789.99
              ],
              mountainV2: "waterfront-finish"
            },
            {
              name: "Sill",
              pace: "flow",
              surface: "paved",
              spot: "the rock shelf beside Stillwater falls (was the Dam apron)",
              start: [
                1305,
                822
              ]
            },
            {
              name: "Notch shelf",
              pace: "fast",
              surface: "paved",
              spot: "shelf rail grind under the High Span",
              start: [
                1150,
                1e3
              ]
            },
            {
              name: "Reach boardwalk",
              pace: "slow",
              surface: "cobble",
              spot: "reed chicane",
              start: [
                1250,
                1230
              ]
            },
            {
              name: "Quay finish",
              pace: "fast",
              surface: "paved",
              spot: "bollards; 25 m run-out",
              start: [
                1265,
                1290
              ]
            }
          ],
          gates: 17,
          finish: [
            1270,
            1330
          ],
          time_target_s: [
            70,
            130
          ],
          steep: "v2.6: the upper half is Mountain v2 race course (its own grades); the Horizon stretch falls from the quay finish (54.7) to the sill shelf (31) at <= 18 %",
          v1_8_pts: [
            [
              1310,
              500
            ],
            [
              1300,
              570
            ],
            [
              1305,
              640
            ],
            [
              1300,
              700
            ],
            [
              1355,
              745
            ],
            [
              1310,
              800
            ],
            [
              1275,
              830
            ],
            [
              1225,
              905
            ],
            [
              1160,
              935
            ],
            [
              1150,
              1e3
            ],
            [
              1195,
              1075
            ],
            [
              1225,
              1150
            ],
            [
              1250,
              1230
            ],
            [
              1265,
              1290
            ],
            [
              1270,
              1330
            ]
          ],
          v2_5_pts: [
            [
              1310,
              500
            ],
            [
              1300,
              570
            ],
            [
              1305,
              640
            ],
            [
              1300,
              700
            ],
            [
              1355,
              745
            ],
            [
              1310,
              800
            ],
            [
              1275,
              830
            ],
            [
              1225,
              905
            ],
            [
              1160,
              935
            ],
            [
              1150,
              1e3
            ],
            [
              1195,
              1075
            ],
            [
              1204,
              1080
            ],
            [
              1204,
              1133
            ],
            [
              1225,
              1150
            ],
            [
              1250,
              1230
            ],
            [
              1265,
              1290
            ],
            [
              1270,
              1330
            ]
          ],
          v2_5_segments: [
            {
              name: "Crown drop",
              pace: "fast",
              surface: "paved",
              spot: "parapets"
            },
            {
              name: "Shoulder sweep",
              pace: "flow",
              surface: "bankedTurf",
              spot: "rock lip (optional jump)"
            },
            {
              name: "Dam apron",
              pace: "flow",
              surface: "apron",
              spot: "half-pipe wall ride; level line beside"
            },
            {
              name: "Notch shelf",
              pace: "fast",
              surface: "paved",
              spot: "shelf rail grind under the High Span"
            },
            {
              name: "Reach boardwalk",
              pace: "slow",
              surface: "cobble",
              spot: "reed chicane"
            },
            {
              name: "Quay finish",
              pace: "fast",
              surface: "paved",
              spot: "bollards; 25 m run-out"
            }
          ],
          v2_5_length_m: 971,
          mountainV2: {
            upperPts: 131,
            course: "land/mountainV2/v2-data.json course.points (Mountain v2 MOUNTAIN_COURSE_POINTS + offset, summit start to the quay finish gate); the builder lays these exact 3-D points, the first upperPts plan points above are their every-third copy",
            finish: [
              1328.48,
              54.72,
              801.97
            ],
            gates: [
              {
                id: "mountain-gate-start",
                name: "Summit start",
                segment: "summit-start",
                at: [
                  1325,
                  158.2,
                  470.5
                ]
              },
              {
                id: "mountain-gate-alpine-1",
                name: "Alpine bends \xB7 crown",
                segment: "alpine-bends",
                at: [
                  1381.13,
                  152.92,
                  471.72
                ]
              },
              {
                id: "mountain-gate-alpine-2",
                name: "Alpine bends \xB7 high terrace",
                segment: "alpine-bends",
                at: [
                  1388.83,
                  150.56,
                  487.31
                ]
              },
              {
                id: "mountain-gate-alpine-3",
                name: "Alpine bends \xB7 Reservoir Heights",
                segment: "alpine-bends",
                at: [
                  1362.87,
                  147.41,
                  493.05
                ]
              },
              {
                id: "mountain-gate-dam-overlook",
                name: "Dam overlook",
                segment: "dam-overlook",
                at: [
                  1352.61,
                  145.59,
                  502.61
                ]
              },
              {
                id: "mountain-gate-meadow-1",
                name: "Meadow sweep \xB7 upper terrace",
                segment: "meadow-sweep",
                at: [
                  1257.28,
                  119.79,
                  530.06
                ]
              },
              {
                id: "mountain-gate-meadow-2",
                name: "Meadow sweep \xB7 the turn",
                segment: "meadow-sweep",
                at: [
                  1212.97,
                  113.09,
                  538.41
                ]
              },
              {
                id: "mountain-gate-meadow-3",
                name: "Meadow sweep \xB7 lower terrace",
                segment: "meadow-sweep",
                at: [
                  1251.69,
                  103.5,
                  568.88
                ]
              },
              {
                id: "mountain-gate-woodland-bridge",
                name: "Woodland bridge",
                segment: "woodland-bridges",
                at: [
                  1315.72,
                  96.21,
                  572.68
                ]
              },
              {
                id: "mountain-gate-library",
                name: "Library Woods",
                segment: "library-balcony",
                at: [
                  1396.68,
                  84.51,
                  601.68
                ]
              },
              {
                id: "mountain-gate-east-arm",
                name: "East arm sweep",
                segment: "neighbourhood-switchbacks",
                at: [
                  1401.23,
                  81.33,
                  624.69
                ]
              },
              {
                id: "mountain-gate-hearth",
                name: "Hearth Terrace",
                segment: "neighbourhood-switchbacks",
                at: [
                  1376.7,
                  75.48,
                  658.89
                ]
              },
              {
                id: "mountain-gate-switchback-2",
                name: "Second switchback",
                segment: "neighbourhood-switchbacks",
                at: [
                  1354.75,
                  66.48,
                  681.99
                ]
              },
              {
                id: "mountain-gate-switchback-1",
                name: "First switchback",
                segment: "neighbourhood-switchbacks",
                at: [
                  1360.94,
                  62.21,
                  701.38
                ]
              },
              {
                id: "mountain-gate-road-foot",
                name: "Road foot",
                segment: "town-canal-crossing",
                at: [
                  1282,
                  54.65,
                  720
                ]
              },
              {
                id: "mountain-gate-canal",
                name: "Canal bridge",
                segment: "town-canal-crossing",
                at: [
                  1304.17,
                  55.1,
                  790.95
                ]
              },
              {
                id: "mountain-gate-finish",
                name: "Quay finish",
                segment: "waterfront-finish",
                at: [
                  1328.48,
                  54.72,
                  801.97
                ]
              }
            ],
            decided: "D-M5 (design lead; confirm)"
          },
          segmentRule_v2_6: "each segment runs from its start (the nearest point of the built line) to the next start; the v2 segments are MOUNTAIN_RACE_SEGMENTS",
          gatesNote_v2_6: "the 17 gates are Mountain v2 MOUNTAIN_GATES (mountainV2.gates); the Horizon stretch below the quay finish is ungated",
          note_v2_6: "D-M5: upper half = Mountain v2 MOUNTAIN_COURSE_POINTS + offset (summit start [1325,470.5] to the quay finish [1328.5,802]); then the sill, the Notch shelf, the Reach and the Landing quay. The Shoulder sweep, the Crown drop and the Dam apron are retired."
        },
        S2: {
          label: "The Wash Run",
          pts: [
            [
              480,
              480
            ],
            [
              475,
              580
            ],
            [
              465,
              700
            ],
            [
              485,
              800
            ],
            [
              510,
              900
            ],
            [
              480,
              985
            ],
            [
              466.1,
              1021.3
            ],
            [
              490.7,
              1038.5
            ],
            [
              548,
              1078.7
            ],
            [
              556.1,
              1095
            ],
            [
              564.1,
              1111.4
            ],
            [
              621.5,
              1151.6
            ],
            [
              655.9,
              1175.7
            ],
            [
              672,
              1192
            ],
            [
              690,
              1210
            ],
            [
              712,
              1230
            ],
            [
              750,
              1265
            ],
            [
              880,
              1375
            ],
            [
              1e3,
              1405
            ],
            [
              1020,
              1430
            ]
          ],
          profile: "skateMain",
          length_m: 1259,
          segments: [
            {
              name: "Strip rim",
              pace: "fast",
              surface: "ochre"
            },
            {
              name: "The Wash bowl",
              pace: "flow",
              surface: "ochre",
              spot: "bowl walls both sides; hip at the bend; centre [465,700]"
            },
            {
              name: "Bight Bridge",
              pace: "flow",
              surface: "boardwalk",
              spot: "S2.archCrown, S2.westAbutmentBank, S2.eastAbutmentBank, S2.deckRail (skate.S2.spots)",
              v1_9_spot: "full-length rail"
            },
            {
              name: "Landing road",
              pace: "slow",
              surface: "gravel",
              spot: "dune-ridge hip into the park"
            }
          ],
          v1_9_pts: [
            [
              480,
              480
            ],
            [
              475,
              580
            ],
            [
              465,
              700
            ],
            [
              485,
              800
            ],
            [
              510,
              900
            ],
            [
              480,
              985
            ],
            [
              470,
              1030
            ],
            [
              560,
              1100
            ],
            [
              650,
              1185
            ],
            [
              750,
              1265
            ],
            [
              880,
              1375
            ],
            [
              1e3,
              1405
            ],
            [
              1020,
              1430
            ]
          ],
          levels: [
            {
              xy: [
                485,
                800
              ],
              h: 23.7,
              why: "the Wash rim: the top of the west ramp"
            },
            {
              xy: [
                466.1,
                1021.3
              ],
              h: 12,
              why: "the west abutment's deck end"
            },
            {
              xy: [
                490.7,
                1038.5
              ],
              h: 12,
              why: "the lagoon lane starts its 8 % climb to the flyover"
            },
            {
              xy: [
                548,
                1078.7
              ],
              h: 17.6,
              why: "the flyover's west end"
            },
            {
              xy: [
                564.1,
                1111.4
              ],
              h: 17.6,
              why: "the flyover's east end"
            },
            {
              xy: [
                621.5,
                1151.6
              ],
              h: 12,
              why: "back on the sea lane at deck height"
            },
            {
              xy: [
                655.9,
                1175.7
              ],
              h: 12,
              why: "the east abutment's deck end: the banked descent starts"
            },
            {
              xy: [
                712,
                1230
              ],
              h: 6.5,
              why: "the foot of the banked descent on the sea-side shelf"
            }
          ],
          westRamp: {
            from: [
              485,
              800
            ],
            from_h: 23.7,
            to: [
              466.1,
              1021.3
            ],
            to_h: 12,
            grade_pct: 5,
            carried: "one even grade from the Wash down to the deck: a timber trestle over the Wash mouth (x 495-515, z 830-925, up to 18.6 over the dry bed, under the Bight pier stair) and a cutting of at most 4 eu through the spit knoll [480-492, 950-1010]",
            why: "D-A1: S2 could not descend from the Wash to the deck at 18 % (it dipped to 11.9 in the Wash mouth and climbed 18.5 again, v1.8 open item); within profiles.skateMain (grade_max_pct 18, typical 8-14)"
          },
          deckLanes: {
            structure: "bightBridge",
            lagoon: {
              from_s: 0,
              to_s: 100,
              offset_m: 10.6
            },
            flyover: "bightBridge.s2Flyover (s 100 \u2192 132)",
            sea: {
              from_s: 132,
              to_s: 244,
              offset_m: -7
            },
            note: "offsets from the V01 axis (+ toward the Bight); S2 never rides the road's shoulder and never crosses it at grade"
          },
          eastDescent: {
            kind: "bankedDescent",
            from: [
              655.9,
              1175.7
            ],
            from_h: 12,
            to: [
              712,
              1230
            ],
            to_h: 6.5,
            via: [
              [
                672,
                1192
              ],
              [
                690,
                1210
              ]
            ],
            bank_deg: [
              12,
              20
            ],
            radius_m: 45,
            grade_pct: 7.1,
            why: "D-A1: S2 left the deck at [606.6,1144.1] and came down over the lagoon with nothing under it (the island's worst drop, 24.0 eu); it now stays on the deck to the east abutment and carves a right-hand banked descent down the headland's sea-side shelf onto its old line to [750,1265]",
            bank: "the outside of the curve is the east abutment's wing wall battered to a bank (spot S2.eastAbutmentBank)"
          },
          spots: [
            {
              id: "S2.archCrown",
              kind: "rail",
              bed: "S2",
              on: "bightBridge.s2Flyover",
              xy: [
                556.1,
                1095
              ],
              h: 17.6,
              length_m: 24,
              groundLine: "the flyover deck beside the rail: roll over the crown without touching it",
              requiredJump: false,
              note: "the flyover's crown parapet rail under the steel arch, 5.6 above the road deck"
            },
            {
              id: "S2.westAbutmentBank",
              kind: "bank lip",
              bed: "S2",
              on: "bightBridge west abutment",
              xy: [
                461.5,
                1015.7
              ],
              h: 12,
              length_m: 14,
              groundLine: "the lagoon lane itself (the bank is its outer wing wall, battered to 30\xB0)",
              requiredJump: false
            },
            {
              id: "S2.eastAbutmentBank",
              kind: "bank lip",
              bed: "S2",
              on: "bightBridge east abutment",
              xy: [
                664,
                1184
              ],
              h: 11,
              length_m: 20,
              groundLine: "the descent's inside line",
              requiredJump: false
            },
            {
              id: "S2.deckRail",
              kind: "rail",
              bed: "S2",
              on: "bightBridge deck edge",
              xy: [
                516.4,
                1054.1
              ],
              h: 12,
              length_m: 244,
              groundLine: "the lane beside the rail",
              requiredJump: false,
              note: "the deck-edge rail, full length on the lagoon side to the flyover and on the sea side after it"
            }
          ],
          spotsRule: "Pass 02 M1 'Spots': rails, kerbs, walls, bollards, stairs and bank lips from pass 1's beds only; kind is one of those words; every spot names its groundLine and requiredJump is always false"
        },
        S3: {
          label: "Town Weave",
          pts: [
            [
              1480,
              1060
            ],
            [
              1500,
              1120
            ],
            [
              1470,
              1160
            ],
            [
              1440,
              1200
            ],
            [
              1470,
              1260
            ],
            [
              1430,
              1300
            ],
            [
              1390,
              1330
            ],
            [
              1350,
              1345
            ],
            [
              1290,
              1400
            ],
            [
              1200,
              1425
            ],
            [
              1100,
              1440
            ],
            [
              1020,
              1430
            ]
          ],
          profile: "skateMain",
          length_m: 736,
          segments: [
            {
              name: "Upper street",
              pace: "fast",
              surface: "paved"
            },
            {
              name: "Market stair",
              pace: "flow",
              surface: "paved",
              spot: "three flights, a rail each; ground line: park at stairTop and carry (stairs only, D-C11)",
              v1_9_spot: "three flights, a rail each; ramp = ground line"
            },
            {
              name: "The square",
              pace: "threshold",
              surface: "plaza",
              spot: "park, or the cobbled edge lane"
            },
            {
              name: "The quay",
              pace: "fast",
              surface: "paved",
              spot: "lantern posts, bollards"
            },
            {
              name: "Long Sands boardwalk",
              pace: "flow",
              surface: "boardwalk",
              spot: "kicker at each beach stair"
            }
          ]
        },
        S4: {
          label: "Hollow Line",
          pts: [
            [
              1e3,
              520
            ],
            [
              940,
              560
            ],
            [
              893,
              600
            ],
            [
              915,
              665
            ],
            [
              920,
              740
            ],
            [
              945,
              820
            ],
            [
              870,
              930
            ],
            [
              905,
              1015
            ],
            [
              900,
              1120
            ],
            [
              950,
              1230
            ],
            [
              990,
              1330
            ],
            [
              1005,
              1375
            ],
            [
              1020,
              1430
            ]
          ],
          profile: "skateMain",
          length_m: 1025,
          segments: [
            {
              name: "Studio terrace",
              pace: "flow",
              surface: "packedEarth",
              spot: "kiln retaining wall grind"
            },
            {
              name: "Orchard wall",
              pace: "slow",
              surface: "cobble",
              spot: "stone wall gap; covered-bridge rail"
            },
            {
              name: "The Green",
              pace: "fast",
              surface: "packedEarth",
              spot: "fallen-log kickers"
            },
            {
              name: "Dune ridge",
              pace: "flow",
              surface: "bankedTurf",
              spot: "last bank onto sand"
            }
          ]
        },
        park: {
          label: "Tideline park",
          xy: [
            1020,
            1430
          ],
          size: [
            60,
            32
          ],
          note: "Skate v2 park; forgiving landings only (RIDE D40); no race"
        },
        rules: [
          "no required jumps",
          "ground alternative for every spot",
          "run-out before every door",
          "board never past a threshold"
        ]
      },
      walks: {
        garden: {
          pts: [
            [
              740,
              400
            ],
            [
              800,
              480
            ],
            [
              880,
              560
            ],
            [
              930,
              660
            ],
            [
              990,
              780
            ]
          ],
          profile: "walk",
          length_m: 459
        },
        lakerim: {
          pts: [
            [
              990,
              780
            ],
            [
              1030,
              740
            ],
            [
              1130,
              720
            ],
            [
              1235,
              755
            ],
            [
              1250,
              840
            ],
            [
              1200,
              900
            ],
            [
              1166,
              905
            ]
          ],
          profile: "trail",
          length_m: 494,
          v2_1_surface_m: 5.2,
          v2_1_shoulder_m: 1.2,
          v2_1_surfaceNote: "the Year Walk's February share rides this trail at offset 0: the trail takes the Year Walk's section (5.2 m + 1.2 m shoulders; profile trail 2.5 elsewhere; design lead, Stage A Wave 5 integration 2026-09-27)",
          sectionNote_v2_3: "D-D8 (design lead, Stage A Wave 7 (W7-A) 2026-09-27, reversible): the trail keeps its profile section (2.5 m); on the February share the Year Walk's own 5.2 m + 1.2 m section carries the trail, so the widening stops where the share stops ([1251,836]) and never reaches the dam end",
          v2_2_pts: [
            [
              990,
              780
            ],
            [
              1030,
              740
            ],
            [
              1130,
              720
            ],
            [
              1235,
              755
            ],
            [
              1250,
              840
            ],
            [
              1200,
              900
            ],
            [
              1140,
              905
            ]
          ],
          v2_2_crossing: {
            a: "walk lakerim",
            b: "river lower",
            at: [
              1140,
              905
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "",
            retired_v2_3: "the trail ends at the gallery exit [1166,905] (D-D8): walk damCrest \xD7 river lower [1140.2,903] is the rim's crossing"
          }
        },
        prow: {
          pts: [
            [
              1590,
              998
            ],
            [
              1606,
              950
            ],
            [
              1616,
              928
            ],
            [
              1641,
              924
            ],
            [
              1641,
              880
            ],
            [
              1640,
              812
            ],
            [
              1633,
              790
            ]
          ],
          profile: "trail",
          length_m: 466,
          v1_8_pts: [
            [
              1560,
              1e3
            ],
            [
              1600,
              880
            ],
            [
              1620,
              760
            ],
            [
              1590,
              640
            ],
            [
              1540,
              560
            ]
          ],
          note_v1_9: "re-laid on the Prow top east of V01's cutting (was along the cutting's lip, over it twice); joins the Year Walk's west Prow lane at [1630,790], short of the sea stair's head"
        },
        bight: {
          pts: [
            [
              840,
              880
            ],
            [
              790,
              950
            ],
            [
              745,
              1010
            ],
            [
              720,
              1090
            ],
            [
              700,
              1150
            ]
          ],
          profile: "trail",
          length_m: 308,
          v1_8_pts: [
            [
              840,
              880
            ],
            [
              790,
              950
            ],
            [
              745,
              1010
            ],
            [
              720,
              1090
            ],
            [
              700,
              1150
            ]
          ],
          footwayOf: {
            host: "VBS",
            offset_m: 4.2,
            side_xy: [
              1100,
              1100
            ],
            why: "D-2 (v1.9): the four Bight plots and their 6 m margins fill the land between the spur and the shore; the trail walks the spur's landward verge at the spur's height"
          }
        },
        bightPier: {
          pts: [
            [
              350,
              880
            ],
            [
              430,
              900
            ],
            [
              498,
              896
            ]
          ],
          profile: "walk",
          length_m: 213,
          v1_8_pts: [
            [
              350,
              880
            ],
            [
              430,
              900
            ],
            [
              520,
              895
            ],
            [
              560,
              890
            ]
          ]
        },
        coveWalk: {
          pts: [
            [
              740,
              400
            ],
            [
              700,
              330
            ],
            [
              650,
              270
            ],
            [
              630,
              240
            ]
          ],
          profile: "walk",
          length_m: 195
        },
        dune: {
          pts: [
            [
              1148,
              1463
            ],
            [
              1125,
              1481
            ],
            [
              1e3,
              1480
            ],
            [
              870,
              1460
            ],
            [
              810,
              1420
            ]
          ],
          profile: "trail",
          length_m: 355,
          v1_8_pts: [
            [
              1150,
              1458
            ],
            [
              1e3,
              1478
            ],
            [
              870,
              1460
            ],
            [
              810,
              1420
            ]
          ]
        },
        crown: {
          profile: "walk",
          footwayOf: {
            host: "mountainV2.road",
            offset_m: 2.4,
            side: "left",
            from_s: 228.81,
            to_s: 945.86
          },
          pts: [
            [
              1359.54,
              664.04
            ],
            [
              1387.3,
              653.33
            ],
            [
              1400.92,
              627.67
            ],
            [
              1394.23,
              599.96
            ],
            [
              1366.09,
              605.63
            ],
            [
              1340.59,
              593.02
            ],
            [
              1321.51,
              574.24
            ],
            [
              1291.92,
              569.98
            ],
            [
              1263.08,
              565.21
            ],
            [
              1234.18,
              571.88
            ],
            [
              1209.52,
              558.05
            ],
            [
              1219.68,
              532.53
            ],
            [
              1248.69,
              527.41
            ],
            [
              1276.38,
              538.74
            ],
            [
              1303.73,
              550.93
            ],
            [
              1333.5,
              553.2
            ],
            [
              1362.74,
              554.9
            ],
            [
              1390.63,
              549.47
            ],
            [
              1392.22,
              522.44
            ],
            [
              1365.09,
              513.11
            ],
            [
              1360.11,
              494.23
            ],
            [
              1388.83,
              487.31
            ],
            [
              1375.14,
              471.85
            ],
            [
              1345.82,
              477.43
            ],
            [
              1325,
              470.5
            ]
          ],
          length_m: 717,
          joinsYearWalk: {
            at: [
              1359.5,
              661.64
            ],
            h: 73.29,
            note: "v2.6: the summit walk continues the Year Walk January lane up v2 road (left side) from the Hearth terrace to the summit"
          },
          note: "v2.6 (D-M4/D-M5): the Crown walk is Mountain v2 road, left side on the carriageway, from the Hearth terrace to the summit (pts is the road centreline for reference)",
          v2_5: {
            pts: [
              [
                1417.7,
                677.4
              ],
              [
                1445,
                665
              ],
              [
                1425,
                605
              ],
              [
                1340,
                620
              ],
              [
                1400,
                540
              ],
              [
                1360,
                470
              ],
              [
                1310,
                500
              ]
            ],
            profile: "walk",
            length_m: 418,
            v1_9_pts: [
              [
                1370,
                690
              ],
              [
                1330,
                600
              ],
              [
                1310,
                500
              ]
            ],
            joinsYearWalk: {
              at: [
                1417.7,
                677.4
              ],
              h: 110.1,
              note: "D-C7 (recommended, accepted Jonathan 2026-09-27): from the turning circle [1370,690] the Crown walk is the Year Walk's January lane (one bed at 110); its own bed starts here, a flush junction"
            }
          }
        },
        glasshouseSteps: {
          pts: [
            [
              990,
              830
            ],
            [
              1e3,
              805
            ],
            [
              1010,
              790
            ]
          ],
          profile: "walk",
          length_m: 45
        },
        flats: {
          pts: [
            [
              340,
              520
            ],
            [
              320,
              700
            ],
            [
              350,
              880
            ]
          ],
          profile: "trail",
          length_m: 364
        },
        reach: {
          pts: [
            [
              1400,
              1290
            ],
            [
              1330,
              1250
            ],
            [
              1270,
              1200
            ],
            [
              1240,
              1130
            ]
          ],
          profile: "walk",
          length_m: 235
        },
        square: {
          pts: [
            [
              1420,
              1210
            ],
            [
              1455,
              1175
            ],
            [
              1490,
              1130
            ],
            [
              1480,
              1060
            ]
          ],
          profile: "walk",
          length_m: 177
        },
        footQuay: {
          pts: [
            [
              1281.5,
              742
            ],
            [
              1276,
              760
            ],
            [
              1279,
              785
            ],
            [
              1283,
              800
            ],
            [
              1282,
              810
            ]
          ],
          profile: "walk",
          length_m: 70,
          note: "v2.6 (D-M6): from the Mountain Road's end on v2's town lane to the gondola's Waterfront station point on the Foot terrace (G1.from; the boarding threshold is the platform beside it), between v2's town lane and the rope; v2's own paths are the region's (T2 graph)"
        }
      },
      cable: {
        G1: {
          label: "Gondola (Mountain v2)",
          from: [
            1282,
            810
          ],
          to: [
            1300,
            480
          ],
          fromH: 54.53,
          toH: 158.05,
          towers: [
            [
              1250,
              710
            ],
            [
              1228,
              614
            ],
            [
              1370,
              550
            ]
          ],
          towerNote: "three towers at ~150 m spacing; heights solved in pass 1 so the cable clears terrain (the Shoulder band from [1425,848]) by profiles.cable.clear_m and passes \u2265 12 m over plot.terraces.*",
          clear_eu: 8,
          length_m: 474,
          speed: 7,
          note: "v2.6 (D-M6): Mountain v2 GONDOLA_LINE + offset: Waterfront (quay, [1282,810]) -> three towers -> Summit Commons ([1300,480]); cable = platform + hang_eu at the stations, tower tops authored, 3.2 % sag; the region draws towers, ropes, terminals and cabins (T3 rides it). The Little Harbour -> v2 quay lower leg is D-M6b (not built).",
          v1_9: {
            to: [
              1360,
              560
            ],
            toH: 112,
            towers: [
              [
                1450,
                958
              ],
              [
                1420,
                825
              ],
              [
                1390,
                693
              ]
            ],
            length_m: 543
          },
          towerSolve: "v2.6 (D-M6): the tower tops are Mountain v2 authored tops (authoredTowers, cable height); the Horizon does not re-solve them. Clearance over the baked ground is measured and reported per span. v2.5: solved (D-A3).",
          decided: "D-M6 (design lead; confirm)",
          v2_5: {
            from: [
              1480,
              1090
            ],
            to: [
              1335,
              535
            ],
            fromH: 18,
            toH: 150,
            towers: [
              [
                1445.8,
                959
              ],
              [
                1411.3,
                827.1
              ],
              [
                1380.9,
                710.7
              ]
            ],
            length_m: 574,
            towerDistances_m: [
              135.4,
              271.7,
              392
            ],
            towerMin_h_reference: {
              at_m: [
                135,
                272,
                407
              ],
              top_h: [
                83,
                110,
                151
              ],
              source: "proposals/gondola-top-station.md (Option 2 solver, no terraces rule); tower 3 now stands at 392 m, so re-solve"
            }
          },
          authoredTowers: [
            100,
            128,
            158
          ],
          hang_eu: 3.1,
          sag_pct: 3.2,
          drawnBy: "mountainV2",
          throat_m: 30,
          throatNote: "v2.6: Mountain v2's cabins leave the Waterfront platform on v2's own climb and reach the Horizon's 8 eu clearance 26-30 m out (7.5 eu over the Foot's lawn at 26 m): the station throat for the authored line is 30 m (25 m for a solved line)"
        },
        ZIP: {
          label: "Zipline",
          from: [
            1610,
            640
          ],
          to: [
            1130,
            1440
          ],
          fromH: 100,
          toH: 12,
          sag_pct: 1,
          length_m: 933,
          speed: 12,
          minClearAboveRoof_eu: 12,
          note: "the Prow tower (30 m tower, deck at h 100) \u2192 Long Sands 44 m inland, skirting the town's west edge over the Reach; at 1 % sag it overflies no roof, clears V01 by 9 m, S1 by 23 m, the Reach walk by 26 m, and crosses under the gondola cable at [1437.5,927.5], 15.0 m beneath it (D-A2: zip under gondola)",
          v1_9_note: "the Prow tower (30 m tower, deck at h 100) \u2192 Long Sands 44 m inland, skirting the town's west edge over the Reach; at 1 % sag it overflies no roof, clears V01 by 9 m, S1 by 23 m, the Reach walk by 26 m, and crosses above the gondola cable at [1442,921] with 10.7 m between cables"
        }
      },
      rail: {
        ORE: {
          label: "Ore Line",
          pts: [
            [
              1090,
              540
            ],
            [
              1160,
              520
            ],
            [
              1225,
              490
            ],
            [
              1270,
              450
            ],
            [
              1300,
              420
            ],
            [
              1360,
              480
            ],
            [
              1375,
              625
            ],
            [
              1345,
              680
            ]
          ],
          profile: "rail",
          length_m: 540,
          stations: [
            "the Adit [1090,540] h40",
            "the South Portal [1345,680] h67.5 (Mountain v2 ground, on v2 road lower switchback leg)"
          ],
          drop: {
            at: [
              1270,
              450
            ],
            fall_m: 28,
            siding: true
          },
          splash: "the Deep [1300,420]",
          note: "climbs after the Deep inside the rock, leaves the footprint at [1398,576] and runs a 119 m tunnel to the South Portal; v2.6 (D-M7): the portal drops to v2 ground (67.5): the chain-lift climbs 27.5 from the Deep, the controls [1360,480] and [1375,625] at 50 and 62",
          v2_5_stations: [
            "the Adit [1090,540] h40",
            "the South Portal [1345,680] h110 (29 m from Crown Road's turning circle)"
          ],
          heights_v2_6: [
            40,
            42,
            68,
            68,
            40,
            50,
            62,
            67.5
          ]
        }
      },
      water_routes: {
        FERRY: {
          label: "The Ferry",
          pts: [
            [
              1470,
              1340
            ],
            [
              1250,
              1540
            ],
            [
              900,
              1530
            ],
            [
              760,
              1480
            ],
            [
              640,
              1300
            ],
            [
              560,
              1100
            ],
            [
              580,
              980
            ],
            [
              560,
              890
            ],
            [
              560,
              1100
            ],
            [
              540,
              1230
            ],
            [
              380,
              1200
            ],
            [
              250,
              1150
            ],
            [
              230,
              900
            ],
            [
              285,
              720
            ],
            [
              280,
              450
            ],
            [
              450,
              250
            ],
            [
              625,
              212
            ],
            [
              900,
              110
            ],
            [
              1200,
              120
            ],
            [
              1500,
              300
            ],
            [
              1720,
              650
            ],
            [
              1712,
              790
            ],
            [
              1700,
              1e3
            ],
            [
              1560,
              1250
            ],
            [
              1470,
              1340
            ]
          ],
          closed: false,
          note: "clockwise (north up: west along Long Sands, in and out of the Bight under the bridge, round the Lamp and the Wreck, up the west, along the north, down the Prow, home); doubles back at the Bight pier",
          length_m: 5357,
          piers: {
            landing: [
              1470,
              1340
            ],
            bight: [
              560,
              890
            ],
            flats: [
              285,
              720
            ],
            scholarsCove: [
              630,
              235
            ],
            seaDoor: [
              1705,
              775
            ]
          },
          slowsAt: [
            "the Wreck [250,1150] (no stop)"
          ],
          headway_s: 370,
          hulls: 2,
          boarding: "walk the gangway (the deliberate action); the Ferry waits 20 s at each pier",
          beam_m: 8,
          beamNote: "v2.0 (D-A1): each hull's beam, authored so the Bight Bridge's navigable opening is provable (along-axis opening needed = beam / sin(angle) + deck width / tan(angle); 27.6 m at the inbound 46\xB0, the steel arch gives 34 m clear)"
        },
        ROW: {
          label: "Rowboat / canoe / dinghy water",
          area: "the Bight, the harbour, the coast to the Sea Door, the river below the Notch, the Deep",
          docks: [
            "boathouse [1320,1320]",
            "bight pier [560,890]",
            "lamp [540,1250]",
            "bightShore jetty [735,955]",
            "seaDoor jetty [1705,775]",
            "deep jetty [1300,440]"
          ],
          range: "the Wreck is reached only by Ferry (it slows there)"
        },
        RIVER_RUN: {
          label: "River Run (canoe)",
          pts: [
            [
              1160,
              740
            ],
            [
              1140,
              905
            ],
            [
              1170,
              980
            ],
            [
              1220,
              1060
            ],
            [
              1250,
              1140
            ],
            [
              1280,
              1220
            ],
            [
              1330,
              1290
            ],
            [
              1350,
              1345
            ],
            [
              1364,
              1390
            ]
          ],
          gates: 9,
          note: "starts at the lake inlet [1160,740] (the Cup's outflow is a 62 % cascade, scenery only) \u2192 lake \u2192 dam portage \u2192 Notch \u2192 Reach \u2192 harbour",
          note_v2_6: "v2.6 (D-M3): the lake inlet is v2 river mouth; the dam portage is retired, so the run crosses the sill falls with no carry: a sill portage is an open item for Jonathan"
        },
        DEEP_RUN: {
          label: "Deep Run (canoe)",
          from: "the Deep [1300,420]",
          to: "the Sea Door [1690,770]",
          pts: [
            [
              1300,
              420
            ],
            [
              1380,
              470
            ],
            [
              1470,
              540
            ],
            [
              1560,
              640
            ],
            [
              1620,
              720
            ],
            [
              1690,
              770
            ]
          ],
          length_m: 529,
          drop: "the Steps: 3 \xD7 12 m chutes in the first 120 m; then level to the sea",
          note: "the underground river through the Sea Passage; out under the Prow into daylight, then paddle round to the Landing"
        }
      },
      structures: {
        highSpan: {
          xy: [
            1240,
            1105
          ],
          kind: "bridge",
          deck: "VG road",
          h_deck: 24,
          shelf: "S1 skate shelf on the west wall, h 12",
          water: "Reach walk at river level, h 9",
          gate: "Ring Run gate 3 under the deck at h 16",
          riverbed_h: 8
        },
        quayBridge: {
          xy: [
            1350,
            1345
          ],
          kind: "bridge",
          deck: "V01 + S3 separated lane",
          h_deck: 9,
          under: "river mouth, rowboat clearance 4 m"
        },
        apronBridge: {
          xy: [
            1158,
            949
          ],
          kind: "bridge",
          deck: "S1",
          under: "the tailrace below the dam and the River Run"
        },
        bightBridge: {
          xy: [
            560,
            1100
          ],
          kind: "bridge",
          deck: "V01, the Year Walk's lagoon-side footways, and S2 as a separated skate ribbon (lagoon lane, flyover, sea lane), every deck edge railed",
          span_m: 245,
          h_deck: 12,
          clear_m: 8,
          under: "the Ferry (twice per lap), Ring Run gate 5",
          ends: {
            west: [
              460,
              1030
            ],
            east: [
              660,
              1170
            ],
            axis_m: 244.1,
            abutments: "both on the headlands and down to the ground: west a 14 \xD7 24 m embankment from the Flats spit tip [460,1020] to the deck end (it carries S2's lagoon lane and its bank), east on the shore; no bed raises the seabed under the deck"
          },
          section: {
            from_axis_m: [
              -9,
              12.6
            ],
            width_m: 21.6,
            lanes: {
              "S2 sea lane": [
                -8.75,
                -5.25
              ],
              V01: [
                -4,
                4
              ],
              "V01 shoulders": 1,
              "Year Walk footways (centres)": [
                5.2,
                7.4
              ],
              "S2 lagoon lane": [
                8.85,
                12.35
              ]
            },
            rails: "a rail on both deck edges the whole length, and a kerb rail between each S2 lane and its neighbour",
            note: "offsets from the V01 axis, + toward the Bight; the deck widens from 17 m (v1.9) to carry S2 as a lane of its own (3.5 m, profiles.skateMain.surface_m 3-4); the width is held to 21.6 so the 36 m opening still proves for the ferry (opening.needAlongAxis_m)"
          },
          opening: {
            at_s: [
              103,
              143
            ],
            centre_s: 123,
            centre: [
              560.8,
              1100.5
            ],
            width_m: 40,
            kind: "steel-arch",
            clear_eu: 11.4,
            clearWidth_m: 38,
            needAlongAxis_m: {
              beam_m: 8,
              deckWidth_m: 21.6,
              at_46deg: 32,
              at_58deg: 22.9,
              rule: "beam / sin(angle) + deck width / tan(angle) \u2264 clearWidth_m (proposals/bight-bridge.md)"
            },
            arch: "a steel through-arch above the deck (rise \u2265 10 over the deck, crown \u2265 22), its ribs on the deck edges and hangers to the deck",
            why: "36 m is past the 30 eu masonry-arch limit (STYLE \xA71.6.3), so the arch is steel; the opening covers the ferry lane (the hull crosses the deck edges at s \u2248 113-131, in at 46\xB0, out at 58\xB0) and Ring Run gate 5 (s 111); a hull of water_routes.FERRY.beam_m 8 at 46\xB0 needs 27.6 m along the axis (proposals/bight-bridge.md)",
            v2_0: {
              at_s: [
                98,
                134
              ],
              centre_s: 116,
              centre: [
                555,
                1096.5
              ],
              width_m: 36,
              clearWidth_m: 34
            },
            decided: "D-A1 (Jonathan 2026-09-27: 36 m); widened to 40 m by the design lead, Stage A Wave 5 integration 2026-09-27, reversible (opening.v2_0)",
            hullClearance_eu: {
              v2_0_36m_s98_134: -3.99,
              v2_1_40m_s103_143: 1.37,
              best_36m_s105_141: 0.15,
              rule: "an 8 m hull (water_routes.FERRY.beam_m) on the FERRY line against the arch piers' and bents' footings"
            }
          },
          bents: {
            west: {
              count: 8,
              bay_m: 11.4,
              from_s: 0,
              to_s: 103
            },
            east: {
              count: 9,
              bay_m: 10.1,
              from_s: 143,
              to_s: 244
            },
            "arch piers": [
              103,
              143
            ],
            note: "timber paired bents, every bay under the 12 eu timber limit; no bent in the opening or in S2's east descent",
            v2_0: {
              west: {
                count: 8,
                bay_m: 10.9,
                from_s: 0,
                to_s: 98
              },
              east: {
                count: 9,
                bay_m: 11,
                from_s: 134,
                to_s: 244
              },
              "arch piers": [
                98,
                134
              ]
            }
          },
          lookout: {
            id: "bightBridge.lookout",
            s: 116,
            xy: [
              562.1,
              1086.4
            ],
            deck_h: 12,
            size_m: [
              24,
              7.2
            ],
            side: "lagoon",
            from_s: 104,
            to_s: 128,
            reach: "off the Year Walk's lagoon footway at deck level, under the arch, railed on its three open sides",
            note: "a bay of the deck (a structure), not a pad: no register pad stands on the deck (D-A1); it spans o +8.8 to +16 where S2 has left the lagoon lane for the flyover, which passes 5.6 above its inner corner; its underside keeps the deck's 11.4 over the water and it stands between the arch piers, not on them"
          },
          s2Flyover: {
            id: "bightBridge.s2Flyover",
            from: [
              548,
              1078.7
            ],
            to: [
              564.1,
              1111.4
            ],
            h: 17.6,
            overRoad: [
              557.7,
              1098.4
            ],
            clear_eu: 5,
            carried: "hung from the arch between its ribs",
            note: "S2 crosses the road and the Year Walk footways once, over them, at the arch crown (register S2 \xD7 V01 'over'); ramps of 8 % up the lagoon lane (s 30 \u2192 100) and down the sea lane (s 132 \u2192 202)"
          },
          v1_9: {
            span_m: 230,
            deck: "V01 + S2 separated lane with a full-length rail",
            h_deck: 12
          },
          decided: "D-A1 option 1 (Jonathan 2026-09-27)"
        },
        hollowBridge: {
          xy: [
            893,
            600
          ],
          kind: "coveredFootbridge",
          deck: "garden walk + S4 (separated lane)",
          under: "Orchard Brook",
          note: "a covered footbridge, not on Green Road; the ninth disc-golf basket; S4 rail if you dare"
        },
        prowTunnel: {
          xy: [
            1592,
            890
          ],
          kind: "gallery",
          length_m: 90,
          route: "V01",
          section: {
            hillSide: "east (the Prow top's flank is the wall)",
            openSide: "west, a colonnade of columns on footings to the ground, open to the sea",
            roof: "a slab from the hill wall to the colonnade beam, lined and ceiled",
            headroom_eu: 5,
            carries: "Horizon Drive and its Year Walk verges (December seaward, January inland)"
          },
          cover: "report the ground over the roof as measured (a gallery needs none); no fill is made to fake a tunnel",
          grade: "V01 unchanged: 25.6 \u2192 30.9 over the 90 m on the candidate-3 bed (\u2248 6 %)",
          v1_9: {
            xy: [
              1600,
              780
            ],
            kind: "tunnel",
            length_m: 90
          },
          decided: "D-A4 candidate A as a gallery (Jonathan 2026-09-27)",
          why: "the v1.9 box at [1600,780] stood on V01's side-hill cut with no hill over it: its roof 3 eu out of the ground, V01 8.4 under its floor at the north portal and 4.977 < 5 headroom (proposals/prow-tunnel.md)",
          kindNote: "gallery (new kind, v2.0, D-A4): a covered road on a hillside: the hill is one wall, a roof slab on a colonnade forms the other, open to the view; ceiling and lining as a tunnel, cover not required"
        },
        gondolaStations: {
          base: [
            1279.71,
            810.73
          ],
          crownStation: [
            1298.3,
            481.7
          ],
          base_deck_h: 54.53,
          crownStation_deck_h: 158.05,
          drawnBy: "mountainV2",
          note: "v2.6 (D-M6): the stations are Mountain v2 GONDOLA_LINE Waterfront (quay) and Summit Commons platforms + offset; the region draws their terminals",
          v2_5: {
            base: [
              1480,
              1090
            ],
            crownStation: [
              1335,
              535
            ],
            v1_9_crownStation: [
              1360,
              560
            ],
            crownStation_deck_h: 150,
            note: "v2.0 (D-A3): the Crown station stands at grade on the summit's south shoulder (ground 148.5, deck 150); it was in a notch 17 m below the 129.7 ridge at [1360,560] (deck 112), which forced a 275 eu tower"
          }
        },
        reachFootbridge: {
          xy: [
            1274,
            1203
          ],
          kind: "footbridge on piles",
          deck: "Reach walk",
          under: "the river"
        },
        duneCulvert: {
          xy: [
            1005,
            1375
          ],
          kind: "underpass",
          deck: "V01 (Long Sands road)",
          under: "S4, 3 m clear",
          note: "a dune tunnel; the last surprise before the sand"
        },
        southPortal: {
          xy: [
            1345,
            680
          ],
          kind: "tunnel portal",
          note: "v2.6 (D-M7): the Ore Line top station stands at Mountain v2 ground at its position (67.5, on v2 road lower switchback leg); was h 110 by Crown Road turning circle",
          h: 67.5
        },
        zipPlatforms: {
          top: [
            1610,
            640
          ],
          topH: 100,
          topNote: "deck of a 30 m tower at the Prow; the glider launch is the same deck",
          landing: [
            1130,
            1440
          ],
          landingH: 12,
          landingNote: "a landing tower on the dune crest, deck 8 m above the Town Weave boardwalk which passes beneath it; a stair and a ramp down to the sand"
        },
        oreStations: [
          [
            1090,
            540
          ],
          [
            1345,
            680
          ]
        ],
        strip: {
          from: [
            425,
            520
          ],
          to: [
            445,
            860
          ],
          width_m: 30,
          hangar: [
            455,
            600
          ],
          windsock: [
            440,
            500
          ],
          balloonMooring: [
            520,
            470
          ],
          runwayLamps: true
        },
        floatplaneDock: [
          1520,
          1275
        ],
        jetties: {
          bightShore: [
            728,
            946
          ],
          deep: [
            1300,
            440
          ],
          lamp: [
            540,
            1250
          ],
          seaDoor: [
            1705,
            775
          ],
          boathouse: [
            1320,
            1320
          ],
          bightPier: [
            560,
            896
          ]
        },
        landingQuay: {
          xy: [
            1270,
            1330
          ],
          note: "the race finish on the islet between the Reach's west channel and the river; 25 m run-out along the bank; kerb-separated from V01 which passes 45 m south; the Boathouse dock is across the west channel by the Reach boardwalk",
          v2_3_finish_h: 3,
          finish_h: 4.7,
          finishNote_v2_4: "the paved finish and its pad at the islet's natural ground (\u2248 4.7) instead of 3 (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-S request)"
        },
        townQuay: {
          from: [
            1420,
            1335
          ],
          to: [
            1497,
            1265
          ],
          note: "Lantern Row, 8 m inside the waterline; pedestrian; the floatplane dock at its east end"
        },
        gardenWalkBridge: {
          xy: [
            965.7,
            761.1
          ],
          kind: "footbridge",
          route: "walk garden",
          span_m: 40,
          opening_m: 26,
          width_m: 5.6,
          deck: "the Garden Walk on its own grade (51-55)",
          under: "Green Road (37) and its May/September footway lanes, 15 eu below",
          note: "v1.9: the Garden Walk hung 16.7 eu over Green Road at [971,765] with no structure (the generated span found no footing within 20 m); the reserved at-grade threshold row VG x walk garden (R-A7) is unchanged",
          register_v2_0: "D-A7: this footbridge is the register's VG \xD7 walk garden crossing (over), at [969.5,764.2]"
        },
        jettiesV1_8: {
          bightShore: [
            735,
            955
          ],
          why: "v1.9: the Bight Shore jetty moved 17 m north-west, out of plot bight.2's 6 m margin"
        },
        bightPierStair: {
          kind: "stair",
          from: [
            498,
            896
          ],
          to: [
            557.5,
            896
          ],
          note: "v1.9: from the Flats' cliff top (the pier walk's end) down to the Bight ferry jetty"
        },
        seaStairWestLaneBridge: {
          xy: [
            1630.9,
            762.8
          ],
          kind: "footbridge",
          route: "yearWalk",
          span_m: 14,
          opening_m: 7,
          width_m: 5.4,
          deck: "the Year Walk's west Prow lane (54)",
          under: "the sea stair's cutting (49)",
          note: "v1.9: the lane crossed the stair 4.9 eu over it with no structure"
        },
        seaStairEastLaneBridge: {
          xy: [
            1650.3,
            766.8
          ],
          kind: "footbridge",
          route: "yearWalk",
          span_m: 16,
          opening_m: 8,
          width_m: 5.4,
          deck: "the Year Walk's east Prow lane (50.6)",
          under: "the sea stair's cutting (36)",
          note: "v1.9: the lane crossed the stair 14.2 eu over it with no structure"
        },
        bightSpurTrestle: {
          xy: [
            904.9,
            891.5
          ],
          kind: "trestle",
          carries: "VBS",
          length_m: 68,
          width_m: 5,
          from: [
            923.6,
            874.5
          ],
          to: [
            881,
            926.5
          ],
          deck: "VBS on its own grade (27.4 \u2192 24.4)",
          beside: "S4 at 17.3-18.2, 4.5-7 m from VBS's centreline on the east side",
          bents: "one line on the west (away from S4) and one under the centreline; none in S4's corridor",
          decided: "D-C9 (recommended, accepted Jonathan 2026-09-27)",
          note: "v2.0: VBS hung 6-9 eu over the ground beside S4 with nothing under it (R2-04; the dropped v1.9 bightSpurBridge put its bents in S4)",
          v2_0_to: [
            891.6,
            906
          ],
          v2_0_length_m: 44,
          v2_3_from: [
            918.1,
            877
          ],
          v2_3_to: [
            886.7,
            916
          ],
          v2_3_length_m: 56,
          note_v2_4: "extended along VBS (north +6, south +12) over the 8.5 / 1.49 eu voids at its ends (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-S request 4)"
        },
        marketStair: {
          xy: [
            1472,
            1124.5
          ],
          kind: "town stair",
          foot: [
            1472,
            12,
            1134
          ],
          head: [
            1472,
            18,
            1115
          ],
          flights: 3,
          twin: "none (stairs only)",
          stepFree: {
            route: [
              "walk square"
            ],
            length_eu: 94,
            grade_pct: {
              mean: 6.4,
              max: 8
            },
            from: "the square [1478,12,1150]",
            to: "the upper street spur's end [1480,18,1062]",
            note: "the square walk climbs beside the upper-street terrace (narrowed to x 1463-1480, TOWN_TIERS) at \u2264 8 %, level with both pads (W5-A); the 295 eu detour (walk square \u2192 town.bankLink \u2192 town.northLink \u2192 V01 \u2192 spur upperStreet) is superseded and comes back if TOWN_TIERS is restored",
            decided: "D-C11 stairs only (Jonathan 2026-09-27); the square walk as the step-free way by the design lead, Stage A Wave 5 integration 2026-09-27"
          },
          decided: "D-C11 stairs only (Jonathan 2026-09-27)",
          note: "v2.0: the ramp twin (marketRamp, land/town/build.ts) is retired; no step-free 75 m run at 8 % fits beside Our home",
          v2_0_stepFree: {
            route: [
              "walk square",
              "town.bankLink",
              "town.northLink",
              "V01",
              "spur upperStreet"
            ],
            length_eu: 295,
            from: "the square",
            to: "the upper street spur's end [1480,18,1060]",
            note: "the recorded step-free way between the square and the upper street (review 2 route walk: 295.5 eu, 123 s at 2.4 m/s)"
          },
          v2_2_xy: [
            1480,
            1160
          ],
          v2_2_head: [
            1480,
            18,
            1150
          ],
          v2_2_foot: [
            1480,
            12,
            1171
          ],
          placeNote_v2_3: "the head on the upper street's south edge (was 6 m over the square at [1480,18,1150]); a level walk (town.upperStreetWalk) joins it to the gondola base walk and a level foot landing (marketStair.foot) to the square walk (design lead, Stage A Wave 7 (W7-A) 2026-09-27)"
        },
        coveStair: {
          kind: "cliff-stair",
          from: [
            631.2,
            241.9
          ],
          from_h: 34.1,
          to: [
            630,
            235
          ],
          to_h: 1,
          rise_m: 33.1,
          along: "cut into the cliff face west of the pier: two flights of \u2248 55 m run with a landing at \u2248 17, between [631,240] and [604,252] and back",
          parapet: "on the sea side, posted to the rock",
          decided: "D-C14 cliff stair (recommended, accepted Jonathan 2026-09-27)",
          note: "v2.0: the cove walk ended 32.8 above the pier; kind cliff-stair (not stair: the tower-stair builder does not apply)",
          v2_0_to_h: 1.8,
          toNote_v2_1: "the foot is the dock deck's own height (ferry.scholarsCove, 1.0); 1.8 would leave a 0.8 lip (W5-S)"
        },
        prowLoopFootbridge: {
          kind: "footbridge",
          carries: "yearWalk",
          over: "the Year Walk's own lower lane (the November loop on the Prow)",
          from: [
            1603.5,
            674.6
          ],
          to: [
            1609.8,
            702.9
          ],
          length_m: 29,
          width_m: 6,
          note: "v2.4: the Year Walk's upper pass over its own lower lane at the Prow (5.6 eu apart) on a named footbridge (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-A \u2192 W7-S request; OPEN_VOIDS yearWalk [1605,690] closed)"
        },
        mountainRoadTunnel: {
          xy: [
            1441.5,
            789.5
          ],
          kind: "tunnel",
          route: "V03",
          length_m: 73,
          width_m: 17,
          note: "v2.6 (D-M4): V03 under the Shoulder remnant east of the Foot terrace (ridge 93-99 over a road at 45-52); the Year Walk January footway rides its south side at 6.5"
        },
        mountainRoadCanalBridge: {
          xy: [
            1300.5,
            748
          ],
          kind: "footbridge",
          route: "V03",
          span_m: 18,
          width_m: 17,
          note: "v2.6: V03 over v2 town channel (water.river.mountain) on the Foot terrace; span 18 so the deck covers the Year Walk January lane's carried run (its share is carried within span/2 + 2 of the centre)"
        },
        s1InflowBridge: {
          xy: [
            1270.5,
            836.5
          ],
          kind: "footbridge",
          route: "S1",
          span_m: 12,
          width_m: 5,
          note: "v2.6: S1 over the mountain river where it runs west from the Foot into Stillwater"
        },
        inflowFootbridge: {
          xy: [
            1249,
            835.5
          ],
          kind: "footbridge",
          route: "walk lakerim",
          span_m: 10,
          width_m: 3.2,
          note: "v2.6: the lake-rim trail over the mountain river at its mouth"
        }
      },
      underground: {
        doors: {
          adit: {
            xy: [
              1090,
              540
            ],
            h: 40,
            mode: "feet, cart"
          },
          throat: {
            xy: [
              1300,
              300
            ],
            h: 110,
            mode: "glider only",
            mouth_m: [
              26,
              18
            ],
            note: "a diving entry: 139 m of sloping throat at 30\xB0 down to the Deep at h 40; flare over the water",
            collarAperture_m: 10.8,
            apertureNote: "v2.0 (D-C3, recommended, accepted Jonathan 2026-09-27): mouth_m [26,18] is the mouth's aperture on the north face; the passage opens into the Deep below its ceiling under the collar (68-76.7) with 10.8 clear (built 10.79); the clearance report checks the passage against collarAperture_m"
          },
          seaDoor: {
            xy: [
              1690,
              770
            ],
            h: 0,
            mode: "boat",
            jetty: [
              1705,
              775
            ],
            passage: "the Sea Passage: a 504 m boat tunnel from the Deep to the sea, glow-worm lit, with the Steps (three 12 m chute drops in the first 120 m; the Deep Run rides them down like a flume; reduced motion cuts them). Upstream travel: boats tie up at the foot of the Steps [1420,505] and a portage stair (threshold stepsFoot) climbs beside the chutes to the Deep's jetty; nobody paddles up. The Sea Door pier has a cliff stair (the Sea Stair) up to the Prow walk, and the Ferry as its step-free way back"
          },
          southPortal: {
            xy: [
              1345,
              680
            ],
            h: 67.5,
            mode: "feet, cart",
            note: "the Ore Line's top; a walk-in door too. v2.6 (D-M7): at Mountain v2 ground (67.45) on v2 road lower switchback leg",
            v2_5_h: 110
          }
        },
        footprint: {
          cx: 1300,
          cy: 470,
          rx: 170,
          ry: 130,
          note: "all rooms inside; doors on its rim or reached by a listed tunnel"
        },
        rooms: {
          lanternCave: {
            xy: [
              1220,
              480
            ],
            h: 42
          },
          deep: {
            xy: [
              1300,
              420
            ],
            h: 40,
            water: true,
            skylight: {
              to: [
                1320,
                400
              ],
              topH: 138,
              shaft_m: 98,
              note: "opens on the north slope 20 m east of the Throat's centreline (so the Throat's mouth of daylight reads from the Deep's jetty); sun shaft when the sun is above 20\xB0"
            }
          },
          bellGallery: {
            xy: [
              1310,
              470
            ],
            h: 90,
            note: "directly under the summit; the bell rope is 68 m"
          },
          sealedDrift: {
            xy: [
              1180,
              500
            ],
            reserve: "plot.under.1"
          }
        },
        light: "glow-worms (cool), found lanterns (warm), skylight (sun/moon)"
      },
      sky: {
        ceiling_m: 300,
        launches: {
          crown: {
            xy: [
              1322,
              472
            ],
            h: 170,
            note: "the run-off deck of the summit lookout (L02), a structure on the summit's south-west lip; the terrain summit (landforms.crown.summitH 158) stays the island's highest ground and no bed may raise the ground above it",
            v2_5_xy: [
              1305,
              482
            ],
            note_v2_6: "v2.6 (integrator, D-M6): moved 17 m east and 10 m north, clear of Mountain v2's Summit Commons gondola terminal [1300,480] and its rope (which arrives from tower 3 at [1370,550]); the deck keeps h 170 over the summit terrace, east of the observatory [1306,466]"
          },
          prow: {
            xy: [
              1610,
              640
            ],
            h: 100,
            note: "the zip tower's deck"
          },
          lampGallery: {
            xy: [
              540,
              1195
            ],
            h: 25
          },
          plane: "anywhere under the ceiling"
        },
        lift: {
          thermals: [
            {
              xy: [
                380,
                600
              ],
              r: 150,
              hours: [
                12,
                18
              ],
              note: "the Flats' ochre"
            },
            {
              xy: [
                1610,
                850
              ],
              r: 120,
              hours: [
                8,
                18
              ],
              note: "the Prow face"
            }
          ],
          ridge: {
            along: "the Crown's south face",
            wind: "south"
          },
          sink: [
            {
              xy: [
                600,
                760
              ],
              r: 200,
              note: "the Bight"
            },
            {
              xy: [
                1210,
                1010
              ],
              r: 90,
              note: "the Notch"
            }
          ]
        },
        landings: {
          green: {
            xy: [
              1028,
              1112
            ],
            r: 60,
            target: true,
            note: "the Drop Zone target is ground paint inside the protected centre, clear of Green Road (its edge 65 m north-east) and the Year Walk",
            modes: [
              "glider",
              "parachute"
            ]
          },
          reachMeadow: {
            xy: [
              1195,
              1205
            ],
            r: 40,
            modes: [
              "glider",
              "parachute"
            ],
            v2_3_xy: [
              1143,
              1167
            ],
            note_v2_4: "the nearest clear 40 m field on the low ground south of the High Span (h 4.7): the Dam Run lands 17.3 m from the centre; Prow \u2192 meadow 23.1 m in hand, 1.9 short of the 25 asked ([1230,1190] kept 25.5 but S1, the Reach walk and the spring stand in its field) (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T A6)"
          },
          sands: {
            xy: [
              1095,
              1362
            ],
            r: 60,
            modes: [
              "glider",
              "parachute"
            ],
            note_v2_4: "accepted: Prow \u2192 Sands arrives +3.5 m at 10:00 and 15:30 alike (no thermal needed); label 'Long Sands' (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T A8)"
          },
          strip: "see structures.strip",
          water: [
            "harbour",
            "bight"
          ],
          deep: "via the Throat, glider only"
        },
        gates: [
          {
            n: 1,
            id: "needle",
            xy: [
              1790,
              680
            ],
            h: 14,
            aperture_m: [
              22,
              16
            ],
            note: "the Needle's Eye; sunrise gate"
          },
          {
            n: 2,
            id: "stacks",
            xy: [
              1780,
              905
            ],
            h: 12
          },
          {
            n: 3,
            id: "highSpan",
            xy: [
              1240,
              1095
            ],
            h: 17,
            aperture_m: [
              40,
              12
            ],
            note: "under the deck (deck h 24, riverbed h 8): 40 \xD7 12 at h 17 (11\u201323), clear of the river pools (\u2264 10.8) and the bank lip; the Notch is \u2265 54 m wide there (T1)",
            v1_7: {
              h: 16,
              aperture_m: [
                40,
                14
              ]
            }
          },
          {
            n: 4,
            id: "damArch",
            xy: [
              1140,
              925
            ],
            h: 45,
            note: "the spillway arch"
          },
          {
            n: 5,
            id: "bightBridge",
            xy: [
              560,
              1080
            ],
            h: 6,
            aperture_m: [
              11,
              8
            ],
            note: "under the deck"
          },
          {
            n: 6,
            id: "lamp",
            xy: [
              540,
              1260
            ],
            h: 20.5,
            note: "round the lighthouse"
          },
          {
            n: 7,
            id: "wreck",
            xy: [
              250,
              1150
            ],
            h: 15
          },
          {
            n: 8,
            id: "flatsRim",
            xy: [
              330,
              700
            ],
            h: 60
          },
          {
            n: 9,
            id: "scholarsCove",
            xy: [
              640,
              280
            ],
            h: 48
          },
          {
            n: 10,
            id: "northFace",
            xy: [
              1300,
              200
            ],
            h: 139,
            v2_3_h: 130,
            note_v2_4: "re-seated with the lookout launch (+10 \u2192 +9): the Throat Run at trim crosses +0.2 (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T A7)"
          },
          {
            n: 11,
            id: "crown",
            xy: [
              1310,
              470
            ],
            h: 190,
            note: "over the summit"
          },
          {
            n: 12,
            id: "throat",
            xy: [
              1300,
              300
            ],
            h: 119,
            aperture_m: [
              24,
              16
            ],
            note: "into the mountain; glider only; centred on the mouth (110\u2013128), 24 \xD7 16 inside the 26 \xD7 18 mouth"
          }
        ],
        plane: {
          speed_ms: 45,
          stall_ms: 18,
          floats: true,
          wheels: true,
          swapAt: "hangar",
          oneButtonRing: true,
          cannot: [
            "enter the Throat",
            "land on a neighbourhood",
            "collide with a person"
          ]
        },
        glider: {
          speed_ms: 11,
          sink_ms: 1.2,
          flare: true
        },
        balloon: {
          xy: [
            520,
            470
          ],
          mooringH: 40,
          tether_m: 250,
          note: "the Look camera made physical; you ride it up and back down, there is no stepping out at the top"
        },
        courses: {
          ringRun: {
            mode: "plane",
            gates: [
              1,
              2,
              3,
              4,
              5,
              6,
              7,
              8,
              9,
              10,
              11
            ],
            note: "the tour, in order"
          },
          damRun: {
            mode: "glider",
            launch: "crown",
            gates: [
              4,
              3
            ],
            land: "reach meadow [1143,1167]",
            note: "514 m to the arch with 115 m of height in hand at a 9:1 glide; under the High Span, then a west turn onto the Reach meadow, 115 m past it"
          },
          throatRun: {
            mode: "glider",
            launch: "crown",
            gates: [
              10,
              12
            ],
            land: "deep",
            note: "out over the north sea, turn, dive in"
          },
          lampHop: {
            mode: "glider",
            launch: "lampGallery",
            gates: [
              5
            ],
            land: "the Bight water beside the sandbar (fade to the sandbar)",
            note: "the short one"
          }
        },
        rules: [
          "no collisions with people: pass through + gust",
          "reduced motion: cuts between the twelve pages",
          "nothing in the sky reads a balance"
        ],
        waterLandings: {
          bight: {
            xy: [
              592,
              804
            ],
            r: 60,
            note: "the inner Bight, clear of the ferry pier and the Year Walk; the landing field is wet below level \u2212 2 all round"
          },
          deep: {
            xy: [
              1278,
              423
            ],
            r: 8,
            note: "the only clear water in the Deep: the west lobe beside the Throat's foot; an r 20 field needs the Ore Line's splash moved \u2265 20 m east or the Deep widened 15 m west (underground track)"
          },
          harbour: {
            note: "found by the envelope beside the floatplane dock (world/sky.ts); unchanged"
          },
          rule: "the envelope reads these centres; before v1.7 it used the water outline's centroid"
        },
        gliderPolar: [
          [
            8,
            1.3
          ],
          [
            9,
            1.05
          ],
          [
            11,
            1.2
          ],
          [
            14,
            1.8
          ],
          [
            17,
            3
          ]
        ],
        gliderPolarRule: "[airspeed m/s, still-air sink m/s] from bar pushed out full to pulled in full; a smooth piecewise cubic between points; trim [11,1.2] is sky.glider; stall below 7.5 (FLIGHT.md \xA72.2)",
        parachute: {
          forward_ms: 6,
          sink_ms: 3,
          freefallCap_ms: 30,
          autoPull_agl_m: 45,
          minBail_agl_m: 60,
          canopy_m: [
            7,
            3
          ],
          note: "reached only by jumping from the plane (carriedThresholds.bailOut); the chute always opens (D37)"
        },
        corridors: {
          throat: {
            gate: 12,
            to: [
              1300,
              420
            ],
            slope_deg: 30,
            level_m: 25,
            splashH: 42,
            coneDeg: 25,
            maxBankDeg: 20,
            note: "glider only: enter gate 12's aperture heading within coneDeg of south and banked at most maxBankDeg; follow the chute at slope_deg; the last level_m run over the Deep at splashH; a miss passes beside the mouth, never a wall"
          }
        },
        dropZone: {
          xy: [
            1028,
            1112
          ],
          rings_m: [
            5,
            10,
            25
          ],
          note: "ground paint inside the Green's protected centre at sky.landings.green; bullseye, inner, outer, then 'on the Green'",
          v1_7_xy: [
            1040,
            1065
          ],
          xyNote_v2_2: "follows sky.landings.green (v2.1 [1028,1112]); FLIGHT v1.7 placed it at the v1.6 green landing [1040,1065]"
        },
        landingModes: {
          strip: [
            "plane",
            "glider",
            "parachute"
          ],
          water: [
            "plane",
            "glider",
            "parachute"
          ],
          deep: [
            "glider"
          ],
          rule: "modes per non-field landing; every landing takes the parachute except water.deep (the Deep is reached only through the Throat, by glider)"
        }
      },
      reserves: {
        rotRule: "rot_deg is the bearing of the 64 m axis, degrees clockwise from +x (east) with y south",
        terraces: {
          plots: [
            [
              1552,
              832
            ],
            [
              1528,
              896
            ],
            [
              1512,
              952
            ]
          ],
          rot_deg: [
            -67,
            23,
            23
          ],
          size_m: [
            64,
            44
          ],
          placeIds: [
            "plot.terraces.1",
            "plot.terraces.2",
            "plot.terraces.3"
          ],
          served: "plots 1\u20133 uphill (west) of the Prow cliff drive between [1600,860] and [1540,1000] with a lay-by each; the Prow walk above; the town below. D12 confirmed 2026-09-25: three uphill plots only; no seaward plot.",
          v2_2_plots: [
            [
              1552,
              832
            ],
            [
              1528,
              896
            ],
            [
              1512,
              952
            ]
          ],
          plot1Note_v2_3: "R3-32: 1.0 m WNW off the Prow walk's corner (margin 5.83 \u2192 \u2265 6.6); design lead, Stage A Wave 7 (W7-A) 2026-09-27",
          v2_3_plots: [
            [
              1551.1,
              832.5
            ],
            [
              1528,
              896
            ],
            [
              1512,
              952
            ]
          ],
          plot1Note_v2_4: "back to v2.2 (design lead, Stage A Wave 7 integrator 4 2026-09-27): the v2.3 move put the service drive's bed 0.47 over the Year Walk at [1594.7,837.9] and blocked the walk to L02; R3-32 open (5.83 of 6), owner W7-A"
        },
        bightShore: {
          plots: [
            [
              813,
              918.8
            ],
            [
              771,
              973
            ],
            [
              729,
              1032
            ],
            [
              705,
              1107
            ]
          ],
          rot_deg: [
            39,
            45,
            24,
            11
          ],
          size_m: [
            64,
            44
          ],
          spacing_m: "\u2265 62 (centres), \u2265 17.5 edge to edge",
          placeIds: [
            "plot.bight.1",
            "plot.bight.2",
            "plot.bight.3",
            "plot.bight.4"
          ],
          served: "VBS spur; jetty [735,955]; all four outside protected.green (r 160)",
          v1_9_plots: [
            [
              836,
              907
            ],
            [
              771,
              973
            ],
            [
              729,
              1032
            ],
            [
              705,
              1107
            ]
          ],
          plot1Note_v2_0: "D-C8 (recommended, accepted Jonathan 2026-09-27): plot bight.1 moved 25 m west-south-west, the nearest spot clear of the June lane and S4 (the \u2248 12 m estimate did not clear); the plot's service drive follows",
          v2_2_plots: [
            [
              814,
              919
            ],
            [
              771,
              973
            ],
            [
              729,
              1032
            ],
            [
              705,
              1107
            ]
          ],
          plot1Note_v2_3: "D-D2: 1.0 m WSW off the June lane's corner (margin 5.79 \u2192 \u2265 6.6 with the Year Walk's shoulder); the service drive meets the June lane at grade (design lead, Stage A Wave 7 (W7-A) 2026-09-27)"
        },
        small: {
          sealedDrift: {
            xy: [
              1180,
              500
            ],
            placeId: "plot.under.1"
          },
          hangarBay: {
            xy: [
              458.2,
              600
            ],
            placeId: "plot.flats.1",
            v1_8_xy: [
              455,
              600
            ],
            size_m: [
              11,
              18
            ],
            door: "west, on the strip edge; its access walk is plot.flats.1.service",
            note_v1_9: "an 11 m bay facing the strip, 18 m deep, between the strip's 6 m margin and S2's (the 18 m face did not fit the 26 m between them)"
          }
        },
        plotRule: "1.5 \xD7 Library footprint + 6 m clear; graded, walled, served, reserved placeId; no lantern spot inside; no view depends on it being empty",
        retiredPlaceIds: [
          "plot.terraces.4"
        ]
      },
      neighbourhoods: [
        {
          id: "harbour",
          label: "Little Harbour",
          centre: [
            1470,
            1180
          ],
          r: 120,
          hosts: [
            "home",
            "bank"
          ],
          places: [
            "court"
          ],
          porch: "the square's edge facing the dam; the quay wall at night"
        },
        {
          id: "hollow",
          label: "The Hollow",
          centre: [
            970,
            590
          ],
          r: 100,
          hosts: [
            "studio",
            "cottage"
          ],
          porch: "picnic table under the apples by the covered bridge"
        },
        {
          id: "scholars",
          label: "Scholars' Edge",
          centre: [
            760,
            420
          ],
          r: 110,
          hosts: [
            "library"
          ],
          porch: "the reading courtyard facing the Bight"
        },
        {
          id: "flats",
          label: "The Flats",
          centre: [
            440,
            680
          ],
          r: 150,
          hosts: [],
          porch: "the hangar's bench"
        },
        {
          id: "landing",
          label: "The Landing & Long Sands",
          centre: [
            1170,
            1380
          ],
          r: 200,
          hosts: [
            "boathouse"
          ],
          places: [
            "campfire"
          ],
          porch: "the Boathouse dock; the log ring"
        },
        {
          id: "lakeside",
          label: "Lakeside",
          centre: [
            1130,
            830
          ],
          r: 130,
          hosts: [
            "glasshouse"
          ],
          places: [],
          porch: "the sill"
        },
        {
          id: "crown",
          label: "The Crown & the Undercroft",
          centre: [
            1310,
            500
          ],
          r: 150,
          hosts: [],
          places: [
            "L02",
            "L01"
          ],
          porch: "the lookout wall; the Deep's jetty"
        }
      ],
      viewRule: {
        landscape: "each pose: xy is the eye position on the ground; eye height 1.6 eu above ground unless eyeH given; target is the look-at point; fov_deg horizontal at 16:9 (the Sketchbook lens; STYLE's 42\xB0/52\xB0 lenses are the walking and ride cameras); radius_eu is the acceptance streaming radius; pageTrigger_eu is how close the player must stand (and face within 25\xB0) for the page to draw; target_h is the look-at height in engine units (it replaces the per-page constants and the terrain-height default); frames lists the Pass 1 subjects the page must hold, deferred the props that arrive in Pass 2/2b/3",
        portrait: "on a portrait capture (width < height, e.g. 390 \xD7 844) the camera holds the page's HORIZONTAL field of view, never its vertical one: horizontal FOV = portrait.fov_deg (never below 45\xB0), aimed at portrait.target at portrait.target_h (the page's target when absent), from the landscape eye unless portrait.xy / portrait.eyeH are given; portrait.frames names the subjects that must be legible on the phone \u2014 the other landscape subjects may fall outside the portrait crop"
      },
      pageTrigger_eu: 6,
      views: [
        {
          id: "A",
          target: [
            1175,
            960
          ],
          fov_deg: 60,
          radius_eu: 480,
          label: "The square, looking north-west",
          xy: [
            1470,
            1186
          ],
          frames: "the High Span's deck line and the Shoulder; Mountain v2's face stands beyond the square's fog (page E holds the Crown)",
          bestHour: "golden hour",
          also: "noon",
          target_h: 30,
          deferred: [
            "the Reach (outside any lens that holds the dam from the square; page I carries it)",
            "the Crown (hidden from the square by the Shoulder's own rim, 4\u201316 eu over the sight line inside its band; page E holds it)"
          ],
          portrait: {
            fov_deg: 45,
            target: [
              1195,
              1005
            ],
            frames: [
              "the High Span"
            ],
            v1_8_fov_deg: 50,
            v2_5_frames: [
              "the High Span",
              "the dam's glass face"
            ]
          },
          v1_6: {
            xy: [
              1455,
              1200
            ],
            target: [
              1200,
              700
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the High Span",
            "the Shoulder"
          ],
          v1_7_frames: "the High Span's deck line, the dam's glass face, the Shoulder and the Crown behind",
          lightRule: "at the page's best hour (golden hour) the dam's glass face reads lit OR emissive: the dam.glassFace light card is on from golden hour (D-A5); P25's golden-hour check is 'the square lit and the dam's face lit or emissive'",
          v2_5_subjects: [
            "the High Span",
            "the dam's glass face",
            "the Shoulder"
          ],
          v2_5_frames: "the High Span's deck line, the dam's glass face, the Shoulder",
          note_v2_6: "D-M10: the Stillwater dam is retired (D-M3): the page keeps its eye, target and lens and loses the dam's glass face from its subjects (landscape: the High Span, the Shoulder; portrait: the High Span). Mountain v2's face shows from the square only between the Shoulder remnant and the Foot plain's rim (bearings 15-25 deg W of N, 700 m, past the fog's legible limit): its silhouette is for Jonathan's eye, not a proof subject (deferred, as the Crown was)"
        },
        {
          id: "B",
          target: [
            515,
            880
          ],
          fov_deg: 55,
          radius_eu: 520,
          label: "The Lamp gallery",
          xy: [
            540,
            1195
          ],
          frames: "the Bight Bridge with its steel arch and the lookout at its crown, the Flats, the whole hook",
          bestHour: "sunset",
          also: "noon",
          target_h: 20,
          portrait: {
            fov_deg: 50,
            target: [
              522,
              940
            ],
            target_h: 18,
            frames: [
              "the Bight Bridge",
              "the hook"
            ]
          },
          deferred: [],
          v1_6: {
            xy: [
              540,
              1195
            ],
            target: [
              900,
              700
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the Bight Bridge",
            "the Flats",
            "the hook"
          ],
          v1_9_frames: "the Bight Bridge, the Flats, the whole hook",
          framesNote_v2_0: "D-A1: the arch and the lookout are parts of the Bight Bridge (bightBridge.* solids), so the machine subject stays 'the Bight Bridge'"
        },
        {
          id: "C",
          target: [
            1210,
            1098
          ],
          fov_deg: 55,
          radius_eu: 220,
          label: "High Span, three speeds",
          xy: [
            1268,
            1145
          ],
          frames: "road above, shelf within, water beside",
          bestHour: "morning",
          also: "night",
          target_h: 16,
          portrait: {
            fov_deg: 50,
            target: [
              1222,
              1102
            ],
            target_h: 16,
            frames: [
              "the road deck",
              "the skate shelf",
              "the walk at the water"
            ]
          },
          deferred: [],
          v1_6: {
            xy: [
              1245,
              1125
            ],
            target: [
              1240,
              1105
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the road deck",
            "the skate shelf",
            "the walk at the water"
          ]
        },
        {
          id: "D",
          target: [
            700,
            1462
          ],
          fov_deg: 55,
          radius_eu: 720,
          label: "Long Sands",
          xy: [
            1185,
            1445
          ],
          frames: "surf, the zipline landing",
          bestHour: "afternoon",
          also: "night",
          target_h: 6,
          deferred: [
            "a bench (Pass 3 dressing)",
            "the Lamp (Pass 2b subject: 670 eu from the eye, 9 px of 13 at 1440 \xD7 900 by size; the Pass 2b lighthouse and its 25 m gallery make it legible; design lead, Stage A Wave 5 integration 2026-09-27)"
          ],
          portrait: {
            fov_deg: 50,
            target: [
              700,
              1454
            ],
            target_h: 5,
            frames: [
              "surf",
              "the zipline landing"
            ],
            v1_7_frames: [
              "surf",
              "the Lamp",
              "the zipline landing"
            ]
          },
          v1_6: {
            xy: [
              900,
              1470
            ],
            target: [
              540,
              1230
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "surf",
            "the zipline landing"
          ],
          v2_0_frames: "surf, the Lamp, the zipline landing",
          v2_0_subjects: [
            "surf",
            "the Lamp",
            "the zipline landing"
          ],
          ground: {
            xy: [
              1181,
              1401
            ],
            h: 3
          },
          groundNote_v2_4: "the beach verge south of Horizon Drive, 5.1 eu off the Drive (Long Sands' dune walk and zip landing are not reachable from the square yet: R3-119) (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
        },
        {
          id: "E",
          target: [
            870,
            860
          ],
          fov_deg: 55,
          radius_eu: 900,
          label: "The Crown",
          xy: [
            1317.5,
            475.5
          ],
          frames: "from the lookout's run-off deck: Stillwater, the Green, the Hollow, the Flats and the Bight, the sea beyond (the harbour, the Reach, Long Sands and the Prow lie behind the Shoulder from here)",
          bestHour: "noon",
          also: "night",
          target_h: 20,
          portrait: {
            fov_deg: 55,
            target: [
              1e3,
              880
            ],
            target_h: 20,
            frames: [
              "the Green",
              "Stillwater",
              "the sea"
            ]
          },
          deferred: [],
          v1_6: {
            xy: [
              1310,
              430
            ],
            target: [
              1e3,
              1e3
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "Stillwater",
            "the Green",
            "the Hollow",
            "the Flats",
            "the Bight",
            "the sea"
          ],
          v1_8_xy: [
            1305,
            482
          ],
          ground: {
            xy: [
              1306,
              482
            ],
            h: 170
          },
          groundNote_v2_4: "on the Crown launch deck (lookout run-off deck), 5.1 eu from crownLaunch.stair's head (design lead, Stage A Wave 7 integrator 4 2026-09-27)",
          v2_5_xy_launch: [
            1300.5,
            485.5
          ],
          note_v2_6: "the eye follows the run-off deck (thresholds.crownLaunch v2.6)"
        },
        {
          id: "F",
          target: [
            1150,
            720
          ],
          fov_deg: 55,
          radius_eu: 420,
          label: "Dam crest (Mountain v2)",
          xy: [
            1332.23,
            533.27
          ],
          frames: "from the east end of Mountain v2's glass dam crest: L01 on the crest plaques, Stillwater and the Foot terrace below (the reservoir is behind the camera)",
          bestHour: "morning",
          also: "dusk",
          target_h: 100,
          portrait: {
            fov_deg: 45,
            target: [
              1150,
              760
            ],
            target_h: 101.4,
            frames: [
              "L01",
              "Stillwater"
            ]
          },
          deferred: [],
          v1_6: {
            xy: [
              1150,
              905
            ],
            target: [
              1450,
              1180
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "L01",
            "Stillwater"
          ],
          v2_5: {
            xy: [
              1158,
              905
            ],
            target: [
              1400,
              1150
            ],
            fov_deg: 55,
            label: "Dam crest",
            frames: "the plaques and L01 on the crest, the town below (the lake is behind the camera)",
            target_h: 14,
            portrait: {
              fov_deg: 45,
              target: [
                1260,
                990
              ],
              target_h: 30,
              frames: [
                "L01",
                "the town below"
              ]
            },
            subjects: [
              "L01",
              "the town below"
            ],
            bestHour: "morning",
            also: "dusk"
          },
          eyeH: 143.7,
          ground: {
            xy: [
              1316,
              539.2
            ],
            h: 142
          },
          note_v2_6: "D-M10 (re-posed; confirm by eye): L01 is on Mountain v2's dam crest (D-M3); from the crest the Little Harbour lies behind v2's south slopes and the Shoulder remnant, so the page holds L01 with Stillwater below instead of 'the town below'. eyeH: the promenade is v2's deck (the region's), not Horizon ground; ground is the L01 bay (place.L01.deck)",
          v2_6a: {
            xy: [
              1337.86,
              526.54
            ],
            target: [
              1119,
              731
            ],
            eyeH: 143.6,
            target_h: 101.4
          },
          note_v2_6b: "integrator: the east-end eye stood inside the abutment (the capture showed paper grain); the eye now stands on promenade[10] at crest + 1.7 looking west-south-west along the crest over L01 to Stillwater and the Foot"
        },
        {
          id: "G",
          target: [
            1320,
            380
          ],
          fov_deg: 55,
          radius_eu: 220,
          label: "The Deep, looking up the skylight shaft",
          xy: [
            1320,
            404
          ],
          frames: "from the Deep's floor up the skylight shaft to its square of daylight; the Throat dark behind (D-B5)",
          bestHour: "noon (sun shaft)",
          also: "night (moon shaft)",
          target_h: 110,
          portrait: {
            fov_deg: 45,
            target: [
              1320,
              380
            ],
            target_h: 110,
            frames: [
              "the skylight shaft"
            ]
          },
          deferred: [],
          v1_6: {
            xy: [
              1300,
              440
            ],
            target: [
              1300,
              300
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the skylight shaft"
          ],
          v2_3: {
            xy: [
              1300,
              440
            ],
            target: [
              1300,
              300
            ],
            target_h: 110,
            label: "The Deep, looking up the Throat",
            frames: "from the Deep's jetty north up the Throat to its mouth of daylight, the skylight shaft overhead, a glider flaring onto the water",
            subjects: [
              "the Throat's mouth of daylight",
              "the skylight shaft"
            ],
            portrait: {
              fov_deg: 45,
              target: [
                1300,
                300
              ],
              target_h: 110,
              frames: [
                "the Throat's mouth of daylight",
                "the skylight shaft"
              ]
            }
          },
          ground: {
            xy: [
              1300,
              440
            ],
            h: 40.6
          },
          decided_v2_4: "D-D7 option 1 (design lead rules, reversible: v2_3), W7-T request A4 (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
        },
        {
          id: "H",
          target: [
            100,
            560
          ],
          fov_deg: 55,
          radius_eu: 260,
          label: "The Flats at golden hour",
          xy: [
            440,
            760
          ],
          frames: "the strip in copper, the west sea under the low sun",
          bestHour: "golden hour",
          also: "dawn",
          target_h: 20,
          deferred: [
            "the windsock (Pass 2b kit: mast and sock; only its footing is built)",
            "the balloon at its mooring (Pass 2 mover and 2b kit)"
          ],
          portrait: {
            fov_deg: 50,
            target: [
              100,
              560
            ],
            target_h: 20,
            frames: [
              "the strip",
              "the west sea"
            ],
            v2_0_xy: null,
            xy: [
              428,
              760
            ],
            poseNote_v2_1: "the portrait eye on the strip 12 m west of the landscape eye (west sea 1 \u2192 14 px at 390 \xD7 844; design lead, Stage A Wave 5 integration 2026-09-27)",
            eyeH: 48
          },
          v1_6: {
            xy: [
              330,
              800
            ],
            target: [
              435,
              690
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the strip",
            "the west sea"
          ],
          v1_9_bestHour: "sunset",
          v1_9_label: "The Flats at sunset",
          v1_9_frames: "the strip in copper, the west sea under the sunset",
          decided: "D-B3 (recommended, accepted Jonathan 2026-09-27)",
          v2_3: {
            eyeH: null,
            eyeH_measured: 39.6,
            target_h: 30,
            portrait: {
              target_h: 30,
              xy: [
                428,
                760
              ]
            }
          },
          eyeH: 48,
          ground: {
            xy: [
              440,
              760
            ],
            h: 38
          },
          poseNote_v2_4: "an aerial eye 10 m over the strip (eye 39.6 \u2192 48, target_h 30 \u2192 20): west sea 0 \u2192 350 / 94 px (design lead, Stage A Wave 7 integrator 4 2026-09-27, W7-T request A5)"
        },
        {
          id: "I",
          target: [
            1250,
            1180
          ],
          fov_deg: 55,
          radius_eu: 220,
          label: "Reach boardwalk",
          xy: [
            1275,
            1226
          ],
          frames: "the spring and the Reach water",
          bestHour: "morning",
          also: "dusk",
          target_h: 5,
          deferred: [
            "reeds at hand height",
            "the heron"
          ],
          portrait: {
            fov_deg: 45,
            target: [
              1250,
              1180
            ],
            target_h: 5,
            frames: [
              "the spring"
            ]
          },
          v1_6: {
            xy: [
              1270,
              1240
            ],
            target: [
              1280,
              1150
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the spring",
            "the Reach water"
          ],
          subjectDefs: {
            "the Reach water": "water.reach.* (the Reach channels) OR water.river.lower where the hit lies inside landforms.reach (the river crossing the Reach)"
          },
          decided: "D-C5 (recommended, accepted Jonathan 2026-09-27)",
          ground: {
            xy: [
              1284.8,
              1215
            ],
            h: 9.5
          },
          groundNote_v2_4: "on the Reach walk beside the boardwalk footbridge, 0.04 eu off the path (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
        },
        {
          id: "J",
          target: [
            1790,
            681
          ],
          fov_deg: 55,
          radius_eu: 340,
          eyeH: 51.6,
          label: "The Needle's Eye at dawn, from the Prow",
          xy: [
            1665,
            695
          ],
          frames: "the arch, the sea through it at dawn, the Prow underfoot",
          bestHour: "dawn",
          also: "noon",
          target_h: 20,
          portrait: {
            fov_deg: 50,
            target: [
              1790,
              681
            ],
            target_h: 20,
            frames: [
              "the arch",
              "the Prow"
            ]
          },
          deferred: [
            "the Stacks (not on J's east line through the arch, 60-65\xB0 to its right; D-D6)"
          ],
          v1_6: {
            xy: [
              1790,
              720
            ],
            target: [
              1790,
              680
            ],
            fov_deg: 55,
            radius_eu: 220,
            eyeH: 60
          },
          subjects: [
            "the arch",
            "the Prow"
          ],
          v2_2: {
            xy: [
              1840,
              1e3
            ],
            target: [
              1780,
              700
            ],
            target_h: 14,
            eyeH: 60,
            label: "The Needle's Eye, from the plane",
            frames: "the arch ahead of the wing, the Stacks, the Prow",
            subjects: [
              "the arch",
              "the Stacks",
              "the Prow"
            ],
            portrait: {
              fov_deg: 50,
              target: [
                1760,
                760
              ],
              target_h: 14,
              frames: [
                "the arch",
                "the Stacks",
                "the Prow"
              ]
            }
          },
          ground: {
            xy: [
              1607.3,
              690.9
            ],
            h: 48.5
          },
          decided_v2_3: "D-D6 re-pose (recommended; design lead, Stage A Wave 7 (W7-A) 2026-09-27, reversible: v2_2), W7-T's measured pose",
          v2_3: {
            xy: [
              1665,
              680
            ],
            eyeH: 51.5,
            target_h: 25,
            portrait: {
              fov_deg: 50,
              target: [
                1790,
                681
              ],
              target_h: 25,
              frames: [
                "the arch",
                "the Prow"
              ]
            }
          },
          poseNote_v2_4: "15 m south on the Prow cliff so the Prow is in the 16:9 frame (0 \u2192 1,250 px); opening 37.7 % of the arch's face (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
        },
        {
          id: "K",
          target: [
            1120,
            815
          ],
          fov_deg: 55,
          radius_eu: 220,
          label: "The Glasshouse at dusk",
          xy: [
            994,
            770
          ],
          frames: "the Glasshouse in front of Stillwater",
          bestHour: "dusk",
          also: "noon",
          target_h: 52,
          deferred: [
            "lit from inside",
            "seed pots in silhouette"
          ],
          portrait: {
            fov_deg: 45,
            target: [
              1120,
              815
            ],
            target_h: 52,
            frames: [
              "the Glasshouse",
              "Stillwater"
            ]
          },
          v1_6: {
            xy: [
              990,
              810
            ],
            target: [
              1130,
              820
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "the Glasshouse",
            "Stillwater"
          ],
          v1_8_xy: [
            1e3,
            758
          ],
          v1_9: {
            xy: [
              1006,
              762
            ],
            target: [
              1120,
              812
            ],
            target_h: 52,
            portrait: {
              fov_deg: 45,
              target: [
                1060,
                800
              ],
              target_h: 55,
              frames: [
                "the Glasshouse",
                "Stillwater"
              ]
            }
          },
          decided: "D-B2 re-pose (recommended, accepted Jonathan 2026-09-27)"
        },
        {
          id: "L",
          target: [
            1285,
            1315
          ],
          fov_deg: 55,
          radius_eu: 240,
          label: "The quay at night",
          xy: [
            1484,
            1295
          ],
          frames: "Lantern Row along the quay, the Boathouse across the water",
          bestHour: "night",
          also: "dawn",
          target_h: 4,
          deferred: [
            "the floatplane rocking (Pass 2 mover; its dock is at the quay's east end, behind this pose)",
            "lantern cards"
          ],
          portrait: {
            fov_deg: 45,
            target: [
              1285,
              1315
            ],
            target_h: 4,
            frames: [
              "Lantern Row",
              "the Boathouse"
            ],
            v1_8_xy: null,
            xy: [
              1460,
              1300
            ]
          },
          v1_6: {
            xy: [
              1430,
              1290
            ],
            target: [
              1285,
              1315
            ],
            fov_deg: 55,
            radius_eu: 220
          },
          subjects: [
            "Lantern Row",
            "the Boathouse"
          ],
          ground: {
            xy: [
              1477,
              1289
            ],
            h: 3
          },
          groundNote_v2_4: "on the town quay (Lantern Row), 4.3 eu off its walk (design lead, Stage A Wave 7 integrator 4 2026-09-27)"
        }
      ],
      crossings: [
        {
          a: "VG",
          b: "river lower",
          at: [
            1240,
            1105
          ],
          resolution: "over",
          structure: "highSpan",
          kind: "crossing"
        },
        {
          a: "S1",
          b: "VG",
          at: [
            1204,
            1098
          ],
          resolution: "under",
          structure: "highSpan (shelf, west wall)",
          kind: "crossing"
        },
        {
          a: "walk reach",
          b: "river lower",
          at: [
            1274,
            1203
          ],
          resolution: "over",
          structure: "reachFootbridge",
          kind: "crossing"
        },
        {
          a: "walk garden",
          b: "brook",
          at: [
            898,
            611
          ],
          resolution: "over",
          structure: "hollowBridge",
          movedFrom: [
            893,
            600
          ],
          note: "the Hollow Bridge carries the Garden Walk over the brook 12 m north of the v1.7 point",
          kind: "crossing"
        },
        {
          a: "S4",
          b: "brook",
          at: [
            899,
            591
          ],
          resolution: "over",
          structure: "hollowBridge (separated lane; the rail)",
          movedFrom: [
            893,
            600
          ],
          note: "S4's lane on the Hollow Bridge crosses the brook 10 m south-east of the v1.7 point",
          kind: "crossing"
        },
        {
          a: "S4",
          b: "walk garden",
          at: [
            893,
            600
          ],
          resolution: "threshold",
          note: "the covered Hollow Bridge is shared: boards to the rail side at walking pace; the Hollow neck stays reserved (D-C10, Jonathan 2026-09-27: keep reserved until the other crossings are done; one P16 row, a hollowBridge beam 0.05 over the brook)",
          reserved: "D-C10",
          kind: "crossing",
          v1_9_note: "the covered bridge is shared: boards to the rail side at walking pace"
        },
        {
          a: "V01",
          b: "river mouth",
          at: [
            1350,
            1345
          ],
          resolution: "over",
          structure: "quayBridge",
          kind: "crossing"
        },
        {
          a: "S3",
          b: "river mouth",
          at: [
            1350,
            1345
          ],
          resolution: "over",
          structure: "quayBridge (separated lane)",
          kind: "crossing"
        },
        {
          a: "S1",
          b: "Reach west channel",
          at: [
            1255,
            1251
          ],
          resolution: "over",
          structure: "Reach boardwalk on piles; the finish sits on the islet between the west channel and the river",
          kind: "crossing"
        },
        {
          a: "V01+S2",
          b: "Bight mouth",
          at: [
            560,
            1100
          ],
          resolution: "over",
          structure: "bightBridge",
          kind: "crossing",
          decided: "D-A1 (Jonathan 2026-09-27)",
          note: "245 m viaduct with one 40 m steel through-arch (s 103-143; D-A1's 36 m widened by the design lead for the ferry hull, reversible); abutments on both headlands to the ground",
          v1_9_note: "245 m viaduct with one 36 m steel through-arch (s 98-134); abutments on both headlands to the ground"
        },
        {
          a: "S2",
          b: "V01",
          at: "[460,1030] to [660,1170] and the Wash to the bridge",
          resolution: "over",
          note: "v2.0 (D-A1): S2 rides the deck's lagoon lane from the west abutment, crosses over V01 and the Year Walk footways once on bightBridge.s2Flyover at the arch crown (17.6, 5.6 above the deck), then the sea lane to the east abutment and a banked descent onto its line; never the shoulder, never at grade",
          kind: "crossing",
          v1_9_note: "S2 rides a separated lane 4 m from the carriageway with a kerb, then the bridge's rail-side lane; never the shoulder"
        },
        {
          a: "S2",
          b: "water wash",
          at: "[465,700] to [485,800]",
          resolution: "threshold",
          note: "S2 shares the dry Wash bed; on almanac drizzle days the bowl is wet and the line closes at a marker for six hours",
          kind: "crossing"
        },
        {
          a: "S4",
          b: "VBS",
          at: [
            874,
            941
          ],
          resolution: "threshold",
          note: "at grade: dismount marker + kerb gap",
          district: "green",
          districtNote: "belongs to district green (Lakeside) unless pass 1 draws the bight district over it",
          kind: "crossing"
        },
        {
          a: "S4",
          b: "VG",
          at: [
            973,
            538
          ],
          resolution: "threshold",
          note: "flush at-grade threshold at the studio terrace (dismount marker + kerb gap): S4 (37.07) rises 2.8 to VG (39.87) at \u2264 12 % over \u2265 24 m on either side; regrade owed (beds)",
          kind: "crossing",
          decided: "D-A7 (Jonathan 2026-09-27)",
          v1_9_note: "at grade at the studio terrace: dismount marker + kerb gap"
        },
        {
          a: "VG",
          b: "walk garden",
          at: [
            969.5,
            764.2
          ],
          resolution: "over",
          kind: "crossing",
          v1_9_at: [
            974,
            748
          ],
          movedFrom: [
            974,
            748
          ],
          v1_9_resolution: "threshold",
          structure: "gardenWalkBridge",
          decided: "D-A7 (Jonathan 2026-09-27)",
          note: "the Garden Walk crosses Green Road on the named gardenWalkBridge, 17.65 over the road (regrading would need \u2248 147 m of 12 % ramp each side)"
        },
        {
          a: "V01",
          b: "walk reach",
          at: [
            1367,
            1271
          ],
          resolution: "threshold",
          kind: "crossing"
        },
        {
          a: "DEEP_RUN",
          b: "V01",
          at: [
            1587,
            677
          ],
          resolution: "under",
          note: "the Sea Passage runs 60+ m below the coast drive; the Deep run passes under the Prow cliff drive 23 m north-east of the v1.7 point",
          movedFrom: [
            1574,
            658
          ],
          kind: "crossing"
        },
        {
          a: "S4",
          b: "V01",
          at: [
            1009,
            1388
          ],
          resolution: "under",
          structure: "duneCulvert",
          movedFrom: [
            1005,
            1375
          ],
          note: "the dune culvert: V01 over S4 13 m south of the v1.7 point",
          kind: "crossing"
        },
        {
          a: "S1",
          b: "river lower",
          at: [
            1158,
            949
          ],
          resolution: "over",
          structure: "apronBridge",
          kind: "crossing"
        },
        {
          a: "ZIP",
          b: "V01",
          at: [
            1157,
            1394
          ],
          resolution: "over",
          note: "\u2265 9 m clear over the Long Sands road",
          kind: "crossing"
        },
        {
          a: "ZIP",
          b: "VG",
          at: [
            1343,
            1084
          ],
          resolution: "over",
          note: "\u2248 24 m clear over Green Road",
          kind: "crossing"
        },
        {
          a: "ZIP",
          b: "S3",
          at: [
            1133,
            1435
          ],
          resolution: "over",
          structure: "landing tower deck 8 m above the boardwalk",
          kind: "crossing"
        },
        {
          a: "V01",
          b: "walk bightPier",
          at: [
            402.3,
            894.5
          ],
          resolution: "threshold",
          kind: "crossing",
          v1_9_at: [
            407,
            894
          ],
          movedFrom: [
            407,
            894
          ],
          decided: "D-A7 (Jonathan 2026-09-27)",
          note: "flush at-grade threshold (a marked crossing on the Drive): the pier walk (34.47) comes down 3.9 to the Drive (30.55) over \u2248 33 m at \u2264 12 %; regrade owed (beds)"
        },
        {
          a: "V01",
          b: "walk coveWalk",
          at: [
            686,
            313
          ],
          resolution: "threshold",
          kind: "crossing"
        },
        {
          a: "FERRY",
          b: "bightBridge",
          at: [
            560,
            1100
          ],
          resolution: "under",
          note: "twice per lap, through the steel-arch opening (s 103-143, 38 m \xD7 11.4 clear; beam 8, +1.37 eu past each pier; v2.0 had s 98-134, 36 m)",
          kind: "crossing",
          decided: "D-A1 (Jonathan 2026-09-27)",
          v1_9_note: "twice per lap"
        },
        {
          a: "crownLaunch.stair",
          b: "underground.bellGallery",
          at: [
            1313,
            480.5
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
        },
        {
          a: "DEEP_RUN",
          b: "ZIP",
          at: [
            1587.5,
            677.4
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ferry.bight",
          b: "FERRY",
          at: [
            560,
            898
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending"
        },
        {
          a: "ferry.flats",
          b: "FERRY",
          at: [
            285,
            720
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending"
        },
        {
          a: "ferry.landing",
          b: "FERRY",
          at: [
            1470,
            1340
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending"
        },
        {
          a: "ferry.seaDoor",
          b: "seaStair",
          at: [
            1705,
            775
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "highSpan.overlook",
          b: "river lower",
          at: [
            1251.2,
            1143.3
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 2.2 eu apart: regrade owed"
        },
        {
          a: "homestead.lane",
          b: "town quay",
          at: [
            1497,
            1265
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "jetty.boathouse",
          b: "reachChannel.2",
          at: [
            1320,
            1318.5
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 0.8 eu apart: regrade owed"
        },
        {
          a: "jetty.deep",
          b: "stepsPortage",
          at: [
            1300,
            440
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "jetty.deep",
          b: "underground.deepAccess",
          at: [
            1300,
            440
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "jetty.lamp",
          b: "lampGallery.ramp",
          at: [
            540,
            1250
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "jetty.lamp",
          b: "lampGallery.stair",
          at: [
            540,
            1250
          ],
          resolution: "threshold",
          kind: "sharedStretch",
          source: "bake v1.8",
          note: "shared stretch 6 eu at one height"
        },
        {
          a: "jetty.seaDoor",
          b: "ferry.seaDoor",
          at: [
            1705,
            781
          ],
          resolution: "threshold",
          kind: "sharedStretch",
          source: "bake v1.8",
          note: "shared stretch 12 eu at one height"
        },
        {
          a: "jetty.seaDoor",
          b: "seaStair",
          at: [
            1705,
            775
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "lampGallery.ramp",
          b: "FERRY",
          at: [
            510.4,
            1224.4
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 3.2 eu apart: regrade owed"
        },
        {
          a: "lampGallery.ramp",
          b: "FERRY",
          at: [
            546.1,
            1190.6
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 6.1 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "lampGallery.ramp",
          b: "lampGallery.stair",
          at: [
            540,
            1195
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "lampGallery.ramp",
          b: "lampGallery.stair",
          at: [
            540,
            1250
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "lampGallery.stair",
          b: "FERRY",
          at: [
            540,
            1230
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ORE",
          b: "DEEP_RUN",
          at: [
            1300,
            420
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ORE",
          b: "ORE.siding",
          at: [
            1270,
            450
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ORE",
          b: "southPortal.link",
          at: [
            1345,
            680
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending"
        },
        {
          a: "ORE",
          b: "stepsPortage",
          at: [
            1343.6,
            463.6
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 25.1 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "ORE",
          b: "underground.bellGallery",
          at: [
            1225.5,
            489.6
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ORE",
          b: "underground.deepAccess",
          at: [
            1280,
            440
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 17.4 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "ORE",
          b: "underground.lanternCave",
          at: [
            1160,
            520
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ORE",
          b: "underground.throat",
          at: [
            1300,
            420
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "reachChannel.1",
          b: "reachChannel.2",
          at: [
            1280,
            1220
          ],
          resolution: "threshold",
          kind: "waterConfluence",
          source: "bake v1.8",
          note: "one waterway"
        },
        {
          a: "river lower",
          b: "reachChannel.1",
          at: [
            1280,
            1220
          ],
          resolution: "threshold",
          kind: "waterConfluence",
          source: "bake v1.8",
          note: "one waterway"
        },
        {
          a: "river lower",
          b: "reachChannel.2",
          at: [
            1280,
            1220
          ],
          resolution: "threshold",
          kind: "waterConfluence",
          source: "bake v1.8",
          note: "one waterway"
        },
        {
          a: "river lower",
          b: "reachChannel.2",
          at: [
            1320,
            1276
          ],
          resolution: "threshold",
          kind: "waterConfluence",
          source: "bake v1.8",
          note: "one waterway"
        },
        {
          a: "S1",
          b: "landingQuay",
          at: [
            1270,
            1330
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S1",
          b: "ZIP",
          at: [
            1251.5,
            1237.5
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S1",
          b: "ZIP",
          at: [
            1251.9,
            1236.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S2",
          b: "FERRY",
          at: [
            560,
            1100
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "v2.0 (D-A1): on the flyover under the arch crown, through the navigable opening",
          v1_9_note: ""
        },
        {
          a: "S2",
          b: "S3",
          at: [
            1020,
            1430
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S2",
          b: "S4",
          at: [
            1020,
            1430
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S2",
          b: "yearWalk",
          at: [
            551.9,
            1086.7
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "v2.0 (D-A1): S2's flyover passes over the Year Walk's lagoon footways (was a crossing on the deck)",
          v1_9_at: [
            553.9,
            1095
          ],
          v1_9_resolution: "threshold",
          structure: "bightBridge.s2Flyover",
          v1_9_note: ""
        },
        {
          a: "S2",
          b: "yearWalk",
          at: [
            742,
            1258.5
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S2",
          b: "yearWalk",
          at: [
            944.8,
            1393.7
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 1.6 eu apart: regrade owed"
        },
        {
          a: "S3",
          b: "gondolaBase.walk",
          at: [
            1480,
            1060
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S3",
          b: "host.home.approach",
          at: [
            1456,
            1175.3
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S3",
          b: "S4",
          at: [
            1020,
            1430
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S3",
          b: "town.quayLink",
          at: [
            1406,
            1319.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S3",
          b: "V01",
          at: [
            1321.9,
            1372.3
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S3",
          b: "V01",
          at: [
            1350,
            1345
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S3",
          b: "walk square",
          at: [
            1480,
            1060
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S4",
          b: "brook",
          at: [
            896.4,
            617.8
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S4",
          b: "plot.bight.1.service",
          at: [
            874.4,
            919.5
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S4",
          b: "walk garden",
          at: [
            897.5,
            620.6
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 1.7 eu apart: regrade owed"
        },
        {
          a: "S4",
          b: "walk garden",
          at: [
            905.9,
            640.6
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "under by 2.7 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under); v2.0 (D-A7): flush threshold confirmed (it was 2.75 apart in v1.8)",
          v1_8_resolution: "under",
          decided: "D-A7 (Jonathan 2026-09-27)",
          v1_9_note: "under by 2.7 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)"
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            880.4,
            909.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            884.8,
            903.6
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 0.9 eu apart: regrade owed"
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            900.7,
            882.8
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "under by 2.6 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            901.2,
            629.8
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            902.6,
            632.9
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            918.6,
            574.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            957.9,
            1248.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "at-grade meeting 0.6 eu apart: regrade owed"
        },
        {
          a: "spur boathouse",
          b: "host.boathouse.approach",
          at: [
            1290,
            1345
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur cottage",
          b: "walk garden",
          at: [
            930,
            650
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur cottage",
          b: "yearWalk",
          at: [
            971.9,
            691.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur cottage",
          b: "yearWalk",
          at: [
            974.4,
            694.4
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur library",
          b: "walk coveWalk",
          at: [
            760.1,
            359.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur library",
          b: "yearWalk",
          at: [
            806.1,
            337
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur studio",
          b: "host.studio.approach",
          at: [
            1e3,
            540
          ],
          resolution: "threshold",
          kind: "sharedStretch",
          source: "bake v1.8",
          note: "shared stretch 1 eu at one height"
        },
        {
          a: "spur upperStreet",
          b: "gondolaBase.walk",
          at: [
            1480,
            1060
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur upperStreet",
          b: "S3",
          at: [
            1480,
            1060
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "spur upperStreet",
          b: "walk square",
          at: [
            1480,
            1060
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "town.bankLink",
          b: "host.bank.approach",
          at: [
            1440,
            1134
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.bankLink",
          b: "host.home.approach",
          at: [
            1455,
            1175
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.bankLink",
          b: "town.northLink",
          at: [
            1420,
            1138
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.bankLink",
          b: "town.quayLink",
          at: [
            1455,
            1175
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.quayLink",
          b: "host.home.approach",
          at: [
            1455,
            1175
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.quayLink",
          b: "town quay",
          at: [
            1420,
            1335
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.quayLink",
          b: "town.riverLink",
          at: [
            1400,
            1290
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.storefront",
          b: "homestead.lane",
          at: [
            1497,
            1265
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "town.storefront",
          b: "homestead.lane",
          at: [
            1498,
            1250.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "town.storefront",
          b: "town quay",
          at: [
            1497,
            1265
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "underground.bellGallery",
          b: "underground.deepAccess",
          at: [
            1220,
            480
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.deepAccess",
          b: "stepsPortage",
          at: [
            1300,
            440
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.lanternCave",
          b: "underground.bellGallery",
          at: [
            1220,
            480
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.lanternCave",
          b: "underground.deepAccess",
          at: [
            1220,
            480
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.lanternCave",
          b: "underground.sealedDrift",
          at: [
            1187.3,
            498.2
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.lanternCave",
          b: "underground.sealedDrift",
          at: [
            1220,
            480
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.sealedDrift",
          b: "underground.bellGallery",
          at: [
            1220,
            480
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.sealedDrift",
          b: "underground.deepAccess",
          at: [
            1220,
            480
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "underground.throat",
          b: "DEEP_RUN",
          at: [
            1300,
            420
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "FERRY",
          at: [
            559.3,
            1104.8
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "FERRY",
          at: [
            560,
            1100
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "FERRY",
          at: [
            562.8,
            1107.1
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "plot.terraces.1.service",
          at: [
            1601.6,
            831.4
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "plot.terraces.2.service",
          at: [
            1580.5,
            918.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "plot.terraces.3.service",
          at: [
            1554.6,
            973.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "spur boathouse",
          at: [
            1300,
            1380
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "spur library",
          at: [
            900,
            290
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "spur upperStreet",
          at: [
            1480,
            1040
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "town.northLink",
          at: [
            1370.9,
            1126.3
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "town.riverLink",
          at: [
            1370,
            1260
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "VG",
          at: [
            900,
            290
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "VG",
          at: [
            1400,
            1060
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "yearWalk",
          at: [
            756.4,
            1247.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "yearWalk",
          at: [
            810.8,
            294.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "yearWalk",
          at: [
            952.7,
            1376.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "V01",
          b: "ZIP",
          at: [
            1587.4,
            677.7
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "plot.bight.1.service",
          at: [
            880.8,
            928.6
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "plot.bight.2.service",
          at: [
            832.6,
            1011.9
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "plot.bight.3.service",
          at: [
            799.1,
            1066.7
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "plot.bight.4.service",
          at: [
            775,
            1125
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "spur glasshouse",
          at: [
            960,
            860
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "yearWalk",
          at: [
            855,
            974.6
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "yearWalk",
          at: [
            904.2,
            885.9
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "yearWalk",
          at: [
            951.2,
            863.4
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VBS",
          b: "yearWalk",
          at: [
            954.1,
            862.3
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "highSpan.walk",
          at: [
            1228.8,
            1104.1
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "spur cottage",
          at: [
            980,
            700
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "spur glasshouse",
          at: [
            960,
            860
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "spur library",
          at: [
            900,
            290
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "spur studio",
          at: [
            975.5,
            540
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "VBS",
          at: [
            960,
            860
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "VG",
          b: "walk garden",
          at: [
            969.5,
            764.2
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "under by 16.5 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "VG",
          b: "yearWalk",
          at: [
            943.6,
            471
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "walk bightPier",
          b: "walk flats",
          at: [
            350,
            880
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "under by 3.9 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "walk bightPier",
          b: "yearWalk",
          at: [
            415.5,
            897.6
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 6.2 eu: a named structure (footbridge, deck or passage) is owed; v2.0: re-check after the D-A7 regrade of the pier walk at V01 (the pier walk falls to the Drive's height here)",
          v1_9_note: "over by 6.2 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk bightPier",
          b: "yearWalk",
          at: [
            422.8,
            899
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 6.6 eu: a named structure (footbridge, deck or passage) is owed; v2.0: re-check after the D-A7 regrade of the pier walk at V01 (the pier walk falls to the Drive's height here)",
          v1_9_note: "over by 6.6 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk coveWalk",
          b: "ferry.scholarsCove",
          at: [
            630,
            235
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "the cove walk comes down the cliff stair to the pier: feet \u2192 ferry (D-C14)",
          v1_9_at: [
            630,
            240
          ],
          v1_9_resolution: "over",
          v1_9_kind: "crossing",
          structure: "coveStair",
          v1_9_note: "over by 32.8 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk coveWalk",
          b: "host.library.approach",
          at: [
            762,
            422
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "host.cottage.approach",
          at: [
            916.5,
            638.7
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "host.glasshouse.approach",
          at: [
            990,
            780
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "host.library.approach",
          at: [
            762,
            422
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "walk coveWalk",
          at: [
            762,
            422
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "walk lakerim",
          at: [
            990,
            780
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "yearWalk",
          at: [
            780.9,
            443.7
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk garden",
          b: "yearWalk",
          at: [
            899.6,
            638.9
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "under by 3.9 eu: a named structure (footbridge, deck or passage) is owed; v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "walk garden",
          b: "yearWalk",
          at: [
            900,
            640
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "walk garden",
          b: "yearWalk",
          at: [
            902.3,
            641.1
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "v1.9: now a flush path junction (was under)",
          v1_8_resolution: "under"
        },
        {
          a: "walk garden",
          b: "yearWalk",
          at: [
            961,
            757
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 14.6 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk garden",
          b: "yearWalk",
          at: [
            963.7,
            759.4
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 15.2 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk glasshouseSteps",
          b: "host.glasshouse.approach",
          at: [
            997.1,
            811.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: "under by 4.6 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk lakerim",
          b: "host.glasshouse.approach",
          at: [
            990,
            780
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk lakerim",
          b: "yearWalk",
          at: [
            1250.5,
            837.6
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk reach",
          b: "highSpan.walk",
          at: [
            1240,
            1130
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk reach",
          b: "town.quayLink",
          at: [
            1400,
            1290
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk reach",
          b: "town.riverLink",
          at: [
            1400,
            1290
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk reach",
          b: "ZIP",
          at: [
            1272.3,
            1202.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "walk reach",
          b: "ZIP",
          at: [
            1272.9,
            1201.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "walk square",
          b: "gondolaBase.walk",
          at: [
            1480,
            1060
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk square",
          b: "host.bank.approach",
          at: [
            1466.3,
            1162.9
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk square",
          b: "host.home.approach",
          at: [
            1455,
            1175
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk square",
          b: "town.bankLink",
          at: [
            1455,
            1175
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk square",
          b: "town.quayLink",
          at: [
            1455,
            1175
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1450.1,
            522.8
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1575.7,
            660.7
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1579.4,
            666
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1580.8,
            667.8
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1600.5,
            695.7
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1611.3,
            710
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "DEEP_RUN",
          at: [
            1649.9,
            743.2
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "FERRY",
          at: [
            560,
            1096.4
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "FERRY",
          at: [
            560,
            1099
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "FERRY",
          at: [
            560.2,
            1099.1
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "FERRY",
          at: [
            560.5,
            1096.7
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "plot.bight.1.service",
          at: [
            856.7,
            935
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: "v2.3: at grade (the June lane rises to the moved plot's service drive (D-D2); design lead, Stage A Wave 7 (W7-A) 2026-09-27)",
          v2_2_resolution: "under",
          v2_2_at: [
            871.2,
            914.9
          ]
        },
        {
          a: "yearWalk",
          b: "plot.terraces.1.service",
          at: [
            1594.9,
            834
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "plot.terraces.2.service",
          at: [
            1575.6,
            912.8
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "plot.terraces.3.service",
          at: [
            1547,
            974.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "seaStair",
          at: [
            1630.8,
            761.9
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 5.6 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "yearWalk",
          b: "seaStair",
          at: [
            1650.3,
            765.4
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: "over by 15.2 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "yearWalk",
          b: "town.storefront",
          at: [
            1494.5,
            1211.8
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "yearWalk",
          b: "town.storefront",
          at: [
            1495,
            1212.4
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "yearWalk",
          b: "ZIP",
          at: [
            1577.6,
            693.9
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "ZIP",
          at: [
            1579.6,
            690.7
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "ZIP",
          at: [
            1581.9,
            686.8
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "yearWalk",
          b: "ZIP",
          at: [
            1596.1,
            663.2
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "ZIP",
          b: "river lower",
          at: [
            1273.1,
            1201.5
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "zipLanding.ramp",
          b: "ZIP",
          at: [
            1130,
            1440
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "bake v1.8",
          note: "boarding threshold; mover pending"
        },
        {
          a: "zipLanding.stair",
          b: "ZIP",
          at: [
            1130,
            1440
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.8",
          note: ""
        },
        {
          a: "zipLanding.stair",
          b: "zipLanding.ramp",
          at: [
            1130,
            1440
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "zipLanding.stair",
          b: "zipLanding.ramp",
          at: [
            1145,
            1460
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.8",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "bightPierStair",
          b: "wash",
          at: [
            513.8,
            896
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.9",
          note: ""
        },
        {
          a: "jetty.bightPier",
          b: "FERRY",
          at: [
            560,
            902
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: "at-grade meeting 1 eu apart: regrade owed"
        },
        {
          a: "jetty.bightPier",
          b: "ferry.bight",
          at: [
            560,
            898
          ],
          resolution: "threshold",
          kind: "sharedStretch",
          source: "bake v1.9",
          note: "shared stretch 8 eu at one height"
        },
        {
          a: "S2",
          b: "bightPierStair",
          at: [
            509.9,
            896
          ],
          resolution: "under",
          kind: "crossing",
          source: "bake v1.9",
          note: ""
        },
        {
          a: "S4",
          b: "walk bight",
          at: [
            873.5,
            951.1
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: "at-grade meeting 1 eu apart: regrade owed"
        },
        {
          a: "S4",
          b: "yearWalk",
          at: [
            968.6,
            540.5
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: "v2.3: at grade (S4 holds VG's level across the September lane (flush landing, D-A7 #17); design lead, Stage A Wave 7 (W7-A) 2026-09-27)",
          v2_2_resolution: "under"
        },
        {
          a: "VG",
          b: "walk bight",
          at: [
            960.4,
            864.4
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: ""
        },
        {
          a: "walk bight",
          b: "yearWalk",
          at: [
            858.5,
            977
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk bight",
          b: "yearWalk",
          at: [
            907.3,
            888.6
          ],
          resolution: "over",
          kind: "crossing",
          source: "bake v1.9",
          note: "over by 8.6 eu: a named structure (footbridge, deck or passage) is owed"
        },
        {
          a: "walk bight",
          b: "yearWalk",
          at: [
            951.6,
            867.7
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk bight",
          b: "yearWalk",
          at: [
            954.5,
            866.6
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "walk bightPier",
          b: "bightPierStair",
          at: [
            498,
            896
          ],
          resolution: "threshold",
          kind: "crossing",
          source: "bake v1.9",
          note: "at-grade meeting 0.9 eu apart: regrade owed"
        },
        {
          a: "walk prow",
          b: "yearWalk",
          at: [
            1641,
            881.6
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "yearWalk",
          b: "southPortal.link",
          at: [
            1369.7,
            689.9
          ],
          resolution: "threshold",
          kind: "junction",
          source: "bake v1.9",
          note: "flush path junction: no marker, no mode change"
        },
        {
          a: "S2",
          b: "V01",
          at: [
            557.7,
            1098.4
          ],
          resolution: "over",
          kind: "crossing",
          structure: "bightBridge.s2Flyover",
          source: "design lead v2.0",
          note: "D-A1: 5.6 over the road deck at the arch crown (road clear 5 + 0.6)"
        },
        {
          a: "jetty.bightPier",
          b: "FERRY",
          at: [
            560,
            890
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          source: "integrator 3 (P15, R2-116)",
          note: "boarding threshold at the pier head (the ferry's second pass); mover pending"
        },
        {
          a: "S1",
          b: "water.river.mountain",
          at: [
            1270.5,
            836.5
          ],
          resolution: "over",
          structure: "s1InflowBridge",
          kind: "crossing",
          note: "v2.6: S1 over the mountain brook below the Foot (D-M3, D-M5)"
        },
        {
          a: "walk lakerim",
          b: "water.river.mountain",
          at: [
            1250.9,
            834.2
          ],
          resolution: "over",
          structure: "inflowFootbridge",
          kind: "crossing",
          note: "v2.6: the lake-rim trail over the mountain brook at its mouth"
        },
        {
          a: "walk footQuay",
          b: "G1",
          at: [
            1282,
            810
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          note: "v2.6 (D-M6): boarding threshold at Mountain v2's Waterfront station (threshold.gondolaBase on its platform; the region draws the terminal)"
        },
        {
          a: "walk summitStation",
          b: "G1",
          at: [
            1300,
            480
          ],
          resolution: "threshold",
          kind: "modeTransfer",
          note: "v2.6 (D-M6): boarding threshold at Mountain v2's Summit Commons station (threshold.gondolaTop on its platform; the region draws the terminal)"
        }
      ],
      thresholds: [
        {
          id: "stairTop",
          xy: [
            1480,
            1150
          ],
          modes: [
            "board\u2192feet"
          ],
          action: "park"
        },
        {
          id: "quayWest",
          xy: [
            1453,
            1277
          ],
          modes: [
            "board\u2192feet"
          ],
          action: "park (Lantern Row is pedestrian)"
        },
        {
          id: "upperStreetSpur",
          xy: [
            1480,
            1060
          ],
          modes: [
            "wheels\u2192feet"
          ],
          action: "park"
        },
        {
          id: "gondolaBase",
          xy: [
            1279.71,
            810.73
          ],
          modes: [
            "feet\u2192cable"
          ],
          action: "Ride the gondola \u2191 Summit Commons",
          v2_5_xy: [
            1480,
            1090
          ],
          action_v2_5: "board by offer"
        },
        {
          id: "adit",
          xy: [
            1090,
            540
          ],
          modes: [
            "feet\u2192cart"
          ],
          action: "sit, lever"
        },
        {
          id: "prowPlatform",
          xy: [
            1610,
            640
          ],
          modes: [
            "feet\u2192zip",
            "feet\u2192glider"
          ],
          action: "clip in / run off"
        },
        {
          id: "crownLaunch",
          xy: [
            1322,
            472
          ],
          modes: [
            "feet\u2192glider"
          ],
          action: "run off",
          v2_5_xy: [
            1305,
            482
          ],
          note_v2_6: "v2.6 (integrator, D-M6): moved 17 m east and 10 m north, clear of Mountain v2's Summit Commons gondola terminal [1300,480] and its rope (which arrives from tower 3 at [1370,550]); the deck keeps h 170 over the summit terrace, east of the observatory [1306,466]"
        },
        {
          id: "strip",
          xy: [
            435,
            690
          ],
          modes: [
            "feet\u2192plane"
          ],
          action: "climb in"
        },
        {
          id: "floatDock",
          xy: [
            1520,
            1275
          ],
          modes: [
            "feet\u2192plane"
          ],
          action: "climb in"
        },
        {
          id: "balloon",
          xy: [
            520,
            470
          ],
          modes: [
            "feet\u2192balloon"
          ],
          action: "step in"
        },
        {
          id: "boathouseDock",
          xy: [
            1320,
            1320
          ],
          modes: [
            "feet\u2192boat"
          ],
          action: "untie"
        },
        {
          id: "ferryPiers",
          xy: "see water_routes.FERRY.piers",
          modes: [
            "feet\u2192ferry"
          ],
          action: "walk the gangway (the offer appears by proximity)"
        },
        {
          id: "skateLineStarts",
          xy: [
            [
              1325,
              470.5
            ],
            [
              480,
              480
            ],
            [
              1480,
              1060
            ],
            [
              1e3,
              520
            ]
          ],
          modes: [
            "feet\u2192board"
          ],
          action: "pick up",
          v2_5_xy: [
            [
              1310,
              500
            ],
            [
              480,
              480
            ],
            [
              1480,
              1060
            ],
            [
              1e3,
              520
            ]
          ]
        },
        {
          id: "landingQuay",
          xy: [
            1270,
            1330
          ],
          modes: [
            "board\u2192feet"
          ],
          action: "park (race run-out)"
        },
        {
          id: "gondolaTop",
          xy: [
            1298.3,
            481.7
          ],
          modes: [
            "cable\u2192feet",
            "feet\u2192cable"
          ],
          action: "step off onto the platform \xB7 board by offer to ride down",
          v1_9_xy: [
            1360,
            560
          ],
          v2_5_xy: [
            1335,
            535
          ],
          v2_5_modes: [
            "cable\u2192feet"
          ],
          action_v2_6: "board by offer (ride down) / step off"
        },
        {
          id: "southPortal",
          xy: [
            1345,
            680
          ],
          modes: [
            "cart\u2192feet"
          ],
          action: "climb out"
        },
        {
          id: "zipLanding",
          xy: [
            1130,
            1440
          ],
          modes: [
            "zip\u2192feet"
          ],
          action: "unclip on the landing tower; stair or ramp to the sand"
        },
        {
          id: "lampGallery",
          xy: [
            540,
            1195
          ],
          modes: [
            "feet\u2192glider"
          ],
          action: "run off the gallery"
        },
        {
          id: "deepJetty",
          xy: [
            1300,
            440
          ],
          modes: [
            "glider\u2192feet",
            "boat\u2192feet"
          ],
          action: "flare onto the water, swim to the jetty (fade)"
        },
        {
          id: "seaDoorJetty",
          xy: [
            1705,
            775
          ],
          modes: [
            "boat\u2192feet",
            "ferry\u2192feet"
          ],
          action: "tie up / gangway"
        },
        {
          id: "bightShoreJetty",
          xy: [
            735,
            955
          ],
          modes: [
            "boat\u2192feet"
          ],
          action: "tie up"
        },
        {
          id: "lampDock",
          xy: [
            540,
            1250
          ],
          modes: [
            "boat\u2192feet"
          ],
          action: "tie up"
        },
        {
          id: "stepsFoot",
          xy: [
            1420,
            505
          ],
          modes: [
            "boat\u2192feet"
          ],
          action: "tie up at the foot of the Steps; portage stair to the Deep"
        },
        {
          id: "funicular.town.to.hearth",
          xy: [
            1291.1,
            728.1
          ],
          h: 55.65,
          modes: [
            "feet\u2192funicular"
          ],
          action: "Ride the funicular \u2191 Lower neighbourhood",
          source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
        },
        {
          id: "funicular.hearth.to.library",
          xy: [
            1314.41,
            677.19
          ],
          h: 69.6,
          modes: [
            "feet\u2192funicular"
          ],
          action: "Ride the funicular \u2191 Library Woods",
          source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
        },
        {
          id: "funicular.hearth.to.town",
          xy: [
            1314.41,
            677.19
          ],
          h: 69.6,
          modes: [
            "feet\u2192funicular"
          ],
          action: "Ride the funicular \u2193 The square",
          source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
        },
        {
          id: "funicular.library.to.reservoir",
          xy: [
            1325.44,
            607.53
          ],
          h: 93.6,
          modes: [
            "feet\u2192funicular"
          ],
          action: "Ride the funicular \u2191 Reservoir Heights",
          source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
        },
        {
          id: "funicular.library.to.hearth",
          xy: [
            1325.44,
            607.53
          ],
          h: 93.6,
          modes: [
            "feet\u2192funicular"
          ],
          action: "Ride the funicular \u2193 Lower neighbourhood",
          source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
        },
        {
          id: "funicular.reservoir.to.library",
          xy: [
            1344.86,
            536.53
          ],
          h: 141.6,
          modes: [
            "feet\u2192funicular"
          ],
          action: "Ride the funicular \u2193 Library Woods",
          source: "v2.6 (R5-02): Mountain v2 FUNICULAR_LINE platform + offset; per-direction boarding (movers/gondola/route.ts cableThresholds)"
        }
      ],
      journeys: {
        note: "Straight-segment lengths between control points at assumed speeds; calibration estimates, not measured journeys. at_active_scale uses the confirmed scale.factor (1.0); the two at_factor tables are comparison scenarios.",
        "square\u2192library by bicycle": {
          length_m: 1455,
          mode: "bicycle"
        },
        "square\u2192summit by gondola + walk": {
          legs: [
            {
              length_m: 830,
              mode: "walk"
            },
            {
              length_m: 474,
              mode: "gondola"
            },
            {
              length_m: 14,
              mode: "walk"
            }
          ],
          note: "v2.6 (D-M6): the gondola is Mountain v2's (Waterfront quay on the Foot terrace -> Summit Commons); the first walk is the square -> the Prow drive -> V03 -> the Foot -> the quay (plan estimate; the Little Harbour -> v2 quay lower leg is D-M6b, not built); the last walk is the summit station -> L02 (v2's observatory). v2.0: time = sum of legs; v2.0 (D-A3): the gondola runs to the shoulder station [1335,535] and the last walk is the station \u2192 L02 leg",
          v1_9_legs: [
            {
              length_m: 158,
              mode: "walk"
            },
            {
              length_m: 543,
              mode: "gondola"
            },
            {
              length_m: 78,
              mode: "walk"
            }
          ],
          v2_5_legs: [
            {
              length_m: 158,
              mode: "walk"
            },
            {
              length_m: 574,
              mode: "gondola"
            },
            {
              length_m: 70,
              mode: "walk"
            }
          ]
        },
        "crown\u2192quay on the board (S1)": {
          length_m: 1712,
          mode: "board",
          v2_5_length_m: 971,
          note_v2_6: "D-M5: Mountain v2 course (summit start to its quay finish, 1059 m) then the Horizon stretch to the Landing"
        },
        "crown\u2192lamp by glider": {
          length_m: 1103,
          mode: "glider"
        },
        "ring by plane": {
          length_m: 3896,
          mode: "plane"
        },
        "ring by bicycle": {
          length_m: 3896,
          mode: "bicycle"
        },
        "square\u2192green on foot": {
          length_m: 562,
          mode: "walk"
        },
        "square\u2192boathouse on foot": {
          length_m: 274,
          mode: "walk"
        },
        "adit\u2192south portal by cart": {
          length_m: 540,
          mode: "cart"
        },
        "prow\u2192sands by zip": {
          length_m: 933,
          mode: "zip"
        },
        at_factor_1_0: {
          "square\u2192library by bicycle": {
            engine_u: 1455,
            time_s: 182
          },
          "square\u2192summit by gondola + walk": {
            engine_u: 802,
            time_s: 177
          },
          "crown\u2192quay on the board (S1)": {
            engine_u: 971,
            time_s: 97
          },
          "crown\u2192lamp by glider": {
            engine_u: 1103,
            time_s: 100
          },
          "ring by plane": {
            engine_u: 3896,
            time_s: 87
          },
          "ring by bicycle": {
            engine_u: 3896,
            time_s: 487
          },
          "square\u2192green on foot": {
            engine_u: 562,
            time_s: 234,
            run_s: 112
          },
          "square\u2192boathouse on foot": {
            engine_u: 274,
            time_s: 114,
            run_s: 55
          },
          "adit\u2192south portal by cart": {
            engine_u: 540,
            time_s: 68
          },
          "prow\u2192sands by zip": {
            engine_u: 933,
            time_s: 78
          }
        },
        at_factor_0_6: {
          "square\u2192library by bicycle": {
            engine_u: 873,
            time_s: 109
          },
          "square\u2192summit by gondola + walk": {
            engine_u: 481,
            time_s: 106
          },
          "crown\u2192quay on the board (S1)": {
            engine_u: 583,
            time_s: 58
          },
          "crown\u2192lamp by glider": {
            engine_u: 662,
            time_s: 60
          },
          "ring by plane": {
            engine_u: 2338,
            time_s: 52
          },
          "ring by bicycle": {
            engine_u: 2338,
            time_s: 292
          },
          "square\u2192green on foot": {
            engine_u: 337,
            time_s: 140,
            run_s: 67
          },
          "square\u2192boathouse on foot": {
            engine_u: 164,
            time_s: 68,
            run_s: 33
          },
          "adit\u2192south portal by cart": {
            engine_u: 324,
            time_s: 40
          },
          "prow\u2192sands by zip": {
            engine_u: 560,
            time_s: 47
          }
        },
        targets_s: {
          "square\u2192library by bicycle": 243,
          "square\u2192green running": 125,
          "square\u2192summit by gondola + walk": 465,
          "crown\u2192quay on the board (S1)": [
            150,
            200
          ],
          "crown\u2192lamp by glider": [
            85,
            120
          ],
          "ring by plane": [
            60,
            120
          ],
          "square\u2192home/bank on foot, walking": 60,
          "square\u2192boathouse on foot, walking": 180,
          note: "v1.7 targets at scale 1.0: each is achievable with \u2265 10 % margin on the Stage A path graph (README v1.7 table); the summit target is 205 s (D-A3, Jonathan 2026-09-27: option 2 gives \u2248 185 s; 205 keeps the \u2265 10 % margin; it was 375 while reserved)",
          decisions: {
            "crown\u2192lamp by glider": "D34 applied pending Jonathan's confirmation: FLIGHT retargeted from [50,90] to [70,110] (~98 s at 11 m/s trim in still air, FLIGHT.md \xA712) on the v1.6 launch. v2.2: the Stage A v1.7 target [85,120] (measured on the Stage A graph from the v2.1 lookout launch [1305,482] h 170: 96.0 s on candidate 5) contains the same flight and stands; D34's [70,110] is kept in v2_2_d34",
            v2_2_d34: [
              70,
              110
            ],
            "square\u2192library by bicycle": "v2.3 (design lead, Stage A Wave 7 (W7-A) 2026-09-27, reversible): planned at the bicycle's 6.0 m/s cap, the ride measures 220.6 s (1,324 eu, Stage A W7-A scratch bake); target = measured + 10 % = 243 s (v2.2: 185 s at 8 m/s)",
            "v2_2_square\u2192library by bicycle": 185
          },
          "v2_5_crown\u2192quay on the board (S1)": [
            110,
            150
          ],
          "v2_5_square\u2192summit by gondola + walk": 205,
          note_v2_6: "v2.6: S1 is Mountain v2 course + the Horizon stretch (1721 m, measured 172 s on the v2.6 bake: target [150,200]); the summit journey walks the square -> the Prow drive -> V03 -> the Foot -> v2 quay (measured 420.6 s: 1321 m; target 465 keeps the 10 % margin) until the Little Harbour lower leg (D-M6b) exists"
        },
        at_active_scale: {
          "square\u2192library by bicycle": {
            engine_u: 1455,
            time_s: 182
          },
          "square\u2192summit by gondola + walk": {
            engine_u: 802,
            time_s: 177
          },
          "crown\u2192quay on the board (S1)": {
            engine_u: 971,
            time_s: 97
          },
          "crown\u2192lamp by glider": {
            engine_u: 1103,
            time_s: 100
          },
          "ring by plane": {
            engine_u: 3896,
            time_s: 87
          },
          "ring by bicycle": {
            engine_u: 3896,
            time_s: 487
          },
          "square\u2192green on foot": {
            engine_u: 562,
            time_s: 234,
            run_s: 112
          },
          "square\u2192boathouse on foot": {
            engine_u: 274,
            time_s: 114,
            run_s: 55
          },
          "adit\u2192south portal by cart": {
            engine_u: 540,
            time_s: 68
          },
          "prow\u2192sands by zip": {
            engine_u: 933,
            time_s: 78
          }
        },
        anchors: {
          "square\u2192green running": [
            1053.9,
            1043.4
          ],
          note: "the Green's edge on Green Road (the centre has no bed within the snap distance); measurements snap to this point"
        },
        targets_v1_6: {
          "square\u2192library by bicycle": 150,
          "square\u2192green running": 100,
          "square\u2192summit by gondola + walk": 120,
          "crown\u2192quay on the board (S1)": [
            70,
            130
          ],
          "crown\u2192lamp by glider": [
            50,
            90
          ],
          "ring by plane": [
            60,
            120
          ],
          "square\u2192home/bank on foot, walking": 60,
          "square\u2192boathouse on foot, walking": 100
        },
        targets_v1_9: {
          "square\u2192summit by gondola + walk": 375
        }
      },
      speeds_ms: {
        walk: 2.4,
        run: 5,
        board: 10,
        bicycle: 6,
        gondola: 7,
        cart: 8,
        zip: 12,
        glider: 11,
        plane: 45,
        ferry: 5,
        row: 1.8,
        v2_2_bicycle: 8
      },
      pastimeData: {
        nineBaskets: [
          [
            1189,
            1151
          ],
          [
            1118,
            1218
          ],
          [
            1022,
            1236
          ],
          [
            932,
            1199
          ],
          [
            876,
            1118
          ],
          [
            874,
            1020
          ],
          [
            913,
            924
          ],
          [
            1022,
            894
          ],
          [
            893,
            600
          ]
        ],
        nineBasketsNote: "baskets 1\u20138 ring the protected centre at 172\u2013190 m; the ninth is on the Hollow Bridge",
        mailDayTargets: "the seven hosts' roofs (MANIFEST.hosts)",
        riverRunGates: [
          [
            1140,
            760
          ],
          [
            1100,
            850
          ],
          [
            1200,
            880
          ],
          [
            1150,
            935
          ],
          [
            1170,
            980
          ],
          [
            1220,
            1060
          ],
          [
            1250,
            1140
          ],
          [
            1290,
            1225
          ],
          [
            1350,
            1320
          ]
        ],
        bocce: {
          xy: [
            1455,
            1150
          ],
          note: "the square's small green; single device vs. the ghost until a presence change is trust-reviewed"
        },
        lanternQuotas: {
          harbour: 6,
          landing: 6,
          reach: 3,
          green: 5,
          hollow: 5,
          scholars: 5,
          flats: 6,
          bight: 4,
          lakeside: 5,
          notch: 3,
          prow: 4,
          crown: 4,
          undercroft: 4,
          offshore: 4,
          total: 64,
          rule: "64 placed, 60 required to fill the Lantern Cave; never inside a reserve; \u2265 8 reachable only by air, \u2265 6 only by water, \u2265 4 only underground"
        },
        skating: {
          where: "stillwater",
          months: [
            1,
            2
          ]
        },
        sledding: {
          where: "Mountain v2 meadow terraces (the meadow sweep); no Horizon bed: T2/T3 place it",
          months: [
            1,
            2
          ],
          note: "v2.6 (D-M5): the Shoulder meadow sledding bed is retired",
          v2_5: {
            where: "the Shoulder's south-east meadow [1400,760]",
            months: [
              1,
              2
            ],
            note: "inside the Jan\u2013Feb snowline; 90 m east of S1"
          }
        }
      },
      journey: {
        principle: "one household state and history \u2192 one WorldOverlay (derived on read, never stored) \u2192 the Journey renderer (L0\u2013L1) and the world renderer (L2\u2013L3) and the Desk; see SCALES.md",
        stations: [
          {
            month: 1,
            id: "jan",
            label: "Hearth Terrace (the mountain)",
            xy: [
              1364,
              650
            ],
            why: "snow on the mountain, the summit walk (v2 road) and the sledding meadows",
            v2_5_xy: [
              1330,
              640
            ],
            v2_5_label: "the Shoulder",
            moveWhy_v2_6: "D-M1/D-M5: the Shoulder is Mountain v2; the station stands on v2 Hearth terrace (level 73.2, an open shelf: D-M9) beside v2 road, 229 m up from the road foot; its pad is carried (a deck): the region draws the terrace"
          },
          {
            month: 2,
            id: "feb",
            label: "Lakeside",
            xy: [
              1100,
              721
            ],
            why: "ice on Stillwater, the skipping shelf",
            movedFrom: [
              1255,
              860
            ],
            moveWhy: "the old pad sat on S1 (0.7 m) and walk lakerim; now on the north-shore lake rim at the rim trail's own height (the skipping shelf)"
          },
          {
            month: 3,
            id: "mar",
            label: "Scholars\u2019 floor",
            xy: [
              700,
              470
            ],
            why: "the woodland floor thaws first; bloodroot"
          },
          {
            month: 4,
            id: "apr",
            label: "the Green (west)",
            xy: [
              932,
              995
            ],
            why: "first grass; dandelions; kites nearby",
            movedFrom: [
              860,
              980
            ],
            moveWhy: "the old pad sat across the Bight Shore spur (VBS 7 m) and S4; moved 72 m east onto open Green (west)"
          },
          {
            month: 5,
            id: "may",
            label: "the Hollow (west rows)",
            xy: [
              960,
              640
            ],
            why: "apple blossom"
          },
          {
            month: 6,
            id: "jun",
            label: "Long Sands",
            xy: [
              950,
              1445
            ],
            why: "lupines; the Campfire is here"
          },
          {
            month: 7,
            id: "jul",
            label: "the Flats",
            xy: [
              401,
              745
            ],
            why: "coneflower, thermals, the strip",
            movedFrom: [
              380,
              800
            ],
            moveWhy: "the old pad sat on Horizon Drive (V01 1.0 m); moved 59 m to the gap between V01 and the strip"
          },
          {
            month: 8,
            id: "aug",
            label: "the Reach",
            xy: [
              1203,
              1292
            ],
            why: "monarchs, Joe-Pye, the boardwalk",
            movedFrom: [
              1230,
              1290
            ],
            moveWhy: "the old pad reached into the Reach west channel (3.1 m); moved 27 m west onto dry Reach meadow"
          },
          {
            month: 9,
            id: "sep",
            label: "the Hollow (east rows)",
            xy: [
              1032,
              652
            ],
            why: "apples",
            v1_8_xy: [
              1040,
              650
            ],
            moveWhy_v1_9: "8 m west so February passes east of the pad on the 45 shelf (the pad's level pins held February at 35 there); the pad sits at 40, a 5 m terrace cut into the shelf's edge"
          },
          {
            month: 10,
            id: "oct",
            label: "the north pass",
            xy: [
              790,
              322
            ],
            why: "maples red",
            movedFrom: [
              800,
              300
            ],
            moveWhy: "the old pad sat on Horizon Drive (V01 5.7 m); moved 24 m south into the north pass"
          },
          {
            month: 11,
            id: "nov",
            label: "the Prow",
            xy: [
              1626,
              904
            ],
            why: "the first storms, the Lamp\u2019s beam",
            movedFrom: [
              1570,
              940
            ],
            moveWhy: "the old pad sat on the Prow cliff drive (V01 0.8 m) in its 34 m cutting; moved onto the Prow top beside the Prow walk",
            v1_9_xy: [
              1622,
              912
            ],
            pad_rot_deg: 90,
            moveWhy_v2_0: "D-A8 (Jonathan 2026-09-27): off the Prow cliff overhang; turned 90\xB0 along the Prow top, ground 54.0-56.7 under the pad (it fell to 26.3 under the v1.9 pad)"
          },
          {
            month: 12,
            id: "dec",
            label: "Little Harbour",
            xy: [
              1488,
              1228
            ],
            why: "Lantern Row, the Chapter at home",
            movedFrom: [
              1475,
              1230
            ],
            moveWhy: "the old pad overlapped Town Weave (S3); moved 13 m east onto the storefront lane"
          }
        ],
        yearWalk: {
          profile: "walk",
          note: "a trail through the twelve stations in calendar order, entirely on land: it never goes below sea level or into Stillwater, the Bight, a river or a channel except across a named bridge, never through a reserve plot, and never stacked on another bed at a different height; where it shares a corridor it shares the host bed's alignment and height (shares); the walk ahead of the current month is dressed as stakes and string",
          pts: [
            [
              1364,
              650
            ],
            [
              1359.58,
              666.44
            ],
            [
              1353.32,
              666.26
            ],
            [
              1347.38,
              665.58
            ],
            [
              1341.56,
              665.37
            ],
            [
              1335.92,
              665.38
            ],
            [
              1331.81,
              667.12
            ],
            [
              1329.46,
              670.59
            ],
            [
              1331.2,
              674.04
            ],
            [
              1335.18,
              677.11
            ],
            [
              1340.36,
              678.72
            ],
            [
              1345.92,
              679.54
            ],
            [
              1351.74,
              679.61
            ],
            [
              1357.67,
              679.58
            ],
            [
              1363.64,
              679.19
            ],
            [
              1370.24,
              679.58
            ],
            [
              1376.54,
              682.24
            ],
            [
              1380.86,
              688.63
            ],
            [
              1379.2,
              696.02
            ],
            [
              1373.51,
              700.48
            ],
            [
              1367.47,
              702.67
            ],
            [
              1361.16,
              703.77
            ],
            [
              1354.77,
              703.83
            ],
            [
              1348.48,
              702.85
            ],
            [
              1342.38,
              700.94
            ],
            [
              1336.81,
              697.94
            ],
            [
              1331.77,
              695.07
            ],
            [
              1326.43,
              692.74
            ],
            [
              1320.9,
              690.65
            ],
            [
              1315.38,
              688.71
            ],
            [
              1310.05,
              687.75
            ],
            [
              1304.51,
              688.03
            ],
            [
              1299.02,
              689.19
            ],
            [
              1293.87,
              691.25
            ],
            [
              1289.3,
              694.23
            ],
            [
              1285.75,
              698.15
            ],
            [
              1283.46,
              702.92
            ],
            [
              1282.74,
              708.09
            ],
            [
              1283.44,
              713.7
            ],
            [
              1284.37,
              719.65
            ],
            [
              1276,
              728
            ],
            [
              1262,
              742
            ],
            [
              1248,
              750
            ],
            [
              1235,
              755
            ],
            [
              1219.3,
              745.4
            ],
            [
              1189,
              733.8
            ],
            [
              1155.8,
              724.5
            ],
            [
              1145,
              720
            ],
            [
              1100,
              720
            ],
            [
              1080,
              725
            ],
            [
              1055,
              710
            ],
            [
              1052,
              662
            ],
            [
              1060,
              600
            ],
            [
              1062,
              540
            ],
            [
              1060,
              505
            ],
            [
              1050,
              487
            ],
            [
              1e3,
              480
            ],
            [
              960,
              470
            ],
            [
              930,
              480
            ],
            [
              895,
              480
            ],
            [
              905,
              470
            ],
            [
              885,
              465
            ],
            [
              872,
              461.7
            ],
            [
              857,
              441.3
            ],
            [
              789.3,
              436.5
            ],
            [
              769.2,
              446.5
            ],
            [
              715,
              446.5
            ],
            [
              700,
              470
            ],
            [
              715,
              450
            ],
            [
              770,
              450
            ],
            [
              790,
              440
            ],
            [
              855,
              445
            ],
            [
              870,
              465
            ],
            [
              905,
              470
            ],
            [
              895,
              475
            ],
            [
              905,
              475
            ],
            [
              895,
              480
            ],
            [
              915,
              480
            ],
            [
              900,
              500
            ],
            [
              905,
              545
            ],
            [
              910,
              565
            ],
            [
              935,
              585
            ],
            [
              905,
              610
            ],
            [
              900,
              640
            ],
            [
              900,
              628
            ],
            [
              899,
              660
            ],
            [
              898,
              700
            ],
            [
              895,
              740
            ],
            [
              892,
              780
            ],
            [
              887,
              815
            ],
            [
              890,
              870
            ],
            [
              920,
              900
            ],
            [
              915,
              910
            ],
            [
              930,
              995
            ],
            [
              990,
              1010
            ],
            [
              997,
              1006.7
            ],
            [
              977.4,
              967.2
            ],
            [
              966.1,
              929.6
            ],
            [
              957.3,
              889.1
            ],
            [
              953.3,
              848.9
            ],
            [
              956.7,
              808.9
            ],
            [
              962.3,
              768.6
            ],
            [
              969.2,
              725.7
            ],
            [
              975.4,
              689.6
            ],
            [
              986.5,
              649.9
            ],
            [
              994.1,
              612.3
            ],
            [
              970,
              625
            ],
            [
              960,
              640
            ],
            [
              930,
              605
            ],
            [
              910,
              605
            ],
            [
              903,
              628
            ],
            [
              902,
              660
            ],
            [
              901,
              700
            ],
            [
              898,
              740
            ],
            [
              895,
              780
            ],
            [
              890,
              815
            ],
            [
              870,
              835
            ],
            [
              870,
              870
            ],
            [
              885,
              905
            ],
            [
              865,
              920
            ],
            [
              845,
              965
            ],
            [
              865,
              985
            ],
            [
              885,
              1065
            ],
            [
              885,
              1120
            ],
            [
              900,
              1180
            ],
            [
              920,
              1220
            ],
            [
              960,
              1355
            ],
            [
              970,
              1365
            ],
            [
              945,
              1385
            ],
            [
              950,
              1445
            ],
            [
              925,
              1440
            ],
            [
              870,
              1385
            ],
            [
              790,
              1325
            ],
            [
              735,
              1270
            ],
            [
              765,
              1235
            ],
            [
              710,
              1190
            ],
            [
              701.9,
              1195.9
            ],
            [
              679.4,
              1178.1
            ],
            [
              645.9,
              1154.1
            ],
            [
              613.3,
              1133.2
            ],
            [
              579.3,
              1111.5
            ],
            [
              546.3,
              1090
            ],
            [
              512.6,
              1067
            ],
            [
              482.5,
              1044.2
            ],
            [
              454.9,
              1014
            ],
            [
              437.3,
              979.5
            ],
            [
              423.4,
              943.6
            ],
            [
              410.5,
              904
            ],
            [
              425,
              890
            ],
            [
              400,
              745
            ],
            [
              425,
              770
            ],
            [
              440,
              860
            ],
            [
              440,
              870
            ],
            [
              412.6,
              903.3
            ],
            [
              425.5,
              942.8
            ],
            [
              439.3,
              978.6
            ],
            [
              456.7,
              1012.8
            ],
            [
              483.9,
              1042.5
            ],
            [
              513.9,
              1065.2
            ],
            [
              547.5,
              1088.2
            ],
            [
              580.5,
              1109.6
            ],
            [
              614.5,
              1131.3
            ],
            [
              647.1,
              1152.2
            ],
            [
              680.8,
              1176.4
            ],
            [
              703.3,
              1194.2
            ],
            [
              730,
              1180
            ],
            [
              930,
              1265
            ],
            [
              950,
              1265
            ],
            [
              970,
              1245
            ],
            [
              1120,
              1270
            ],
            [
              1160,
              1300
            ],
            [
              1205,
              1290
            ],
            [
              1160,
              1245
            ],
            [
              1120,
              1250
            ],
            [
              1100,
              1245
            ],
            [
              975,
              1155
            ],
            [
              960,
              1130
            ],
            [
              955,
              1095
            ],
            [
              990,
              1010
            ],
            [
              994.6,
              1008.6
            ],
            [
              974.6,
              968.2
            ],
            [
              963.2,
              930.4
            ],
            [
              954.3,
              889.7
            ],
            [
              950.3,
              848.9
            ],
            [
              953.7,
              808.6
            ],
            [
              959.3,
              768.2
            ],
            [
              966.2,
              725.2
            ],
            [
              972.5,
              688.9
            ],
            [
              983.6,
              649
            ],
            [
              991.1,
              612
            ],
            [
              1010,
              615
            ],
            [
              1032,
              652
            ],
            [
              1025,
              626
            ],
            [
              1010,
              604
            ],
            [
              991.3,
              592.5
            ],
            [
              974.3,
              552.6
            ],
            [
              956.4,
              515.5
            ],
            [
              938.9,
              476.8
            ],
            [
              929.5,
              433.8
            ],
            [
              927.1,
              388
            ],
            [
              915,
              370
            ],
            [
              820,
              345
            ],
            [
              790,
              320
            ],
            [
              810,
              305
            ],
            [
              810,
              280
            ],
            [
              815,
              275
            ],
            [
              895,
              275
            ],
            [
              899.2,
              283.6
            ],
            [
              940,
              276.6
            ],
            [
              980,
              268.6
            ],
            [
              1017.4,
              261
            ],
            [
              1056.8,
              253.2
            ],
            [
              1096.5,
              246.3
            ],
            [
              1136.3,
              242.6
            ],
            [
              1178.5,
              242.2
            ],
            [
              1216.7,
              243.5
            ],
            [
              1259.2,
              246.9
            ],
            [
              1297.7,
              252.8
            ],
            [
              1320.2,
              260.7
            ],
            [
              1338.9,
              296.4
            ],
            [
              1382.5,
              312.2
            ],
            [
              1413.8,
              330.5
            ],
            [
              1439.8,
              360
            ],
            [
              1467.2,
              393.5
            ],
            [
              1494.8,
              422.8
            ],
            [
              1521.4,
              455.9
            ],
            [
              1546.9,
              487.5
            ],
            [
              1553.8,
              519.4
            ],
            [
              1561,
              556.4
            ],
            [
              1567.4,
              598.5
            ],
            [
              1572.5,
              635.5
            ],
            [
              1577.9,
              678.4
            ],
            [
              1581,
              705
            ],
            [
              1570,
              665
            ],
            [
              1575,
              670
            ],
            [
              1600,
              665
            ],
            [
              1615,
              725
            ],
            [
              1630,
              745
            ],
            [
              1630,
              855
            ],
            [
              1626,
              904
            ],
            [
              1645,
              875
            ],
            [
              1650,
              855
            ],
            [
              1650,
              745
            ],
            [
              1645,
              725
            ],
            [
              1615,
              685
            ],
            [
              1596.9,
              703.2
            ],
            [
              1601.8,
              746.3
            ],
            [
              1606,
              790.3
            ],
            [
              1608,
              832
            ],
            [
              1602.7,
              877.6
            ],
            [
              1588.6,
              919
            ],
            [
              1572.7,
              957.4
            ],
            [
              1553.6,
              996.8
            ],
            [
              1523,
              1027.7
            ],
            [
              1498.6,
              1039.6
            ],
            [
              1510,
              1050
            ],
            [
              1510,
              1100
            ],
            [
              1525,
              1175
            ],
            [
              1500,
              1200
            ],
            [
              1490,
              1230
            ],
            [
              1500,
              1200
            ],
            [
              1545,
              1160
            ],
            [
              1535,
              1120
            ],
            [
              1540,
              1085
            ],
            [
              1530,
              1055
            ],
            [
              1505,
              1015
            ],
            [
              1495,
              1015
            ],
            [
              1490,
              1020
            ],
            [
              1493.6,
              1027.6
            ],
            [
              1528.6,
              1007.9
            ],
            [
              1549.8,
              975.8
            ],
            [
              1567.7,
              936.2
            ],
            [
              1582.4,
              898.3
            ],
            [
              1593.6,
              859
            ],
            [
              1593.5,
              820
            ],
            [
              1593.1,
              803
            ],
            [
              1574.97,
              797.5
            ],
            [
              1539.91,
              797
            ],
            [
              1504.95,
              796.5
            ],
            [
              1477.95,
              796.5
            ],
            [
              1441.41,
              796
            ],
            [
              1404.69,
              795.49
            ],
            [
              1387.28,
              793.27
            ],
            [
              1362.44,
              783.97
            ],
            [
              1337.28,
              771.91
            ],
            [
              1312.36,
              760.94
            ],
            [
              1292.65,
              752.06
            ],
            [
              1279.65,
              748.23
            ],
            [
              1285.5,
              736
            ],
            [
              1279.4,
              727.5
            ],
            [
              1278.7,
              714.46
            ],
            [
              1277.94,
              708.17
            ],
            [
              1278.88,
              701.5
            ],
            [
              1281.75,
              695.49
            ],
            [
              1286.22,
              690.55
            ],
            [
              1291.67,
              686.99
            ],
            [
              1297.64,
              684.59
            ],
            [
              1303.87,
              683.27
            ],
            [
              1310.31,
              682.95
            ],
            [
              1316.74,
              684.11
            ],
            [
              1322.54,
              686.15
            ],
            [
              1328.23,
              688.3
            ],
            [
              1333.89,
              690.77
            ],
            [
              1339.27,
              693.82
            ],
            [
              1344.24,
              696.52
            ],
            [
              1349.58,
              698.17
            ],
            [
              1355.13,
              699.05
            ],
            [
              1360.72,
              698.99
            ],
            [
              1366.21,
              698.03
            ],
            [
              1371.45,
              696.14
            ],
            [
              1375.16,
              693.42
            ],
            [
              1376.1,
              689.27
            ],
            [
              1373.88,
              686.24
            ],
            [
              1369.16,
              684.26
            ],
            [
              1363.84,
              683.99
            ],
            [
              1357.83,
              684.38
            ],
            [
              1351.76,
              684.41
            ],
            [
              1345.6,
              684.32
            ],
            [
              1339.3,
              683.4
            ],
            [
              1333.06,
              681.41
            ],
            [
              1327.6,
              677.22
            ],
            [
              1324.68,
              670.05
            ],
            [
              1328.61,
              663.54
            ],
            [
              1335.3,
              660.62
            ],
            [
              1341.64,
              660.57
            ],
            [
              1347.8,
              660.8
            ],
            [
              1353.78,
              661.48
            ],
            [
              1359.5,
              661.64
            ],
            [
              1364,
              650
            ]
          ],
          ptsRule: "centreline control points, solved as the other beds are (Catmull-Rom, 5 m samples) and graded at profiles.walk.grade_max_pct; the builder uses these points verbatim (no inserted controls) and places each station pad at the walk height at its station",
          pins: [
            {
              station: "jan",
              xy: [
                1364,
                650
              ],
              h: 73.2,
              v1_8_h: 117,
              v2_5_xy: [
                1330,
                640
              ],
              v2_5_h: 112.8
            },
            {
              station: "feb",
              xy: [
                1100,
                721
              ],
              h: 53
            },
            {
              station: "mar",
              xy: [
                700,
                470
              ],
              h: 48
            },
            {
              station: "apr",
              xy: [
                932,
                995
              ],
              h: 19.5
            },
            {
              station: "may",
              xy: [
                960,
                640
              ],
              h: 37,
              v1_8_h: 31.5
            },
            {
              station: "jun",
              xy: [
                950,
                1445
              ],
              h: 2
            },
            {
              station: "jul",
              xy: [
                401,
                745
              ],
              h: 36
            },
            {
              station: "aug",
              xy: [
                1203,
                1292
              ],
              h: 4
            },
            {
              station: "sep",
              xy: [
                1040,
                650
              ],
              h: 40,
              v1_8_h: 33
            },
            {
              station: "oct",
              xy: [
                790,
                322
              ],
              h: 45.5
            },
            {
              station: "nov",
              xy: [
                1626,
                904
              ],
              h: 56,
              v1_9_xy: [
                1622,
                912
              ],
              v1_9_h: 56.5
            },
            {
              station: "dec",
              xy: [
                1488,
                1228
              ],
              h: 8
            }
          ],
          shares: [
            {
              stretch: "may",
              host: "VG",
              side: "west",
              offset_m: 6.5,
              from: [
                997,
                1006.7
              ],
              to: [
                994.1,
                612.3
              ],
              note: "Green Road's west footway"
            },
            {
              stretch: "sep",
              host: "VG",
              side: "west",
              offset_m: 9.5,
              from: [
                994.6,
                1008.6
              ],
              to: [
                991.1,
                612
              ],
              note: "the same footway's outer lane"
            },
            {
              stretch: "jul",
              host: "V01",
              via: "structure.bightBridge",
              side: "lagoon (north-east)",
              offset_m: 5.2,
              from: [
                701.9,
                1195.9
              ],
              to: [
                410.5,
                904
              ],
              note: "the Bight Bridge's lagoon-side footway and the Drive's verge down the Flats arm; deck height 12 on the bridge"
            },
            {
              stretch: "aug",
              host: "V01",
              via: "structure.bightBridge",
              side: "lagoon (north-east)",
              offset_m: 7.4,
              from: [
                412.6,
                903.3
              ],
              to: [
                703.3,
                1194.2
              ],
              note: "the same footway's outer lane, walked back east a month later"
            },
            {
              stretch: "nov",
              host: "V01",
              side: "seaward (north)",
              offset_m: 6.5,
              from: [
                899.2,
                283.6
              ],
              to: [
                1320.2,
                260.7
              ],
              note: "the north coast drive's seaward verge",
              v1_8_to: [
                1319.7,
                258.5
              ]
            },
            {
              stretch: "nov",
              host: "V01",
              side: "inland",
              offset_m: 9.5,
              from: [
                1338.9,
                296.4
              ],
              to: [
                1581,
                705
              ],
              note: "crosses the Drive at grade at [1330,270] and takes the inland verge round the north-east corner (the seaward verge there is off the outline) up onto the Prow",
              v1_8_from: [
                1340.4,
                281.3
              ]
            },
            {
              stretch: "dec",
              host: "V01",
              side: "seaward (east)",
              offset_m: 6.5,
              from: [
                1596.9,
                703.2
              ],
              to: [
                1498.6,
                1039.6
              ],
              note: "down the Prow cliff drive's seaward verge to the harbour",
              v1_8_from: [
                1596.9,
                703.2
              ],
              v1_8_to: [
                1500.3,
                1038.1
              ]
            },
            {
              stretch: "apr",
              host: "S4",
              side: "east",
              offset_m: 6,
              from: [
                905,
                610
              ],
              to: [
                899,
                660
              ],
              note: "v1.9: the April lane is S4's east footway through the Hollow neck, at S4's height"
            },
            {
              stretch: "jun",
              host: "S4",
              side: "east",
              offset_m: 8,
              from: [
                903,
                628
              ],
              to: [
                902,
                660
              ],
              note: "v1.9: the June lane, 3 m further out on the same footway"
            },
            {
              stretch: "sep",
              host: "VG",
              side: "west",
              offset_m: 6.5,
              from: [
                991.3,
                592.5
              ],
              to: [
                927.1,
                388
              ],
              note: "v1.9: Green Road's west footway from the September pad's return to the north pass"
            },
            {
              stretch: "feb",
              host: "walk lakerim",
              side: "on the rim trail",
              offset_m: 0,
              from: [
                1235,
                755
              ],
              to: [
                1100,
                721
              ],
              note: "v2.6: the February stretch walks the lake rim trail from the north-east shore by the Foot terrace to the station; the Inlet Footbridge is retired",
              v1_8_from: [
                1250,
                800
              ],
              v2_5_from: [
                1251,
                836
              ]
            },
            {
              stretch: "jan",
              host: "V01",
              side: "inland (west)",
              offset_m: 6.5,
              from: [
                1493.6,
                1027.6
              ],
              to: [
                1593.1,
                803
              ],
              note: "up the Prow cliff drive inland verge to the Mountain Road junction (v2.6: was on to the north-east corner and Crown Road)",
              v1_8_to: [
                1495.4,
                344.6
              ],
              v1_8_from: [
                1494.7,
                1026.4
              ],
              v2_5_to: [
                1456.6,
                378.1
              ]
            },
            {
              stretch: "jan",
              host: "V03",
              side: "south",
              offset_m: 6.5,
              from: [
                1574.97,
                797.5
              ],
              to: [
                1279.65,
                748.23
              ],
              via: "structure.mountainRoadTunnel",
              note: "v2.6: the Mountain Road south footway, through the Mountain Road Tunnel as its footway and over the town channel bridge"
            },
            {
              stretch: "jan",
              host: "mountainV2.road",
              side: "left (uphill)",
              offset_m: 2.4,
              from: [
                1278.7,
                714.46
              ],
              to: [
                1359.5,
                661.64
              ],
              note: "v2.6: up Mountain v2 road on its carriageway, left side, to the Hearth terrace (the region draws the road)"
            },
            {
              stretch: "feb",
              host: "mountainV2.road",
              side: "right (uphill)",
              offset_m: 2.4,
              from: [
                1359.58,
                666.44
              ],
              to: [
                1284.37,
                719.65
              ],
              note: "v2.6: back down v2 road right side to the road foot"
            }
          ],
          sharesRule: "a shared stretch is a footway of its host bed: the same alignment at offset_m from the host centreline, the host's solved height at every point (the builder copies it, it does not re-grade), no separate terrain override, retaining or kerb between host and footway; tunnels and bridges on the host carry the footway inside their own section",
          ownTrails: [
            {
              stretch: "apr",
              name: "the Hollow lane (west lane)",
              from: [
                900,
                628
              ],
              to: [
                887,
                815
              ],
              note: "a new trail on the valley floor between Orchard Brook and S4; the April and June stretches walk two lanes 3 m apart"
            },
            {
              stretch: "jun",
              name: "the Hollow lane (east lane)",
              from: [
                903,
                628
              ],
              to: [
                890,
                815
              ]
            },
            {
              stretch: "feb",
              name: "the Foot lane",
              from: [
                1276,
                728
              ],
              to: [
                1235,
                755
              ],
              note: "v2.6: from the road foot west across the Foot terrace to the lake rim trail"
            }
          ],
          crossings: "v2.6: the walk no longer crosses S1 on the Horizon (it walks v2 road beside the course); every other crossing is at grade on a walk, a spur or a road (thresholds) or on a named bridge (the Mountain Road canal bridge, the Hollow Bridge, the Bight Bridge). v2.5: the walk crosses S1 once, at grade, at [1267,842] (v1.9: flush, where S1 stands at the lake terrace height); every other crossing is at grade on a walk, a spur or a road (thresholds) or on a named bridge (the Inlet Footbridge, the Hollow Bridge, the Bight Bridge)",
          retired_v1_6_pts: [
            [
              1330,
              640
            ],
            [
              1255,
              860
            ],
            [
              1130,
              720
            ],
            [
              990,
              780
            ],
            [
              930,
              660
            ],
            [
              880,
              560
            ],
            [
              740,
              400
            ],
            [
              700,
              470
            ],
            [
              760,
              700
            ],
            [
              860,
              980
            ],
            [
              960,
              640
            ],
            [
              893,
              600
            ],
            [
              950,
              1445
            ],
            [
              740,
              1432
            ],
            [
              560,
              1100
            ],
            [
              470,
              1030
            ],
            [
              380,
              800
            ],
            [
              430,
              900
            ],
            [
              560,
              890
            ],
            [
              840,
              880
            ],
            [
              1240,
              1130
            ],
            [
              1230,
              1290
            ],
            [
              1040,
              650
            ],
            [
              900,
              290
            ],
            [
              800,
              300
            ],
            [
              1300,
              260
            ],
            [
              1500,
              340
            ],
            [
              1590,
              700
            ],
            [
              1570,
              940
            ],
            [
              1480,
              1060
            ],
            [
              1475,
              1230
            ],
            [
              1370,
              690
            ],
            [
              1330,
              640
            ]
          ],
          levels: [],
          levelsRule: "levels are extra height pins on the Year Walk's own (unshared) stretches: the builder pins the nearest walk sample to h, so the grade between two pins can use the walk maximum where the ground demands it",
          s1Crossing: null,
          v1_9_edits: [
            {
              was: [
                [
                  885,
                  465
                ],
                [
                  815,
                  470
                ],
                [
                  800,
                  480
                ],
                [
                  755,
                  480
                ],
                [
                  700,
                  470
                ]
              ],
              now: [
                [
                  885,
                  465
                ],
                [
                  872,
                  461.7
                ],
                [
                  857,
                  441.3
                ],
                [
                  789.3,
                  436.5
                ],
                [
                  769.2,
                  446.5
                ],
                [
                  715,
                  446.5
                ],
                [
                  700,
                  470
                ]
              ],
              why: "the March in-leg is the out-leg's north lane (3.5 m, one height) instead of a second line 3-4 eu over the Garden Walk at [802,468]"
            },
            {
              was: [
                [
                  910,
                  565
                ],
                [
                  925,
                  585
                ],
                [
                  905,
                  610
                ]
              ],
              now: [
                [
                  910,
                  565
                ],
                [
                  935,
                  585
                ],
                [
                  905,
                  610
                ]
              ],
              why: "the April lane swings 10 m further east above the Hollow so its 18 eu band-face descent to the S4 footway fits 12 % (148 \u2192 164 m)"
            },
            {
              was: [
                [
                  1330,
                  885
                ],
                [
                  1320,
                  880
                ],
                [
                  1315,
                  865
                ],
                [
                  1320,
                  885
                ],
                [
                  1305,
                  845
                ],
                [
                  1305,
                  875
                ],
                [
                  1300,
                  855
                ],
                [
                  1300,
                  880
                ],
                [
                  1295,
                  860
                ],
                [
                  1295,
                  880
                ],
                [
                  1290,
                  860
                ],
                [
                  1290,
                  885
                ],
                [
                  1285,
                  870
                ],
                [
                  1285,
                  880
                ],
                [
                  1245,
                  855
                ],
                [
                  1250,
                  845
                ]
              ],
              now: [
                [
                  1330,
                  885
                ],
                [
                  1325,
                  880
                ],
                [
                  1325,
                  852
                ],
                [
                  1321.3,
                  848.5
                ],
                [
                  1317.6,
                  852
                ],
                [
                  1317.6,
                  880
                ],
                [
                  1313.9,
                  883.5
                ],
                [
                  1310.2,
                  880
                ],
                [
                  1310.2,
                  852
                ],
                [
                  1306.5,
                  848.5
                ],
                [
                  1302.8,
                  852
                ],
                [
                  1302.8,
                  880
                ],
                [
                  1299.1,
                  883.5
                ],
                [
                  1295.4,
                  880
                ],
                [
                  1295.4,
                  852
                ],
                [
                  1291.7,
                  848.5
                ],
                [
                  1288,
                  852
                ],
                [
                  1288,
                  880
                ],
                [
                  1284.3,
                  883.5
                ],
                [
                  1280.6,
                  880
                ],
                [
                  1280.6,
                  852
                ],
                [
                  1276,
                  846
                ],
                [
                  1267,
                  842
                ],
                [
                  1251,
                  836
                ]
              ],
              why: "the Lakeside switchback: seven 28 m legs on a 7.4 m pitch (walk surfaces 2.2 m apart, shoulders meeting as the walls between legs) at <= 12 %, leaving at grade across S1 at [1267,842] to the rim trail"
            },
            {
              was: [
                [
                  1319.7,
                  258.5
                ],
                [
                  1340.4,
                  281.3
                ],
                [
                  1379.9,
                  294.4
                ],
                [
                  1415.6,
                  307.5
                ],
                [
                  1453.6,
                  323.6
                ],
                [
                  1487.1,
                  341.9
                ],
                [
                  1508.5,
                  367.9
                ],
                [
                  1524.1,
                  404.6
                ],
                [
                  1535.4,
                  441.5
                ],
                [
                  1545.7,
                  481.6
                ],
                [
                  1554.7,
                  520.2
                ]
              ],
              now: [
                [
                  1320.2,
                  260.7
                ],
                [
                  1338.9,
                  296.4
                ],
                [
                  1382.5,
                  312.2
                ],
                [
                  1413.8,
                  330.5
                ],
                [
                  1439.8,
                  360
                ],
                [
                  1467.2,
                  393.5
                ],
                [
                  1494.8,
                  422.8
                ],
                [
                  1521.4,
                  455.9
                ],
                [
                  1546.9,
                  487.5
                ],
                [
                  1553.8,
                  519.4
                ]
              ],
              why: "November's inland verge re-laid 9.5 m inside the re-aligned Drive round the north-east corner"
            },
            {
              was: [
                [
                  1555.2,
                  508.1
                ],
                [
                  1546.3,
                  471.5
                ],
                [
                  1536.1,
                  432.7
                ],
                [
                  1524.2,
                  396
                ],
                [
                  1506.8,
                  358.9
                ],
                [
                  1495.4,
                  344.6
                ],
                [
                  1505.5,
                  343.5
                ],
                [
                  1482.9,
                  377.2
                ],
                [
                  1461,
                  411.8
                ],
                [
                  1449.5,
                  447.4
                ]
              ],
              now: [
                [
                  1555,
                  508.6
                ],
                [
                  1538.9,
                  473.1
                ],
                [
                  1513,
                  440.8
                ],
                [
                  1486.4,
                  408.4
                ],
                [
                  1456.6,
                  378.1
                ],
                [
                  1451.4,
                  371.3
                ],
                [
                  1445.5,
                  364.7
                ],
                [
                  1444.8,
                  372.2
                ],
                [
                  1446.4,
                  383.9
                ],
                [
                  1451.2,
                  425.9
                ],
                [
                  1452.6,
                  447.1
                ]
              ],
              why: "January's inland verge and Crown Road's east verge re-laid on the re-aligned corner and junction"
            },
            {
              was: [
                [
                  1055,
                  710
                ],
                [
                  1100,
                  600
                ],
                [
                  1085,
                  555
                ],
                [
                  1070,
                  535
                ],
                [
                  960,
                  470
                ]
              ],
              now: [
                [
                  1055,
                  710
                ],
                [
                  1052,
                  662
                ],
                [
                  1060,
                  600
                ],
                [
                  1062,
                  540
                ],
                [
                  1060,
                  505
                ],
                [
                  1050,
                  487
                ],
                [
                  1e3,
                  480
                ],
                [
                  960,
                  470
                ]
              ],
              why: "February leaves the Crown's flank for the 45 shelf (September no longer uses it)"
            },
            {
              was: [
                [
                  1010,
                  615
                ],
                [
                  1040,
                  650
                ],
                [
                  1045,
                  550
                ],
                [
                  1055,
                  505
                ],
                [
                  1045,
                  490
                ],
                [
                  995,
                  470
                ],
                [
                  980,
                  415
                ],
                [
                  945,
                  370
                ]
              ],
              now: [
                [
                  1010,
                  615
                ],
                [
                  1032,
                  652
                ],
                [
                  1025,
                  626
                ],
                [
                  1010,
                  604
                ],
                [
                  991.3,
                  592.5
                ],
                [
                  974.3,
                  552.6
                ],
                [
                  956.4,
                  515.5
                ],
                [
                  938.9,
                  476.8
                ],
                [
                  929.5,
                  433.8
                ],
                [
                  927.1,
                  388
                ]
              ],
              why: "September returns from its pad across Green Road and walks its west footway north to the pass (it ran up the shelf beside February, 24 eu apart)"
            },
            {
              was: [
                [
                  1596.9,
                  703.2
                ],
                [
                  1601.5,
                  743.6
                ],
                [
                  1605.7,
                  784.8
                ],
                [
                  1608.1,
                  827.2
                ],
                [
                  1605.7,
                  864.9
                ],
                [
                  1592.8,
                  905.1
                ],
                [
                  1576.5,
                  943.3
                ],
                [
                  1558.6,
                  980.4
                ],
                [
                  1536.4,
                  1014.4
                ],
                [
                  1502.6,
                  1037
                ],
                [
                  1500.3,
                  1038.1
                ]
              ],
              now: [
                [
                  1596.9,
                  703.2
                ],
                [
                  1601.8,
                  746.3
                ],
                [
                  1606,
                  790.3
                ],
                [
                  1608,
                  832
                ],
                [
                  1602.7,
                  877.6
                ],
                [
                  1588.6,
                  919
                ],
                [
                  1572.7,
                  957.4
                ],
                [
                  1553.6,
                  996.8
                ],
                [
                  1523,
                  1027.7
                ],
                [
                  1498.6,
                  1039.6
                ]
              ],
              why: "December's seaward verge re-laid on the Prow cliff drive after its [1540,1000] control moved 3.5 m off the Terraces plots"
            },
            {
              was: [
                [
                  1494.7,
                  1026.4
                ],
                [
                  1527.3,
                  1005.1
                ],
                [
                  1548.8,
                  970.9
                ],
                [
                  1564.7,
                  937.9
                ],
                [
                  1580.6,
                  900.4
                ],
                [
                  1593,
                  862.2
                ],
                [
                  1595,
                  822.6
                ],
                [
                  1592.7,
                  785.9
                ],
                [
                  1588.9,
                  747.7
                ],
                [
                  1584,
                  704.7
                ],
                [
                  1579.2,
                  664
                ],
                [
                  1574.3,
                  626.7
                ],
                [
                  1568.7,
                  586.5
                ],
                [
                  1562.7,
                  548
                ]
              ],
              now: [
                [
                  1493.6,
                  1027.6
                ],
                [
                  1528.6,
                  1007.9
                ],
                [
                  1549.8,
                  975.8
                ],
                [
                  1567.7,
                  936.2
                ],
                [
                  1582.4,
                  898.3
                ],
                [
                  1593.6,
                  859
                ],
                [
                  1594.6,
                  817.6
                ],
                [
                  1591.6,
                  774.9
                ],
                [
                  1587.1,
                  732.1
                ],
                [
                  1582.3,
                  690.2
                ],
                [
                  1576.2,
                  645.9
                ],
                [
                  1570.1,
                  604.3
                ],
                [
                  1561.2,
                  546.4
                ]
              ],
              why: "January's inland verge re-laid on the moved Prow cliff drive (6.5 m, now 6 m clear of Terraces plot 3's margin)"
            },
            {
              was: [
                [
                  1330,
                  640
                ],
                [
                  1355,
                  660
                ],
                [
                  1350,
                  685
                ],
                [
                  1375,
                  690
                ]
              ],
              now: [
                [
                  1330,
                  640
                ],
                [
                  1339,
                  662
                ],
                [
                  1344,
                  684
                ],
                [
                  1375,
                  690
                ]
              ],
              why: "January's first leg leaves the pad west of the Ore Line's approach cut"
            },
            {
              was: [
                [
                  1345,
                  680
                ],
                [
                  1355,
                  675
                ],
                [
                  1330,
                  660
                ],
                [
                  1345,
                  650
                ],
                [
                  1330,
                  640
                ]
              ],
              now: [
                [
                  1340.5,
                  687.5
                ],
                [
                  1335.5,
                  663
                ],
                [
                  1330,
                  640
                ]
              ],
              why: "January's last leg returns as the first leg's west lane (3.5 m), west of the Ore Line"
            }
          ],
          v2_0_edits: [
            {
              was: [
                [
                  1630,
                  855
                ],
                [
                  1620,
                  910
                ],
                [
                  1645,
                  875
                ]
              ],
              now: [
                [
                  1630,
                  855
                ],
                [
                  1626,
                  904
                ],
                [
                  1645,
                  875
                ]
              ],
              why: "v2.0 (D-A8): the November loop's tip on the moved pad's centre"
            }
          ],
          v2_5_pts: [
            [
              1330,
              640
            ],
            [
              1339,
              662
            ],
            [
              1344,
              684
            ],
            [
              1375,
              690
            ],
            [
              1415,
              680
            ],
            [
              1445,
              690
            ],
            [
              1445,
              695
            ],
            [
              1465,
              685
            ],
            [
              1460,
              705
            ],
            [
              1470,
              700
            ],
            [
              1460,
              755
            ],
            [
              1405,
              865
            ],
            [
              1390,
              870
            ],
            [
              1395,
              870
            ],
            [
              1330,
              885
            ],
            [
              1325,
              880
            ],
            [
              1325,
              852
            ],
            [
              1321.3,
              848.5
            ],
            [
              1317.6,
              852
            ],
            [
              1317.6,
              880
            ],
            [
              1313.9,
              883.5
            ],
            [
              1310.2,
              880
            ],
            [
              1310.2,
              852
            ],
            [
              1306.5,
              848.5
            ],
            [
              1302.8,
              852
            ],
            [
              1302.8,
              880
            ],
            [
              1299.1,
              883.5
            ],
            [
              1295.4,
              880
            ],
            [
              1295.4,
              852
            ],
            [
              1291.7,
              848.5
            ],
            [
              1288,
              852
            ],
            [
              1288,
              880
            ],
            [
              1284.3,
              883.5
            ],
            [
              1280.6,
              880
            ],
            [
              1280.6,
              852
            ],
            [
              1276,
              846
            ],
            [
              1267,
              842
            ],
            [
              1251,
              836
            ],
            [
              1250,
              800
            ],
            [
              1235,
              755
            ],
            [
              1145,
              720
            ],
            [
              1100,
              720
            ],
            [
              1080,
              725
            ],
            [
              1055,
              710
            ],
            [
              1052,
              662
            ],
            [
              1060,
              600
            ],
            [
              1062,
              540
            ],
            [
              1060,
              505
            ],
            [
              1050,
              487
            ],
            [
              1e3,
              480
            ],
            [
              960,
              470
            ],
            [
              930,
              480
            ],
            [
              895,
              480
            ],
            [
              905,
              470
            ],
            [
              885,
              465
            ],
            [
              872,
              461.7
            ],
            [
              857,
              441.3
            ],
            [
              789.3,
              436.5
            ],
            [
              769.2,
              446.5
            ],
            [
              715,
              446.5
            ],
            [
              700,
              470
            ],
            [
              715,
              450
            ],
            [
              770,
              450
            ],
            [
              790,
              440
            ],
            [
              855,
              445
            ],
            [
              870,
              465
            ],
            [
              905,
              470
            ],
            [
              895,
              475
            ],
            [
              905,
              475
            ],
            [
              895,
              480
            ],
            [
              915,
              480
            ],
            [
              900,
              500
            ],
            [
              905,
              545
            ],
            [
              910,
              565
            ],
            [
              935,
              585
            ],
            [
              905,
              610
            ],
            [
              900,
              640
            ],
            [
              900,
              628
            ],
            [
              899,
              660
            ],
            [
              898,
              700
            ],
            [
              895,
              740
            ],
            [
              892,
              780
            ],
            [
              887,
              815
            ],
            [
              890,
              870
            ],
            [
              920,
              900
            ],
            [
              915,
              910
            ],
            [
              930,
              995
            ],
            [
              990,
              1010
            ],
            [
              997,
              1006.7
            ],
            [
              977.4,
              967.2
            ],
            [
              966.1,
              929.6
            ],
            [
              957.3,
              889.1
            ],
            [
              953.3,
              848.9
            ],
            [
              956.7,
              808.9
            ],
            [
              962.3,
              768.6
            ],
            [
              969.2,
              725.7
            ],
            [
              975.4,
              689.6
            ],
            [
              986.5,
              649.9
            ],
            [
              994.1,
              612.3
            ],
            [
              970,
              625
            ],
            [
              960,
              640
            ],
            [
              930,
              605
            ],
            [
              910,
              605
            ],
            [
              903,
              628
            ],
            [
              902,
              660
            ],
            [
              901,
              700
            ],
            [
              898,
              740
            ],
            [
              895,
              780
            ],
            [
              890,
              815
            ],
            [
              870,
              835
            ],
            [
              870,
              870
            ],
            [
              885,
              905
            ],
            [
              865,
              920
            ],
            [
              845,
              965
            ],
            [
              865,
              985
            ],
            [
              885,
              1065
            ],
            [
              885,
              1120
            ],
            [
              900,
              1180
            ],
            [
              920,
              1220
            ],
            [
              960,
              1355
            ],
            [
              970,
              1365
            ],
            [
              945,
              1385
            ],
            [
              950,
              1445
            ],
            [
              925,
              1440
            ],
            [
              870,
              1385
            ],
            [
              790,
              1325
            ],
            [
              735,
              1270
            ],
            [
              765,
              1235
            ],
            [
              710,
              1190
            ],
            [
              701.9,
              1195.9
            ],
            [
              679.4,
              1178.1
            ],
            [
              645.9,
              1154.1
            ],
            [
              613.3,
              1133.2
            ],
            [
              579.3,
              1111.5
            ],
            [
              546.3,
              1090
            ],
            [
              512.6,
              1067
            ],
            [
              482.5,
              1044.2
            ],
            [
              454.9,
              1014
            ],
            [
              437.3,
              979.5
            ],
            [
              423.4,
              943.6
            ],
            [
              410.5,
              904
            ],
            [
              425,
              890
            ],
            [
              400,
              745
            ],
            [
              425,
              770
            ],
            [
              440,
              860
            ],
            [
              440,
              870
            ],
            [
              412.6,
              903.3
            ],
            [
              425.5,
              942.8
            ],
            [
              439.3,
              978.6
            ],
            [
              456.7,
              1012.8
            ],
            [
              483.9,
              1042.5
            ],
            [
              513.9,
              1065.2
            ],
            [
              547.5,
              1088.2
            ],
            [
              580.5,
              1109.6
            ],
            [
              614.5,
              1131.3
            ],
            [
              647.1,
              1152.2
            ],
            [
              680.8,
              1176.4
            ],
            [
              703.3,
              1194.2
            ],
            [
              730,
              1180
            ],
            [
              930,
              1265
            ],
            [
              950,
              1265
            ],
            [
              970,
              1245
            ],
            [
              1120,
              1270
            ],
            [
              1160,
              1300
            ],
            [
              1205,
              1290
            ],
            [
              1160,
              1245
            ],
            [
              1120,
              1250
            ],
            [
              1100,
              1245
            ],
            [
              975,
              1155
            ],
            [
              960,
              1130
            ],
            [
              955,
              1095
            ],
            [
              990,
              1010
            ],
            [
              994.6,
              1008.6
            ],
            [
              974.6,
              968.2
            ],
            [
              963.2,
              930.4
            ],
            [
              954.3,
              889.7
            ],
            [
              950.3,
              848.9
            ],
            [
              953.7,
              808.6
            ],
            [
              959.3,
              768.2
            ],
            [
              966.2,
              725.2
            ],
            [
              972.5,
              688.9
            ],
            [
              983.6,
              649
            ],
            [
              991.1,
              612
            ],
            [
              1010,
              615
            ],
            [
              1032,
              652
            ],
            [
              1025,
              626
            ],
            [
              1010,
              604
            ],
            [
              991.3,
              592.5
            ],
            [
              974.3,
              552.6
            ],
            [
              956.4,
              515.5
            ],
            [
              938.9,
              476.8
            ],
            [
              929.5,
              433.8
            ],
            [
              927.1,
              388
            ],
            [
              915,
              370
            ],
            [
              820,
              345
            ],
            [
              790,
              320
            ],
            [
              810,
              305
            ],
            [
              810,
              280
            ],
            [
              815,
              275
            ],
            [
              895,
              275
            ],
            [
              899.2,
              283.6
            ],
            [
              940,
              276.6
            ],
            [
              980,
              268.6
            ],
            [
              1017.4,
              261
            ],
            [
              1056.8,
              253.2
            ],
            [
              1096.5,
              246.3
            ],
            [
              1136.3,
              242.6
            ],
            [
              1178.5,
              242.2
            ],
            [
              1216.7,
              243.5
            ],
            [
              1259.2,
              246.9
            ],
            [
              1297.7,
              252.8
            ],
            [
              1320.2,
              260.7
            ],
            [
              1338.9,
              296.4
            ],
            [
              1382.5,
              312.2
            ],
            [
              1413.8,
              330.5
            ],
            [
              1439.8,
              360
            ],
            [
              1467.2,
              393.5
            ],
            [
              1494.8,
              422.8
            ],
            [
              1521.4,
              455.9
            ],
            [
              1546.9,
              487.5
            ],
            [
              1553.8,
              519.4
            ],
            [
              1561,
              556.4
            ],
            [
              1567.4,
              598.5
            ],
            [
              1572.5,
              635.5
            ],
            [
              1577.9,
              678.4
            ],
            [
              1581,
              705
            ],
            [
              1570,
              665
            ],
            [
              1575,
              670
            ],
            [
              1600,
              665
            ],
            [
              1615,
              725
            ],
            [
              1630,
              745
            ],
            [
              1630,
              855
            ],
            [
              1626,
              904
            ],
            [
              1645,
              875
            ],
            [
              1650,
              855
            ],
            [
              1650,
              745
            ],
            [
              1645,
              725
            ],
            [
              1615,
              685
            ],
            [
              1596.9,
              703.2
            ],
            [
              1601.8,
              746.3
            ],
            [
              1606,
              790.3
            ],
            [
              1608,
              832
            ],
            [
              1602.7,
              877.6
            ],
            [
              1588.6,
              919
            ],
            [
              1572.7,
              957.4
            ],
            [
              1553.6,
              996.8
            ],
            [
              1523,
              1027.7
            ],
            [
              1498.6,
              1039.6
            ],
            [
              1510,
              1050
            ],
            [
              1510,
              1100
            ],
            [
              1525,
              1175
            ],
            [
              1500,
              1200
            ],
            [
              1490,
              1230
            ],
            [
              1500,
              1200
            ],
            [
              1545,
              1160
            ],
            [
              1535,
              1120
            ],
            [
              1540,
              1085
            ],
            [
              1530,
              1055
            ],
            [
              1505,
              1015
            ],
            [
              1495,
              1015
            ],
            [
              1490,
              1020
            ],
            [
              1493.6,
              1027.6
            ],
            [
              1528.6,
              1007.9
            ],
            [
              1549.8,
              975.8
            ],
            [
              1567.7,
              936.2
            ],
            [
              1582.4,
              898.3
            ],
            [
              1593.6,
              859
            ],
            [
              1594.6,
              817.6
            ],
            [
              1591.6,
              774.9
            ],
            [
              1587.1,
              732.1
            ],
            [
              1582.3,
              690.2
            ],
            [
              1576.2,
              645.9
            ],
            [
              1570.1,
              604.3
            ],
            [
              1561.2,
              546.4
            ],
            [
              1555,
              508.6
            ],
            [
              1538.9,
              473.1
            ],
            [
              1513,
              440.8
            ],
            [
              1486.4,
              408.4
            ],
            [
              1456.6,
              378.1
            ],
            [
              1451.4,
              371.3
            ],
            [
              1445.5,
              364.7
            ],
            [
              1444.8,
              372.2
            ],
            [
              1446.4,
              383.9
            ],
            [
              1451.2,
              425.9
            ],
            [
              1452.6,
              447.1
            ],
            [
              1452,
              485.4
            ],
            [
              1449.1,
              529
            ],
            [
              1433.5,
              565.6
            ],
            [
              1417,
              599.6
            ],
            [
              1400.2,
              635.7
            ],
            [
              1383.7,
              674.4
            ],
            [
              1376.8,
              690.6
            ],
            [
              1340.5,
              687.5
            ],
            [
              1335.5,
              663
            ],
            [
              1330,
              640
            ]
          ],
          v2_5_shares: [
            {
              stretch: "feb",
              host: "walk lakerim",
              via: "structure.inletFootbridge",
              side: "on the rim trail",
              offset_m: 0,
              from: [
                1251,
                836
              ],
              to: [
                1100,
                721
              ],
              note: "the February stretch walks the lake rim trail round the east and north shore and crosses the upper river on the Inlet Footbridge; one bed, the rim trail's",
              v1_8_from: [
                1250,
                800
              ]
            },
            {
              stretch: "may",
              host: "VG",
              side: "west",
              offset_m: 6.5,
              from: [
                997,
                1006.7
              ],
              to: [
                994.1,
                612.3
              ],
              note: "Green Road's west footway"
            },
            {
              stretch: "sep",
              host: "VG",
              side: "west",
              offset_m: 9.5,
              from: [
                994.6,
                1008.6
              ],
              to: [
                991.1,
                612
              ],
              note: "the same footway's outer lane"
            },
            {
              stretch: "jul",
              host: "V01",
              via: "structure.bightBridge",
              side: "lagoon (north-east)",
              offset_m: 5.2,
              from: [
                701.9,
                1195.9
              ],
              to: [
                410.5,
                904
              ],
              note: "the Bight Bridge's lagoon-side footway and the Drive's verge down the Flats arm; deck height 12 on the bridge"
            },
            {
              stretch: "aug",
              host: "V01",
              via: "structure.bightBridge",
              side: "lagoon (north-east)",
              offset_m: 7.4,
              from: [
                412.6,
                903.3
              ],
              to: [
                703.3,
                1194.2
              ],
              note: "the same footway's outer lane, walked back east a month later"
            },
            {
              stretch: "nov",
              host: "V01",
              side: "seaward (north)",
              offset_m: 6.5,
              from: [
                899.2,
                283.6
              ],
              to: [
                1320.2,
                260.7
              ],
              note: "the north coast drive's seaward verge",
              v1_8_to: [
                1319.7,
                258.5
              ]
            },
            {
              stretch: "nov",
              host: "V01",
              side: "inland",
              offset_m: 9.5,
              from: [
                1338.9,
                296.4
              ],
              to: [
                1581,
                705
              ],
              note: "crosses the Drive at grade at [1330,270] and takes the inland verge round the north-east corner (the seaward verge there is off the outline) up onto the Prow",
              v1_8_from: [
                1340.4,
                281.3
              ]
            },
            {
              stretch: "dec",
              host: "V01",
              side: "seaward (east)",
              offset_m: 6.5,
              from: [
                1596.9,
                703.2
              ],
              to: [
                1498.6,
                1039.6
              ],
              note: "down the Prow cliff drive's seaward verge to the harbour",
              v1_8_from: [
                1596.9,
                703.2
              ],
              v1_8_to: [
                1500.3,
                1038.1
              ]
            },
            {
              stretch: "jan",
              host: "V01",
              side: "inland (west)",
              offset_m: 6.5,
              from: [
                1493.6,
                1027.6
              ],
              to: [
                1456.6,
                378.1
              ],
              note: "up the Prow cliff drive's inland verge, through the Prow Tunnel as its footway",
              v1_8_to: [
                1495.4,
                344.6
              ],
              v1_8_from: [
                1494.7,
                1026.4
              ]
            },
            {
              stretch: "jan",
              host: "V02",
              side: "east",
              offset_m: 6.5,
              from: [
                1446.4,
                383.9
              ],
              to: [
                1376.8,
                690.6
              ],
              note: "up Crown Road's east verge, through the Shoulder Tunnel as its footway, to the turning circle",
              v1_8_from: [
                1505.5,
                343.5
              ]
            },
            {
              stretch: "apr",
              host: "S4",
              side: "east",
              offset_m: 6,
              from: [
                905,
                610
              ],
              to: [
                899,
                660
              ],
              note: "v1.9: the April lane is S4's east footway through the Hollow neck, at S4's height"
            },
            {
              stretch: "jun",
              host: "S4",
              side: "east",
              offset_m: 8,
              from: [
                903,
                628
              ],
              to: [
                902,
                660
              ],
              note: "v1.9: the June lane, 3 m further out on the same footway"
            },
            {
              stretch: "sep",
              host: "VG",
              side: "west",
              offset_m: 6.5,
              from: [
                991.3,
                592.5
              ],
              to: [
                927.1,
                388
              ],
              note: "v1.9: Green Road's west footway from the September pad's return to the north pass"
            }
          ],
          v2_5_levels: [
            {
              xy: [
                1350,
                687
              ],
              h: 110,
              r: 9,
              why: "the south portal forecourt: both January legs cross the ORE station's link walk (110) there at its height",
              v1_9_first_xy: [
                1358,
                685
              ]
            }
          ],
          v2_5_ownTrails: [
            {
              stretch: "apr",
              name: "the Hollow lane (west lane)",
              from: [
                900,
                628
              ],
              to: [
                887,
                815
              ],
              note: "a new trail on the valley floor between Orchard Brook and S4; the April and June stretches walk two lanes 3 m apart"
            },
            {
              stretch: "jun",
              name: "the Hollow lane (east lane)",
              from: [
                903,
                628
              ],
              to: [
                890,
                815
              ]
            },
            {
              stretch: "feb",
              name: "the Lakeside zig-zag",
              from: [
                1330,
                885
              ],
              to: [
                1285,
                875
              ],
              note: "from the Shoulder's south-west corner down to the lake terrace: seven short switchback legs on the band face (x 1285\u20131330, z 845\u2013885), outside S1's loop; built as a ramp with retaining walls between legs (the only step-free way off the Shoulder that does not cross S1)"
            }
          ],
          v2_5_s1Crossing: [
            1267,
            842
          ]
        },
        stretch: {
          rule: "a month is the stretch of the Year Walk from the previous station to its own; one paving stone per day (28\u201331); every seventh stone a flagstone with a lantern post; the camp stands on today\u2019s stone; scheduled items stand on their stone as explicit markers (slip, pennant, stake, chairs); the next stretch is stakes and string until its month begins",
          stone_m: [
            2.4,
            1.6
          ],
          flagstone_m: [
            3.2,
            2.4
          ],
          markers: [
            "bill slip on a post (name, amount)",
            "payday pennant",
            "task or plan-step stake (card name)",
            "goal-deadline stake with ribbon",
            "two chairs (Sitdown)",
            "station gate ajar (Chapter close due)"
          ]
        },
        station: {
          pad_m: [
            36,
            14
          ],
          bed_m: [
            3,
            2
          ],
          bedsPerRow: 10,
          rows: 2,
          identity: "site(monthOrdinal) = station(month) + bed(yearIndex); appending never moves a bed",
          maxHeight: "a bench (0.85 eu)",
          waymark: "post with the month name and the year count; lit at the camp",
          padRotRule: "v2.0: a station may carry pad_rot_deg (default 0; 90 turns the 36 m side north-south); the builder lays the pad and its beds rotated"
        },
        camp: {
          rule: "the current month\u2019s bed: lit waymark + tent card; the camp card docks to it on the map",
          moves: "on Chapter/books close; 1 s card animation, a cut under reduced motion"
        },
        eraGates: {
          rule: "a gate (two posts + lantern) on the Year Walk at the bed where the era ended; lantern from the existing finish rules"
        },
        homestead: {
          where: "the land around Our home in Little Harbour: the yard behind the house, the lane down to the quay, the household\u2019s footbridge over the town channel, the Boathouse dock",
          centre: [
            1520,
            1190
          ],
          sites: [
            {
              id: "home",
              label: "the home anchor",
              note: "Our home; never wears, never moves"
            },
            {
              id: "kitchenGarden",
              label: "the kitchen garden",
              xy: [
                1535,
                1160
              ],
              category: "food",
              maturity: [
                "none",
                "trace",
                "cluster",
                "established",
                "district"
              ],
              rule: "qualifying weeks in the trailing 24; one credit per week"
            },
            {
              id: "landing",
              label: "the landing (cargo)",
              xy: [
                1320,
                1322
              ],
              category: "income",
              note: "cargo on the Boathouse dock when income arrives; never a beauty score"
            },
            {
              id: "workbench",
              label: "the workbench",
              xy: [
                1545,
                1200
              ],
              category: "making",
              note: "cosmetic; fired pieces as today"
            },
            {
              id: "pavilion",
              label: "a place in the making \u2192 the ready pavilion",
              xy: [
                1510,
                1215
              ],
              category: "goal",
              rule: "stakes while backing; finished at 100 % backed; a memory only when a kept memory exists"
            },
            {
              id: "reserveBasin",
              label: "the reserve basin",
              note: "= L01 [1172,912]; using the buffer shows as water, never damage"
            },
            {
              id: "timberCrossing",
              label: "the timber crossing",
              xy: [
                1500,
                1250
              ],
              category: "connection",
              note: "the household\u2019s footbridge on the lane over the town channel; the one site with physical wear (D19, D24)"
            }
          ]
        },
        kittyPlaza: {
          xy: [
            1440,
            1145
          ],
          max: 6,
          note: "Kitty Bank sculptures, step 0\u201310, beside the Fund bank"
        },
        lod: {
          L0: {
            tris: [
              4e4,
              25e3
            ],
            drawCalls: [
              60,
              40
            ],
            coastVerts: 400,
            heightfieldDecimation: 8
          },
          L1: {
            tris: [
              8e4,
              45e3
            ]
          },
          note: "[full, lite]; L2\u2013L3 are the world\u2019s budgets (CONTRACT \xA76)"
        },
        camera: {
          tiers: {
            sky: "the island\u2019s diagonal",
            region: 250,
            stop: 80,
            upClose: 25
          },
          handoff: "below upClose the target snaps to the nearest apron or bed and the controller hands to the world\u2019s Look camera, then Walk; one orbit controller, same north",
          fallback: "the #543 cloud crossfade for reduced motion, no WebGL, or a tier load over 400 ms"
        },
        focus: {
          fields: [
            "target xy",
            "tier",
            "radius",
            "heading",
            "period (day/week/month/era) + date",
            "selected object",
            "active filters",
            "unsent draft"
          ],
          rule: "tools open over it and restore it exactly; the world always shows now (entering from a past month lands at that bed with a banner)"
        },
        retired: [
          "weather-from-money (bills\u2192clouds, storm, mist, payday sunrise) \u2192 explicit strip markers (D18)",
          "grow.ts landform generation (coast, coves, noise)",
          "the harbour islet miniature",
          "past eras as separate islands"
        ]
      },
      names: {
        island: "The Horizon",
        landformRule: "polygons are clipped to the island outline; the Hollow, the Stillwater terrace and the Cup are cut INTO the Shoulder (their own band wins inside them); elsewhere where polygons overlap the innermost (higher) band wins; band edges blend over 60 m; a bed (road, skate, rail, walk) overrides the bands within its profile width + 15 m each side and holds its own grade limits, so band steps never appear as cliffs on a route",
        districts: [
          {
            id: "harbour",
            neighbourhood: "harbour",
            note: "town + the Terraces + the town quay"
          },
          {
            id: "landing",
            neighbourhood: "landing",
            note: "Long Sands, the Landing quay, the Boathouse, Campfire, Tideline park"
          },
          {
            id: "reach",
            neighbourhood: "landing",
            note: "the wetland and the river mouth"
          },
          {
            id: "green",
            neighbourhood: "lakeside",
            note: "the Green and the Glasshouse steps"
          },
          {
            id: "hollow",
            neighbourhood: "hollow",
            note: "the orchard bowl, the Adit"
          },
          {
            id: "scholars",
            neighbourhood: "scholars",
            note: "the woodland rise and the north pass"
          },
          {
            id: "flats",
            neighbourhood: "flats",
            note: "the arm: strip, hangar, balloon, the Wash"
          },
          {
            id: "bight",
            neighbourhood: "flats",
            note: "the lagoon, the sandbar, Bight Shore, the Bight Bridge"
          },
          {
            id: "lakeside",
            neighbourhood: "lakeside",
            note: "Stillwater, the dam, L01"
          },
          {
            id: "notch",
            neighbourhood: "lakeside",
            note: "the gorge, the High Span"
          },
          {
            id: "prow",
            neighbourhood: "crown",
            note: "the cliffs, the zip tower, the Sea Door"
          },
          {
            id: "crown",
            neighbourhood: "crown",
            note: "the Shoulder and the summit; the Undercroft is its underground child district"
          },
          {
            id: "offshore",
            neighbourhood: null,
            note: "the Lamp, the Needle's Eye, the Stacks, the Wreck; the sky ring streams by the districts beneath it"
          }
        ],
        landforms: [
          "Little Harbour",
          "Long Sands",
          "the Landing",
          "the Reach",
          "the Green",
          "the Hollow",
          "Scholars' Edge",
          "the Flats",
          "the Bight",
          "Stillwater",
          "the Cup",
          "the Notch",
          "the Prow",
          "the Shoulder",
          "the Crown",
          "the Undercroft",
          "the Lamp",
          "the Needle's Eye",
          "the Stacks",
          "the Wreck",
          "the Terraces",
          "Bight Shore"
        ],
        roads: [
          "Horizon Drive",
          "Green Road",
          "Crown Road",
          "Bight Shore spur"
        ],
        skate: [
          "Summit to Sea",
          "the Wash Run",
          "Town Weave",
          "Hollow Line",
          "Tideline park"
        ],
        underground: [
          "the Adit",
          "the Throat",
          "Dam Gallery",
          "the Sea Door",
          "Ore Line",
          "Lantern Cave",
          "the Deep",
          "Bell Gallery"
        ],
        structures: [
          "High Span",
          "Quay Bridge",
          "Bight Bridge",
          "Hollow Bridge",
          "Apron Bridge",
          "Inlet Footbridge",
          "Reach Footbridge",
          "Dune Culvert",
          "Prow Tunnel",
          "Shoulder Tunnel",
          "Lantern Row",
          "the Landing quay",
          "the town quay",
          "the Glasshouse steps",
          "the Sea Stair",
          "Crown station",
          "the South Portal",
          "the Sea Passage",
          "the Steps"
        ],
        water: [
          "Orchard Brook",
          "the Wash (streambed)",
          "the Bight sandbar",
          "the Steps"
        ],
        idRule: "ids are camelCase keys in this manifest (e.g. highSpan, plot.terraces.1); display names above are their labels; STYLE and the guide map use labels, code uses ids",
        journey: [
          "the Year Walk",
          "the camp",
          "the homestead",
          "the kitchen garden",
          "the landing",
          "the workbench",
          "the ready pavilion",
          "the reserve basin",
          "the timber crossing",
          "the home anchor",
          "the Kitty plaza",
          "era gates"
        ],
        pastimes: [
          "Lantern Hunt",
          "Summit to Sea",
          "Ring Run",
          "Drop Zone",
          "Mail Day",
          "River Run",
          "Deep Run",
          "Nine Baskets",
          "Bocce",
          "Ring Race",
          "Ore Line ride",
          "the Sketchbook",
          "Campfire",
          "Winter (skating, sledding)"
        ]
      },
      scale: {
        factor: 1,
        status: "confirmed by Jonathan 2026-09-25",
        rule: "engine_units = concept_metres \xD7 factor, applied to x, y and height alike; speeds in m/s are engine units per second",
        why: "Jonathan selected full concept scale. Journey estimates use factor 1.0; the 0.6 table remains a comparison scenario, not the active scale.",
        decision: "D13 \u2014 Jonathan: \u201C1.0 \u2014 full concept scale\u201D, confirmed 2026-09-25; applies to x, y and height."
      },
      crossingRule: "crossings contains physical resolutions only (over, under, threshold) at authored point, corridor or area locations; Pass 1 resolves these into numeric WorldDefinition geometry. District metadata belongs to its crossing. routePairNotes preserves coordination evidence for Pass 1 verification, including shared plan points; it never exempts a computed intersection from the crossing register.. v1.8: every computed intersection of the Stage A build has a row; kind names the proof class (crossing, junction, sharedStretch, footway, waterBody, waterConfluence, modeTransfer) and resolution stays over / under / threshold; rows with source 'bake v1.8' are the design lead's acceptance of the computed resolution and never create a register pad or a dismount threshold; reserved names the decision a row waits on",
      routePairNotes: [
        {
          a: "ORE",
          b: "Crown Road",
          note: "the South Portal [1345,680] is 29 m from the turning circle; a path links them",
          kind: "nearby-endpoints",
          sharedPlanPoints: [],
          verification: "Verify the South Portal link against the built Crown Road turning circle; register any actual intersection found in Pass 1."
        },
        {
          a: "DEEP_RUN",
          b: "ORE",
          note: "the Sea Passage leaves the Deep east; the rail leaves north-east and climbs; separated by 20 m of rock",
          kind: "shared-plan-point",
          sharedPlanPoints: [
            [
              1300,
              420
            ]
          ],
          verification: "Both centrelines include [1300,420] at the Deep. The original 20 m rock-separation note describes the departing passages, not proven clearance at this shared point. Pass 1 must compute their vertical profiles and register and build every actual crossing; this note is not an exclusion."
        },
        {
          a: "walk reach",
          b: "VG",
          kind: "retired register row (v1.8)",
          verification: "the Reach walk runs under the High Span gallery beside the river; the two centrelines never cross in plan (the High Span's walk-level gallery is the Reach walk's own stretch)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk reach",
            b: "VG",
            at: [
              1240,
              1110
            ],
            resolution: "under",
            structure: "highSpan (water level)"
          }
        },
        {
          a: "S1 finish",
          b: "V01",
          kind: "retired register row (v1.8)",
          verification: "S1 finishes on the quay without crossing V01 near [1270,1330]; S1 \xD7 V01 has no plan intersection in the v1.8 build",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S1 finish",
            b: "V01",
            at: [
              1270,
              1330
            ],
            resolution: "threshold",
            note: "kerb-separated; the run-out ends 20 m before the Long Sands road"
          }
        },
        {
          a: "S2",
          b: "V01",
          kind: "retired register row (v1.8)",
          verification: "S2 is a lane of the Bight Bridge deck (row 13); it passes 17.9 m from the [660,1170] dismount, which does not exist (T2 D-3: S2 cannot descend from the Wash to the deck at 18 %; Jonathan decides)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S2",
            b: "V01",
            at: [
              660,
              1170
            ],
            resolution: "threshold",
            note: "after the bridge S2 leaves the road at a dismount marker onto its own bed 18\u201345 m from the carriageway"
          }
        },
        {
          a: "S3",
          b: "town quay",
          kind: "retired register row (v1.8)",
          verification: "S3 runs beside the town quay, never across it (T0 request 4: S3 at [1433,1298] should come down \u2264 3.5 eu)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S3",
            b: "town quay",
            at: [
              1453,
              1277
            ],
            resolution: "threshold",
            note: "quayWest: park here; Lantern Row is pedestrian"
          }
        },
        {
          a: "S3",
          b: "walk dune",
          kind: "retired register row (v1.8)",
          verification: '"none": S3 and the dune walk do not cross',
          sharedPlanPoints: [],
          retiredRow: {
            a: "S3",
            b: "walk dune",
            at: "none",
            resolution: "over",
            note: "S3's boardwalk runs the dune crest; the dune walk runs the beach foot 30 m south; they never meet"
          }
        },
        {
          a: "S3",
          b: "V01",
          kind: "retired register row (v1.8)",
          verification: "S3 never reaches [1480,1050]; it meets V01 only on the river-mouth bridge decks ([1350,1345], [1322,1372]), carried below as rows accepted from the bake: a threshold there needs a widened, guarded deck (a register pad would stand in the river)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S3",
            b: "V01",
            at: [
              1480,
              1050
            ],
            resolution: "threshold",
            note: "the upper-street spur end is the board pick-up"
          }
        },
        {
          a: "ZIP",
          b: "town",
          kind: "retired register row (v1.8)",
          verification: "an area rule, not an intersection: the zip line passes over the town's roofs with \u2265 12 eu clearance (checked as cable.ZIP.roofs)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "ZIP",
            b: "town",
            at: "overhead",
            resolution: "over",
            note: "\u2265 12 m above every roof, sag included; the line skirts the town's west edge"
          }
        },
        {
          a: "S4",
          b: "spur studio",
          kind: "retired register row (v1.8)",
          verification: "S4 starts at [1000,520]; it never meets the Studio spur at [974,540] (the spur meets VG there, listed below)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S4",
            b: "spur studio",
            at: [
              974,
              540
            ],
            resolution: "threshold",
            note: "S4 starts at the studio terrace; the spur ends there"
          }
        },
        {
          a: "plane",
          b: "everything",
          kind: "retired register row (v1.8)",
          verification: "an area rule, not an intersection: planes fly over everything under the sky ceiling",
          sharedPlanPoints: [],
          retiredRow: {
            a: "plane",
            b: "everything",
            at: "sky",
            resolution: "over",
            note: "ceiling 300 m; no landing on a neighbourhood"
          }
        },
        {
          a: "DEEP_RUN",
          b: "walk prow",
          kind: "retired register row (v1.9)",
          verification: "the Prow walk (v1.9) keeps to the Prow top east of V01's cutting and no longer crosses the Deep run's line at [1611,710]",
          sharedPlanPoints: [],
          retiredRow: {
            a: "DEEP_RUN",
            b: "walk prow",
            at: [
              1611,
              710
            ],
            resolution: "under",
            movedFrom: [
              1605,
              700
            ],
            note: "the Deep run passes under the Prow walk 11 m east of the v1.7 point",
            kind: "crossing"
          }
        },
        {
          a: "S2",
          b: "walk bightPier",
          kind: "retired register row (v1.9)",
          verification: "the pier walk (v1.9) ends at the Flats' cliff top; S2 now passes under the Bight pier stair (a row accepted from the v1.9 bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S2",
            b: "walk bightPier",
            at: [
              509,
              896
            ],
            resolution: "threshold",
            note: "the pier walk crosses the Wash Run bed at a marked gap",
            kind: "crossing"
          }
        },
        {
          a: "walk bightPier",
          b: "water wash",
          kind: "retired register row (v1.9)",
          verification: "the pier walk (v1.9) ends at the Flats' cliff top; the wash footbridge is retired and the Bight pier stair crosses the dry wash mouth",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk bightPier",
            b: "water wash",
            at: [
              514,
              895
            ],
            resolution: "over",
            structure: "a plank footbridge at the Wash mouth",
            kind: "crossing"
          }
        },
        {
          a: "damGallery.flight.1",
          b: "damGallery.exit",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "damGallery.flight.1",
            b: "damGallery.exit",
            at: [
              1165,
              898
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 7 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "damGallery.flight.1",
          b: "water.stillwater",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "damGallery.flight.1",
            b: "water.stillwater",
            at: [
              1165,
              898
            ],
            resolution: "threshold",
            kind: "waterBody",
            source: "bake v1.8",
            note: "bed inside the water outline below its surface: a bridge, causeway or re-route is owed (diagnostic)"
          }
        },
        {
          a: "damGallery.flight.2",
          b: "damGallery.exit",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "damGallery.flight.2",
            b: "damGallery.exit",
            at: [
              1165,
              886
            ],
            resolution: "threshold",
            kind: "sharedStretch",
            source: "bake v1.8",
            note: "shared stretch 10 eu at one height"
          }
        },
        {
          a: "damGallery.flight.2",
          b: "water.stillwater",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "damGallery.flight.2",
            b: "water.stillwater",
            at: [
              1165,
              892
            ],
            resolution: "threshold",
            kind: "waterBody",
            source: "bake v1.8",
            note: "bed inside the water outline below its surface: a bridge, causeway or re-route is owed (diagnostic)"
          }
        },
        {
          a: "highSpan.overlook",
          b: "river lower",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "highSpan.overlook",
            b: "river lower",
            at: [
              1251.2,
              1143.3
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: "at-grade meeting 2.1 eu apart: regrade owed"
          }
        },
        {
          a: "jetty.lamp",
          b: "lampGallery.ramp",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "jetty.lamp",
            b: "lampGallery.ramp",
            at: [
              540,
              1250
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 9.6 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "jetty.lamp",
          b: "lampGallery.ramp",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "jetty.lamp",
            b: "lampGallery.ramp",
            at: [
              540,
              1250
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 19.2 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "lampGallery.ramp",
          b: "FERRY",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "lampGallery.ramp",
            b: "FERRY",
            at: [
              510.4,
              1224.4
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 12.8 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "lampGallery.ramp",
          b: "FERRY",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "lampGallery.ramp",
            b: "FERRY",
            at: [
              510.4,
              1224.4
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 22.4 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "lampGallery.ramp",
          b: "FERRY",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "lampGallery.ramp",
            b: "FERRY",
            at: [
              546.1,
              1190.6
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "lampGallery.ramp",
          b: "lampGallery.stair",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "lampGallery.ramp",
            b: "lampGallery.stair",
            at: [
              540,
              1250
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 9.6 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "lampGallery.ramp",
          b: "lampGallery.stair",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "lampGallery.ramp",
            b: "lampGallery.stair",
            at: [
              540,
              1250
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 19.2 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "river lower",
          b: "reachChannel.2",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "river lower",
            b: "reachChannel.2",
            at: [
              1320,
              1276
            ],
            resolution: "threshold",
            kind: "waterConfluence",
            source: "bake v1.8",
            note: "one waterway"
          }
        },
        {
          a: "S1",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S1",
            b: "yearWalk",
            at: [
              1254.7,
              862
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "V01",
          b: "S3",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V01",
            b: "S3",
            at: [
              1321.9,
              1372.3
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "V01",
          b: "S3",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V01",
            b: "S3",
            at: [
              1350,
              1345
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "V01",
          b: "V02",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V01",
            b: "V02",
            at: [
              1500,
              340
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "V01",
          b: "walk prow",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V01",
            b: "walk prow",
            at: [
              1580.1,
              620.7
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 11.5 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "VG",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "VG",
            b: "yearWalk",
            at: [
              933,
              369.1
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 5.5 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk bight",
          b: "plot.bight.3.service",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk bight",
            b: "plot.bight.3.service",
            at: [
              729.5,
              1056.6
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "walk bight",
          b: "plot.bight.4.service",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk bight",
            b: "plot.bight.4.service",
            at: [
              706.4,
              1131.1
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "walk bightPier",
          b: "FERRY",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk bightPier",
            b: "FERRY",
            at: [
              560,
              890
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "walk bightPier",
          b: "ferry.bight",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk bightPier",
            b: "ferry.bight",
            at: [
              560,
              890
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "walk crownFromGondola",
          b: "V02",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "V02",
            at: [
              1443.1,
              526.5
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk dune",
          b: "zipLanding.ramp",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk dune",
            b: "zipLanding.ramp",
            at: [
              1079.2,
              1469
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 6.6 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk dune",
          b: "zipLanding.stair",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk dune",
            b: "zipLanding.stair",
            at: [
              1144.1,
              1458.9
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 2.7 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk garden",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk garden",
            b: "yearWalk",
            at: [
              807.5,
              474.1
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "under by 3.9 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk lakerim",
          b: "damGallery.flight.1",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk lakerim",
            b: "damGallery.flight.1",
            at: [
              1165,
              905.2
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "walk lakerim",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk lakerim",
            b: "yearWalk",
            at: [
              1244.4,
              852.1
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: "at-grade meeting 2.3 eu apart: regrade owed"
          }
        },
        {
          a: "walk lakerim",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk lakerim",
            b: "yearWalk",
            at: [
              1244.5,
              851.9
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: "at-grade meeting 2.3 eu apart: regrade owed"
          }
        },
        {
          a: "walk prow",
          b: "seaStair",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "seaStair",
            at: [
              1620,
              760
            ],
            resolution: "threshold",
            kind: "junction",
            source: "bake v1.8",
            note: "flush path junction: no marker, no mode change"
          }
        },
        {
          a: "walk prow",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "yearWalk",
            at: [
              1567.7,
              600.9
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 11.2 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk prow",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "yearWalk",
            at: [
              1571.6,
              606.8
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 11.3 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk prow",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "yearWalk",
            at: [
              1591.5,
              908.6
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 33.9 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk prow",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "yearWalk",
            at: [
              1598.3,
              664
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 10.8 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk prow",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "yearWalk",
            at: [
              1605.7,
              689.4
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 13.6 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk prow",
          b: "yearWalk",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "yearWalk",
            at: [
              1607.5,
              847.7
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 26.7 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "walk prow",
          b: "ZIP",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk prow",
            b: "ZIP",
            at: [
              1597.3,
              661.1
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "yearWalk",
          b: "ORE",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "yearWalk",
            b: "ORE",
            at: [
              1345,
              680
            ],
            resolution: "threshold",
            kind: "modeTransfer",
            source: "bake v1.8",
            note: "boarding threshold; mover pending"
          }
        },
        {
          a: "yearWalk",
          b: "ORE",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "yearWalk",
            b: "ORE",
            at: [
              1349.6,
              671.6
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "yearWalk",
          b: "ORE",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "yearWalk",
            b: "ORE",
            at: [
              1355.1,
              661.5
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "yearWalk",
          b: "southPortal.link",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "yearWalk",
            b: "southPortal.link",
            at: [
              1345,
              680
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 3 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "yearWalk",
          b: "southPortal.link",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "yearWalk",
            b: "southPortal.link",
            at: [
              1347.7,
              681.4
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 2.8 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "yearWalk",
          b: "southPortal.link",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "yearWalk",
            b: "southPortal.link",
            at: [
              1349.7,
              682.4
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 2.9 eu: a named structure (footbridge, deck or passage) is owed"
          }
        },
        {
          a: "ZIP",
          b: "river lower",
          kind: "retired register row (v1.9)",
          verification: "no plan intersection of this pair here in the v1.9 build (or a duplicate of a row that matches)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "ZIP",
            b: "river lower",
            at: [
              1273.1,
              1201.5
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: ""
          }
        },
        {
          a: "S2",
          b: "yearWalk",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A1): S2 comes onto the deck's lagoon lane outboard of the Year Walk footways (+10.6 against +5.2/+7.4); they run side by side and never meet",
          sharedPlanPoints: [],
          retiredRow: {
            a: "S2",
            b: "yearWalk",
            at: [
              468.2,
              1026.4
            ],
            resolution: "threshold",
            kind: "crossing",
            source: "bake v1.8",
            note: "at-grade meeting 0.7 eu apart: regrade owed"
          }
        },
        {
          a: "V02",
          b: "walk crownFromGondola",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V02",
            b: "walk crownFromGondola",
            at: [
              1412.8,
              593.4
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "V02",
          b: "walk crownFromGondola",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V02",
            b: "walk crownFromGondola",
            at: [
              1443.1,
              526.5
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crown",
          b: "walk crownFromGondola",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crown",
            b: "walk crownFromGondola",
            at: [
              1376,
              574.7
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 19.8 eu: a named structure (footbridge, deck or passage) is owed; RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "crownLaunch.stair",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "crownLaunch.stair",
            at: [
              1320.4,
              479.2
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "DEEP_RUN",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "DEEP_RUN",
            at: [
              1341.3,
              445.2
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "DEEP_RUN",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "DEEP_RUN",
            at: [
              1437.6,
              512.9
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "ORE",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "ORE",
            at: [
              1334.3,
              454.3
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "ORE",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "ORE",
            at: [
              1369.1,
              568.4
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "stepsPortage",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "stepsPortage",
            at: [
              1332.3,
              457.5
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "over by 117.5 eu: a named structure (footbridge, deck or passage) is owed; RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "underground.bellGallery",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "underground.bellGallery",
            at: [
              1315.5,
              489.2
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "yearWalk",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "yearWalk",
            at: [
              1422.1,
              589.2
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crownFromGondola",
          b: "yearWalk",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-A3): the station walk is a 43 m leg [1335,535] \u2192 [1310,500]; the v1.9 switchback that met this route here goes (re-check on the next bake)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crownFromGondola",
            b: "yearWalk",
            at: [
              1446.4,
              537.2
            ],
            resolution: "over",
            kind: "crossing",
            source: "bake v1.8",
            note: "RESERVED R-A3: waits on the gondola top station"
          }
        },
        {
          a: "walk crown",
          b: "yearWalk",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crown",
            b: "yearWalk",
            at: [
              1371.2,
              689.7
            ],
            resolution: "threshold",
            kind: "junction",
            source: "bake v1.8",
            note: "flush path junction: no marker, no mode change"
          }
        },
        {
          a: "walk crown",
          b: "G1",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crown",
            b: "G1",
            at: [
              1375.1,
              688.6
            ],
            resolution: "under",
            kind: "crossing",
            source: "bake v1.8",
            note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
            v1_9_at: [
              1388.3,
              685.3
            ]
          }
        },
        {
          a: "walk crown",
          b: "southPortal.link",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "walk crown",
            b: "southPortal.link",
            at: [
              1370,
              690
            ],
            resolution: "threshold",
            kind: "junction",
            source: "bake v1.8",
            note: "flush path junction: no marker, no mode change"
          }
        },
        {
          a: "V02",
          b: "walk crown",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-C7): the Crown walk's own bed starts at [1417.7,677.4]; from the turning circle to there it is the Year Walk's January lane (that lane's rows stand)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "V02",
            b: "walk crown",
            at: [
              1370,
              690
            ],
            resolution: "threshold",
            note: "turning circle is the wheels' end; the Crown walk begins",
            kind: "crossing"
          }
        },
        {
          a: "marketRamp",
          b: "host.home.approach",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-C11, Jonathan 2026-09-27): the market stair is stairs only; the ramp twin is retired (it ran into Our home's walls, R2-09)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "marketRamp",
            b: "host.home.approach",
            at: [
              1482.4,
              1181.8
            ],
            resolution: "threshold",
            kind: "junction",
            source: "bake v1.8",
            note: "flush path junction: no marker, no mode change"
          }
        },
        {
          a: "marketStair.flight.0",
          b: "marketRamp",
          kind: "retired register row (v2.0)",
          verification: "v2.0 (D-C11, Jonathan 2026-09-27): the market stair is stairs only; the ramp twin is retired (it ran into Our home's walls, R2-09)",
          sharedPlanPoints: [],
          retiredRow: {
            a: "marketStair.flight.0",
            b: "marketRamp",
            at: [
              1480,
              1150
            ],
            resolution: "threshold",
            kind: "junction",
            source: "bake v1.8",
            note: "flush path junction: no marker, no mode change"
          }
        }
      ],
      lights: [
        {
          id: "dam.glassFace",
          kind: "card",
          anchor: "structures.dam",
          face: "south",
          on: "golden hour \u2192 dawn (sunset \u2212 1 h to sunrise); off by day",
          colour: "warm interior glow (the kit pass picks the swatch)",
          note: "v2.0 (D-A5, Jonathan 2026-09-27): an emissive card on the dam's glass band, no dynamic light; the square sees it lit at golden hour and dusk; LIGHT \xA72"
        }
      ],
      lightsRule: "lights lists the manifest-authored light cards (LIGHT \xA73 WorldDefinition.lights); the bake's door and threshold lamps are derived and not listed here",
      carriedThresholds: [
        {
          id: "bailOut",
          carriedBy: "plane",
          xy: "carried",
          modes: [
            "plane\u2192parachute"
          ],
          action: "jump",
          minAgl_m: 60,
          hold_s: 0.5,
          note: "the plane's door: its place is the plane's each frame; offered only at >= minAgl_m above the ground under the plane; never inside the Throat"
        }
      ],
      carriedThresholdRule: "A carried threshold moves with a vehicle and has no pad, marker or fixed xy. It is listed apart from thresholds so the land pass never grades a pad for it; WorldDefinition.thresholds carries it with carried = carriedBy.",
      moverAnchors_v2_5: {
        source: "main #554 parachute, #555 cruiser, #556 fall rescue (Little Harbour), #557 fleet + yacht, #558 fleet water, #559 Yacht Kitchen, #560 personal homes \u2014 anchors are code-owned (movers/fleet/model.ts, movers/cruiser/*, kitchen/geometry.ts, home/site.ts); reconciliation 2, 2026-09-27",
        fleet: {
          launch: "structures.floatplaneDock [1520,1275]: the dock's bed at h 1.2 (the fleet's launchBody [1523,1.2,1276] stands on it, dry)",
          moorings: {
            kayak: [
              1527,
              1269
            ],
            dinghy: [
              1527,
              1276
            ],
            motorboat: [
              1528,
              1283
            ]
          },
          yacht: [
            1620,
            1340
          ],
          measured: "every hull navigable at its mooring (seabed \u22123.5 / \u22124.3 / \u22125.3 / \u221212); the three small hulls' approach to the yacht's stern clear 40/40 each; identical on candidate 5 and candidate 6 (the land there did not move)"
        },
        pedestrianWater: {
          deep: [
            1315,
            420
          ],
          floor_h: 38,
          pool_h: 40,
          note: "main's swimmer test stands in the Deep under the skylight shaft; candidate 6's page G eye [1320,404] is 16 m north of it (the floor unchanged)"
        },
        fallRescue: {
          rule: "a fall that ends in water or off walkable ground fades to a path node that is never submerged (FLIGHT \xA72.4: fadeShore / fadeApron / the Deep jetty)",
          measured: "1,618 touchdowns on a 40 m grid (water and > 40\xB0 ground): 0 submerged returns on candidate 6 (0 on candidate 5); 26 returns stand against a rail or support or 0.4\u20130.8 off the node's deck (22 on candidate 5), listed in final8/probes"
        },
        rideChunkRule: "v2.2's rule (every chunk resident before a feet \u2192 mover boarding) now covers the cruiser (V), every boat and the yacht's helm; no hull moves while any chunk is missing; a fall (never refused) puts every missing chunk first and the canopy holds at an unloaded boundary",
        kitchen: {
          board: "kitchen/geometry.ts KITCHEN_BOARD, yacht-local [-2.6, main deck 3.85, -10.6]: it sails with the yacht, no land anchor",
          measured: "at the yacht's mooring the menu board stands at [1617.4,3.85,1329.4] over the harbour water (seabed -12), district harbour; the yacht's whole 14 x 44 hull is inside the harbour chunk and the galley opens only aboard, so it needs the harbour chunk resident like the fleet",
          rule: "an open service holds the body: a chosen page while cooking returns to the galley on Walk (main: Choose Walk and Resume); after Exit a chosen page is a visit again (Stage A walk-out)"
        },
        homes: {
          plots: "home/ownership.ts HOME_PLOTS: plot.terraces.1-3, plot.bight.1-4 (one per member, first come); home/site.ts reads each plot from the bake (outline centre, door xy and height), so the homes follow these reserves",
          measured: "on the candidate-6 bake all seven plots are graded pads: ground within 0.05 of the door height over the whole 52 x 32 home plot, dry, the door on a path node, no path node inside the 16 x 22 cottage; plot.terraces.3 has one path node at its plot corner (local [25.4,13.7]); plot.terraces.1 is the v2.2 plot (R3-32 margin 5.83 of 6 still open)"
        },
        comfort: "one comfort source: reduced motion and calm reach the fleet (wind off, no bob), the cruiser (no lean, camera cut) and the parachute (comfort camera) through the registry; the stricter rule wins"
      },
      regions: [
        {
          id: "mountainV2",
          kind: "placedWorld",
          label: "Mountain v2",
          offset: {
            x: 1308,
            y: 54,
            z: 764
          },
          footprint: {
            minX: 1108,
            maxX: 1508,
            minZ: 368,
            maxZ: 848
          },
          source: "src/harbour/mountain/** (geography hearth-mountain-geo-2), placed by src/harbour/horizon/regions/mountainV2/placement.ts: horizon = native + offset",
          ground: "land/mountainV2/ground.ts mountainV2Height: v2 land wins south of native z -294, the higher of v2 and the Crown north of it; the harbour island is the Foot terrace (53.95 + the lawn hump); v2 sea inside 40 m of v2 land is an apron from 53.95 to the Horizon; the Horizon elsewhere",
          data: "land/mountainV2/v2-data.json (scripts/horizon/dump-mountain-v2.mjs)",
          decisions: [
            "D-M1",
            "D-M2",
            "D-M3",
            "D-M4",
            "D-M5",
            "D-M6",
            "D-M7",
            "D-M8",
            "D-M9",
            "D-M10"
          ],
          summitNote: "v2's summit crest (native (-11,109.24,-312), Horizon [1297,452] h 163.24) stands 5.2 eu above landforms.crown.summitH 158 at the Crown summit [1310,470]: north of native z -294 D-M2 keeps the higher of v2 and the Crown, and v2 is the higher there (pass-5 deviation, recorded in docs/horizon/HANDOFF-notes/land.md); the observatory and L02 stay at 158"
        }
      ],
      retired_v2_6: {
        "roads.V02": {
          value: {
            label: "Crown Road",
            pts: [
              [
                1433.3,
                335.6
              ],
              [
                1445,
                430
              ],
              [
                1445,
                520
              ],
              [
                1400,
                620
              ],
              [
                1370,
                690
              ]
            ],
            profile: "road",
            length_m: 381,
            structures: [
              "shoulderTunnel"
            ],
            end: "turning circle at [1370,690]",
            v1_8_pts: [
              [
                1500,
                340
              ],
              [
                1445,
                430
              ],
              [
                1445,
                520
              ],
              [
                1400,
                620
              ],
              [
                1370,
                690
              ]
            ]
          },
          why: "D-M4: Crown Road retired; v2 road is the mountain road"
        },
        "structures.shoulderTunnel": {
          value: {
            xy: [
              1445,
              480
            ],
            kind: "tunnel",
            length_m: 110
          },
          why: "D-M4 (Crown Road retired)"
        },
        "structures.dam": {
          value: {
            xy: [
              1140,
              905
            ],
            kind: "dam",
            face: "south",
            spillwayArch: "Ring Run gate 4",
            apron: "S1 half-pipe",
            crest: "walk with plaques",
            gallery: "stair in the east abutment from the apron to the crest, past the plaques (does not enter the Undercroft)",
            faceLight: "dam.glassFace"
          },
          why: "D-M3: v2 glass dam is the one Fund picture; Stillwater drains over a natural rock sill"
        },
        "structures.lakesideSwitchback": {
          value: {
            kind: "switchbackRamp",
            route: "yearWalk",
            bbox: [
              [
                1274,
                843
              ],
              [
                1331,
                889
              ]
            ],
            legs: 7,
            pitch_m: 7.4,
            note: "v1.9 (T0 #16): the Year Walk's seven legs down the Shoulder's south-west corner to the lake terrace; each leg's downhill shoulder is carried to the leg below as a masonry retaining wall (the builder grounds it: no leg hangs over the next)"
          },
          why: "D-M5 (the Year Walk leaves the Foot terrace on v2 road and V03; the Lakeside zig-zag is not laid)"
        },
        "structures.s1Flyover": {
          value: {
            xy: [
              1345,
              744
            ],
            kind: "skateFlyover",
            carries: "S1 (the upper pass)",
            length_m: 44,
            width_m: 4,
            from: [
              1363.5,
              752.2
            ],
            to: [
              1326.6,
              735.7
            ],
            deck: "S1's own grade, 89.8 \u2192 83.4",
            over: "S1's lower pass at [1353.6,747.9] (76.9), 11.5 below",
            opening_m: 12,
            rails: "both edges",
            bents: "outside the lower pass's corridor (2 m + 1 m margin either side of its centreline)",
            decided: "D-C15 (recommended, accepted Jonathan 2026-09-27)",
            note: "v2.0: a route's self-crossing is not a register pair; P12 proves it (was a 13.4 eu unsupported run at [1358,750])"
          },
          why: "D-M5 (the Shoulder sweep and its self-crossing are retired)"
        },
        "structures.crownWalkBridge": {
          value: {
            xy: [
              1410.1,
              605.8
            ],
            kind: "footbridge",
            route: "walk crown",
            span_m: 36,
            opening_m: 24,
            width_m: 3.2,
            deck: "the Crown walk on its own grade (119-122)",
            under: "Crown Road's cutting (99) and its January footway lane",
            note: "v1.9: the Crown walk hung 21 eu over Crown Road at [1400-1417,605] (span refused: no footing outside the corridors)"
          },
          why: "D-M4/D-M5 (the Crown walk rides v2 road verge; Crown Road retired)"
        },
        "structures.inletFootbridge": {
          value: {
            xy: [
              1161,
              731
            ],
            kind: "footbridge",
            deck: "lake rim walk",
            under: "the upper river at the lake inlet",
            deck_h: 55,
            note: "v1.9 (integrator 2): deck 55 over the inlet pool at the lake level 50 (clear 4.4, a river's 4); was 52 over a pool at 58-60"
          },
          why: "D-M3/D-M5: water.cup and water.river.upper retired; the inlet it crossed is v2 ground"
        },
        "underground.damGallery": {
          value: {
            xy: [
              1165,
              895
            ],
            note: "a stair inside the dam's east abutment from the apron to the crest past the plaques; it does NOT enter the Undercroft"
          },
          why: "D-M3 (the Stillwater dam is removed)"
        },
        "water.cup": {
          value: {
            cx: 1170,
            cy: 660,
            rx: 22,
            ry: 14,
            surface: 100,
            note: "tarn; paper-boat and River Run launch"
          },
          why: "D-M5 (the Cup tarn is Mountain v2 ground; v2 reservoir is the mountain water)"
        },
        "water.river.upper": {
          value: [
            [
              1170,
              660
            ],
            [
              1165,
              700
            ],
            [
              1160,
              740
            ]
          ],
          why: "D-M3/D-M5 (v2 gorge river replaces the upper river)"
        },
        "water.dam": {
          value: {
            xy: [
              1140,
              905
            ],
            facing: "south (toward the square)",
            crestLength: 44,
            instrument: "L01 at [1172,912]"
          },
          why: "D-M3 (the Stillwater dam is removed; L01 is on v2 dam crest)"
        },
        "walks.crownFromGondola": {
          value: {
            pts: [
              [
                1335,
                535
              ],
              [
                1322,
                517
              ],
              [
                1310,
                500
              ]
            ],
            profile: "walk",
            length_m: 43,
            v1_9_pts: [
              [
                1360,
                560
              ],
              [
                1330,
                520
              ],
              [
                1310,
                500
              ]
            ],
            levels: [
              {
                xy: [
                  1335,
                  535
                ],
                h: 150,
                why: "the station deck"
              },
              {
                xy: [
                  1310,
                  500
                ],
                h: 154,
                why: "the summit junction (walk summit on to L02 [1310,470] at 158)"
              }
            ],
            note_v2_0: "D-A3: a 43 m leg at 9 % from the station at grade to the summit junction (the station \u2192 L02 walk is \u2248 70 m of plan and 8 m of climb, step-free); the builder's hard-coded switchback via [1405,595], [1450,565], [1430,500], [1350,440] goes"
          },
          why: "D-M6 (the Summit Commons station joins v2 summit paths; T2 graph)"
        },
        "thresholds.damPortage": {
          value: {
            id: "damPortage",
            xy: [
              1150,
              910
            ],
            modes: [
              "canoe\u2192feet\u2192canoe"
            ],
            action: "carry the canoe down the portage steps beside the apron"
          },
          why: "D-M3 (the dam portage is removed)"
        },
        crossings: {
          value: [
            {
              a: "walk lakerim",
              b: "river upper",
              at: [
                1161,
                731
              ],
              resolution: "over",
              structure: "inletFootbridge",
              kind: "crossing"
            },
            {
              a: "DEEP_RUN",
              b: "V02",
              at: [
                1445,
                520
              ],
              resolution: "under",
              note: "the Sea Passage passes \u2265 40 m beneath Crown Road and its tunnel",
              kind: "crossing"
            },
            {
              a: "S1",
              b: "damPortage",
              at: [
                1160.8,
                940.1
              ],
              resolution: "threshold",
              note: "dam apron: boards on the apron, the canoe portage meets it flush: the portage stair's foot (35.81) comes down to the apron (31) at the threshold; regrade owed (beds/structures)",
              movedFrom: [
                1160,
                935
              ],
              kind: "crossing",
              decided: "D-A7 (Jonathan 2026-09-27)",
              v1_9_note: "dam apron: boards on the apron; walkers on the crest above; RESERVED R-A7: S1 meets the dam portage stair (was the lake-rim walk) 4.8 eu apart; physically separated until Jonathan rules"
            },
            {
              a: "ZIP",
              b: "G1",
              at: [
                1437.5,
                927.4
              ],
              resolution: "under",
              note: "zip under gondola: 15.0 m below the gondola cable where they cross (profiles.cable.clear_eu 8); riders on the zip pass beneath the cabins",
              kind: "crossing",
              v1_9_resolution: "over",
              decided: "D-A2 option A (Jonathan 2026-09-27)",
              measured: {
                at: [
                  1437.5,
                  927.5
                ],
                separation_eu: 15,
                bake: "Stage A candidate 4 (the W5-A tower solve: the lowest tops keeping 8 eu over the ground at 1 % sag)"
              },
              v1_9_note: "zip 10.7 m above the gondola chord at 1 % sag",
              v1_9_at: [
                1442,
                921
              ],
              predicted_v2_0: {
                separation_eu: 29,
                g1_h: 88.8,
                zip_h: 59.8,
                source: "proposals/zip-over-g1.md, with the station at [1335,535]"
              },
              v2_0_measured: {
                at: [
                  1441.5,
                  920.8
                ],
                zip_h: 60.6,
                g1_h: 91.1,
                separation_eu: 30.45,
                bake: "candidate 3 (f1a1ec1)"
              },
              v2_0_note: "zip under gondola: 30.45 m below the gondola cable where they cross (profiles.cable.clear_eu 8); riders on the zip pass beneath the cabins"
            },
            {
              a: "walk crown",
              b: "ORE",
              at: [
                1374,
                615
              ],
              resolution: "over",
              note: "the Ore Line is in its tunnel here; the Crown walk crosses over the Ore Line 48 m north of the v1.7 point (two more crossings are listed below)",
              movedFrom: [
                1356,
                659
              ],
              kind: "crossing"
            },
            {
              a: "G1",
              b: "ORE",
              at: [
                1363.9,
                645.4
              ],
              resolution: "over",
              note: "cable above, rail in its tunnel",
              kind: "crossing",
              v1_9_at: [
                1375,
                625
              ]
            },
            {
              a: "G1",
              b: "V01",
              at: [
                1468,
                1044
              ],
              resolution: "over",
              structure: "cable clear \u2265 8 m; tower 1 beside the road",
              kind: "crossing",
              v1_9_at: [
                1469,
                1043
              ]
            },
            {
              a: "G1",
              b: "Crown Road",
              at: [
                1373.4,
                682
              ],
              resolution: "over",
              structure: "cable clear \u2265 8 m",
              kind: "crossing",
              v1_9_at: [
                1385,
                655
              ]
            },
            {
              a: "gondolaBase.walk",
              b: "G1",
              at: [
                1480,
                1090
              ],
              resolution: "threshold",
              kind: "modeTransfer",
              source: "bake v1.8",
              note: "boarding threshold; mover pending; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "river lower",
              b: "river upper",
              at: [
                1160,
                740
              ],
              resolution: "threshold",
              kind: "waterConfluence",
              source: "bake v1.8",
              note: "one waterway"
            },
            {
              a: "S1",
              b: "dam.apron.level",
              at: [
                1168,
                929.2
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.8",
              note: "at-grade meeting 0.5 eu apart: regrade owed"
            },
            {
              a: "S1",
              b: "G1",
              at: [
                1378.6,
                701.8
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1391.9,
                701.5
              ]
            },
            {
              a: "S1",
              b: "G1",
              at: [
                1395.2,
                765.5
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1407.5,
                770.1
              ]
            },
            {
              a: "S1",
              b: "underground.bellGallery",
              at: [
                1308.2,
                510.9
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "S1",
              b: "walk crown",
              at: [
                1310,
                500
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "S1",
              b: "walk crownFromGondola",
              at: [
                1310,
                500
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "S1",
              b: "walk summit",
              at: [
                1310,
                500
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "V02",
              b: "southPortal.link",
              at: [
                1370,
                690
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "V02",
              b: "walk crown",
              at: [
                1406.5,
                606.3
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "under by 21.5 eu: a named structure (footbridge, deck or passage) is owed"
            },
            {
              a: "walk crown",
              b: "crownLaunch.stair",
              at: [
                1343.7,
                474.9
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.8",
              note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "walk crown",
              b: "G1",
              at: [
                1352.3,
                601.4
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1365.9,
                586.1
              ]
            },
            {
              a: "walk crown",
              b: "G1",
              at: [
                1357,
                619.2
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1372.4,
                615.2
              ]
            },
            {
              a: "walk crown",
              b: "ORE",
              at: [
                1351.2,
                471.2
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "walk crown",
              b: "ORE",
              at: [
                1370.4,
                581
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "walk crown",
              b: "stepsPortage",
              at: [
                1355.2,
                469.9
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: "over by 124.3 eu: a named structure (footbridge, deck or passage) is owed"
            },
            {
              a: "walk crown",
              b: "stepsPortage",
              at: [
                1367.8,
                476.7
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: "over by 126.6 eu: a named structure (footbridge, deck or passage) is owed"
            },
            {
              a: "walk crown",
              b: "underground.bellGallery",
              at: [
                1317,
                494.6
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "walk crown",
              b: "walk crownFromGondola",
              at: [
                1310,
                500
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.8",
              note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "walk crown",
              b: "walk summit",
              at: [
                1310,
                500
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.8",
              note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "walk crown",
              b: "yearWalk",
              at: [
                1417.7,
                677.4
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.8",
              note: "flush path junction where the Crown walk leaves the Year Walk's January lane (D-C7): no marker, no mode change",
              v1_9_at: [
                1379.9,
                687.4
              ],
              movedFrom: [
                1379.9,
                687.4
              ],
              v1_9_note: "flush path junction: no marker, no mode change"
            },
            {
              a: "walk crown",
              b: "yearWalk",
              at: [
                1414.5,
                604.8
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: "over by 21.1 eu: a named structure (footbridge, deck or passage) is owed"
            },
            {
              a: "walk crownFromGondola",
              b: "G1",
              at: [
                1335,
                535
              ],
              resolution: "threshold",
              kind: "modeTransfer",
              source: "bake v1.8",
              note: "boarding threshold; mover pending; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1360,
                560
              ]
            },
            {
              a: "walk crownFromGondola",
              b: "walk summit",
              at: [
                1310,
                500
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.8",
              note: "flush path junction: no marker, no mode change; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "walk damCrest",
              b: "damGallery.exit",
              at: [
                1162,
                903
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.8",
              note: "flush path junction: no marker, no mode change"
            },
            {
              a: "walk damCrest",
              b: "river lower",
              at: [
                1140.2,
                903
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: ""
            },
            {
              a: "walk summit",
              b: "stepsPortage",
              at: [
                1310.1,
                445.5
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: "over by 120.4 eu: a named structure (footbridge, deck or passage) is owed; D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "walk summit",
              b: "underground.bellGallery",
              at: [
                1310,
                470
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake"
            },
            {
              a: "yearWalk",
              b: "G1",
              at: [
                1375.7,
                690.8
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1385.1,
                671.2
              ]
            },
            {
              a: "yearWalk",
              b: "G1",
              at: [
                1375.5,
                689.9
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1388.6,
                686.7
              ]
            },
            {
              a: "yearWalk",
              b: "G1",
              at: [
                1416,
                844.9
              ],
              resolution: "under",
              kind: "crossing",
              source: "bake v1.8",
              note: "D-A3 decided Jonathan 2026-09-27 (station [1335,535]); re-point on the next bake",
              v1_9_at: [
                1421.9,
                833.4
              ]
            },
            {
              a: "yearWalk",
              b: "river upper",
              at: [
                1161.9,
                725.2
              ],
              resolution: "over",
              kind: "crossing",
              source: "bake v1.8",
              note: "v1.9 (integrator 2): over by 5 eu on its deck beside the Inlet Footbridge; the inlet pool is level with the lake (was under a pool at 58-60)",
              v1_8_resolution: "under"
            },
            {
              a: "damGallery.flight.2",
              b: "damGallery.exit",
              at: [
                1170.6,
                910.8
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.9",
              note: "flush path junction: no marker, no mode change"
            },
            {
              a: "S1",
              b: "yearWalk",
              at: [
                1266.9,
                842
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.9",
              note: ""
            },
            {
              a: "V01",
              b: "V02",
              at: [
                1433.3,
                335.6
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.9",
              note: ""
            },
            {
              a: "V02",
              b: "yearWalk",
              at: [
                1436,
                355.4
              ],
              resolution: "threshold",
              kind: "crossing",
              source: "bake v1.9",
              note: ""
            },
            {
              a: "walk lakerim",
              b: "damGallery.exit",
              at: [
                1166.2,
                905.1
              ],
              resolution: "threshold",
              kind: "junction",
              source: "bake v1.9",
              note: "flush path junction: no marker, no mode change"
            }
          ],
          why: "v2.6: rows on retired routes (V02, the Shoulder Tunnel, the dam, the portage, the upper river, the Crown walk, the old G1 line, S1 upper half); the re-bake measures the new meetings"
        }
      }
    };
  }
});

// src/harbour/horizon/world/manifest.ts
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function point(value) {
  return Array.isArray(value) && value.length === 2 && value.every(Number.isFinite);
}
function parseHorizonManifest(value) {
  if (!record(value) || !record(value.scale) || typeof value.scale.factor !== "number" || !Number.isFinite(value.scale.factor) || value.scale.factor <= 0 || typeof value.scale.status !== "string" || !record(value.names) || typeof value.names.idRule !== "string" || !Array.isArray(value.hosts) || !Array.isArray(value.places) || !Array.isArray(value.districts) || !Array.isArray(value.neighbourhoods) || !Array.isArray(value.views) || !Array.isArray(value.crossings) || !Array.isArray(value.routePairNotes) || !Array.isArray(value.thresholds) || !record(value.reserves) || !record(value.journey)) {
    throw new Error("Invalid Horizon manifest");
  }
  for (const crossing2 of value.crossings) {
    if (!record(crossing2) || typeof crossing2.a !== "string" || typeof crossing2.b !== "string" || typeof crossing2.resolution !== "string" || !["over", "under", "threshold"].includes(crossing2.resolution) || !(point(crossing2.at) || typeof crossing2.at === "string" && crossing2.at.trim().length > 0)) {
      throw new Error("Invalid Horizon crossing");
    }
  }
  for (const note of value.routePairNotes) {
    if (!record(note) || typeof note.a !== "string" || typeof note.b !== "string" || typeof note.verification !== "string" || !Array.isArray(note.sharedPlanPoints) || !note.sharedPlanPoints.every(point) || "resolution" in note) {
      throw new Error("Invalid Horizon route-pair note");
    }
  }
  for (const threshold of value.thresholds) {
    if (!record(threshold) || !Array.isArray(threshold.modes) || !threshold.modes.length || threshold.modes.some((mode) => typeof mode !== "string" || mode.split("\u2192").length < 2 || mode.split("\u2192").some((step) => !step.trim()))) {
      throw new Error("Invalid Horizon threshold mode sequence");
    }
  }
  const carried = value.carriedThresholds ?? [];
  if (!Array.isArray(carried)) throw new Error("Invalid Horizon carried thresholds");
  for (const threshold of carried) {
    if (!record(threshold) || typeof threshold.id !== "string" || typeof threshold.carriedBy !== "string" || !threshold.carriedBy || typeof threshold.action !== "string" || !Array.isArray(threshold.modes) || !threshold.modes.length || threshold.modes.some((mode) => typeof mode !== "string" || mode.split("\u2192").length < 2 || mode.split("\u2192").some((step) => !step.trim()))) {
      throw new Error("Invalid Horizon carried threshold");
    }
  }
  const plotIds = /* @__PURE__ */ new Set();
  const retiredIds = value.reserves.retiredPlaceIds;
  if (!Array.isArray(retiredIds) || retiredIds.some((id) => typeof id !== "string")) {
    throw new Error("Invalid Horizon retired reserve IDs");
  }
  for (const area2 of ["terraces", "bightShore"]) {
    const reserve = value.reserves[area2];
    if (!record(reserve) || !Array.isArray(reserve.plots) || !reserve.plots.every(point) || !Array.isArray(reserve.rot_deg) || !reserve.rot_deg.every(Number.isFinite) || !Array.isArray(reserve.placeIds) || reserve.plots.length !== reserve.rot_deg.length || reserve.plots.length !== reserve.placeIds.length) {
      throw new Error("Invalid Horizon reserve arrays");
    }
    for (const id of reserve.placeIds) {
      if (typeof id !== "string" || !id || plotIds.has(id) || retiredIds.includes(id)) {
        throw new Error("Invalid Horizon reserve ID");
      }
      plotIds.add(id);
    }
  }
  if (!record(value.reserves.small)) throw new Error("Invalid Horizon small reserves");
  for (const reserve of Object.values(value.reserves.small)) {
    if (!record(reserve) || !point(reserve.xy) || typeof reserve.placeId !== "string" || !reserve.placeId || plotIds.has(reserve.placeId) || retiredIds.includes(reserve.placeId)) {
      throw new Error("Invalid Horizon small reserve");
    }
    plotIds.add(reserve.placeId);
  }
  return value;
}
var HORIZON_MANIFEST;
var init_manifest = __esm({
  "src/harbour/horizon/world/manifest.ts"() {
    "use strict";
    init_MANIFEST();
    HORIZON_MANIFEST = parseHorizonManifest(MANIFEST_default);
  }
});

// src/harbour/horizon/land/terrain/geometry.ts
var clamp;
var init_geometry = __esm({
  "src/harbour/horizon/land/terrain/geometry.ts"() {
    "use strict";
    clamp = (n, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, n));
  }
});

// src/harbour/horizon/land/coast/index.ts
var init_coast = __esm({
  "src/harbour/horizon/land/coast/index.ts"() {
    "use strict";
    init_manifest();
    init_geometry();
  }
});

// src/harbour/horizon/land/water/index.ts
var init_water = __esm({
  "src/harbour/horizon/land/water/index.ts"() {
    "use strict";
    init_manifest();
    init_geometry();
    init_coast();
  }
});

// src/harbour/horizon/regions/mountainV2/placement.ts
function insideMountainV2(hx, hz) {
  return hx >= MOUNTAIN_V2_FOOTPRINT.minX && hx <= MOUNTAIN_V2_FOOTPRINT.maxX && hz >= MOUNTAIN_V2_FOOTPRINT.minZ && hz <= MOUNTAIN_V2_FOOTPRINT.maxZ;
}
var MOUNTAIN_V2_OFFSET, MOUNTAIN_V2_NATIVE_BOUNDS, MOUNTAIN_V2_GRID_BOUNDS, MOUNTAIN_V2_MASSIF_Z, MOUNTAIN_V2_SUMMIT_Z, MOUNTAIN_V2_FOOTPRINT;
var init_placement = __esm({
  "src/harbour/horizon/regions/mountainV2/placement.ts"() {
    "use strict";
    MOUNTAIN_V2_OFFSET = { x: 1308, y: 54, z: 764 };
    MOUNTAIN_V2_NATIVE_BOUNDS = { minX: -180, maxX: 180, minZ: -310, maxZ: 84, minY: -8, maxY: 150 };
    MOUNTAIN_V2_GRID_BOUNDS = { minX: -200, maxX: 200, minZ: -396, maxZ: -30 };
    MOUNTAIN_V2_MASSIF_Z = -48;
    MOUNTAIN_V2_SUMMIT_Z = -294;
    MOUNTAIN_V2_FOOTPRINT = {
      minX: MOUNTAIN_V2_GRID_BOUNDS.minX + MOUNTAIN_V2_OFFSET.x,
      // 1108
      maxX: MOUNTAIN_V2_GRID_BOUNDS.maxX + MOUNTAIN_V2_OFFSET.x,
      // 1508
      minZ: MOUNTAIN_V2_GRID_BOUNDS.minZ + MOUNTAIN_V2_OFFSET.z,
      // 368
      maxZ: MOUNTAIN_V2_NATIVE_BOUNDS.maxZ + MOUNTAIN_V2_OFFSET.z
      // 848 (the town island's south edge)
    };
  }
});

// src/harbour/horizon/land/mountainV2/ground.ts
var MOUNTAIN_V2_ISLAND, MOUNTAIN_V2_FOOT;
var init_ground = __esm({
  "src/harbour/horizon/land/mountainV2/ground.ts"() {
    "use strict";
    init_placement();
    MOUNTAIN_V2_ISLAND = { radius: 84, lawn: 58, terrace: 10.4, level: -0.05, sea: -0.45 };
    MOUNTAIN_V2_FOOT = MOUNTAIN_V2_ISLAND.level + MOUNTAIN_V2_OFFSET.y;
  }
});

// src/harbour/horizon/regions/mountainV2/drawnRoadFloor.ts
function drawnRoadFloor(rows) {
  const cellSize = 12, cells2 = /* @__PURE__ */ new Map();
  const triangles = [];
  for (let i2 = 1; i2 < rows.length; i2++) for (let k = 1; k < rows[i2].length; k++) for (const [a, b, c] of [[rows[i2 - 1][k - 1], rows[i2][k - 1], rows[i2][k]], [rows[i2 - 1][k - 1], rows[i2][k], rows[i2 - 1][k]]]) {
    const ux = b[0] - a[0], uz = b[2] - a[2], vx = c[0] - a[0], vz = c[2] - a[2], det = ux * vz - uz * vx;
    if (Math.abs(det) < 1e-10) continue;
    const dy = b[1] - a[1], ey = c[1] - a[1], id = triangles.length;
    const ny = -det / Math.hypot(dy * vz - uz * ey, det, ux * ey - dy * vx);
    if (ny <= 0 && ny >= -0.2) continue;
    triangles.push({ x: a[0], z: a[2], y: a[1], ux, uz, vx, vz, det, dy, ey, gx: (dy * vz - ey * uz) / det, gz: (ux * ey - vx * dy) / det });
    for (let x2 = Math.floor(Math.min(a[0], b[0], c[0]) / cellSize); x2 <= Math.floor(Math.max(a[0], b[0], c[0]) / cellSize); x2++) for (let z = Math.floor(Math.min(a[2], b[2], c[2]) / cellSize); z <= Math.floor(Math.max(a[2], b[2], c[2]) / cellSize); z++) {
      const key2 = `${x2}:${z}`, list = cells2.get(key2) ?? [];
      list.push(id);
      cells2.set(key2, list);
    }
  }
  return (x2, z, ceiling = Infinity) => {
    let best = null;
    for (const id of cells2.get(`${Math.floor(x2 / cellSize)}:${Math.floor(z / cellSize)}`) ?? []) {
      const t = triangles[id], px = x2 - t.x, pz = z - t.z, u = (px * t.vz - pz * t.vx) / t.det, v = (t.ux * pz - t.uz * px) / t.det;
      if (u < -1e-7 || v < -1e-7 || u + v > 1 + 1e-7) continue;
      const y = t.y + t.dy * u + t.ey * v;
      if (y > ceiling + 1e-8 || best && y <= best.y) continue;
      best = { y, gx: t.gx, gz: t.gz };
    }
    return best;
  };
}
var init_drawnRoadFloor = __esm({
  "src/harbour/horizon/regions/mountainV2/drawnRoadFloor.ts"() {
    "use strict";
  }
});

// src/harbour/horizon/regions/mountainV2/drawnRoadGround.ts
function drawnRoadGroundCeiling(road, clearance = 0.08, batterWidth = 1.5) {
  const floor = drawnRoadFloor(road.landingRows), size2 = 12, cells2 = /* @__PURE__ */ new Map();
  const segments = road.points.slice(1).map((b, i2) => {
    const a = road.points[i2], wa = road.widths?.[i2] ?? road.halfWidth, wb = road.widths?.[i2 + 1] ?? road.halfWidth, r = Math.max(wa, wb) + batterWidth;
    for (let x2 = Math.floor((Math.min(a[0], b[0]) - r) / size2); x2 <= Math.floor((Math.max(a[0], b[0]) + r) / size2); x2++) for (let z = Math.floor((Math.min(a[2], b[2]) - r) / size2); z <= Math.floor((Math.max(a[2], b[2]) + r) / size2); z++) {
      const key2 = `${x2}:${z}`, list = cells2.get(key2) ?? [];
      list.push(i2);
      cells2.set(key2, list);
    }
    return { a, b, wa, wb };
  });
  const endRow = road.landingRows.at(-1), previous = road.points.at(-2), end = road.points.at(-1);
  const left = endRow[0], right = endRow.at(-1), ex = right[0] - left[0], ez = right[2] - left[2], length = Math.hypot(ex, ez);
  const side = (px, pz) => ex * (pz - left[2]) - ez * (px - left[0]);
  const insideSign = Math.sign(side(previous[0], previous[2]));
  const terminalWidth = road.widths?.at(-1) ?? road.halfWidth;
  return (x2, z) => {
    const top = floor(x2, z);
    if (top) return top.y - clearance;
    if (length > 0 && insideSign && side(x2, z) * insideSign < -1e-8 && Math.hypot(x2 - end[0], z - end[2]) <= terminalWidth + batterWidth) return null;
    let nearest = null;
    for (const i2 of cells2.get(`${Math.floor(x2 / size2)}:${Math.floor(z / size2)}`) ?? []) {
      const { a, b, wa, wb } = segments[i2], dx = b[0] - a[0], dz = b[2] - a[2], t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / (dx * dx + dz * dz || 1))), px = a[0] + t * dx, pz = a[2] + t * dz, distance2 = Math.hypot(x2 - px, z - pz), over = distance2 - (wa + (wb - wa) * t);
      if (over < 0 || over > batterWidth || nearest && distance2 >= nearest.distance) continue;
      nearest = { distance: distance2, over, x: px, z: pz };
    }
    if (!nearest) return null;
    const edge2 = floor(nearest.x, nearest.z);
    return edge2 ? edge2.y - clearance + nearest.over * 2 : null;
  };
}
var init_drawnRoadGround = __esm({
  "src/harbour/horizon/regions/mountainV2/drawnRoadGround.ts"() {
    "use strict";
    init_drawnRoadFloor();
  }
});

// src/harbour/horizon/land/mountainV2/roadSource.ts
var init_roadSource = __esm({
  "src/harbour/horizon/land/mountainV2/roadSource.ts"() {
    "use strict";
    init_drawnRoadFloor();
    init_drawnRoadGround();
  }
});

// src/harbour/horizon/land/structures/mesh.ts
var init_mesh = __esm({
  "src/harbour/horizon/land/structures/mesh.ts"() {
    "use strict";
  }
});

// src/harbour/horizon/land/underground/oreRoad.ts
var door, mouth;
var init_oreRoad = __esm({
  "src/harbour/horizon/land/underground/oreRoad.ts"() {
    "use strict";
    init_manifest();
    init_roadSource();
    init_mesh();
    door = HORIZON_MANIFEST.underground.doors.southPortal;
    mouth = [door.xy[0] - 8, door.xy[0] + 8, door.xy[1] - 9, door.xy[1] + 9];
  }
});

// src/harbour/horizon/land/terrain/index.ts
function sampleTerrain(field, x2, z) {
  const gx = clamp(x2 / field.step, 0, field.columns - 1), gz = clamp(z / field.step, 0, field.rows - 1);
  const i2 = Math.min(field.columns - 2, Math.floor(gx)), j = Math.min(field.rows - 2, Math.floor(gz));
  const tx = gx - i2, tz = gz - j, n = j * field.columns + i2;
  const nw = field.heights[n], ne = field.heights[n + 1], sw = field.heights[n + field.columns], se = field.heights[n + field.columns + 1];
  return tx + tz <= 1 ? nw + tx * (ne - nw) + tz * (sw - nw) : se + (1 - tx) * (sw - se) + (1 - tz) * (ne - se);
}
var GEOGRAPHY_REVISION, WALKABLE_DEGREES, WALKABLE_SLOPE, TERRAIN_SURFACE_PALETTE, BIOME_GROUNDS, ROAD_BATTER, PAINT;
var init_terrain = __esm({
  "src/harbour/horizon/land/terrain/index.ts"() {
    "use strict";
    init_manifest();
    init_coast();
    init_water();
    init_geometry();
    init_ground();
    init_oreRoad();
    GEOGRAPHY_REVISION = "horizon-geo-1";
    WALKABLE_DEGREES = HORIZON_MANIFEST.profiles.walkable.slope_max_deg;
    WALKABLE_SLOPE = Math.tan(WALKABLE_DEGREES * Math.PI / 180);
    TERRAIN_SURFACE_PALETTE = [
      { id: "sand", color: "#e0cfa5", night: "#6c7282" },
      { id: "bankedTurf", color: "#7d9a58", night: "#37453c" },
      { id: "duff", color: "#8a6f4f", night: "#37453c" },
      { id: "ochre", color: "#d7ac6b", night: "#5d5660" },
      { id: "rock.crown", color: "#a3998a", night: "#6c7282", strata: "Crown" },
      { id: "rock.crown.ledge", color: "#c4bba9", night: "#8991a1", strata: "Crown" },
      { id: "rock.notch", color: "#b3a58f", night: "#6c7282", strata: "Notch" },
      { id: "rock.notch.ledge", color: "#d3bf99", night: "#8991a1", strata: "Notch" },
      { id: "rock.ochre", color: "#8f6236", night: "#5d5660", strata: "Ochre" },
      { id: "rock.ochre.ledge", color: "#d7ac6b", night: "#8a5f45", strata: "Ochre" },
      { id: "rock.sea", color: "#9a9489", night: "#6c7282", strata: "Sea cliff" },
      { id: "rock.sea.ledge", color: "#c4bba9", night: "#8991a1", strata: "Sea cliff" },
      { id: "paved", color: "#c9b891", night: "#6c7282" },
      { id: "packedEarth", color: "#b39f78", night: "#5d5660" },
      { id: "apron", color: "#d9d2c2", night: "#6c7282" },
      { id: "boardwalk", color: "#b08a5e", night: "#3a2c26" },
      { id: "cobble", color: "#bfa982", night: "#6c7282" },
      { id: "gravel", color: "#cbbb98", night: "#6c7282" },
      { id: "plaza", color: "#d3bf99", night: "#6c7282" },
      { id: "snow", color: "#f1f1ec", night: "#8fa3c7" },
      { id: "scree", color: "#b8ad98", night: "#6c7282" }
    ];
    BIOME_GROUNDS = ["sand", "bankedTurf", "duff", "ochre", "scree"].map((id) => TERRAIN_SURFACE_PALETTE.findIndex((p) => p.id === id));
    ROAD_BATTER = 1 / 1.5;
    PAINT = Object.fromEntries(TERRAIN_SURFACE_PALETTE.map((p, i2) => [p.id, i2]));
  }
});

// ../horizon-complete/node_modules/.pnpm/fflate@0.8.2/node_modules/fflate/esm/index.mjs
import { createRequire } from "module";
var require2 = createRequire("/");
var Worker;
try {
  Worker = require2("worker_threads").Worker;
} catch (e) {
}
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b[i2] = start += 1 << eb[i2 - 1];
  }
  var r = new i32(b[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j = b[i2]; j < b[i2 + 1]; ++j) {
      r[j] = j - b[i2] << 5 | i2;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var x;
var i;
var hMap = (function(cd, mb, r) {
  var s = cd.length;
  var i2 = 0;
  var l = new u16(mb);
  for (; i2 < s; ++i2) {
    if (cd[i2])
      ++l[cd[i2] - 1];
  }
  var le = new u16(mb);
  for (i2 = 1; i2 < mb; ++i2) {
    le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v = le[cd[i2] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
      }
    }
  }
  return co;
});
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
  var m = a[0];
  for (var i2 = 1; i2 < a.length; ++i2) {
    if (a[i2] > m)
      m = a[i2];
  }
  return m;
};
var bits = function(d, p, m) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var inflt = function(dat, st, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st.f && !st.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st.i != 2;
  var noSt = st.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l2) {
    var bl = buf.length;
    if (l2 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l2));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
        if (t > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + l);
        buf.set(dat.subarray(s, t), bt);
        st.b = bt += l, st.p = pos = t * 8, st.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i2 = 0; i2 < hcLen; ++i2) {
          clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i2 = 0; i2 < tl; ) {
          var r = clm[bits(dat, pos, clbmsk)];
          pos += r & 15;
          var s = r >> 4;
          if (s < 16) {
            ldt[i2++] = s;
          } else {
            var c = 0, n = 0;
            if (s == 16)
              n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i2 - 1];
            else if (s == 17)
              n = 3 + bits(dat, pos, 7), pos += 3;
            else if (s == 18)
              n = 11 + bits(dat, pos, 127), pos += 7;
            while (n--)
              ldt[i2++] = c;
          }
        }
        var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
        lbt = max(lt);
        dbt = max(dt);
        lm = hMap(lt, lbt, 1);
        dm = hMap(dt, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
      pos += c & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c)
        err(2);
      if (sym < 256)
        buf[bt++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add = sym - 254;
        if (sym > 264) {
          var i2 = sym - 257, b = fleb[i2];
          add = bits(dat, pos, (1 << b) - 1) + fl[i2];
          pos += b;
        }
        var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
        if (!d)
          err(3);
        pos += d & 15;
        var dt = fd[dsym];
        if (dsym > 3) {
          var b = fdeb[dsym];
          dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + 131072);
        var end = bt + add;
        if (bt < dt) {
          var shift = dl - dt, dend = Math.min(dt, end);
          if (shift + bt < 0)
            err(3);
          for (; bt < dend; ++bt)
            buf[bt] = dict[shift + bt];
        }
        for (; bt < end; ++bt)
          buf[bt] = buf[bt - dt];
      }
    }
    st.l = lm, st.p = lpos, st.b = bt, st.f = final;
    if (lm)
      final = 1, st.m = lbt, st.d = dm, st.n = dbt;
  } while (!final);
  return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var et = /* @__PURE__ */ new u8(0);
var gzs = function(d) {
  if (d[0] != 31 || d[1] != 139 || d[2] != 8)
    err(6, "invalid gzip data");
  var flg = d[3];
  var st = 10;
  if (flg & 4)
    st += (d[10] | d[11] << 8) + 2;
  for (var zs = (flg >> 3 & 1) + (flg >> 4 & 1); zs > 0; zs -= !d[st++])
    ;
  return st + (flg & 2);
};
var gzl = function(d) {
  var l = d.length;
  return (d[l - 4] | d[l - 3] << 8 | d[l - 2] << 16 | d[l - 1] << 24) >>> 0;
};
function gunzipSync(data, opts) {
  var st = gzs(data);
  if (st + 8 > data.length)
    err(6, "invalid gzip data");
  return inflt(data.subarray(st, -8), { i: 2 }, opts && opts.out || new u8(gzl(data)), opts && opts.dictionary);
}
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}

// src/harbour/horizon/land/terrain/asset.ts
init_terrain();
var MAGIC = "HZGEO001";
var HEADER = 96;
var ENTRIES = 32;
var LODS = ["full", "lite", "journey"];
function decodeTerrainAsset(buffer, lod = "full") {
  if (buffer.byteLength < HEADER + 3 * ENTRIES || buffer.byteLength > 25e5) throw new Error("Invalid terrain asset length");
  const view = new DataView(buffer), text = new TextDecoder();
  if (text.decode(new Uint8Array(buffer, 0, 8)) !== MAGIC) throw new Error("Invalid terrain asset magic");
  if (text.decode(new Uint8Array(buffer, 8, GEOGRAPHY_REVISION.length)) !== GEOGRAPHY_REVISION) throw new Error("Terrain revision mismatch");
  if (view.getUint32(32, true) !== buffer.byteLength || view.getUint32(36, true) !== 3) throw new Error("Invalid terrain asset header");
  const index = LODS.indexOf(lod);
  if (index < 0) throw new Error("Unknown terrain LOD");
  const entry = HEADER + index * ENTRIES;
  const columns = view.getUint32(entry, true), rows = view.getUint32(entry + 4, true), step = view.getFloat64(entry + 8, true);
  const offset = view.getUint32(entry + 16, true), count = view.getUint32(entry + 20, true);
  const width = view.getFloat64(40, true), depth = view.getFloat64(48, true);
  if (columns < 2 || rows < 2 || columns * rows !== count || !Number.isFinite(step) || step <= 0 || width !== (columns - 1) * step || depth !== (rows - 1) * step || offset < HEADER + 3 * ENTRIES || offset + count * 3 > buffer.byteLength) throw new Error("Invalid terrain lattice");
  const heights = new Float32Array(count), surfaces = new Uint8Array(count);
  for (let n = 0; n < count; n++) {
    heights[n] = view.getInt16(offset + n * 3, true) / 100;
    surfaces[n] = view.getUint8(offset + n * 3 + 2);
  }
  return { revision: GEOGRAPHY_REVISION, width, depth, step, columns, rows, heights, surfaces };
}

// src/worldGeography.ts
var CURRENT_WORLD_GEOGRAPHY = "hearth-mountain-geo-2";
var HORIZON_GEOGRAPHY = "horizon-geo-1";

// src/house/world/horizonAssets.ts
var HORIZON_INDEX_URL = `/horizon/world/${HORIZON_GEOGRAPHY}.index.json.gz`;
var HORIZON_MONOLITH_URL = `/horizon/world/${HORIZON_GEOGRAPHY}.json.gz`;
var decodeJson = (bytes) => {
  const encoded = new Uint8Array(bytes);
  return JSON.parse(new TextDecoder().decode(encoded[0] === 31 && encoded[1] === 139 ? gunzipSync(encoded) : encoded));
};
function parseHorizonDefinition(bytes) {
  const world = decodeJson(bytes);
  if (world.id !== "horizon" || world.geographyRevision !== HORIZON_GEOGRAPHY || !world.geometry || !world.collision || !world.pathGraph) throw new Error("The Horizon definition is incomplete or has a different geography revision.");
  return world;
}

// <stdin>
init_terrain();

// src/harbour/worldDistricts.ts
var DISTRICTS = [
  { id: "hearth", name: "Hearth Terrace", at: [56, 19.2, -114], radius: 14, biome: "garden", destination: "kitchen", words: "A sheltered front garden above the harbour. Come home by the long way." },
  { id: "orchard", name: "Orchard Hollow", at: [-68, 28, -124], radius: 18, biome: "orchard", destination: "cottage", words: "Apple blossom, clover and a sunny doorstep for Hercules, tucked into a hollow." },
  { id: "library", name: "Library Woods", at: [48, 35, -176], radius: 14, biome: "woods", destination: "library", words: "A reading courtyard among the birches, with a balcony over the gorge." },
  { id: "glasshouse", name: "Glasshouse Meadows", at: [-72, 62, -214], radius: 20, biome: "meadow", destination: "glasshouse", words: "Broad flowering terraces. Plans take root beside the water." },
  { id: "reservoir", name: "Reservoir Heights", at: [54, 90, -244], radius: 15, biome: "alpine", destination: "loft-banks", words: "Exposed stone beside the glass dam, which holds a visible picture of the shared Fund." },
  { id: "summit", name: "Summit Commons", at: [2, 104, -294], radius: 15, biome: "summit", destination: "journey", words: "A windswept crown. The whole neighbourhood below, and a new way down ahead." }
];

// src/harbour/mountain/places.ts
var MOUNTAIN_VERSION = "hearth-mountain-2";
var WORLD_BOUNDS = { minX: -180, maxX: 180, minZ: -310, maxZ: 84, minY: -8, maxY: 150 };
var RESERVED_PLOTS = [
  { id: "woodland-clearing", name: "Woodland clearing", at: [-104, 54, -196], half: [10, 8], biome: "woods", envelope: { half: [7, 5.5], height: 9 }, gate: [-96, 54, -190], words: "An open woodland plot, held for a future idea." },
  { id: "sunny-shelf", name: "Sunny meadow shelf", at: [102, 26, -134], half: [10, 9], biome: "meadow", envelope: { half: [7, 6], height: 8 }, gate: [96, 26, -128], words: "A sunny terrace with room to grow." },
  { id: "high-terrace", name: "High rocky terrace", at: [80, 97, -266], half: [9, 8], biome: "alpine", envelope: { half: [6.5, 5.5], height: 8 }, gate: [76, 97, -272], words: "A quiet high plot; its view and access are reserved." }
];
var BUILDING_SITES = { home: [58, -119], cottage: [-70, -128], library: [50, -181], glasshouse: [-76, -223] };
var BUILDING_FORMS = {
  home: { half: [4.5, 3.5], door: [1.6, 3.15] },
  library: { half: [4.4, 3.4], door: [1.8, 3.15] },
  glasshouse: { half: [4, 3], door: [1.7, 2.8] },
  cottage: { half: [3.2, 2.6], door: [1.75, 2.45] }
};
var buildingYaw = (spot) => Math.atan2(-spot[0], -spot[1]);
function buildingDoor(id) {
  const spot = BUILDING_SITES[id], yaw = buildingYaw(spot), [lx, lz] = BUILDING_FORMS[id].door, c = Math.cos(yaw), s = Math.sin(yaw);
  return { at: [spot[0] + lx * c + lz * s, spot[1] + lz * c - lx * s], facing: [s, c], yaw };
}
var SUMMIT_OBSERVATORY_SITE = { at: [-2, 104, -298], radius: 4.7 };
var GOAL_PAVILION_SITE = { at: [44, 90, -246], half: [3.5, 3] };
var terrace = (id, at, radii, yaw = 0, bank = 14) => ({ id, at, radii, yaw, level: at[1], bank });
var TERRACES = [
  ...DISTRICTS.map((d) => terrace(`district:${d.id}`, d.at, [d.radius, d.radius * 0.78], 0, d.id === "summit" ? 10 : d.id === "orchard" ? 9 : 14)),
  ...RESERVED_PLOTS.map((p) => terrace(`plot:${p.id}`, p.at, [p.half[0] + 3, p.half[1] + 3], 0, 10)),
  // Glasshouse Meadows: broad steps below and above the main plateau.
  terrace("meadow-step-low", [-58, 57, -200], [18, 8], -0.3, 8),
  terrace("meadow-step-high", [-86, 66, -230], [20, 8], -0.3, 8)
];
var RIVER_BED_DEPTH = 0.28;
var GORGE_POINTS = [
  [8, 36, -236, 1.3],
  [8, 33, -222, 1.7],
  [6, 24.5, -210, 1.7],
  [3, 16, -198, 1.7],
  [-1, 14, -186, 1.7],
  [-4, 12, -174, 1.65],
  [-3, 10.6, -160, 1.6],
  [1, 9.6, -146, 1.55],
  [4, 8.8, -132, 1.45],
  [4, 8.1, -118, 1.3],
  [1, 6.8, -104, 1.15],
  [-3, 4.8, -90, 1],
  [-5, 2.9, -78, 0.8],
  [-5, 2.1, -66, 0.6],
  [-2, 1.5, -56, 0.45],
  [1, 0.9, -47, 0.4],
  [3, 0.18, -34, 0.35]
];
var RIVER = [...GORGE_POINTS.slice(1).map((p) => [p[0], p[1], p[2]]), [-8, 0.18, -15], [-8, 0.18, 20], [12, 0.05, 48], [9, -0.1, 69]];
var RIVER_HALF_WIDTH = 2.2;
var DAM = {
  centre: [8, 60, -250],
  radius: 24,
  halfAngle: 1.05,
  crest: 88,
  foot: 33,
  face: [0, 1]
};
var BASIN = { x: DAM.centre[0], z: DAM.centre[2], bottom: 52, top: DAM.crest, radius: DAM.radius, angle: DAM.halfAngle * 2 };
var RESERVOIR_BOWL = { at: [6, -256], radii: [24, 20], floor: 52, rise: 44 };
var RESERVOIR_LEVEL_MAX = 86;

// src/harbour/mountain/terrainAsset.ts
var terrainAssetUrl = `/mountain/terrain/${CURRENT_WORLD_GEOGRAPHY}.bin`;
var pending;
function grid(meta, bytes, offset) {
  const size2 = meta.cols * meta.rows * 4;
  if (!Number.isInteger(meta.cols) || !Number.isInteger(meta.rows) || size2 <= 0 || offset + size2 > bytes.byteLength) throw new Error("Invalid mountain terrain grid");
  const copy = bytes.slice(offset, offset + size2);
  return { ...meta, data: new Float32Array(copy) };
}
function decodeTerrainAsset2(bytes, revision = CURRENT_WORLD_GEOGRAPHY) {
  const data = new DataView(bytes);
  if (bytes.byteLength < 4) throw new Error("Invalid mountain terrain asset");
  const headerLength = data.getUint32(0, true);
  if (headerLength < 8 || headerLength > bytes.byteLength - 4) throw new Error("Invalid mountain terrain header");
  const header = JSON.parse(new TextDecoder().decode(bytes.slice(4, 4 + headerLength)));
  if (header.revision !== revision) throw new Error(`Stale mountain terrain asset: ${header.revision}`);
  const baseOffset = 4 + headerLength;
  const groundOffset = baseOffset + header.base.cols * header.base.rows * 4;
  const end = groundOffset + header.ground.cols * header.ground.rows * 4;
  if (end !== bytes.byteLength || !Array.isArray(header.conflictCells) || !Number.isInteger(header.conflicts)) throw new Error("Invalid mountain terrain length");
  return { revision, base: grid(header.base, bytes, baseOffset), ground: grid(header.ground, bytes, groundOffset), conflicts: header.conflicts, conflictCells: header.conflictCells };
}
function loadTerrainAsset() {
  return pending ??= (async () => {
    let bytes;
    if (typeof process !== "undefined" && Boolean(process.versions?.node)) {
      const { readFile } = await import("node:fs/promises");
      const buffer = await readFile(`${process.cwd()}/public/mountain/terrain/${CURRENT_WORLD_GEOGRAPHY}.bin`);
      bytes = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
    } else {
      const response = await fetch(terrainAssetUrl);
      if (!response.ok) throw new Error(`Mountain terrain unavailable: ${response.status}`);
      bytes = await response.arrayBuffer();
    }
    return decodeTerrainAsset2(bytes);
  })();
}

// src/harbour/mountain/math.ts
var mix3 = (a, b, t) => a + (b - a) * t;
var clamp3 = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
var smooth2 = (v) => {
  const t = clamp3(v);
  return t * t * (3 - 2 * t);
};
function arcLengths(points, horizontal = false) {
  const out = [0];
  for (let i2 = 1; i2 < points.length; i2++) {
    const a = points[i2 - 1], b = points[i2];
    out.push(out[i2 - 1] + Math.hypot(b[0] - a[0], horizontal ? 0 : b[1] - a[1], b[2] - a[2]));
  }
  return out;
}
function authorCurve(way, step = 1, ease = 24, flatEnds = false) {
  const dense = [], denseWay = [];
  const P = (i2) => way[Math.max(0, Math.min(way.length - 1, i2))];
  for (let i2 = 0; i2 < way.length - 1; i2++) {
    const p0 = P(i2 - 1), p1 = P(i2), p2 = P(i2 + 1), p3 = P(i2 + 2);
    const knot = (a, b) => Math.max(1e-4, Math.pow(Math.hypot(b[0] - a[0], b[2] - a[2]), 0.5));
    const t0 = 0, t1 = t0 + knot(p0, p1) + (i2 === 0 ? 1e-3 : 0), t2 = t1 + knot(p1, p2), t3 = t2 + knot(p2, p3) + (i2 === way.length - 2 ? 1e-3 : 0);
    const n = Math.max(4, Math.ceil(Math.hypot(p2[0] - p1[0], p2[2] - p1[2]) * 4));
    denseWay.push(dense.length);
    for (let k = 0; k < n; k++) {
      const t = t1 + (t2 - t1) * k / n;
      const L = (a, b, ta, tb, j2) => ta === tb ? a[j2] : (tb - t) / (tb - ta) * a[j2] + (t - ta) / (tb - ta) * b[j2];
      const pt = (j2) => {
        const A1 = L(p0, p1, t0, t1, j2), A2 = L(p1, p2, t1, t2, j2), A3 = L(p2, p3, t2, t3, j2);
        const B1 = (t2 - t) / (t2 - t0) * A1 + (t - t0) / (t2 - t0) * A2, B2 = (t3 - t) / (t3 - t1) * A2 + (t - t1) / (t3 - t1) * A3;
        return (t2 - t) / (t2 - t1) * B1 + (t - t1) / (t2 - t1) * B2;
      };
      dense.push([pt(0), pt(2)]);
    }
  }
  denseWay.push(dense.length);
  dense.push([way[way.length - 1][0], way[way.length - 1][2]]);
  const ds = [0];
  for (let i2 = 1; i2 < dense.length; i2++) ds.push(ds[i2 - 1] + Math.hypot(dense[i2][0] - dense[i2 - 1][0], dense[i2][1] - dense[i2 - 1][1]));
  const total = ds[ds.length - 1], wayS = denseWay.map((i2) => ds[i2]);
  const count = Math.max(2, Math.round(total / step)), out = [];
  let j = 0;
  for (let k = 0; k <= count; k++) {
    const s = total * k / count;
    while (j < ds.length - 2 && ds[j + 1] < s) j++;
    const t = (s - ds[j]) / (ds[j + 1] - ds[j] || 1), a = dense[j], b = dense[j + 1];
    let w = 0;
    while (w < wayS.length - 2 && wayS[w + 1] < s) w++;
    const u = clamp3((s - wayS[w]) / (wayS[w + 1] - wayS[w] || 1));
    out.push([mix3(a[0], b[0], t), mix3(way[w][1], way[w + 1][1], u), mix3(a[1], b[1], t)]);
  }
  if (ease > 0) {
    const half = Math.max(1, Math.round(ease / step / 2));
    if (!flatEnds) for (let pass = 0; pass < 2; pass++) {
      const ys = out.map((p) => p[1]), prefix = [0];
      for (const y of ys) prefix.push(prefix[prefix.length - 1] + y);
      for (let k = 0; k < out.length; k++) {
        const r = Math.min(half, k, out.length - 1 - k);
        out[k][1] = (prefix[k + r + 1] - prefix[k - r]) / (2 * r + 1);
      }
    }
    else {
      const y0 = out[0][1], y1 = out[out.length - 1][1], n = out.length;
      for (let pass = 0; pass < 2; pass++) {
        const ys = out.map((p) => p[1]), prefix = [0], at = (k) => k < 0 ? y0 : k >= n ? y1 : ys[k];
        for (let k = -half; k < n + half; k++) prefix.push(prefix[prefix.length - 1] + at(k));
        for (let k = 0; k < n; k++) out[k][1] = (prefix[k + 2 * half + 1] - prefix[k]) / (2 * half + 1);
      }
      const d0 = out[0][1] - y0, d1 = out[n - 1][1] - y1, fade = Math.min(n / 2, half * 6);
      for (let k = 0; k < n; k++) {
        const a = clamp3(1 - k / fade), b = clamp3(1 - (n - 1 - k) / fade);
        out[k][1] -= d0 * a * a * (3 - 2 * a) + d1 * b * b * (3 - 2 * b);
      }
    }
  }
  return { points: out, wayS, step: total / count };
}

// src/harbour/mountain/natural.ts
var RIDGES = [
  { id: "crown", spine: [[-8, -304, 110, 6], [-4, -300, 110, 6]] },
  { id: "east-arm", slope: 0.78, spine: [[4, -302, 106, 30], [40, -292, 100, 30], [74, -276, 96, 28], [96, -248, 86, 30], [108, -210, 64, 30], [112, -170, 42, 30], [110, -130, 28, 30], [100, -94, 14, 26], [88, -64, 3, 22]] },
  { id: "west-arm", slope: 0.78, spine: [[4, -302, 106, 30], [-38, -290, 102, 30], [-70, -264, 90, 32], [-96, -236, 74, 32], [-114, -198, 58, 32], [-116, -160, 44, 32], [-106, -126, 34, 30], [-90, -94, 18, 28], [-76, -64, 4, 24]] },
  // Inner spurs: gorge rims, shoulders and the saddles the road uses.
  { id: "library-shoulder", spine: [[86, -176, 34, 20], [60, -184, 40, 18], [36, -181, 41, 14], [22, -180, 40, 8]] },
  { id: "reservoir-spur", spine: [[92, -232, 82, 16], [80, -214, 78, 16], [56, -210, 73, 14], [30, -212, 68, 8]] },
  { id: "west-rim", spine: [[-64, -204, 52, 18], [-36, -198, 47, 14], [-18, -194, 45, 8]] },
  { id: "orchard-north", spine: [[-104, -150, 44, 18], [-70, -148, 40, 16], [-30, -144, 34, 12]] },
  { id: "orchard-rim", spine: [[-26, -150, 38, 10], [-24, -134, 36, 10], [-22, -118, 28, 10], [-22, -106, 22, 10]] },
  { id: "gorge-east-rim", spine: [[22, -150, 38, 8], [26, -136, 37, 8], [26, -124, 30, 8]] },
  { id: "dam-west", spine: [[-60, -252, 92, 20], [-28, -242, 91, 14], [-14, -238, 90, 8]] },
  { id: "dam-east", spine: [[70, -256, 94, 20], [44, -244, 92, 14], [30, -238, 90, 8]] }
];
var BLOBS = [
  { at: [4, -130], r: [24, 70], yaw: 0, dh: -8 }
];
function segment(x2, z, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az, l = dx * dx + dz * dz, t = clamp3(((x2 - ax) * dx + (z - az) * dz) / (l || 1));
  return { d: Math.hypot(x2 - ax - dx * t, z - az - dz * t), t };
}
var bump = (u) => u >= 1 ? 0 : (1 - u * u) * (1 - u * u);
var smax = (a, b, k) => {
  const h = Math.max(k - Math.abs(a - b), 0) / k;
  return Math.max(a, b) + h * h * k / 4;
};
var smin = (a, b, k) => -smax(-a, -b, k);
function ridgeHeight(spine, x2, z, slope = 0.62) {
  let best = -Infinity;
  for (let i2 = 1; i2 < spine.length; i2++) {
    const a = spine[i2 - 1], b = spine[i2], { d, t } = segment(x2, z, a[0], a[1], b[0], b[1]);
    const h = mix3(a[2], b[2], t), w = mix3(a[3], b[3], t);
    best = Math.max(best, h - slope * (Math.sqrt(d * d + w * w) - w));
  }
  return best;
}
function massif(x2, z) {
  const sx = 0, sz = -292;
  const dx = (x2 - sx) / 140, dz = z > sz ? (z - sz) / 262 : (sz - z) / 88;
  const q = Math.hypot(dx, dz), soft = Math.sqrt(q * q + 0.01) - 0.1;
  if (soft >= 1) return -(soft - 1) * 40 - 0.6;
  return 106 * Math.pow(1 - soft, 1.7) - 0.6;
}
function hash(ix, iz) {
  let h = Math.imul(ix, 374761393) ^ Math.imul(iz, 668265263);
  h = Math.imul(h ^ h >>> 13, 1274126177);
  return ((h ^ h >>> 16) >>> 0) / 4294967296;
}
function valueNoise(x2, z) {
  const ix = Math.floor(x2), iz = Math.floor(z), fx = x2 - ix, fz = z - iz, u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
  return mix3(mix3(hash(ix, iz), hash(ix + 1, iz), u), mix3(hash(ix, iz + 1), hash(ix + 1, iz + 1), u), v) * 2 - 1;
}
function surfaceNoise(x2, z) {
  return valueNoise(x2 / 38, z / 38) * 1.6 + valueNoise(x2 / 13 + 17, z / 13 - 9) * 0.45;
}
function terraceWeight(t, x2, z) {
  const c = Math.cos(t.yaw), s = Math.sin(t.yaw), dx = x2 - t.at[0], dz = z - t.at[2], u = dx * c - dz * s, v = dx * s + dz * c;
  const e = Math.hypot(u / t.radii[0], v / t.radii[1]);
  if (e <= 1) return 1;
  return 1 - smooth2((e - 1) * Math.min(t.radii[0], t.radii[1]) / t.bank);
}
function channelProfile(d, wall) {
  if (d < 3) return -RIVER_BED_DEPTH;
  if (d < 6) return mix3(-RIVER_BED_DEPTH, 0.6, smooth2((d - 3) / 3));
  return 0.6 + wall * (d - 6) * smooth2((d - 6) / 5);
}
var riverLengths = [0];
for (let i2 = 1; i2 < GORGE_POINTS.length; i2++) {
  const a = GORGE_POINTS[i2 - 1], b = GORGE_POINTS[i2];
  riverLengths.push(riverLengths[i2 - 1] + Math.hypot(b[0] - a[0], b[2] - a[2]));
}
function nearestRiver(x2, z) {
  let best = { d: Infinity, y: 0, s: 0, wall: 1.4 };
  for (let i2 = 1; i2 < GORGE_POINTS.length; i2++) {
    const a = GORGE_POINTS[i2 - 1], b = GORGE_POINTS[i2], { d, t } = segment(x2, z, a[0], a[2], b[0], b[2]);
    if (d < best.d) best = { d, y: mix3(a[1], b[1], t), s: mix3(riverLengths[i2 - 1], riverLengths[i2], t), wall: mix3(a[3], b[3], t) };
  }
  return best;
}
function macroHeight(x2, z) {
  let h = massif(x2, z);
  for (const r of RIDGES) {
    const ridge = ridgeHeight(r.spine, x2, z, r.slope);
    if (ridge > h - 10) h = smax(h, ridge, 10);
  }
  for (const b of BLOBS) {
    const c = Math.cos(b.yaw), s = Math.sin(b.yaw), dx = x2 - b.at[0], dz = z - b.at[1], u = dx * c - dz * s, v = dx * s + dz * c;
    h += b.dh * bump(Math.hypot(u / b.r[0], v / b.r[1]));
  }
  const cz = z > -190 ? (z + 190) / 150 : (-190 - z) / 196, cx = Math.abs(x2) / 170, foot = Math.pow(Math.pow(cx, 2.6) + Math.pow(Math.abs(cz), 2.6), 1 / 2.6);
  h = mix3(Math.min(h, -3.5), h, smooth2((1 - foot) / 0.1));
  if (z > -84) h = mix3(Math.min(h, 1 + (-48 - z) * 0.12), h, smooth2((-48 - z) / 36));
  h += surfaceNoise(x2, z) * smooth2((h + 2) / 6);
  const inland = smooth2((0.93 - foot) / 0.12);
  return Math.max(h, mix3(-9, 0.9 + Math.max(0, -48 - z) * 0.09, inland));
}
function bowlHeight(x2, z) {
  const bowl = RESERVOIR_BOWL, bx = (x2 - bowl.at[0]) / bowl.radii[0], bz = (z - bowl.at[1]) / bowl.radii[1], br = Math.hypot(bx, bz);
  return br < 2.4 ? bowl.floor + Math.max(0, br - 0.55) * (br - 0.55) * bowl.rise : Infinity;
}

// src/harbour/mountain/orchardJunction.generated.json
var orchardJunction_generated_default = { sourceSha256: "86fe249963667423a4b9f8c5360f271f6ada0ef1a0bbe9a4a6a1ffb88387d91f", fixedFromRow: 26, bridgeArtFromRow: 8, bridgeRowY: { "8": 16.25220008859172, "9": 16.366577737951136, "10": 16.472310941225945, "11": 16.578626461714517, "12": 16.692880491602672, "13": 16.809719003498763, "14": 16.918885495176937, "15": 17.021282440208026, "16": 17.118300397328024, "17": 17.211782105509517, "18": 17.30384340815399, "19": 17.396812200957022, "20": 17.49423020934998, "21": 17.59706942328228, "22": 17.703483977029062, "23": 17.812426818360077, "24": 17.923131395900185, "25": 18.022329101684075 }, points: [[20.696268453997583, 16.0679568131175, -97.20695250177008], [20.656913833725177, 16.07757678239782, -97.35320587689638], [20.52329340991823, 16.05878596337876, -97.22023344355172], [20.52490468735362, 16.0578877242956, -97.20807432988292], [21.07996188499331, 16.07757678239782, -97.04629635674927], [20.520802009751275, 16.05811184851502, -97.21316659965139], [20.514207931981982, 16.057661857870695, -97.2111920255195], [21.413868881701006, 16.0939357227349, -97.00430980218056], [21.607060234023926, 16.09626493524637, -96.89266732011866], [21.3743987940093, 16.101577006149018, -97.12648298852002], [21.260147617069787, 16.083965226809315, -96.99377909790299], [21.31259798095744, 16.092734817146862, -97.06390980709058], [21.360853637560353, 16.101669850373728, -97.14009534219802], [21.254991875190324, 16.083727185255395, -96.99528179974129], [21.259784554311768, 16.092519699462276, -97.1092194692563], [21.206681343939533, 16.102726612407242, -97.29503248124288], [21.21661136055686, 16.081955149812742, -97.00646825384301], [21.06425087956579, 16.091741399416403, -97.24956136565807], [20.904060805959194, 16.108970676647342, -97.59915431318636], [20.720067347941107, 16.085598870343546, -97.41605312898781], [21.126339323596333, 16.0790627556526, -97.03277910474671], [21.21174509540171, 16.09213433163493, -97.14788091194157], [20.895820597563983, 16.079953797697947, -97.21208361684504], [21.37939647293347, 16.0749754525406, -96.81259868538534], [21.445386826810136, 16.069772792826146, -96.73179201282728], [21.474098106744243, 16.07757678239782, -96.76036155967935], [21.218704485246032, 16.07757678239782, -96.94564248364932], [21.228382695455657, 16.057829881815774, -96.71818436716028], [21.03224907005805, 16.04567470681107, -96.69058089597958], [21.2171903997084, 16.038295245228063, -96.50472207618496], [21.09870956771521, 16.061854031070613, -96.84032369269904], [21.151610622572363, 16.07757678239782, -96.99431720307248], [20.9922740929844, 16.046587852675742, -96.73075418809483], [20.854964547159792, 16.063373286376297, -97.0357423465493], [20.526071447895266, 16.057237290114507, -97.19926965494702], [20.521728022410286, 16.0575956240936, -97.20617867011647], [21.3829195614137, 16.08259210184983, -96.88790274396304], [21.35458736398451, 16.07757678239782, -96.8470632584648], [21.244614659168718, 16.08175639815418, -96.97823446043121], [21.230102573664407, 16.081086372488652, -96.9824641790779], [21.195359140824216, 16.0800726447775, -96.99638663333226], [21.167593582162144, 16.080384577786834, -97.02075506404913], [21.157239506330193, 16.07856563266499, -97.00362809730376], [21.216646769825843, 16.081881081225095, -97.00543926781607], [21.17585153804953, 16.077906399153544, -96.98119592800852], [21.15039080402956, 16.079337655368143, -97.01905408869986], [21.12878783437305, 16.078195488278308, -97.01925519046806], [19.120021429744774, 15.88241518462803, -95.74531915015497], [19.099967487751933, 15.88664404136909, -95.80380992145278], [18.95479643607314, 15.869728614404849, -95.65934287485202], [19.217025389119396, 15.886644041369092, -95.75732886069527], [19.208296406034634, 15.886644041369092, -95.76079494361983], [20.172164679714104, 15.972801186804167, -96.34923139123514], [19.903671240749475, 15.982122886524698, -96.60361612382441], [19.88160974435321, 15.979085613868326, -96.58166161436054], [20.00984143872855, 15.938551660578417, -96.05357708695273], [20.53784397345393, 15.982122886524698, -96.25087356505625], [20.52785700128536, 15.982122886524698, -96.25642856598174], [19.80076769357699, 15.951168622235635, -96.28512272524333], [19.801070055592735, 15.96956052049634, -96.50151250174603], [19.400855353622802, 15.898679841857, -95.82601982746361], [19.91046187558766, 15.969965474378098, -96.46284259569379], [19.549116368331187, 15.927598934663669, -96.10997615686198], [19.5953726968794, 15.944375182653744, -96.29681266962905], [19.380989886833238, 15.89722192486139, -95.81859678235361], [19.567293848727758, 15.928157203449869, -96.10693900311757], [19.380932442741564, 15.908618782442188, -95.9630339609444], [19.24398488449117, 15.90135168043609, -95.94712890774824], [19.303382302762447, 15.891526341817531, -95.78959748404672], [19.246065527001814, 15.893498861628645, -95.84647153699738], [19.16950690048494, 15.892232685419499, -95.87301210373164], [19.267388020268704, 15.888884738841458, -95.77614765246291], [19.18573734538609, 15.888484048386967, -95.80162794973239], [19.15274311460761, 15.886644041369092, -95.78285390661108], [19.185234099435398, 15.891694748971442, -95.85744825955315], [21.008419212600632, 16.02858998160962, -96.51169978328795], [20.775818168035443, 16.001799992789728, -96.33979637769933], [20.887614069379616, 16.023388382241944, -96.52283085629249], [20.750114946440554, 15.999490976691234, -96.33019196339623], [20.777790604328555, 16.016341071695088, -96.51627912147987], [20.86416239019608, 16.049514300173175, -96.85950145041383], [20.63602656247954, 15.995940595241203, -96.36952009889089], [20.64637502954219, 15.990171633694082, -96.2914279066035], [20.67542013352363, 16.03423072850963, -96.80943040141726], [20.624076833656687, 15.990696786178342, -96.31041552064471], [20.58982890894833, 15.98597812959974, -96.27029855643971], [20.466628759819518, 16.011922557597867, -96.6641387071328], [19.977106986386367, 15.99120876255, -96.67669574379272], [20.556530721225613, 15.983508710211053, -96.257856163207], [20.339934254172267, 15.983868169809973, -96.38283968367233], [20.53659560193286, 15.982122886524698, -96.25156794017194], [19.760587483774042, 15.8634557118069, -95.29734016327458], [19.595132093003834, 15.830479672641637, -95.01583052314216], [19.6577110624463, 15.826866762285595, -94.95294110045012], [20.109821428933586, 15.886644041369092, -95.40281962649664], [20.10737541238615, 15.886644041369092, -95.40379088467252], [19.332897422100338, 15.886644041369092, -95.71131868161152], [19.375809319978593, 15.858135986099008, -95.3802255347534], [19.199398444831612, 15.857284244286292, -95.41352739950648], [19.20217731893772, 15.877388996559684, -95.65264230918464], [19.306768902564098, 15.886644041369093, -95.72169372925786], [20.75542783338296, 15.98072421676894, -96.12236696301419], [20.795501501031147, 15.977926877257417, -96.085114842533], [20.809968982028252, 15.982122886524698, -96.09951090488643], [20.66081301708948, 15.982122886524698, -96.1824751416231], [20.61403534216125, 15.963629582330027, -96.0076612257875], [20.309733728230196, 15.91325785494096, -95.60174505978165], [20.69009312229419, 15.981210710597027, -96.16130985921221], [20.425567657481793, 15.940144694715794, -95.84029106717625], [20.571951488812687, 15.982122886524698, -96.23190212144094], [20.25163017849016, 15.90525901288096, -95.5439283379086], [20.33370987478644, 15.917960832707655, -95.64140467512692], [20.349032867941844, 15.947058558905702, -95.9607708357381], [20.15656632889569, 15.892172020400743, -95.4493337705065], [20.566363799270015, 15.982122886524698, -96.23501013256352], [19.81300425816959, 15.902423109890114, -95.70643059903692], [19.38243301068239, 15.89541712271321, -95.79492612291425], [20.115325158918555, 15.887294903901205, -95.40829618734755], [19.809570486604205, 15.88852883014434, -95.5442303006085], [19.38485599272976, 15.89659923584015, -95.80855650402506], [19.37268398968475, 15.895395052131459, -95.8000691216068], [19.387317722825674, 15.896282237637699, -95.80317066578718], [19.369747661254035, 15.895991094380083, -95.80925460364092], [19.35556910724413, 15.895356306147407, -95.80909790696242], [19.365994182614195, 15.892931833638766, -95.77257965762635], [19.375962307989305, 15.894271118341305, -95.78400470437285], [19.341133205447914, 15.892230435366372, -95.77752079855686], [19.3012225817105, 15.889018374009362, -95.75902127270706], [19.291702921156688, 15.887216481997452, -95.73759275102316], [19.328146782184657, 15.886644041369092, -95.71320505391085], [19.297991010702937, 15.887837987666884, -95.74586252820052], [20.86594764171539, 16.001085252766796, -96.28162612509846], [20.728915377188486, 15.99447128533522, -96.28415449423956], [20.6857676643574, 15.990595165636671, -96.26803167054095], [20.61853164718857, 15.985376970915157, -96.24679554751715], [20.577109633174295, 15.98323523384211, -96.2429805854023], [20.60329137969215, 15.982493668963835, -96.21911928282212], [20.574489754449413, 15.984240691217634, -96.25704510168299], [20.560501844724943, 15.982539248358659, -96.24349139347486], [20.55321145241309, 15.982122886524698, -96.2423257931791], [19.62362989456116, 15.827639461950538, -94.97460980366043], [19.618046528233343, 15.825571950924378, -94.955057787389], [19.4069817333223, 15.831018056646778, -95.06762235054853], [19.008451333260176, 15.81529015141771, -94.98758866699731], [19.613880267282525, 15.82646426396388, -94.96610737570775], [19.070741248794917, 15.837143386967584, -95.22396454605953], [19.108453669552144, 15.861911150049131, -95.50492335033691], [18.966661547535736, 15.814088002117206, -94.9898187673975], [18.7967948870618, 15.830763726668103, -95.25651616132505], [18.408985954790175, 15.806130416102285, -95.11617929421502], [18.545076827357807, 15.801960450667044, -95.01231651982388], [18.423639383904316, 15.802500171830733, -95.05099710302413], [18.316855369564976, 15.799409648722873, -95.02449549503352], [19.110324021561215, 15.781043280354845, -94.58990805369889], [19.09365712333768, 15.76087285513254, -94.39167161063838], [19.33872665255178, 15.791128492965997, -94.63553135541345], [18.89858828879419, 15.791128492965997, -94.74252119504483], [18.96132988553015, 15.768656173175216, -94.4894427902067], [18.83333188733148, 15.76904730783936, -94.50545674476679], [19.019742242657262, 15.753576036762967, -94.31812161037678], [18.74442461841136, 15.783768097923785, -94.69568661062294], [18.50135367910842, 15.791128492966, -94.8390818920572], [19.6350686863204, 15.825189547467646, -94.94427230409053], [19.62944846828155, 15.823129929192966, -94.92481802443247], [19.36508490763866, 15.813738333299282, -94.88344232615835], [18.935599041917435, 15.799268092413211, -94.82507972732526], [19.374210522348335, 15.795034408294471, -94.67084005927381], [19.624753551791112, 15.824135467552958, -94.93726969153221], [19.136781126402937, 15.794139871659919, -94.71849308426434], [18.958321680736425, 15.806966206270216, -94.90803673031729], [18.922574800232354, 15.799218579132742, -94.82965975954912], [18.86914500107789, 15.805044138561804, -94.92048127374511], [18.7548075694652, 15.807993687271338, -95.00112429656176], [18.832536087078267, 15.798876285725926, -94.86132227147202], [18.69969266705388, 15.801768733234331, -94.948631341862], [18.66635018431425, 15.798244509273012, -94.91976227959029], [18.918920710314662, 15.79653838817065, -94.79908689397307], [18.884566392034937, 15.796407785941554, -94.811167742022], [18.799158186728903, 15.796083095988312, -94.84120191536904], [18.549868062151656, 15.80006446592558, -94.97896918286743], [18.37776321422689, 15.800090407885843, -95.02124516468604], [18.610282022707676, 15.799962495876418, -94.96255276736952], [18.552182147201744, 15.796000310362745, -94.90942120528238], [17.18101405982031, 15.683198369800571, -93.7098511285991], [17.13837273198974, 15.695564487350396, -93.85172789328409], [16.757443873656133, 15.658466134700918, -93.47264634436604], [17.647225573815057, 15.695564487350397, -93.80517914814713], [18.869183107262646, 15.754995819109965, -94.34752109798535], [18.7544751917992, 15.742364112727568, -94.21898493881248], [18.721050184889247, 15.757011184709643, -94.39488365162283], [18.659572519522126, 15.780604731408284, -94.68007813027512], [18.636821140904186, 15.736028586863364, -94.17501479263693], [18.368066969591336, 15.76240541579884, -94.54247539649204], [18.203334445070677, 15.791128492965997, -94.91152508874778], [17.880075688021737, 15.756183933247112, -94.58983397072774], [18.327244344920874, 15.719358257342284, -94.05931850450747], [17.98161800202102, 15.727194379716742, -94.23309236763501], [17.584794828969073, 15.724263809234978, -94.29598507226096], [18.134357146172384, 15.708971519042594, -93.98723192304388], [17.561078302031177, 15.703985758065752, -93.95540159255336], [17.300641229209607, 15.695564487350397, -93.83688392603072], [18.340514497914693, 15.79388887821829, -94.92503415861283], [17.62259174355308, 15.66805129977369, -93.50045182002975], [16.975752188048098, 15.640593007019556, -93.25325500467258], [17.68237496996203, 15.622555194870483, -92.98735624417299], [18.432100268341845, 15.695564487350397, -93.7333805275697], [18.240653587495316, 15.695564487350397, -93.75089365125015], [17.372796687801763, 15.624502977861962, -93.00231729449582], [17.46026290539516, 15.610360731695845, -92.76634063464194], [18.82206908589004, 15.739053575825475, -94.17636456273773], [18.691989823213657, 15.721220577985893, -93.99198713902395], [18.677221669469077, 15.728414404306802, -94.07797810966964], [18.625600521959253, 15.714044339650384, -93.9259255682052], [18.5285383688751, 15.718136470072567, -93.99639263084273], [18.524487467716085, 15.703114696434234, -93.82531165802126], [18.368449215512797, 15.707645886233756, -93.91514393531145], [18.48770790324185, 15.699139072115912, -93.78871365567316], [18.23578114798751, 15.698167230229405, -93.79533265076854], [18.2141316650962, 15.695564487350397, -93.75331981870923], [18.251915156956876, 15.695564487350397, -93.74986346750424], [18.478157882780515, 15.699404813924742, -93.79407901425076], [16.796856062625547, 15.649259790024612, -93.36632041417501], [16.6573721261724, 15.64872022835336, -93.37305989348643], [16.86524455482365, 15.633120766594413, -93.11933489737503], [16.36759099967892, 15.632809099308886, -93.08468405669917], [17.078403911835736, 15.594259397922851, -92.50372627529951], [16.89435584322488, 15.599940270557271, -92.55530593762577], [17.070393071079636, 15.582897652654013, -92.37839539070823], [17.27046282120269, 15.59994027055727, -92.57747749756452], [16.998168142375413, 15.610762593029818, -92.74595203163285], [19.85835870485997, 16.076375051840948, -97.91615103022609], [19.83965367985214, 16.077576782397816, -97.94610524354906], [19.811089608453685, 16.073971590727204, -97.91767495415333], [19.924332826274085, 16.07757678239782, -97.88467289297583], [20.7669347391988, 16.10747753092731, -97.6784100001002], [20.738813545833683, 16.112378131427665, -97.76519232470947], [20.657929865803514, 16.101083784706923, -97.67088336240478], [20.687309952189917, 16.10653926013979, -97.7252804953201], [20.716278100956977, 16.112517489155085, -97.78783560758917], [20.636218296165495, 16.10017763526949, -97.67721068657698], [20.62271539162289, 16.105262947604892, -97.76523787214413], [20.62031600769817, 16.11311091250697, -97.88425690458487], [20.518049161670923, 16.09524575348803, -97.71164828982548], [20.338871971214083, 16.101453362232075, -97.96759812314659], [20.20091014379187, 16.11570449112857, -98.30566973534071], [20.05562466503749, 16.097082896253205, -98.16106471218536], [20.299459877871953, 16.086122757783603, -97.77535097379653], [20.029767762258917, 16.084589804708113, -97.9417984556267], [20.55659778139221, 16.071313176058133, -97.34934559476618], [20.489586100533224, 16.07757678239782, -97.4745974638504], [20.479167400666764, 16.064036195684743, -97.31060927427697], [20.389582160233623, 16.062120179091703, -97.3364141641863], [20.405296756208095, 16.07014978511848, -97.43448828970905], [20.41126582734557, 16.077576782397816, -97.531416629876], [20.330752936719957, 16.063325396586574, -97.3955249009235], [20.11936029969832, 16.073112638027354, -97.68232234448216], [20.677122651505275, 16.091302006537475, -97.52446025408447], [20.594578087500743, 16.092946067458076, -97.60756383761071], [20.52824272702898, 16.08992448702472, -97.62312908963933], [20.469117349746302, 16.086697776943556, -97.62905991830452], [20.46349425694084, 16.081483232066947, -97.55656573793463], [20.431779320543, 16.080175136859467, -97.56603983164896], [20.480978118977276, 16.091529974732854, -97.69016897218206], [20.45576784551461, 16.09264639376698, -97.72979870841624], [20.414031098418967, 16.0864105163384, -97.67506235804157], [20.4442104161406, 16.078442900551703, -97.52401797512512], [20.24979174753989, 16.079805648367305, -97.69102703992641], [20.182120885664865, 16.07757678239782, -97.69765487133475], [18.877678098092762, 15.948476489620866, -96.74797824918471], [18.99734217336304, 15.982122886524696, -97.10773876711822], [18.461126611051196, 15.916462275060498, -96.57403461120975], [18.55656411684495, 15.91319791037357, -96.47958839267864], [19.49567949111186, 15.982122886524698, -96.83055122573225], [18.423166064999027, 15.909766064753025, -96.47310627776405], [18.251807467100942, 15.899638008825008, -96.36569582940378], [20.374316462897355, 16.051853889318917, -97.21617789875008], [20.219159296476466, 16.03577963099435, -97.10092750654444], [20.2694507250421, 16.0476216237613, -97.22589470268152], [20.138308506738355, 16.029261288372574, -97.07071223907184], [20.133815068568932, 16.042405316315563, -97.25317610422809], [20.163334563058022, 16.066755248977085, -97.56374441529809], [19.902864267759394, 16.010279331326025, -96.98272286161892], [19.85559885668315, 16.040135974518144, -97.42407426192543], [19.60661276867726, 16.048163708184394, -97.71415579722098], [19.79409307546739, 16.001509993376015, -96.94207328133575], [19.5816262793155, 16.01141397737174, -97.23124165039108], [19.26875695938356, 16.005521504538287, -97.37788236132805], [19.6570423137338, 15.990460703388262, -96.89085516167955], [19.369573772117956, 15.988943344454723, -97.02344395827], [19.163454612612657, 15.982122886524698, -97.01534291998958], [19.6351670825028, 15.991309199227699, -96.91829331377242], [18.892326915180472, 15.881005565714343, -95.8188889219054], [18.62221682171635, 15.88664404136909, -95.99351396941138], [19.88576070919837, 15.981110462305908, -96.60216985131622], [19.872001142492426, 15.982122886524698, -96.62123181576371], [19.851560314146123, 15.976923006963121, -96.56813531062342], [19.758859236641616, 15.96954536904987, -96.52479922504875], [19.766993051601908, 15.982122886524696, -96.67963991305625], [19.417029023134212, 15.950895322711354, -96.4786260347054], [18.98311499158671, 15.944503977417535, -96.63899745736116], [18.98829272335194, 15.912821563411674, -96.2346817153799], [18.746926673725838, 15.897310156199373, -96.1287686343456], [18.781497248455953, 15.905504249839968, -96.25699158939534], [20.161232036013768, 16.019106459272766, -96.92408575318035], [19.934453929210264, 15.991775585676022, -96.70752773686476], [19.92180832470963, 15.986807530318854, -96.65226785506141], [20.05461174745395, 16.012147642263702, -96.89810662566336], [19.92652525739072, 15.991774064011858, -96.71325902017234], [19.92537886397064, 16.003332817108994, -96.87168126286925], [19.82590698213246, 15.993593231589648, -96.811057061453], [19.833289305832256, 15.991756170244857, -96.78065513203009], [19.825538862481654, 15.99236750883758, -96.79461277419448], [19.817420299480247, 15.991753124678235, -96.79212612910037], [19.910993443031135, 15.98855751207086, -96.68067285760027], [19.877271901905132, 15.988551040260472, -96.7050486559887], [19.827684523114407, 15.9877530603066, -96.73014335438415], [19.7880273446527, 15.985380059778613, -96.72656034064245], [19.840954775119748, 16.001794185430562, -96.9119510681359], [19.77753722154724, 15.994645426299194, -96.8604934574447], [19.672728529108873, 15.991725355552884, -96.89671735788971], [19.733804621743904, 15.9898298108495, -96.82656474732802], [19.80900717958234, 15.98320861094267, -96.6758106898208], [19.68802722372845, 15.985524900752914, -96.78478962308385], [19.732393917541984, 15.987537967548302, -96.79634147430875], [18.32026889241815, 15.868541057051917, -95.89711016158039], [18.090142993517397, 15.886644041369092, -96.20478852368832], [17.613919318365728, 15.831147531064643, -95.73079527836985], [18.29568547238882, 15.889892533233072, -96.17944738499676], [18.21857460722059, 15.886644041369092, -96.15379121748354], [18.156009124456205, 15.834126350031799, -95.55113553477665], [17.646334788595762, 15.829498838555423, -95.69822469166974], [18.18153134641115, 15.81071392512116, -95.24927051280956], [18.353949272693672, 15.807816797104058, -95.15818257032], [17.234422565266517, 15.767358550728146, -94.87477954798773], [17.068058112444003, 15.791128492965997, -95.18749065495759], [16.681967492576224, 15.74938616058541, -94.80320831989758], [17.09866324231879, 15.737791056395178, -94.56910179372032], [18.08900141372705, 15.791128492966, -94.93931742337544], [16.611755970635997, 15.732075925533149, -94.5170420890794], [16.054637177012985, 15.709050559618861, -94.1788161536203], [17.6232399696057, 15.830424970718393, -95.71846086342764], [17.609465801855606, 15.830628542535111, -95.72636262024331], [17.74594309723748, 15.80835880314908, -95.31517817705591], [16.73334723271998, 15.683198369800571, -93.75080271091947], [16.304225092514056, 15.695564487350397, -93.92803389510826], [17.743948482521393, 15.761077962890539, -94.67898234452613], [16.914554507896707, 15.715706399789392, -94.21265420392497], [17.306633974575593, 15.732003998786537, -94.45226041555588], [18.203063742787563, 15.79388887821829, -94.95844600238559], [16.14284425192487, 15.681904896098471, -93.7903885871706], [15.844891399854486, 15.695564487350396, -93.97005273677519], [15.664816641674799, 15.678024474992176, -93.79082137243292], [16.1215907646779, 15.698936005417513, -94.00172850946673], [16.282609389330077, 15.695564487350397, -93.93001125236317], [16.203721038081753, 15.664367461682032, -93.58914426610926], [15.735251510823673, 15.672259008681666, -93.72004945415163], [16.281597694763263, 15.65248546593708, -93.41510723714], [16.366176142378066, 15.656153527404404, -93.4826355442228], [19.88798035035416, 16.113002341858657, -98.55106382187655], [19.552256182566676, 16.119708784470834, -98.95732435370293], [19.910774724703927, 16.103593749976564, -98.390197376586], [19.529126773033273, 16.109541538508317, -98.7803925666926], [19.49770489830507, 16.120508060240276, -99.01212799085258], [19.1079164603249, 16.085299695072333, -98.62410096393695], [19.576981599265796, 16.118597402781575, -98.91821214838453], [19.761918475874417, 16.076375051840948, -97.98611571700837], [19.63501213931742, 16.07757678239782, -98.09456695332271], [20.055769844511097, 16.105460379119446, -98.28564394137068], [19.69859552081157, 16.086451114749263, -98.21751727017657], [19.64259145563352, 16.07757678239782, -98.08906837147924], [18.035777244518712, 15.960612025860382, -97.37002906821233], [18.091057267987583, 15.9821228865247, -97.61183684640933], [17.7527475450882, 15.940691822853646, -97.27505590792502], [17.845757005715797, 15.937510507538478, -97.18301251501742], [18.453547159283268, 15.9821228865247, -97.41021100349751], [17.740857586408353, 15.935254860778814, -97.18559008208533], [17.548762708404215, 15.924294368493467, -97.07199285627446], [17.8161630864252, 15.938522744229667, -97.21229904912438], [19.23478181464251, 16.05448890882956, -98.07014572622077], [19.02241683392371, 16.07757678239782, -98.53898770094032], [18.643660207222833, 16.029767739371366, -98.1619426337626], [19.06173028429489, 16.013551649253582, -97.63755638892484], [18.607929570267633, 16.006334027883454, -97.76007410004462], [18.789652932549583, 16.024104977742933, -97.97882362762878], [19.31945962795118, 16.079507510566447, -98.36027668026155], [19.51249307823868, 16.07757678239782, -98.18345110284623], [18.439443237353327, 15.954554638912093, -97.06874922421073], [18.032667400937566, 15.921645693224397, -96.83396093049038], [18.05588321241569, 15.930323306204535, -96.97506884054651], [19.665341391339282, 16.059113033603733, -97.82083153236586], [19.57832179688691, 16.0552038018996, -97.83066384572327], [19.378855452310653, 16.030610165968966, -97.64006459829929], [18.932603536572465, 15.993088362673193, -97.34109661659224], [18.881641106537565, 15.982122886524698, -97.17209456209255], [17.196172684434845, 15.880060443821542, -96.48110099732507], [17.080391480720504, 15.886644041369092, -96.60573814663584], [16.910927082618482, 15.86689324872644, -96.43703953950343], [17.59719948996555, 15.886644041369092, -96.40052530583593], [17.619540286547803, 15.899305115014165, -96.6109880345375], [17.553047221116792, 15.867832215632317, -96.19328716184938], [17.977576645293745, 15.889892533233072, -96.30576124802506], [17.97115663059109, 15.886644041369092, -96.25203533317223], [16.073368755560686, 15.7808429233642, -95.31146680359603], [15.93289631046079, 15.791128492965997, -95.46342838079676], [15.779181595836585, 15.774507358823294, -95.31040828605539], [16.06308595638944, 15.766607348701509, -95.15090614652874], [16.518311159555942, 15.791128492965997, -95.32112440100323], [15.731346960974605, 15.762712244971526, -95.1154152881417], [15.351773330697798, 15.747022027389773, -94.88493143184094], [17.235460514726732, 15.84596750342297, -96.05814677147623], [16.80996356957273, 15.85512611986059, -96.33653226946457], [17.607032088349996, 15.830703114040212, -95.72821999856706], [16.717050781984863, 15.817021554958199, -95.7123262624579], [16.5828556802414, 15.774562623804728, -95.11568238059678], [16.037865989169113, 15.743016524073887, -94.75446551297189], [17.61013906952378, 15.830826395879988, -95.72845929906008], [17.28224864831919, 15.81485011505372, -95.5380783913901], [17.608376079390407, 15.830661932761275, -95.72719428217931], [15.456131800142805, 15.726009500048317, -94.52021733012884], [14.961984892717627, 15.72195591313632, -94.49690440492532], [15.653402183493057, 15.689717816564324, -93.92233501504255], [15.450498508949885, 15.695564487350397, -94.00613093591954], [15.578002994633746, 15.705533861863994, -94.16297605781008], [18.8989275148019, 16.11563715443605, -99.35372125531397], [18.794414944010608, 16.130806149115806, -99.71854957949078], [18.404662702090032, 16.09559725395208, -99.33048619559857], [19.00342802024, 16.10046833642156, -98.98890505012936], [17.193916561056366, 15.972747381426423, -97.99205525438578], [17.18480657379634, 15.982122886524698, -98.11591589659362], [17.044363876384406, 15.964921528079914, -97.97608175957349], [17.13497562612532, 15.96182222457638, -97.88641117308507], [17.41152016791939, 15.982122886524698, -97.98981218829091], [17.02640045329956, 15.959842878095495, -97.89523477941658], [16.845653734407733, 15.948945953047184, -97.77823266002966], [17.08060857628077, 15.963681806678501, -97.94021352497812], [18.41605576745014, 16.061452689112155, -98.75905185016197], [18.205181316602733, 16.07757678239782, -99.13186919446407], [18.018538089648096, 16.05401495807739, -98.94603472209344], [18.466427575872387, 16.036642233575584, -98.3842459247981], [18.974076087677336, 16.07757678239782, -98.57405755929224], [17.749343275697207, 16.01427487901904, -98.38055466233091], [17.25722897191898, 15.982122886524698, -98.07563276755248], [18.15753827502805, 16.048623422887175, -98.77168647465696], [18.700376353975283, 16.082725459243573, -98.8707142576175], [18.81004520318142, 16.07757678239782, -98.69305737479557], [17.597575151780124, 15.966689955119856, -97.6907790289276], [17.355496438575827, 15.945050105175092, -97.50829597314451], [17.495342578853666, 15.949496156904784, -97.52978726840837], [18.776645176174068, 16.05539088443565, -98.41480845469832], [18.06274545634665, 16.00255572650421, -97.99531988369786], [17.701062062731054, 15.982122886524698, -97.82876182522833], [19.03480312730865, 16.080151086622656, -98.57904874138984], [16.86743126044988, 15.923637121495085, -97.33114845544277], [16.2078773385377, 15.897671042944603, -97.1432198500242], [16.83790215522275, 15.880060443821542, -96.62336216928698], [16.522387902329267, 15.886644041369092, -96.82730882172166], [16.83985485749792, 15.898813373544064, -96.91206491866404], [14.800183693498244, 15.787185614439942, -95.66987633619124], [14.797878779051162, 15.791128492965996, -95.73933103701509], [14.661907983087891, 15.781488907239398, -95.60394942398828], [14.66272024472822, 15.78105368606232, -95.59614730270268], [14.947982689262261, 15.791128492965997, -95.70284343537905], [14.930428771361681, 15.791128492965997, -95.7071104818711], [14.65783219955717, 15.781077709584865, -95.5970210137154], [14.648868370855398, 15.780690535452878, -95.59096631445529], [16.453862010944935, 15.875324195620648, -96.71926559046851], [16.070719393101754, 15.886644041369092, -97.00665623163088], [16.01048557761822, 15.879622954437274, -96.94668341878419], [16.75479009905695, 15.856816692201352, -96.37863994070247], [15.959169842551166, 15.85059857373693, -96.4664940420492], [15.506383523880647, 15.842834244506909, -96.44476571887192], [15.251008721132827, 15.802145292126278, -95.8161836465438], [16.273181291067182, 15.871573685412832, -96.74619748534359], [15.335322493767165, 15.81937379049405, -96.09179475305304], [15.321566497708325, 15.828486766675212, -96.26074953406716], [15.217709843984737, 15.800714074888992, -95.803728935164], [15.379943882129282, 15.822688574272851, -96.13354593061825], [15.233993877885531, 15.812079007969766, -96.0011570336531], [15.207350741701674, 15.819620115905666, -96.14702869297247], [15.189348428147389, 15.799495074409196, -95.79312097240881], [15.075199643754898, 15.80240028869926, -95.872589710679], [14.876460239994309, 15.796596299212725, -95.81757199207547], [15.027639165176216, 15.793889665269452, -95.73263718525921], [14.908019417800217, 15.792499989391027, -95.73697438949131], [14.867726861955664, 15.791128492965997, -95.7223522053479], [16.266994877989575, 15.890319708560929, -96.99239496779224], [15.631314078157294, 15.785588114918431, -95.47327587292806], [15.181864328174507, 15.791128492965997, -95.64599095193199], [15.409033916592211, 15.770517786958875, -95.27683420725731], [15.072632185947995, 15.762099469963474, -95.16531554722754], [15.65971814230417, 15.777831585651835, -95.37752481923071], [14.906027947307695, 15.781054859495175, -95.53702401369232], [14.664940288425484, 15.779864155518078, -95.57482283122033], [14.658842968003034, 15.780536125677758, -95.58731214945942], [16.82522691708272, 15.859612020262794, -96.38407058322349], [15.886559040734888, 15.814578930514369, -95.8727426928573], [15.38883121601151, 15.791128492965997, -95.59568096770421], [15.216860964430689, 15.797995953327089, -95.75530117787993], [15.196307533435544, 15.797112547421396, -95.74761361983492], [15.132950640499368, 15.794837744214881, -95.72391636986667], [15.078004004353854, 15.791680727426689, -95.68106892250253], [15.086934745002527, 15.791128492965997, -95.66906665202124], [15.14559909415375, 15.791128492965997, -95.65480638792114], [15.15152939861918, 15.753313261678295, -95.00958790650527], [15.030182679211745, 15.750818287681641, -94.97851674044739], [14.87132598739576, 15.761114423151247, -95.19703767018251], [14.717548795997821, 15.75167577944179, -95.06949556183478], [14.635628304931304, 15.768051537377605, -95.3677585614273], [14.589261623968193, 15.777041013967695, -95.53161785301765], [14.500321614527708, 15.754116819877432, -95.13271031239314], [14.692829135813229, 15.764920920007757, -95.30693849564246], [14.449566455810242, 15.770961726788729, -95.28907703199128], [14.259116128934822, 15.781727349389218, -95.20290293056307], [15.068085974577034, 15.73589150585963, -94.72274710349403], [14.928402995680964, 15.723769795230785, -94.53063583676247], [14.85792748870122, 15.739391102292343, -94.82072026518992], [14.755575483914349, 15.731300546815149, -94.70423292171499], [14.635870911548377, 15.744883696631245, -94.95636658322074], [14.468973712680084, 15.746036931075997, -94.99211088466154], [14.736934950621933, 15.741288405945856, -94.8832832354992], [14.409470485380872, 15.760627033440354, -95.1092413758726], [18.195578046829034, 16.125931152142574, -100.06010807243341], [18.0910141910701, 16.141098416228697, -100.42494063027128], [17.70130500540639, 16.10588889108322, -100.03683400753813], [18.300127550502342, 16.110764098050367, -99.69528992754249], [16.263553200778492, 15.978334514403375, -98.55791223163624], [16.27859417135331, 15.982122886524698, -98.61997364796049], [16.142468262751546, 15.970757770160729, -98.48440751660556], [16.36959716823062, 15.982122886524698, -98.56935553034263], [17.791533752662378, 16.07162882082502, -99.35086517426276], [17.871122810579674, 16.059732897679414, -99.13093804060834], [18.09239219343947, 16.07757678239782, -99.21369454636934], [17.411086253967994, 16.07757678239782, -99.7079629358106], [17.325542489468393, 16.04540724785418, -99.1765807425051], [16.694418403857508, 15.998912063485307, -98.69084125109634], [16.990075715410857, 16.033736023441726, -99.15678179014651], [17.38793841569454, 16.07757678239782, -99.72475604457367], [17.0625025323431, 16.048906580670682, -99.40065841934424], [16.65525740895422, 15.996708453747157, -98.67619472811863], [16.72925127764778, 16.002735477951582, -98.74027736193561], [16.75039101470552, 16.01376969815011, -98.94054069575938], [16.69387733027934, 16.01643149280994, -99.03354907860947], [16.58992678724542, 15.993032265372667, -98.65176055696519], [16.48299886427717, 15.993427382808001, -98.71865970346946], [17.847812526080524, 16.091210334192827, -99.65088359213402], [17.629616475498757, 16.0994119611332, -99.96544027535353], [17.51530308201286, 16.08835128725569, -99.83831504216158], [17.50520651657184, 16.088065118236052, -99.8415419153206], [17.450138124467614, 16.082407900230706, -99.77341805609142], [17.43412160286302, 16.08158180005825, -99.77074931714301], [17.41286212688044, 16.079069044134748, -99.73629534493968], [17.39337852381032, 16.078048549948182, -99.73017378186545], [17.397467731157615, 16.07773403824794, -99.72096425408324], [16.923544188865595, 15.976389100376435, -98.18858588387853], [16.541462116416046, 15.982122886524698, -98.47375999546848], [16.708199881723512, 15.965127466432275, -98.11313249101066], [16.401319799685865, 15.964519498077307, -98.22445554897102], [16.363711836771017, 15.974880760321858, -98.43799464784692], [18.046808602567495, 16.06722535513811, -99.1056341258838], [17.262069598859533, 16.0153811384583, -98.67149798117204], [16.63037930974259, 15.99258113458572, -98.61359865822782], [16.595548770871897, 15.990621201881506, -98.6005717601841], [16.51853616485052, 15.986660869208793, -98.57176843415903], [16.424219590890097, 15.984827455729013, -98.5897847500434], [16.44509295851225, 15.983024409592803, -98.54430009195151], [18.234078737377413, 16.08358360624924, -99.22534997881066], [16.472525095132116, 15.949668090228915, -97.93890357679369], [16.17060175130275, 15.935538819562257, -97.81402252138044], [16.12120036996358, 15.951409080431437, -98.13653622369644], [15.988994663770558, 15.957944299682314, -98.33156503208016], [15.90261737230718, 15.928285014674577, -97.82823049944504], [15.770021410184956, 15.934583204203852, -97.99504847665624], [15.629881264111233, 15.930348266301058, -97.97392837929604], [15.558592340550858, 15.92175523615746, -97.84646999580372], [15.564411975745552, 15.92589450818633, -97.88990744241096], [15.504762322574562, 15.925579258556043, -97.84932395213315], [16.29179129430188, 15.922277365262516, -97.53616644434796], [15.94303235295934, 15.906953645496019, -97.40919074595749], [16.022443827634678, 15.920723113766757, -97.62100085343431], [16.064948876802365, 15.932679006089842, -97.81962401848631], [15.911192329474256, 15.90772098391891, -97.44116612791298], [15.931494257467973, 15.919486936680908, -97.64860815450527], [15.84721845128809, 15.909262742040305, -97.50541197217673], [15.746984055573932, 15.920301749028747, -97.74531656177291], [15.540253552848089, 15.9195447138539, -97.81368184136028], [15.88623856087545, 15.922661038417488, -97.73278850007875], [15.53453607199117, 15.922293346196572, -97.83649192976571], [15.881384364793815, 15.885405392655626, -97.06703712326738], [15.902619097368243, 15.882928095228696, -97.0290057060265], [15.960188411503589, 15.886644041369092, -97.05054559929626], [15.78134558550961, 15.886644041369092, -97.12156006447941], [15.799742816616765, 15.881895779936395, -97.03649046380959], [15.715263766972441, 15.876115203211398, -96.95890562092288], [15.500877545830928, 15.876267608443625, -97.04676781590221], [15.239595642733335, 15.855667147824919, -96.7809316293647], [15.267305188108324, 15.886644041369092, -97.32567394884187], [15.173670175050084, 15.863386861841107, -96.93439011008466], [15.014109694308594, 15.84784939632931, -96.6965647520474], [15.950798701987736, 15.89291136250958, -97.16284580508564], [15.86154982142844, 15.886644041369092, -97.08971276567084], [15.878523422647737, 15.900439556928006, -97.32397231278328], [15.846585455423984, 15.901209255776102, -97.35604605485638], [15.627473233038732, 15.902746912895882, -97.47455560872218], [15.341075342509154, 15.895536154320235, -97.45756855687233], [15.489389337572383, 15.888867069606876, -97.27778609575886], [15.567831234162439, 15.886644041369092, -97.20634181284184], [15.389060760587643, 15.912523020026766, -97.6511154792896], [15.282692178963643, 15.916906860546833, -97.6281670058325], [15.276520406042764, 15.904894304518734, -97.50683604024974], [15.256750928900502, 15.9120708240479, -97.56393757401914], [15.2110402016951, 15.911268263169507, -97.55680967597515], [15.294966978886748, 15.895691500069354, -97.430026181988], [15.204003533635406, 15.902578722116038, -97.44921346591892], [15.061148338695435, 15.903220380113439, -97.40753419860886], [14.790925589136663, 15.88140267112941, -96.91999519692101], [13.945925579919715, 15.893676974126578, -96.29689746120057], [14.889323249823178, 15.85235869426366, -96.6498751790327], [15.0569127107467, 15.862541843612902, -96.89070462664067], [14.701234733758833, 15.787915297723798, -95.70667892416161], [14.64391743913745, 15.791128492965997, -95.77675631148145], [14.641417908816187, 15.783986570519952, -95.65017249338979], [14.610977842184006, 15.782638346421532, -95.62901792363415], [15.986003119897951, 15.883959783101037, -97.00822273893445], [15.824872032036717, 15.872352631298172, -96.86839544586151], [15.98960819434403, 15.880262659106583, -96.96261676470206], [15.500398106543757, 15.853127105317245, -96.63180285788545], [15.458378637613615, 15.865072206875466, -96.86279055767986], [15.306722879939239, 15.842211559320315, -96.51287510352104], [15.044135522751906, 15.826863396743738, -96.31565470459265], [14.700199198695877, 15.799751991163049, -95.9165983442863], [15.227097619077654, 15.841695430026759, -96.53523281680957], [14.7546139142197, 15.794651319076943, -95.81256442121457], [16.05774234127731, 15.889400791762968, -97.05956561582295], [15.992184221966214, 15.886644041369092, -97.0378407823405], [14.686914952368005, 15.848631440109541, -96.44052905940784], [14.565627721154744, 15.864574207440548, -96.528762616826], [14.60579388612609, 15.827388203008878, -96.14294938236482], [14.766876800600736, 15.826970278021005, -96.27297155192403], [14.624957974049941, 15.809462474159476, -95.95887010188898], [14.423955009963358, 15.851002234738337, -96.24926496919575], [13.99236307673786, 15.891496151565933, -96.31427232036297], [14.532035355834736, 15.821045344083208, -96.01107555722923], [14.587595738670254, 15.819485579041183, -96.03763168049433], [14.65635820396109, 15.800114319429506, -95.8840749192189], [14.261348568492465, 15.846911302109135, -96.05709784134558], [14.406364364228839, 15.815378176864808, -95.83450125598351], [14.430054465741183, 15.812959864141144, -95.82874261195163], [14.557741308690828, 15.808512146330592, -95.89386114563781], [14.420005053987582, 15.814858209015853, -95.82681329982688], [14.423596331992718, 15.814495757763277, -95.81719603154549], [14.522414862510777, 15.801566555124303, -95.76766994965195], [14.592091213171756, 15.785842771078144, -95.6479848436292], [14.61566216483107, 15.78653896850378, -95.6845863595816], [14.621721488832401, 15.78150282508051, -95.60787272274798], [14.605318253457803, 15.781179593367122, -95.60363393015452], [14.005114037909545, 15.869599244291104, -96.04886200022543], [13.663052169580078, 15.899742582993039, -96.01518728349217], [14.159044480005596, 15.837729388280877, -95.80363805537955], [13.556216394256003, 15.901257252060635, -95.90879083846743], [14.577498258791296, 15.784363761015811, -95.61172605532545], [14.596471391901215, 15.78350788068148, -95.62309068818583], [14.61448274942713, 15.779637047595898, -95.57540603254249], [14.227165885865116, 15.811357919899953, -95.54548174843589], [14.515832761478347, 15.778083317125288, -95.45850716938757], [14.571977724423908, 15.780166910113223, -95.55137125197129], [18.059077623564587, 16.14085112878807, -100.44339827037031], [18.052462319099977, 16.14166201930762, -100.46364698600699], [18.03375636052369, 16.1397929508279, -100.44160719483264], [17.89673332503782, 16.13864564343235, -100.54266269881214], [17.78635636797204, 16.14282274159148, -100.73081926795814], [17.714358252555567, 16.130304862002397, -100.53457734645082], [17.65503327830796, 16.13558199660334, -100.6823648124361], [17.66337249237249, 16.144548488364197, -100.85429596041035], [17.456046000331753, 16.124651894455283, -100.6097666749251], [17.35076605922253, 16.15857648441843, -100.8469981936787], [17.635476792073487, 16.149291644935523, -100.88230344342199], [17.387462701150426, 16.191461931141262, -101.13131136807412], [16.997807732927008, 16.16103261974576, -100.74315031163131], [17.382317010739193, 16.130784607537066, -100.63122765158737], [17.53430307387923, 16.13731915882302, -100.7443984325862], [17.880347665141926, 16.123189179414776, -100.23655743614019], [17.695315103567534, 16.10597645951929, -100.04284791191873], [17.779674281512627, 16.12135009018489, -100.28756869596921], [17.577388987449346, 16.106490839120177, -100.16124657777155], [17.877552703467003, 16.124185339454694, -100.25756444887237], [17.51355441962481, 16.117935172714986, -100.43472188165529], [17.30642443816257, 16.110293095282078, -100.43329692747368], [17.253426057140445, 16.13257091460356, -100.59540463801004], [17.020009391401953, 16.0714429089953, -99.87182739316565], [16.8837651227399, 16.05917516219026, -99.73096707611006], [17.21074914371136, 16.07757678239782, -99.85330190189782], [16.965513907754595, 16.07757678239782, -100.03121320148907], [16.85255971009509, 16.06241431757553, -99.80917929332877], [16.708400099790776, 16.050491008138508, -99.66535760238712], [17.69388969525626, 16.10560534523125, -100.03681134813108], [17.68504897679486, 16.104950685091243, -100.0307521249364], [17.67218193211138, 16.10474013915333, -100.03809022536106], [17.667045901468374, 16.10609976639458, -100.07123039345412], [17.62186985143597, 16.10106555196002, -100.00711486195566], [17.691629827290164, 16.10560823280153, -100.03850583454046], [17.59276781491412, 16.101880141137325, -100.05072368004687], [17.504766519302773, 16.09386440707453, -99.96330288700618], [17.373682529683922, 16.095734357272534, -100.09551836157965], [17.062332737482375, 16.08686823820199, -100.14540526166341], [17.27580820015757, 16.08118084658309, -99.87764250518669], [17.515374295548902, 16.095708717373334, -99.9922160103764], [17.128600997276475, 16.08080066239518, -99.97689071755926], [17.12669225986275, 16.108762059046146, -100.35033438704747], [17.124674184571017, 16.14119609093581, -100.61577548482808], [17.013337679235033, 16.096692041526378, -100.2068598742247], [16.975995316829035, 16.13662784056423, -100.52004259200598], [16.76816167058308, 16.144208286441536, -100.51438469733984], [17.013728108157334, 16.08704572326385, -100.12782611245905], [16.829422441910342, 16.112283563424395, -100.2675286137819], [16.570676510068658, 16.13191774151722, -100.31765668207402], [16.40150948461835, 16.082086769265967, -99.7939121178496], [15.439187860033327, 16.067853180770687, -99.19050608586002], [16.630659660616825, 16.051536830246977, -99.63627250197531], [16.76819122272073, 16.059873546188275, -99.77761443528384], [16.128599620395796, 15.97709393625421, -98.60991383374305], [16.033925632204912, 15.973372201806718, -98.5933850962962], [16.059410415273412, 15.982122886524698, -98.74188907410996], [16.030130402947293, 15.976700597373714, -98.65522582797148], [15.997055161363557, 15.974606703789728, -98.63040331350828], [17.245541944380463, 16.068020048488773, -99.64132994895665], [17.286184885103747, 16.07757678239782, -99.7985753829521], [17.02741580283549, 16.055933360093302, -99.56341037178274], [16.524809427887345, 16.01806868723762, -99.15834729583541], [17.671990152566668, 16.103417179102554, -100.01100880260935], [17.610435455075358, 16.09837332910513, -99.96121229439154], [17.5164911225434, 16.09114421933221, -99.89567724535635], [17.41298306282162, 16.085094469521668, -99.85580971801085], [17.34523169665365, 16.08502668682433, -99.90361598035588], [17.307960815852464, 16.080324239857724, -99.83731340647662], [17.492439218447515, 16.091721133366992, -99.92970293521797], [17.34386566011527, 16.078381588650387, -99.77270465396697], [17.309666904221228, 16.08217725775505, -99.87285729733973], [17.263202532495644, 16.078847086726856, -99.84046343240202], [17.23530961765307, 16.07757678239782, -99.83548396549689], [16.307257793737733, 16.039955114658518, -99.37467645198119], [16.184232983059452, 16.05752179384832, -99.46925048767707], [16.106880737536926, 16.01079727203604, -99.01850636629115], [16.376337728304485, 16.02375323989925, -99.26550638619088], [15.866644604585598, 16.032392026942563, -99.08979941748089], [15.670625891769829, 16.028501351792652, -98.95814064179447], [15.932295550528458, 15.997286536265223, -98.81259350578173], [16.032862234446267, 15.996735564941996, -98.85766298206094], [15.827184554399869, 16.007177328565763, -98.840011647602], [15.878632220901322, 15.994441552037207, -98.74930079522979], [15.964503981080687, 15.987538445511664, -98.73590042233423], [15.987677737619556, 15.975900344731393, -98.63981831421545], [16.01471443808551, 15.97764358483309, -98.6707035672779], [16.06425416871117, 15.970491212285047, -98.5229566969324], [16.01636861117704, 15.967343664887693, -98.49107747789542], [15.992318041842417, 15.970218239750592, -98.55273475475023], [15.921922762624163, 15.965550388518231, -98.49607313130103], [15.494081336680411, 16.05387469684115, -99.09088371867283], [15.372430258238081, 16.065269557950074, -99.12400442836396], [15.544045162983073, 16.015565739643684, -98.75503369004171], [14.801570639304094, 16.02557387679461, -98.55533344804451], [15.887921287983797, 15.967966005319, -98.49787161779022], [15.948644237397769, 15.970937344223517, -98.56604159420375], [16.049277179233048, 15.965348578243578, -98.43568334219371], [15.889291825420749, 15.955296654847324, -98.32316100514316], [15.383891523679466, 15.981866208600813, -98.31509310701573], [15.462182643750513, 15.9326537805394, -97.89207425521242], [15.681334056208854, 15.944453013502104, -98.14185426714657], [15.366265870370624, 15.93713330712426, -97.88963566269244], [15.304185501575994, 15.958834370212706, -98.05070451969915], [15.289849786961312, 15.926136963535203, -97.76887851624502], [14.971557702126137, 15.970345844361267, -98.04422346015971], [14.411642091314265, 16.022508631835127, -98.1668998607223], [15.050540491475019, 15.928943796592298, -97.67930095608762], [14.554399042461784, 15.978561406006053, -97.80100693920853], [14.051718427491435, 16.019744078223063, -97.80835612079457], [14.703695159566417, 15.944125039464346, -97.5494708192297], [13.999454784489421, 15.992358059360589, -97.45350538743249], [13.242950766410413, 16.013205060322186, -97.00268922227322], [15.35910142949984, 15.924546109013853, -97.74878982473689], [15.208530664773768, 15.921393796018481, -97.65828903853507], [15.006606047857993, 15.920370914863954, -97.54827891247533], [14.238429961147997, 15.938681954896456, -97.06414792532809], [13.347390714839042, 15.975886050666347, -96.63803828310141], [12.853295798186995, 16.02077611861302, -96.61452816583041], [13.45181259078757, 15.939087577059098, -96.27340548849946], [16.788418451859705, 16.259916766565727, -101.47281490715928], [16.683687013372214, 16.31110722600426, -101.83768413749851], [16.294105641056476, 16.277181142558117, -101.44944921590518], [16.89312535837797, 16.21105331807517, -101.10797029853687], [16.343608258049322, 16.21117790254396, -100.89901671479551], [15.753374205429255, 16.24460691193509, -100.91058662792793], [16.32914545278456, 16.16517706164429, -100.49288070371762], [15.606099936669116, 16.199116743837457, -100.43332562039245], [14.735780151793529, 16.187435918985386, -99.89650952953181], [16.815479942390073, 16.15559852612803, -100.62730367866565], [16.68047042366013, 16.161659009536155, -100.6243760270258], [16.587113514274105, 16.150738319875824, -100.48732452753931], [15.768697493670018, 16.138142773617027, -99.97438825029587], [14.757750457519423, 16.13347508052476, -99.4494105456206], [14.098283360731413, 16.145136141828804, -99.26121602146998], [14.779680620022944, 16.079959509365555, -99.0023518517915], [13.813270623834656, 16.10114243322392, -98.5082752682037], [12.539957871468465, 16.13271728066367, -97.70827633509661], [13.52815975906099, 16.057243031737332, -97.75543300180478], [12.644428379010535, 16.09539938880605, -97.34366899029105], [12.150376499152728, 16.140275826450573, -97.32004141350328], [12.748874354583378, 16.058085668461548, -96.9790862672023], [16.08443575542265, 16.29209369272762, -102.17918695655327], [15.97954604785273, 16.25220008859172, -102.5441107660622], [15.590074205043004, 16.25220008859172, -102.15576596609908], [16.18928895315723, 16.31172319805678, -101.81429977316759], [15.305455559967859, 16.292087487487745, -101.40253398275028], [14.032186833804099, 16.25220008859172, -100.60238676624661], [15.020690875551367, 16.254460275047173, -100.64944850389452], [14.054278752813453, 16.248886552584594, -100.15526991766482], [13.394869272842728, 16.25220008859172, -99.96691345721604], [14.07631092845589, 16.19882892702003, -99.70821300273929], [13.11004484505932, 16.220676547636582, -99.21388791201652], [11.836981901603822, 16.25220008859172, -98.41353425736357], [12.825074377934568, 16.1766845034655, -98.46100887131006], [11.941483277288794, 16.212372485445027, -98.0490000166202], [11.447510058794096, 16.25220008859172, -98.02518945740044], [12.04594814313843, 16.17757770809045, -97.68450240200009], [15.399056705602442, 16.32845185483133, -102.86622182551626], [15.306156700056341, 16.366577737951136, -103.21879780576359], [14.911467368898261, 16.366577737951136, -102.835756904723], [15.493695873931332, 16.290325971711525, -102.51187787896141], [14.611417206069069, 16.32845185483133, -102.09837205712756], [13.33271004426594, 16.366577737951136, -101.30359330056064], [14.318323694371015, 16.290325971711525, -101.3539153443021], [13.350583884389403, 16.32845185483133, -100.86092638855503], [12.686854775098173, 16.366577737951136, -100.67679909885786], [13.371303627248333, 16.290325971711525, -100.4153664407735], [12.396607166135587, 16.32845185483133, -99.92944935025646], [11.108097450465852, 16.366577737951136, -99.14463549469549], [12.113316208304134, 16.290325971711525, -99.17502773642502], [11.219495823792483, 16.32845185483133, -98.77325478190465], [10.713408119307772, 16.366577737951136, -98.7615945936549], [11.332633359901896, 16.290325971711525, -98.4001061028063], [14.766521317351641, 16.43706654013434, -103.52285217981769], [14.700814090066812, 16.472310941225945, -103.85917239020195], [14.29259316193177, 16.472310941225945, -103.49058634348754], [14.836739076962123, 16.401822139042743, -103.18171368465805], [13.954589993407211, 16.437066540134346, -102.78086180161347], [12.659709449391602, 16.472310941225945, -102.01624215662984], [13.634628954185269, 16.401822139042736, -102.05186412063783], [12.661377020215449, 16.437066540134346, -101.57764560336862], [11.991711566988808, 16.472310941225945, -101.41310135291535], [12.67042546211764, 16.401822139042736, -101.13116458411127], [11.679131398845207, 16.43706654013434, -100.67621920594361], [10.358827854448641, 16.472310941225945, -99.93875716605766], [11.384593360004223, 16.401822139042736, -99.92006391987034], [10.472510743742697, 16.437066540134346, -99.55118792669879], [9.950606926313599, 16.472310941225945, -99.57017111934324], [10.590704165362409, 16.401822139042736, -99.15880040256455], [14.174882531543991, 16.543187954884992, -104.18846195496498], [14.122264738762148, 16.578626461714517, -104.53024714658162], [13.701568765803009, 16.578626461714517, -104.17596632811136], [14.231658672600531, 16.507749448055467, -103.8419083539336], [13.33764893390041, 16.543187954884996, -103.47513190860973], [12.018784873966448, 16.578626461714517, -102.75884305423028], [12.990362495096605, 16.50774944805547, -102.75522385144922], [12.002955868403182, 16.543187954884996, -102.31806533889484], [11.330373281851491, 16.578626461714517, -102.1791108058244], [11.993931432743969, 16.50774944805547, -101.86948477178987], [10.989891412951742, 16.543187954884996, -101.45139989689436], [9.64758939001493, 16.578626461714517, -100.76198753194332], [10.666042937150793, 16.50774944805547, -100.70461535030545], [9.744436887173121, 16.543187954884992, -100.36948380382466], [9.226893417055791, 16.578626461714517, -100.40770671347306], [9.84544273260601, 16.50774944805547, -99.97221166629133], [13.577588161101914, 16.654795814973287, -104.90472054320192], [13.518030789205346, 16.692880491602672, -105.2661676929463], [13.092468955338248, 16.692880491602672, -104.91774679007783], [13.63876748663447, 16.616711138343902, -104.54132008825694], [12.728086447003705, 16.654795814973287, -104.2059254322644], [11.390221619869859, 16.692880491602672, -103.524063178604], [12.370191753213104, 16.616711138343902, -103.48629085364854], [11.367618067913943, 16.654795814973287, -103.07894203861179], [10.69384770990552, 16.692880491602672, -102.95391988300105], [11.34766862190782, 16.616711138343902, -102.63062458101858], [10.338607122064714, 16.654795814973287, -102.23108898678423], [8.99160037443713, 16.692880491602672, -101.56023627152722], [9.98985434876785, 16.616711138343902, -101.50044486976498], [9.068409435007366, 16.654795814973287, -101.17801305737642], [8.566038540570032, 16.692880491602672, -101.21181536865875], [9.146840449213585, 16.616711138343902, -100.79383653802505], [12.947328520649492, 16.770772832866733, -105.67546281232819], [12.873512629531923, 16.809719003498763, -106.05583128967291], [12.450442143211205, 16.809719003498763, -105.70438945436534], [13.020313962584934, 16.731826662234702, -105.29610131246316], [12.100357098825926, 16.770772832866736, -104.97358611919276], [10.758160197928326, 16.809719003498763, -104.29862211313508], [11.746950257712143, 16.731826662234702, -104.24681069393898], [10.738081618764204, 16.770772832866736, -103.84874025509332], [10.06586303849442, 16.809719003498763, -103.72353547354089], [10.7166441227566, 16.731826662234702, -103.40050617838199], [9.71109728053716, 16.770772832866736, -102.99840782961752], [8.373581093211541, 16.809719003498763, -102.31776813231063], [9.353009725851397, 16.731826662234702, -102.27730809561297], [8.438564024846498, 16.770772832866733, -101.94811023361365], [7.9505106068908225, 16.809719003498763, -101.96632629700306], [8.502716507299327, 16.731826662234702, -101.57945931239634], [12.269232207010711, 16.88249666461754, -106.48613452759996], [12.17378950230961, 16.918885495176937, -106.882672862676], [11.760394489190599, 16.918885495176937, -106.51989943045096], [12.361449753977908, 16.846107834058156, -106.09337339149641], [11.439217023038786, 16.88249666461754, -105.76436486212238], [10.106814436714554, 16.918885495176937, -105.06880570155083], [11.10513892595136, 16.846107834058156, -105.02393908968376], [10.098441501478472, 16.88249666461755, -104.61420142116829], [9.430349869792536, 16.918885495176937, -104.47517644881894], [10.084791035405095, 16.846107834058156, -104.16577801183165], [9.090994241867817, 16.88249666461754, -103.74093154742621], [7.776769817316491, 16.918885495176937, -103.02408271991881], [8.738737983007484, 16.846107834058152, -103.02179544192343], [7.837908571575171, 16.88249666461755, -102.66772004664108], [7.3633748041974805, 16.918885495176937, -102.66130928769377], [7.895822168099948, 16.846107834058152, -102.31513457233582], [11.529799843022396, 16.98715012519766, -107.31715391815935], [11.406188858424876, 17.021282440208026, -107.72483826970407], [11.0094211683327, 17.021282440208026, -107.34395062209796], [11.647868386610972, 16.9530178101873, -106.91550763840831], [10.7307220218291, 16.98715012519766, -106.5614166947408], [9.422350407963997, 17.021282440208026, -105.8204000316735], [10.429853111289717, 16.9530178101873, -105.80303505455844], [9.434086344163905, 16.98715012519766, -105.36211168960504], [8.773094187813165, 17.021282440208026, -105.19712933559077], [9.436752831440085, 16.9530178101873, -104.91370382865352], [8.463155828350054, 16.98715012519766, -104.44862817652535], [7.186023427444461, 17.021282440208026, -103.67357874516631], [8.131047704851163, 16.9530178101873, -103.72427930463469], [7.250682994037746, 16.98715012519766, -103.33011752088176], [6.789255737352285, 17.021282440208026, -103.29269109756021], [7.309800119622086, 16.9530178101873, -102.99269436839093], [10.719787589120655, 17.085961078288026, -108.14497772323273], [10.563455208644932, 17.118300397328024, -108.55680288506899], [10.189718700292152, 17.118300397328024, -108.15329201492511], [10.868442909016578, 17.053621759248024, -107.74069363557571], [9.964637511835297, 17.085961078288022, -107.3454970571242], [8.694772666881036, 17.118300397328024, -106.53924853434958], [9.708848081059244, 17.053621759248024, -106.56786639604036], [8.733442303292023, 17.085961078288022, -106.07953552853058], [8.083203835031036, 17.118300397328024, -105.87895801956867], [8.759549476936066, 17.053621759248028, -105.63216246227766], [7.8148519414880395, 17.085961078288022, -105.11366729805086], [6.588257801619919, 17.118300397328024, -104.26491453899314], [7.515791805625848, 17.053621759248024, -104.37854087325007], [6.662934174110507, 17.085961078288026, -103.93329898433625], [6.214521293267141, 17.118300397328024, -103.86140366884926], [6.729933486021295, 17.053621759248024, -103.60922450385858], [9.83710983672431, 17.180621536115684, -108.94427005903246], [9.646685486121555, 17.211782105509517, -109.35197329954288], [9.301188815406439, 17.211782105509517, -108.92403399248548], [10.01812090811451, 17.149460966721858, -108.54470963082652], [9.136703216081521, 17.180621536115687, -108.09653425722216], [7.919202132545973, 17.211782105509517, -107.21227676425586], [8.934564499906386, 17.149460966721858, -107.30160577117685], [7.989272914510021, 17.180621536115687, -106.75451258074064], [7.353843944103055, 17.211782105509517, -106.51201244361648], [8.043940148671709, 17.149460966721858, -106.31007299917826], [7.13630168012556, 17.180621536115687, -105.73040855952401], [5.971857261242588, 17.211782105509517, -104.80025521538687], [6.881106299297848, 17.149460966721858, -104.98137592464957], [6.062158551129993, 17.180621536115687, -104.47916188756983], [5.626360590527471, 17.211782105509517, -104.37231590832947], [6.1430465618048435, 17.149460966721858, -104.1662113720573], [8.888563757491061, 17.2731563072725, -109.6916388575453], [8.666504040793322, 17.30384340815399, -110.0872494911886], [8.35250174555831, 17.30384340815399, -109.63569378190441], [9.100125349028767, 17.24246920639101, -109.30390035797758], [8.250061041861004, 17.2731563072725, -108.79639957305251], [7.0964925646182655, 17.30384340815399, -107.82947094476766], [8.105627837523558, 17.24246920639101, -107.988593900503], [7.199455108041739, 17.2731563072725, -107.37743643710871], [6.582670626960975, 17.30384340815399, -107.09056160230263], [7.285238901203335, 17.24246920639101, -106.93828360339165], [6.421058672361653, 17.2731563072725, -106.295637603695], [5.326661446020929, 17.30384340815399, -105.28433876516588], [6.217454217122191, 17.24246920639101, -105.53220214138975], [5.437059286016479, 17.2731563072725, -104.97245901214482], [5.012659150785918, 17.30384340815399, -104.83278305588169], [5.536959000851993, 17.24246920639101, -104.66845139319935], [7.889823113047534, 17.36582260335601, -110.36921627144706], [7.642491204740612, 17.396812200957022, -110.74629622499305], [7.3604740936086674, 17.396812200957022, -110.27410309815954], [8.1264932933201, 17.334833005755, -109.99901545708418], [7.315127162749289, 17.36582260335601, -109.43170915696317], [6.232405649080889, 17.396812200957022, -108.38533059082557], [7.227133319752489, 17.334833005755, -108.61683177249921], [6.366607105763802, 17.365822603356012, -107.94248415477587], [5.770923103592253, 17.396812200957022, -107.6126509287344], [6.483362098390498, 17.334833005755, -107.51089449193489], [5.6654827965392345, 17.36582260335601, -106.80903031747914], [4.642854659064474, 17.396812200957022, -105.72387842140043], [5.517395577348792, 17.334833005755, -106.03292626295632], [4.776784551005978, 17.365822603356012, -105.41996749371107], [4.36083754793253, 17.396812200957022, -105.25168529456693], [4.900052714913126, 17.334833005755, -105.12293570520484], [6.869075933706777, 17.461757539885664, -110.96521593791668], [6.609538476645519, 17.49423020934998, -111.31850513164446], [6.355198119734203, 17.49423020934998, -110.83084645711254], [7.119387806027827, 17.42928487042134, -110.61708192675503], [6.351169635143936, 17.461757539885664, -109.995053771419], [5.337836692088939, 17.49423020934998, -108.88021175898488], [6.310238811592832, 17.42928487042134, -109.17988181598999], [5.49729524064978, 17.46175753988566, -108.44925572894466], [4.921643380779513, 17.49423020934998, -108.08222483702356], [5.641657377817552, 17.42928487042134, -108.0267354521945], [4.865616145835339, 17.46175753988566, -107.27548863488461], [3.9042819531342494, 17.49423020934998, -106.1315901388959], [4.7726865719303255, 17.42928487042134, -106.48937316301026], [4.065692736140552, 17.46175753988566, -105.83313334155343], [3.6499415962229333, 17.49423020934998, -105.64393146436399], [4.217877934406645, 17.42928487042134, -105.53983172677711], [5.852288677590017, 17.562789685304843, -111.48628123113122], [5.590096766462629, 17.59706942328228, -111.81930450361952], [5.357230789661902, 17.59706942328228, -111.32103405812968], [6.107322462013873, 17.52850994732741, -111.1567952156289], [5.379398597285031, 17.562789685304843, -110.49327759713752], [4.425766882458989, 17.59706942328228, -109.32795227617032], [5.372933898094043, 17.52850994732741, -109.67967016408926], [4.60277234680797, 17.562789685304843, -108.90692155775042], [4.044713465875979, 17.59706942328228, -108.51260063809605], [4.768064512914811, 17.52850994732741, -108.49167907803484], [4.026535468442853, 17.562789685304843, -107.7047814437521], [3.113249558673067, 17.59706942328228, -106.51951885613668], [3.97972496419561, 17.52850994732741, -106.91111127735205], [3.299305031226552, 17.56278968530485, -106.22411913522649], [2.880383581872339, 17.59706942328228, -106.02124841064685], [3.478202377076508, 17.52850994732741, -105.93225667130226], [4.8443956984052035, 17.66801245911347, -111.9501676750762], [4.57937808052121, 17.703483977029062, -112.26857566720584], [4.363712248231771, 17.703483977029062, -111.7626228544032], [5.103679934785434, 17.632540941197874, -111.63432047205079], [4.407330652322561, 17.66801245911347, -110.94082283857517], [3.5010489190740133, 17.703483977029062, -109.73881160319264], [4.428015530398301, 17.632540941197874, -110.12926597916423], [3.691652331680826, 17.66801245911347, -109.32588423265649], [3.148141193509476, 17.703483977029062, -108.9108888186065], [3.872873847281481, 17.632540941197874, -108.91714724429096], [3.1594441745790576, 17.66801245911347, -108.10352234136616], [2.2854778643517184, 17.703483977029062, -106.88707756739593], [3.1478136296335886, 17.632540941197874, -107.30639902054288], [2.489513151695688, 17.66801245911347, -106.5959070593753], [2.069812032062279, 17.703483977029062, -106.3811247545933], [2.687815057535895, 17.632540941197874, -106.30729734045894], [3.8425655880517304, 17.776112537916408, -112.37160474426209], [3.5749512276723134, 17.812426818360077, -112.6789825191993], [3.373367455961667, 17.812426818360077, -112.16725604638114], [4.105485928238216, 17.739798257472735, -112.0661515226634], [3.4347040244375058, 17.776112537916404, -111.35007635196428], [2.56703236911908, 17.812426818360077, -110.12035015510853], [3.477264512141621, 17.739798257472735, -110.54059487090144], [2.7684164345346143, 17.776112537916404, -109.71404710717515], [2.237168015410749, 17.812426818360077, -109.28297956322427], [2.9621193759980797, 17.739798257472735, -109.31089332834114], [2.2720473791627955, 17.776112537916404, -108.47664735126081], [1.430832928568162, 17.812426818360077, -107.23607367195166], [2.2881506621431185, 17.739798257472735, -107.67801335265136], [1.648519983259132, 17.776112537916408, -106.94916614616035], [1.2292491568575155, 17.812426818360077, -106.7243471991335], [1.861513017757171, 17.739798257472735, -106.66418317370757], [2.8445756482787843, 17.886229870053484, -112.76014955194869], [2.5742458793667775, 17.923131395900185, -113.05885504703265], [2.3845298377972624, 17.923131395900185, -112.54261108961408], [3.1109495071437476, 17.849328344206782, -112.46294988506484], [2.46118765509271, 17.886229870053484, -111.72916746531166], [1.6256656715192, 17.923131395900185, -110.47763525993977], [2.5220218321999823, 17.849328344206782, -110.92174715380982], [1.8359730934994243, 17.886229870053484, -110.07695261185863], [1.315221239859993, 17.923131395900185, -109.63287242052755], [2.039807208129941, 17.849328344206782, -109.67873404628678], [1.3695821096175578, 17.886229870053484, -108.82791619153501], [0.5563570735819308, 17.923131395900185, -107.56789659085324], [1.4081193391869473, 17.849328344206782, -108.02898327534307], [0.784610344720836, 17.886229870053484, -107.28520763207986], [0.3666410320124154, 17.923131395900185, -107.05165263343467], [1.0089077058126976, 17.849328344206782, -107.0040245015066], [1.849194957126507, 17.98926319975611, -113.12211466598463], [1.5764698671487303, 18.022329101684075, -113.41366925947071], [1.396869124864013, 18.022329101684075, -112.89381969145052], [2.1185482806760176, 17.956197297828147, -112.83176194269907], [1.4866217061288065, 17.98926319975611, -112.08361740014477], [0.6784661557251439, 18.022329101684075, -110.81442141936975], [1.5628872216805354, 17.956197297828147, -111.2782225896412], [0.8962352864102865, 17.98926319975611, -110.41860505639723], [0.38457403198651563, 18.022329101684075, -109.96375848988217], [1.1084869811219027, 17.956197297828147, -110.02475539011648], [0.4553221115647183, 17.98926319975611, -109.16033037607038], [-0.3338289371523536, 18.022329101684075, -107.8843602178014], [0.5125831254298566, 17.956197297828147, -108.36170974306073], [-0.09696718100249786, 17.989263199756113, -107.60558915281194], [-0.5134296794370707, 18.022329101684075, -107.36451064978121], [0.1365228087190918, 17.956197297828147, -107.32801995802305], [0.855851503566531, 18.071089185106615, -113.46207711661373], [0.5809835032557122, 18.095469226817887, -113.74767118368946], [0.41010114029515027, 18.095469226817887, -113.22489090668104], [1.1278133774359647, 18.046709143395347, -113.1774599525341], [0.5111806512040219, 18.07108918510662, -112.41749346559294], [-0.27342831154709774, 18.095469226817887, -111.1337697986473], [0.600635656347353, 18.046709143395347, -111.61400363648919], [-0.049338717404535826, 18.071089185106615, -110.74216746051987], [-0.5530539963916536, 18.095469226817887, -110.2783111635426], [0.16999539710666864, 18.046709143395347, -110.3521636909315], [-0.4683544708796799, 18.07108918510662, -109.47641990297787], [-1.2365834482339018, 18.095469226817887, -108.18719005550885], [-0.39527945113324653, 18.046709143395347, -108.67843625439748], [-0.9926260655269065, 18.071089185106615, -107.9119866839369], [-1.4074658111944636, 18.095469226817887, -107.66440977850043], [-0.7515748092612959, 18.046709143395347, -107.63776021536101]], triangles: [[0, 1, 2], [0, 2, 3], [0, 3, 4], [0, 4, 1], [5, 2, 6], [5, 6, 3], [5, 3, 2], [7, 8, 9], [7, 9, 10], [7, 10, 8], [11, 9, 12], [11, 12, 13], [11, 13, 10], [11, 10, 9], [14, 12, 15], [21, 16, 14], [15, 21, 14], [14, 16, 13], [14, 13, 12], [17, 15, 18], [17, 18, 19], [17, 19, 20], [41, 16, 17], [20, 41, 17], [17, 16, 21], [17, 21, 15], [22, 19, 1], [22, 1, 4], [22, 4, 20], [22, 20, 19], [23, 24, 25], [37, 26, 23], [25, 37, 23], [23, 26, 24], [27, 28, 29], [27, 29, 24], [27, 24, 26], [27, 26, 28], [30, 31, 32], [30, 32, 28], [30, 28, 26], [30, 26, 31], [33, 4, 3], [33, 3, 34], [80, 32, 33], [34, 80, 33], [33, 32, 31], [33, 31, 4], [35, 3, 6], [35, 6, 34], [35, 34, 3], [36, 8, 10], [36, 10, 26], [36, 26, 37], [36, 37, 25], [36, 25, 8], [38, 10, 13], [38, 13, 26], [38, 26, 10], [39, 13, 16], [43, 26, 39], [16, 43, 39], [39, 26, 13], [40, 16, 41], [40, 41, 42], [40, 42, 26], [40, 26, 43], [40, 43, 16], [44, 42, 31], [44, 31, 26], [44, 26, 42], [45, 41, 20], [45, 20, 42], [45, 42, 41], [46, 20, 4], [46, 4, 31], [46, 31, 42], [46, 42, 20], [47, 48, 49], [47, 49, 50], [47, 50, 51], [73, 48, 47], [51, 73, 47], [52, 53, 54], [61, 55, 52], [54, 61, 52], [52, 55, 56], [90, 57, 52], [56, 90, 52], [52, 57, 53], [58, 54, 59], [65, 60, 58], [59, 65, 58], [58, 60, 55], [58, 55, 61], [58, 61, 54], [62, 59, 63], [62, 63, 64], [62, 64, 60], [62, 60, 65], [62, 65, 59], [66, 63, 67], [66, 67, 68], [123, 64, 66], [68, 123, 66], [66, 64, 63], [69, 67, 70], [74, 71, 69], [70, 74, 69], [69, 71, 68], [69, 68, 67], [72, 70, 48], [72, 48, 73], [72, 73, 51], [72, 51, 50], [72, 50, 71], [72, 71, 74], [72, 74, 70], [75, 29, 28], [75, 28, 76], [75, 76, 29], [77, 28, 32], [77, 32, 78], [77, 78, 76], [77, 76, 28], [79, 32, 80], [79, 80, 81], [79, 81, 82], [79, 82, 78], [79, 78, 32], [83, 80, 34], [83, 34, 81], [83, 81, 80], [84, 81, 85], [84, 85, 82], [84, 82, 81], [86, 34, 6], [86, 6, 87], [86, 87, 88], [86, 88, 85], [86, 85, 81], [86, 81, 34], [89, 87, 53], [89, 53, 57], [89, 57, 90], [89, 90, 56], [89, 56, 88], [89, 88, 87], [91, 92, 93], [91, 93, 94], [91, 94, 95], [91, 95, 96], [91, 96, 92], [97, 98, 92], [97, 92, 96], [97, 96, 98], [99, 50, 49], [146, 98, 99], [49, 146, 99], [99, 98, 96], [129, 100, 99], [96, 129, 99], [99, 100, 50], [101, 102, 103], [101, 103, 104], [107, 102, 101], [104, 107, 101], [105, 106, 102], [105, 102, 107], [105, 107, 104], [111, 106, 105], [104, 111, 105], [108, 109, 110], [108, 110, 106], [108, 106, 111], [108, 111, 104], [108, 104, 109], [112, 56, 55], [112, 55, 113], [112, 113, 110], [112, 110, 109], [112, 109, 114], [139, 56, 112], [114, 139, 112], [115, 55, 60], [121, 116, 115], [60, 121, 115], [115, 116, 117], [115, 117, 113], [115, 113, 55], [118, 96, 95], [118, 95, 94], [118, 94, 117], [118, 117, 116], [125, 96, 118], [116, 125, 118], [119, 60, 64], [119, 64, 120], [119, 120, 116], [119, 116, 121], [119, 121, 60], [122, 64, 123], [122, 123, 120], [122, 120, 64], [124, 96, 125], [124, 125, 116], [124, 116, 120], [124, 120, 96], [126, 123, 68], [126, 68, 96], [126, 96, 120], [126, 120, 123], [127, 68, 71], [130, 96, 127], [71, 130, 127], [127, 96, 68], [128, 71, 50], [128, 50, 100], [128, 100, 129], [128, 129, 96], [128, 96, 130], [128, 130, 71], [131, 29, 76], [131, 76, 104], [131, 104, 103], [131, 103, 29], [132, 76, 78], [132, 78, 104], [132, 104, 76], [133, 78, 82], [133, 82, 104], [133, 104, 78], [134, 82, 85], [134, 85, 135], [134, 135, 104], [134, 104, 82], [136, 135, 109], [136, 109, 104], [136, 104, 135], [137, 85, 88], [137, 88, 135], [137, 135, 85], [138, 88, 56], [138, 56, 139], [138, 139, 114], [138, 114, 109], [138, 109, 135], [138, 135, 88], [140, 93, 92], [144, 141, 140], [92, 144, 140], [140, 141, 93], [142, 92, 98], [142, 98, 143], [142, 143, 141], [142, 141, 144], [142, 144, 92], [145, 98, 146], [145, 146, 147], [145, 147, 143], [145, 143, 98], [148, 146, 49], [148, 49, 149], [148, 149, 150], [172, 147, 148], [150, 172, 148], [148, 147, 146], [151, 149, 152], [180, 150, 151], [152, 180, 151], [151, 150, 149], [153, 154, 155], [153, 155, 156], [153, 156, 154], [157, 158, 159], [157, 159, 154], [157, 154, 156], [157, 156, 158], [190, 158, 160], [161, 190, 160], [160, 158, 156], [160, 156, 161], [162, 93, 141], [167, 163, 162], [141, 167, 162], [162, 163, 93], [164, 141, 143], [164, 143, 165], [164, 165, 166], [164, 166, 163], [164, 163, 167], [164, 167, 141], [168, 156, 155], [168, 155, 166], [168, 166, 165], [168, 165, 156], [169, 143, 147], [169, 147, 170], [169, 170, 165], [169, 165, 143], [171, 147, 172], [171, 172, 173], [171, 173, 170], [171, 170, 147], [174, 172, 150], [181, 175, 174], [150, 181, 174], [174, 175, 173], [174, 173, 172], [176, 156, 165], [176, 165, 170], [176, 170, 156], [177, 156, 170], [177, 170, 173], [177, 173, 156], [178, 156, 173], [178, 173, 175], [178, 175, 156], [179, 150, 180], [179, 180, 175], [179, 175, 181], [179, 181, 150], [182, 180, 152], [182, 152, 161], [182, 161, 156], [182, 156, 175], [182, 175, 180], [183, 184, 185], [183, 185, 186], [200, 184, 183], [186, 200, 183], [187, 159, 158], [187, 158, 188], [187, 188, 159], [189, 158, 190], [189, 190, 191], [189, 191, 188], [189, 188, 158], [192, 190, 161], [192, 161, 193], [192, 193, 194], [192, 194, 195], [192, 195, 191], [192, 191, 190], [196, 194, 197], [196, 197, 198], [196, 198, 195], [196, 195, 194], [199, 197, 184], [199, 184, 200], [199, 200, 186], [199, 186, 198], [199, 198, 197], [201, 161, 152], [201, 152, 193], [201, 193, 161], [202, 186, 185], [202, 185, 203], [202, 203, 204], [202, 204, 205], [219, 206, 202], [205, 219, 202], [218, 186, 202], [206, 218, 202], [207, 203, 208], [207, 208, 204], [207, 204, 203], [209, 159, 188], [209, 188, 210], [209, 210, 159], [211, 188, 191], [211, 191, 212], [211, 212, 210], [211, 210, 188], [213, 191, 195], [213, 195, 214], [213, 214, 212], [213, 212, 191], [215, 195, 198], [220, 216, 215], [198, 220, 215], [215, 216, 214], [215, 214, 195], [217, 198, 186], [217, 186, 218], [217, 218, 206], [217, 206, 219], [217, 219, 205], [217, 205, 216], [217, 216, 220], [217, 220, 198], [221, 203, 185], [221, 185, 222], [221, 222, 203], [223, 208, 203], [223, 203, 222], [223, 222, 224], [223, 224, 208], [225, 226, 227], [225, 227, 228], [225, 228, 226], [229, 208, 224], [229, 224, 226], [229, 226, 228], [229, 228, 208], [230, 231, 232], [230, 232, 233], [230, 233, 231], [234, 18, 235], [234, 235, 236], [234, 236, 18], [237, 235, 238], [237, 238, 239], [237, 239, 236], [237, 236, 235], [240, 238, 241], [240, 241, 242], [240, 242, 239], [240, 239, 238], [243, 241, 244], [243, 244, 245], [243, 245, 246], [263, 242, 243], [246, 263, 243], [243, 242, 241], [247, 245, 231], [247, 231, 233], [247, 233, 246], [247, 246, 245], [248, 2, 1], [248, 1, 249], [248, 249, 2], [250, 251, 6], [250, 6, 2], [250, 2, 249], [250, 249, 251], [252, 253, 254], [252, 254, 251], [252, 251, 249], [252, 249, 253], [255, 233, 232], [280, 254, 255], [232, 280, 255], [255, 254, 253], [267, 233, 255], [253, 267, 255], [256, 18, 236], [256, 236, 249], [256, 249, 1], [19, 18, 256], [1, 19, 256], [257, 236, 239], [257, 239, 249], [257, 249, 236], [258, 239, 242], [258, 242, 259], [258, 259, 249], [258, 249, 239], [260, 259, 261], [260, 261, 249], [260, 249, 259], [262, 242, 263], [262, 263, 259], [262, 259, 242], [264, 263, 246], [264, 246, 261], [264, 261, 259], [264, 259, 263], [265, 261, 253], [265, 253, 249], [265, 249, 261], [266, 246, 233], [266, 233, 267], [266, 267, 253], [266, 253, 261], [266, 261, 246], [268, 269, 270], [268, 270, 271], [299, 272, 268], [271, 299, 268], [289, 269, 268], [272, 289, 268], [273, 270, 274], [273, 274, 271], [273, 271, 270], [275, 6, 251], [275, 251, 276], [275, 276, 6], [277, 251, 254], [277, 254, 278], [277, 278, 276], [277, 276, 251], [279, 254, 280], [279, 280, 281], [279, 281, 278], [279, 278, 254], [282, 280, 232], [282, 232, 283], [282, 283, 284], [282, 284, 281], [282, 281, 280], [285, 283, 286], [290, 287, 285], [286, 290, 285], [319, 284, 285], [287, 319, 285], [285, 284, 283], [288, 286, 269], [288, 269, 289], [288, 289, 272], [288, 272, 287], [288, 287, 290], [288, 290, 286], [291, 292, 49], [291, 49, 48], [291, 48, 292], [293, 54, 53], [293, 53, 294], [293, 294, 54], [295, 59, 54], [295, 54, 294], [295, 294, 59], [296, 297, 63], [296, 63, 59], [296, 59, 294], [296, 294, 297], [298, 272, 299], [298, 299, 67], [298, 67, 63], [298, 63, 297], [298, 297, 272], [300, 299, 271], [302, 70, 300], [271, 302, 300], [300, 70, 67], [300, 67, 299], [301, 271, 274], [301, 274, 292], [301, 292, 48], [301, 48, 70], [301, 70, 302], [301, 302, 271], [303, 6, 276], [303, 276, 304], [303, 304, 87], [303, 87, 6], [305, 294, 53], [305, 53, 87], [305, 87, 304], [305, 304, 294], [306, 276, 278], [306, 278, 307], [306, 307, 304], [306, 304, 276], [308, 278, 281], [308, 281, 309], [308, 309, 310], [308, 310, 307], [308, 307, 278], [311, 309, 312], [311, 312, 310], [311, 310, 309], [313, 294, 304], [313, 304, 307], [313, 307, 294], [314, 294, 307], [314, 307, 310], [314, 310, 294], [315, 312, 316], [315, 316, 294], [315, 294, 310], [315, 310, 312], [317, 281, 284], [317, 284, 309], [317, 309, 281], [318, 284, 319], [318, 319, 312], [318, 312, 309], [318, 309, 284], [320, 319, 287], [323, 316, 320], [287, 323, 320], [320, 316, 312], [320, 312, 319], [321, 316, 297], [321, 297, 294], [321, 294, 316], [322, 287, 272], [322, 272, 297], [322, 297, 316], [322, 316, 323], [322, 323, 287], [324, 49, 292], [328, 325, 324], [292, 328, 324], [324, 325, 326], [324, 326, 49], [327, 292, 274], [327, 274, 325], [327, 325, 328], [327, 328, 292], [329, 49, 326], [329, 326, 330], [332, 149, 329], [330, 332, 329], [329, 149, 49], [331, 330, 152], [331, 152, 149], [331, 149, 332], [331, 332, 330], [333, 334, 335], [333, 335, 336], [333, 336, 337], [333, 337, 334], [338, 335, 339], [338, 339, 336], [338, 336, 335], [340, 330, 326], [340, 326, 341], [340, 341, 330], [342, 152, 330], [342, 330, 341], [342, 341, 334], [342, 334, 337], [342, 337, 152], [343, 344, 185], [343, 185, 184], [343, 184, 344], [345, 337, 336], [347, 197, 345], [336, 347, 345], [194, 193, 345], [197, 194, 345], [345, 193, 337], [346, 336, 339], [346, 339, 344], [346, 344, 184], [346, 184, 197], [346, 197, 347], [346, 347, 336], [348, 152, 337], [348, 337, 193], [348, 193, 152], [349, 185, 344], [353, 350, 349], [344, 353, 349], [349, 350, 351], [349, 351, 185], [352, 344, 339], [352, 339, 350], [352, 350, 353], [352, 353, 344], [354, 185, 351], [354, 351, 355], [357, 222, 354], [355, 357, 354], [354, 222, 185], [356, 355, 224], [356, 224, 222], [356, 222, 357], [356, 357, 355], [358, 244, 359], [364, 360, 358], [359, 364, 358], [358, 360, 244], [361, 359, 362], [361, 362, 363], [361, 363, 360], [361, 360, 364], [361, 364, 359], [365, 366, 232], [365, 232, 231], [369, 366, 365], [231, 369, 365], [367, 244, 360], [367, 360, 245], [367, 245, 244], [368, 360, 363], [368, 363, 366], [368, 366, 369], [368, 369, 231], [368, 231, 245], [368, 245, 360], [370, 371, 372], [377, 373, 370], [372, 377, 370], [370, 373, 374], [370, 374, 371], [375, 372, 376], [375, 376, 373], [375, 373, 377], [375, 377, 372], [378, 232, 366], [385, 379, 378], [366, 385, 378], [378, 379, 380], [383, 381, 378], [380, 383, 378], [390, 232, 378], [381, 390, 378], [382, 380, 371], [382, 371, 374], [382, 374, 381], [382, 381, 383], [382, 383, 380], [384, 366, 363], [384, 363, 379], [384, 379, 385], [384, 385, 366], [386, 374, 373], [388, 270, 386], [373, 388, 386], [386, 270, 269], [393, 374, 386], [269, 393, 386], [387, 373, 376], [387, 376, 274], [387, 274, 270], [387, 270, 388], [387, 388, 373], [389, 232, 390], [389, 390, 283], [389, 283, 232], [391, 390, 381], [391, 381, 286], [391, 286, 283], [391, 283, 390], [392, 381, 374], [392, 374, 393], [392, 393, 269], [392, 269, 286], [392, 286, 381], [394, 395, 396], [394, 396, 397], [394, 397, 395], [398, 274, 376], [398, 376, 395], [398, 395, 397], [398, 397, 274], [399, 397, 396], [399, 396, 326], [399, 326, 325], [401, 397, 399], [325, 401, 399], [400, 274, 397], [400, 397, 401], [400, 401, 325], [400, 325, 274], [402, 403, 404], [402, 404, 405], [402, 405, 406], [402, 406, 403], [407, 404, 408], [407, 408, 405], [407, 405, 404], [409, 326, 396], [409, 396, 410], [409, 410, 411], [409, 411, 326], [412, 410, 403], [412, 403, 406], [412, 406, 411], [412, 411, 410], [413, 406, 405], [413, 405, 335], [413, 335, 334], [413, 334, 406], [414, 405, 408], [414, 408, 339], [414, 339, 335], [414, 335, 405], [415, 326, 411], [417, 341, 415], [411, 417, 415], [415, 341, 326], [416, 411, 406], [416, 406, 334], [416, 334, 341], [416, 341, 417], [416, 417, 411], [418, 339, 408], [418, 408, 419], [418, 419, 339], [420, 421, 351], [420, 351, 350], [420, 350, 421], [422, 339, 419], [422, 419, 421], [422, 421, 350], [422, 350, 339], [423, 362, 424], [423, 424, 425], [423, 425, 362], [426, 362, 425], [426, 425, 363], [426, 363, 362], [427, 428, 429], [434, 430, 427], [429, 434, 427], [427, 430, 431], [441, 428, 427], [431, 441, 427], [432, 429, 433], [432, 433, 430], [432, 430, 434], [432, 434, 429], [435, 436, 437], [442, 438, 435], [437, 442, 435], [435, 438, 439], [444, 436, 435], [439, 444, 435], [440, 437, 428], [440, 428, 441], [440, 441, 431], [440, 431, 438], [440, 438, 442], [440, 442, 437], [443, 363, 425], [443, 425, 436], [443, 436, 444], [443, 444, 439], [443, 439, 363], [445, 431, 430], [447, 372, 445], [430, 447, 445], [445, 372, 371], [450, 431, 445], [371, 450, 445], [446, 430, 433], [446, 433, 376], [446, 376, 372], [446, 372, 447], [446, 447, 430], [448, 439, 438], [448, 438, 380], [448, 380, 379], [448, 379, 439], [449, 438, 431], [449, 431, 450], [449, 450, 371], [449, 371, 380], [449, 380, 438], [451, 363, 439], [451, 439, 379], [451, 379, 363], [452, 376, 433], [452, 433, 453], [452, 453, 376], [454, 455, 396], [454, 396, 395], [454, 395, 455], [456, 376, 453], [456, 453, 455], [456, 455, 395], [456, 395, 376], [457, 458, 459], [457, 459, 460], [457, 460, 461], [457, 461, 462], [484, 458, 457], [462, 484, 457], [463, 459, 464], [463, 464, 460], [463, 460, 459], [465, 396, 455], [465, 455, 466], [465, 466, 467], [472, 468, 465], [467, 472, 465], [465, 468, 396], [469, 467, 470], [476, 471, 469], [470, 476, 469], [469, 471, 468], [469, 468, 472], [469, 472, 467], [473, 470, 474], [473, 474, 475], [473, 475, 471], [473, 471, 476], [473, 476, 470], [477, 474, 478], [477, 478, 479], [477, 479, 475], [477, 475, 474], [480, 478, 481], [480, 481, 482], [480, 482, 479], [480, 479, 478], [483, 481, 458], [483, 458, 484], [483, 484, 462], [483, 462, 461], [483, 461, 482], [483, 482, 481], [485, 455, 453], [485, 453, 466], [485, 466, 455], [486, 404, 403], [496, 487, 486], [403, 496, 486], [490, 404, 486], [487, 490, 486], [488, 489, 408], [488, 408, 404], [488, 404, 490], [488, 490, 487], [488, 487, 489], [491, 461, 460], [491, 460, 492], [491, 492, 489], [491, 489, 487], [501, 461, 491], [502, 501, 491], [487, 502, 491], [493, 460, 464], [493, 464, 492], [493, 492, 460], [494, 396, 468], [494, 468, 410], [494, 410, 396], [495, 468, 471], [495, 471, 487], [495, 487, 496], [495, 496, 403], [495, 403, 410], [495, 410, 468], [497, 471, 475], [497, 475, 487], [497, 487, 471], [498, 475, 479], [498, 479, 487], [498, 487, 475], [499, 479, 482], [499, 482, 487], [499, 487, 479], [500, 482, 461], [500, 461, 501], [500, 501, 502], [500, 502, 487], [500, 487, 482], [503, 408, 489], [503, 489, 504], [503, 504, 408], [505, 489, 492], [510, 506, 505], [492, 510, 505], [505, 506, 504], [505, 504, 489], [507, 492, 464], [507, 464, 508], [507, 508, 509], [507, 509, 506], [507, 506, 510], [507, 510, 492], [663, 512, 511], [508, 663, 511], [511, 512, 509], [511, 509, 508], [513, 408, 504], [513, 504, 514], [513, 514, 419], [513, 419, 408], [515, 504, 506], [519, 516, 515], [506, 519, 515], [515, 516, 514], [515, 514, 504], [517, 506, 509], [517, 509, 518], [517, 518, 516], [517, 516, 519], [517, 519, 506], [520, 509, 512], [520, 512, 518], [520, 518, 509], [521, 424, 522], [521, 522, 523], [521, 523, 424], [524, 424, 523], [524, 523, 425], [524, 425, 424], [525, 526, 527], [525, 527, 528], [525, 528, 526], [529, 530, 531], [529, 531, 532], [529, 532, 530], [533, 534, 530], [533, 530, 532], [539, 534, 533], [532, 539, 533], [535, 536, 537], [535, 537, 538], [535, 538, 534], [535, 534, 539], [535, 539, 532], [535, 532, 536], [540, 537, 541], [540, 541, 542], [540, 542, 538], [540, 538, 537], [543, 541, 526], [543, 526, 528], [563, 542, 543], [528, 563, 543], [543, 542, 541], [544, 425, 523], [544, 523, 545], [544, 545, 532], [544, 532, 531], [544, 531, 425], [546, 545, 547], [546, 547, 532], [546, 532, 545], [548, 547, 549], [548, 549, 532], [548, 532, 547], [550, 549, 551], [550, 551, 532], [550, 532, 549], [552, 551, 536], [552, 536, 532], [552, 532, 551], [553, 429, 428], [553, 428, 554], [553, 554, 429], [555, 556, 433], [555, 433, 429], [555, 429, 554], [555, 554, 556], [557, 528, 527], [557, 527, 556], [557, 556, 554], [557, 554, 528], [558, 531, 530], [558, 530, 437], [558, 437, 436], [558, 436, 531], [559, 530, 534], [559, 534, 554], [559, 554, 428], [559, 428, 437], [559, 437, 530], [560, 534, 538], [560, 538, 554], [560, 554, 534], [561, 538, 542], [561, 542, 554], [561, 554, 538], [562, 542, 563], [562, 563, 554], [562, 554, 542], [564, 563, 528], [564, 528, 554], [564, 554, 563], [565, 425, 531], [565, 531, 436], [565, 436, 425], [566, 433, 556], [566, 556, 567], [566, 567, 433], [568, 556, 527], [568, 527, 569], [568, 569, 570], [579, 567, 568], [570, 579, 568], [568, 567, 556], [571, 569, 572], [571, 572, 573], [571, 573, 570], [571, 570, 569], [574, 572, 575], [574, 575, 573], [574, 573, 572], [576, 433, 567], [576, 567, 577], [576, 577, 453], [576, 453, 433], [578, 567, 579], [578, 579, 580], [578, 580, 577], [578, 577, 567], [581, 579, 570], [585, 582, 581], [570, 585, 581], [581, 582, 580], [581, 580, 579], [583, 570, 573], [583, 573, 584], [583, 584, 582], [583, 582, 585], [583, 585, 570], [586, 573, 575], [586, 575, 584], [586, 584, 573], [587, 588, 589], [599, 590, 587], [589, 599, 587], [587, 590, 588], [591, 592, 588], [591, 588, 590], [591, 590, 592], [626, 592, 593], [594, 626, 593], [593, 592, 590], [605, 595, 593], [590, 605, 593], [593, 595, 594], [596, 597, 594], [596, 594, 595], [596, 595, 597], [598, 453, 577], [598, 577, 590], [598, 590, 599], [598, 599, 589], [598, 589, 453], [600, 577, 580], [600, 580, 590], [600, 590, 577], [601, 580, 582], [601, 582, 590], [601, 590, 580], [602, 582, 584], [602, 584, 603], [602, 603, 590], [602, 590, 582], [604, 595, 605], [604, 605, 590], [604, 590, 603], [604, 603, 595], [606, 584, 575], [606, 575, 607], [606, 607, 608], [606, 608, 603], [606, 603, 584], [609, 607, 610], [609, 610, 608], [609, 608, 607], [611, 595, 603], [611, 603, 608], [611, 608, 595], [612, 610, 613], [612, 613, 595], [612, 595, 608], [612, 608, 610], [614, 613, 615], [635, 616, 614], [640, 635, 614], [615, 640, 614], [614, 616, 595], [614, 595, 613], [617, 616, 597], [617, 597, 595], [617, 595, 616], [618, 459, 458], [618, 458, 619], [618, 619, 459], [620, 621, 464], [620, 464, 459], [620, 459, 619], [620, 619, 621], [622, 589, 588], [624, 467, 622], [588, 624, 622], [622, 467, 466], [633, 589, 622], [466, 633, 622], [623, 588, 592], [623, 592, 470], [623, 470, 467], [623, 467, 624], [623, 624, 588], [625, 592, 626], [625, 626, 474], [625, 474, 470], [625, 470, 592], [627, 626, 594], [630, 478, 627], [594, 630, 627], [627, 478, 474], [627, 474, 626], [628, 594, 597], [628, 597, 629], [628, 629, 481], [628, 481, 478], [628, 478, 630], [628, 630, 594], [631, 619, 458], [631, 458, 481], [631, 481, 629], [631, 629, 619], [632, 453, 589], [632, 589, 633], [632, 633, 466], [632, 466, 453], [634, 616, 635], [634, 635, 636], [634, 636, 616], [637, 597, 616], [637, 616, 636], [637, 636, 638], [637, 638, 629], [637, 629, 597], [639, 635, 640], [639, 640, 641], [639, 641, 636], [639, 636, 635], [642, 641, 638], [642, 638, 636], [642, 636, 641], [643, 619, 629], [643, 629, 638], [643, 638, 619], [644, 640, 615], [644, 615, 645], [644, 645, 646], [644, 646, 641], [644, 641, 640], [647, 646, 619], [647, 619, 638], [647, 638, 641], [647, 641, 646], [648, 645, 649], [648, 649, 646], [648, 646, 645], [650, 649, 651], [650, 651, 619], [650, 619, 646], [650, 646, 649], [652, 651, 621], [652, 621, 619], [652, 619, 651], [653, 464, 621], [653, 621, 654], [653, 654, 464], [655, 645, 615], [655, 615, 656], [655, 656, 645], [649, 645, 657], [651, 649, 657], [657, 645, 656], [657, 656, 658], [657, 658, 659], [657, 659, 651], [660, 621, 651], [660, 651, 659], [660, 659, 654], [660, 654, 621], [661, 464, 654], [661, 654, 508], [661, 508, 464], [662, 659, 658], [662, 658, 512], [662, 512, 663], [662, 663, 659], [664, 654, 659], [664, 659, 663], [664, 663, 508], [664, 508, 654], [665, 522, 666], [665, 666, 667], [665, 667, 522], [668, 666, 669], [668, 669, 670], [668, 670, 667], [668, 667, 666], [671, 669, 672], [671, 672, 673], [671, 673, 670], [671, 670, 669], [674, 675, 676], [674, 676, 677], [674, 677, 678], [674, 678, 675], [679, 672, 675], [679, 675, 678], [679, 678, 673], [679, 673, 672], [680, 522, 667], [684, 681, 680], [667, 684, 680], [680, 681, 523], [680, 523, 522], [682, 667, 670], [682, 670, 683], [697, 681, 682], [683, 697, 682], [682, 681, 684], [682, 684, 667], [685, 670, 673], [685, 673, 686], [685, 686, 683], [685, 683, 670], [678, 677, 687], [673, 678, 687], [708, 686, 687], [677, 708, 687], [687, 686, 673], [688, 689, 690], [688, 690, 691], [688, 691, 689], [692, 693, 689], [692, 689, 691], [692, 691, 693], [694, 523, 681], [699, 695, 694], [681, 699, 694], [694, 695, 523], [696, 681, 697], [696, 697, 698], [696, 698, 695], [696, 695, 699], [696, 699, 681], [700, 697, 683], [705, 701, 700], [683, 705, 700], [700, 701, 698], [700, 698, 697], [702, 683, 686], [702, 686, 703], [702, 703, 704], [732, 701, 702], [704, 732, 702], [702, 701, 705], [702, 705, 683], [706, 691, 690], [706, 690, 704], [706, 704, 703], [706, 703, 691], [707, 686, 708], [707, 708, 709], [707, 709, 703], [707, 703, 686], [710, 708, 677], [710, 677, 711], [710, 711, 709], [710, 709, 708], [712, 691, 703], [712, 703, 709], [712, 709, 691], [713, 711, 714], [713, 714, 691], [713, 691, 709], [713, 709, 711], [715, 714, 716], [740, 717, 715], [716, 740, 715], [715, 717, 691], [715, 691, 714], [718, 717, 693], [718, 693, 691], [718, 691, 717], [719, 720, 527], [719, 527, 526], [719, 526, 721], [719, 721, 720], [722, 723, 720], [722, 720, 721], [722, 721, 723], [724, 725, 537], [724, 537, 536], [724, 536, 725], [726, 690, 689], [726, 689, 541], [726, 541, 537], [726, 537, 725], [738, 690, 726], [725, 738, 726], [727, 689, 693], [727, 693, 721], [727, 721, 526], [727, 526, 541], [727, 541, 689], [728, 523, 695], [728, 695, 545], [728, 545, 523], [729, 695, 698], [729, 698, 547], [729, 547, 545], [729, 545, 695], [730, 698, 701], [734, 549, 730], [701, 734, 730], [730, 549, 547], [730, 547, 698], [731, 701, 732], [731, 732, 733], [731, 733, 551], [731, 551, 549], [731, 549, 734], [731, 734, 701], [735, 733, 725], [735, 725, 536], [735, 536, 551], [735, 551, 733], [736, 732, 704], [736, 704, 733], [736, 733, 732], [737, 704, 690], [737, 690, 738], [737, 738, 725], [737, 725, 733], [737, 733, 704], [739, 717, 740], [739, 740, 741], [739, 741, 717], [742, 693, 717], [742, 717, 741], [742, 741, 721], [742, 721, 693], [743, 740, 716], [743, 716, 744], [743, 744, 745], [743, 745, 741], [743, 741, 740], [746, 745, 721], [746, 721, 741], [746, 741, 745], [747, 744, 748], [747, 748, 745], [747, 745, 744], [749, 748, 750], [749, 750, 721], [749, 721, 745], [749, 745, 748], [751, 750, 723], [751, 723, 721], [751, 721, 750], [752, 527, 720], [752, 720, 753], [752, 753, 527], [754, 720, 723], [754, 723, 755], [754, 755, 753], [754, 753, 720], [756, 744, 716], [756, 716, 757], [756, 757, 744], [748, 744, 758], [750, 748, 758], [758, 744, 757], [758, 757, 759], [758, 759, 760], [758, 760, 750], [761, 723, 750], [761, 750, 760], [761, 760, 755], [761, 755, 723], [762, 527, 753], [762, 753, 569], [762, 569, 527], [763, 753, 755], [763, 755, 572], [763, 572, 569], [763, 569, 753], [764, 760, 759], [768, 765, 764], [759, 768, 764], [764, 765, 760], [766, 755, 760], [766, 760, 765], [766, 765, 575], [766, 575, 572], [766, 572, 755], [765, 768, 767], [575, 765, 767], [767, 768, 769], [767, 769, 575], [770, 768, 759], [770, 759, 771], [770, 771, 772], [770, 772, 769], [770, 769, 768], [773, 771, 774], [773, 774, 775], [773, 775, 772], [773, 772, 771], [776, 774, 777], [776, 777, 775], [776, 775, 774], [778, 575, 769], [778, 769, 607], [778, 607, 575], [779, 769, 772], [779, 772, 610], [779, 610, 607], [779, 607, 769], [780, 772, 775], [780, 775, 613], [780, 613, 610], [780, 610, 772], [781, 775, 777], [781, 777, 615], [781, 615, 613], [781, 613, 775], [782, 615, 777], [782, 777, 783], [782, 783, 615], [784, 615, 783], [784, 783, 658], [656, 615, 784], [658, 656, 784], [785, 676, 786], [785, 786, 787], [785, 787, 676], [788, 676, 787], [788, 787, 677], [788, 677, 676], [789, 677, 787], [789, 787, 790], [789, 790, 791], [795, 677, 789], [791, 795, 789], [792, 790, 793], [792, 793, 791], [792, 791, 790], [794, 677, 795], [794, 795, 711], [794, 711, 677], [796, 795, 791], [796, 791, 714], [796, 714, 711], [796, 711, 795], [797, 791, 793], [797, 793, 716], [797, 716, 714], [797, 714, 791], [798, 716, 793], [798, 793, 799], [798, 799, 716], [800, 716, 799], [800, 799, 759], [757, 716, 800], [759, 757, 800], [801, 759, 799], [801, 799, 802], [801, 802, 759], [803, 759, 802], [803, 802, 777], [771, 759, 803], [774, 771, 803], [777, 774, 803], [804, 777, 802], [804, 802, 805], [804, 805, 777], [806, 777, 805], [806, 805, 783], [806, 783, 777], [807, 786, 808], [807, 808, 809], [807, 809, 786], [810, 786, 809], [810, 809, 787], [810, 787, 786], [811, 787, 809], [811, 809, 812], [811, 812, 787], [813, 787, 812], [813, 812, 793], [790, 787, 813], [793, 790, 813], [814, 793, 812], [814, 812, 815], [814, 815, 793], [816, 793, 815], [816, 815, 799], [816, 799, 793], [817, 799, 815], [817, 815, 818], [817, 818, 799], [819, 799, 818], [819, 818, 802], [819, 802, 799], [820, 802, 818], [820, 818, 821], [820, 821, 802], [822, 802, 821], [822, 821, 805], [822, 805, 802], [823, 808, 824], [823, 824, 825], [823, 825, 808], [826, 808, 825], [826, 825, 809], [826, 809, 808], [827, 809, 825], [827, 825, 828], [827, 828, 809], [829, 809, 828], [829, 828, 812], [829, 812, 809], [830, 812, 828], [830, 828, 831], [830, 831, 812], [832, 812, 831], [832, 831, 815], [832, 815, 812], [833, 815, 831], [833, 831, 834], [833, 834, 815], [835, 815, 834], [835, 834, 818], [835, 818, 815], [836, 818, 834], [836, 834, 837], [836, 837, 818], [838, 818, 837], [838, 837, 821], [838, 821, 818], [839, 824, 840], [839, 840, 841], [839, 841, 824], [842, 824, 841], [842, 841, 825], [842, 825, 824], [843, 825, 841], [843, 841, 844], [843, 844, 825], [845, 825, 844], [845, 844, 828], [845, 828, 825], [846, 828, 844], [846, 844, 847], [846, 847, 828], [848, 828, 847], [848, 847, 831], [848, 831, 828], [849, 831, 847], [849, 847, 850], [849, 850, 831], [851, 831, 850], [851, 850, 834], [851, 834, 831], [852, 834, 850], [852, 850, 853], [852, 853, 834], [854, 834, 853], [854, 853, 837], [854, 837, 834], [855, 840, 856], [855, 856, 857], [855, 857, 840], [858, 840, 857], [858, 857, 841], [858, 841, 840], [859, 841, 857], [859, 857, 860], [859, 860, 841], [861, 841, 860], [861, 860, 844], [861, 844, 841], [862, 844, 860], [862, 860, 863], [862, 863, 844], [864, 844, 863], [864, 863, 847], [864, 847, 844], [865, 847, 863], [865, 863, 866], [865, 866, 847], [867, 847, 866], [867, 866, 850], [867, 850, 847], [868, 850, 866], [868, 866, 869], [868, 869, 850], [870, 850, 869], [870, 869, 853], [870, 853, 850], [871, 856, 872], [871, 872, 873], [871, 873, 856], [874, 856, 873], [874, 873, 857], [874, 857, 856], [875, 857, 873], [875, 873, 876], [875, 876, 857], [877, 857, 876], [877, 876, 860], [877, 860, 857], [878, 860, 876], [878, 876, 879], [878, 879, 860], [880, 860, 879], [880, 879, 863], [880, 863, 860], [881, 863, 879], [881, 879, 882], [881, 882, 863], [883, 863, 882], [883, 882, 866], [883, 866, 863], [884, 866, 882], [884, 882, 885], [884, 885, 866], [886, 866, 885], [886, 885, 869], [886, 869, 866], [887, 872, 888], [887, 888, 889], [887, 889, 872], [890, 872, 889], [890, 889, 873], [890, 873, 872], [891, 873, 889], [891, 889, 892], [891, 892, 873], [893, 873, 892], [893, 892, 876], [893, 876, 873], [894, 876, 892], [894, 892, 895], [894, 895, 876], [896, 876, 895], [896, 895, 879], [896, 879, 876], [897, 879, 895], [897, 895, 898], [897, 898, 879], [899, 879, 898], [899, 898, 882], [899, 882, 879], [900, 882, 898], [900, 898, 901], [900, 901, 882], [902, 882, 901], [902, 901, 885], [902, 885, 882], [903, 888, 904], [903, 904, 905], [903, 905, 888], [906, 888, 905], [906, 905, 889], [906, 889, 888], [907, 889, 905], [907, 905, 908], [907, 908, 889], [909, 889, 908], [909, 908, 892], [909, 892, 889], [910, 892, 908], [910, 908, 911], [910, 911, 892], [912, 892, 911], [912, 911, 895], [912, 895, 892], [913, 895, 911], [913, 911, 914], [913, 914, 895], [915, 895, 914], [915, 914, 898], [915, 898, 895], [916, 898, 914], [916, 914, 917], [916, 917, 898], [918, 898, 917], [918, 917, 901], [918, 901, 898], [919, 904, 920], [919, 920, 921], [919, 921, 904], [922, 904, 921], [922, 921, 905], [922, 905, 904], [923, 905, 921], [923, 921, 924], [923, 924, 905], [925, 905, 924], [925, 924, 908], [925, 908, 905], [926, 908, 924], [926, 924, 927], [926, 927, 908], [928, 908, 927], [928, 927, 911], [928, 911, 908], [929, 911, 927], [929, 927, 930], [929, 930, 911], [931, 911, 930], [931, 930, 914], [931, 914, 911], [932, 914, 930], [932, 930, 933], [932, 933, 914], [934, 914, 933], [934, 933, 917], [934, 917, 914], [935, 920, 936], [935, 936, 937], [935, 937, 920], [938, 920, 937], [938, 937, 921], [938, 921, 920], [939, 921, 937], [939, 937, 940], [939, 940, 921], [941, 921, 940], [941, 940, 924], [941, 924, 921], [942, 924, 940], [942, 940, 943], [942, 943, 924], [944, 924, 943], [944, 943, 927], [944, 927, 924], [945, 927, 943], [945, 943, 946], [945, 946, 927], [947, 927, 946], [947, 946, 930], [947, 930, 927], [948, 930, 946], [948, 946, 949], [948, 949, 930], [950, 930, 949], [950, 949, 933], [950, 933, 930], [951, 936, 952], [951, 952, 953], [951, 953, 936], [954, 936, 953], [954, 953, 937], [954, 937, 936], [955, 937, 953], [955, 953, 956], [955, 956, 937], [957, 937, 956], [957, 956, 940], [957, 940, 937], [958, 940, 956], [958, 956, 959], [958, 959, 940], [960, 940, 959], [960, 959, 943], [960, 943, 940], [961, 943, 959], [961, 959, 962], [961, 962, 943], [963, 943, 962], [963, 962, 946], [963, 946, 943], [964, 946, 962], [964, 962, 965], [964, 965, 946], [966, 946, 965], [966, 965, 949], [966, 949, 946], [967, 952, 968], [967, 968, 969], [967, 969, 952], [970, 952, 969], [970, 969, 953], [970, 953, 952], [971, 953, 969], [971, 969, 972], [971, 972, 953], [973, 953, 972], [973, 972, 956], [973, 956, 953], [974, 956, 972], [974, 972, 975], [974, 975, 956], [976, 956, 975], [976, 975, 959], [976, 959, 956], [977, 959, 975], [977, 975, 978], [977, 978, 959], [979, 959, 978], [979, 978, 962], [979, 962, 959], [980, 962, 978], [980, 978, 981], [980, 981, 962], [982, 962, 981], [982, 981, 965], [982, 965, 962], [983, 968, 984], [983, 984, 985], [983, 985, 968], [986, 968, 985], [986, 985, 969], [986, 969, 968], [987, 969, 985], [987, 985, 988], [987, 988, 969], [989, 969, 988], [989, 988, 972], [989, 972, 969], [990, 972, 988], [990, 988, 991], [990, 991, 972], [992, 972, 991], [992, 991, 975], [992, 975, 972], [993, 975, 991], [993, 991, 994], [993, 994, 975], [995, 975, 994], [995, 994, 978], [995, 978, 975], [996, 978, 994], [996, 994, 997], [996, 997, 978], [998, 978, 997], [998, 997, 981], [998, 981, 978], [999, 984, 1e3], [999, 1e3, 1001], [999, 1001, 984], [1002, 984, 1001], [1002, 1001, 985], [1002, 985, 984], [1003, 985, 1001], [1003, 1001, 1004], [1003, 1004, 985], [1005, 985, 1004], [1005, 1004, 988], [1005, 988, 985], [1006, 988, 1004], [1006, 1004, 1007], [1006, 1007, 988], [1008, 988, 1007], [1008, 1007, 991], [1008, 991, 988], [1009, 991, 1007], [1009, 1007, 1010], [1009, 1010, 991], [1011, 991, 1010], [1011, 1010, 994], [1011, 994, 991], [1012, 994, 1010], [1012, 1010, 1013], [1012, 1013, 994], [1014, 994, 1013], [1014, 1013, 997], [1014, 997, 994], [1015, 1e3, 1016], [1015, 1016, 1017], [1015, 1017, 1e3], [1018, 1e3, 1017], [1018, 1017, 1001], [1018, 1001, 1e3], [1019, 1001, 1017], [1019, 1017, 1020], [1019, 1020, 1001], [1021, 1001, 1020], [1021, 1020, 1004], [1021, 1004, 1001], [1022, 1004, 1020], [1022, 1020, 1023], [1022, 1023, 1004], [1024, 1004, 1023], [1024, 1023, 1007], [1024, 1007, 1004], [1025, 1007, 1023], [1025, 1023, 1026], [1025, 1026, 1007], [1027, 1007, 1026], [1027, 1026, 1010], [1027, 1010, 1007], [1028, 1010, 1026], [1028, 1026, 1029], [1028, 1029, 1010], [1030, 1010, 1029], [1030, 1029, 1013], [1030, 1013, 1010], [1031, 1016, 1032], [1031, 1032, 1033], [1031, 1033, 1016], [1034, 1016, 1033], [1034, 1033, 1017], [1034, 1017, 1016], [1035, 1017, 1033], [1035, 1033, 1036], [1035, 1036, 1017], [1037, 1017, 1036], [1037, 1036, 1020], [1037, 1020, 1017], [1038, 1020, 1036], [1038, 1036, 1039], [1038, 1039, 1020], [1040, 1020, 1039], [1040, 1039, 1023], [1040, 1023, 1020], [1041, 1023, 1039], [1041, 1039, 1042], [1041, 1042, 1023], [1043, 1023, 1042], [1043, 1042, 1026], [1043, 1026, 1023], [1044, 1026, 1042], [1044, 1042, 1045], [1044, 1045, 1026], [1046, 1026, 1045], [1046, 1045, 1029], [1046, 1029, 1026], [1047, 1032, 1048], [1047, 1048, 1049], [1047, 1049, 1032], [1050, 1032, 1049], [1050, 1049, 1033], [1050, 1033, 1032], [1051, 1033, 1049], [1051, 1049, 1052], [1051, 1052, 1033], [1053, 1033, 1052], [1053, 1052, 1036], [1053, 1036, 1033], [1054, 1036, 1052], [1054, 1052, 1055], [1054, 1055, 1036], [1056, 1036, 1055], [1056, 1055, 1039], [1056, 1039, 1036], [1057, 1039, 1055], [1057, 1055, 1058], [1057, 1058, 1039], [1059, 1039, 1058], [1059, 1058, 1042], [1059, 1042, 1039], [1060, 1042, 1058], [1060, 1058, 1061], [1060, 1061, 1042], [1062, 1042, 1061], [1062, 1061, 1045], [1062, 1045, 1042], [1063, 1048, 1064], [1063, 1064, 1065], [1063, 1065, 1048], [1066, 1048, 1065], [1066, 1065, 1049], [1066, 1049, 1048], [1067, 1049, 1065], [1067, 1065, 1068], [1067, 1068, 1049], [1069, 1049, 1068], [1069, 1068, 1052], [1069, 1052, 1049], [1070, 1052, 1068], [1070, 1068, 1071], [1070, 1071, 1052], [1072, 1052, 1071], [1072, 1071, 1055], [1072, 1055, 1052], [1073, 1055, 1071], [1073, 1071, 1074], [1073, 1074, 1055], [1075, 1055, 1074], [1075, 1074, 1058], [1075, 1058, 1055], [1076, 1058, 1074], [1076, 1074, 1077], [1076, 1077, 1058], [1078, 1058, 1077], [1078, 1077, 1061], [1078, 1061, 1058], [1079, 1064, 1080], [1079, 1080, 1081], [1079, 1081, 1064], [1082, 1064, 1081], [1082, 1081, 1065], [1082, 1065, 1064], [1083, 1065, 1081], [1083, 1081, 1084], [1083, 1084, 1065], [1085, 1065, 1084], [1085, 1084, 1068], [1085, 1068, 1065], [1086, 1068, 1084], [1086, 1084, 1087], [1086, 1087, 1068], [1088, 1068, 1087], [1088, 1087, 1071], [1088, 1071, 1068], [1089, 1071, 1087], [1089, 1087, 1090], [1089, 1090, 1071], [1091, 1071, 1090], [1091, 1090, 1074], [1091, 1074, 1071], [1092, 1074, 1090], [1092, 1090, 1093], [1092, 1093, 1074], [1094, 1074, 1093], [1094, 1093, 1077], [1094, 1077, 1074], [1095, 1080, 1096], [1095, 1096, 1097], [1095, 1097, 1080], [1098, 1080, 1097], [1098, 1097, 1081], [1098, 1081, 1080], [1099, 1081, 1097], [1099, 1097, 1100], [1099, 1100, 1081], [1101, 1081, 1100], [1101, 1100, 1084], [1101, 1084, 1081], [1102, 1084, 1100], [1102, 1100, 1103], [1102, 1103, 1084], [1104, 1084, 1103], [1104, 1103, 1087], [1104, 1087, 1084], [1105, 1087, 1103], [1105, 1103, 1106], [1105, 1106, 1087], [1107, 1087, 1106], [1107, 1106, 1090], [1107, 1090, 1087], [1108, 1090, 1106], [1108, 1106, 1109], [1108, 1109, 1090], [1110, 1090, 1109], [1110, 1109, 1093], [1110, 1093, 1090]], bands: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26], columns: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5], ownership: ["overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "overlap", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend", "blend"], expectedLane: [{ at: [19.33872665255178, 15.791128492965997, -94.63553135541345], normal: [-0.7088542442100453, 0, 0.7053549889703804], halfWidth: 3.2 }, { at: [18.635825902819057, 15.90305249270916, -95.34191918494277], normal: [-0.7088234072312928, 0, 0.7053859775761216], halfWidth: 3.2 }, { at: [17.932863392733335, 16.01497649245232, -96.04824555388682], normal: [-0.7087646097057925, 0, 0.7054450567043445], halfWidth: 3.2 }, { at: [17.22984489551135, 16.124408893828804, -96.75451619788895], normal: [-0.7087062508730382, 0, 0.7055036853011346], halfWidth: 3.2 }, { at: [16.526765536472716, 16.227561930407873, -97.46072625502693], normal: [-0.7086404398555916, 0, 0.7055697888949568], halfWidth: 3.2 }, { at: [15.823615292663053, 16.327787279900527, -98.16686573436935], normal: [-0.708562155752203, 0, 0.7056484049693521], halfWidth: 3.2 }, { at: [15.12037924966871, 16.425820630219903, -98.87291976695226], normal: [-0.7084635785880363, 0, 0.7057473753505807], halfWidth: 3.2 }, { at: [14.417031756262471, 16.521304554340418, -99.5788627755009], normal: [-0.7083297678467947, 0, 0.7058816756242551], halfWidth: 3.2 }, { at: [13.713528053323413, 16.61401991812796, -100.28465011173132], normal: [-0.7081306232904118, 0, 0.7060814544784001], halfWidth: 3.2 }, { at: [13.009782409682057, 16.710366308917145, -100.99019619970925], normal: [-0.7176169657419637, 0, 0.6964380018919827], halfWidth: 3.2 }, { at: [12.325710508190205, 16.804633896995146, -101.7146717547726], normal: [-0.7422198693364395, 0, 0.670156448571674], halfWidth: 3.2 }, { at: [11.67457907790897, 16.896791417920774, -102.46897693002734], normal: [-0.7649017690166184, 0, 0.644146942673213], halfWidth: 3.2 }, { at: [11.042034664887689, 16.98680913786582, -103.23899153080252], normal: [-0.7737487888492677, 0, 0.6334925506699282], halfWidth: 3.2 }, { at: [10.412011618211373, 17.074657323002064, -104.01107879333799], normal: [-0.7692190660376721, 0, 0.638985155104664], halfWidth: 3.2 }, { at: [9.768582153253545, 17.16047407897257, -104.77199107518489], normal: [-0.7516272965800204, 0, 0.6595880585909741], halfWidth: 3.2 }, { at: [9.09772229788858, 17.244752105803936, -105.50876468363214], normal: [-0.7213958001675922, 0, 0.6925229956474799], halfWidth: 3.2 }, { at: [8.388988250956036, 17.327776864675517, -106.20910327695913], normal: [-0.6795209242777797, 0, 0.7336561275343321], halfWidth: 3.2 }, { at: [7.636523038324514, 17.409722571469896, -106.86214460393617], normal: [-0.6281757649365757, 0, 0.7780714673770964], halfWidth: 3.2 }, { at: [6.83958159578962, 17.490229604691798, -107.46001627353515], normal: [-0.5709132640636569, 0, 0.8210103805167027], halfWidth: 3.2 }, { at: [6.001664376336571, 17.5693783631368, -107.99899075977999], normal: [-0.5127583838762629, 0, 0.8585329578790805], halfWidth: 3.2 }, { at: [5.129740036434226, 17.647249245600484, -108.48121829800422], normal: [-0.4624370125660289, 0, 0.8866521355125732], halfWidth: 3.2 }, { at: [4.235240174167484, 17.723982002379174, -108.92027645713318], normal: [-0.42339268509223277, 0, 0.9059462645269803], halfWidth: 3.2 }, { at: [3.3245950562917446, 17.799716499924866, -109.32485021089957], normal: [-0.39211969507170796, 0, 0.9199142050957093], halfWidth: 3.2 }, { at: [2.4021001922649146, 17.874592604689578, -109.7016648591664], normal: [-0.36651594856481223, 0, 0.9304117687602818], halfWidth: 3.2 }, { at: [1.4704434556895964, 17.948750183125313, -110.05525384023366], normal: [-0.3449382573991191, 0, 0.9386253771246862], halfWidth: 3.2 }, { at: [0.5315200938558298, 18.022329101684075, -110.38908995462596], normal: [-0.3265468041540314, 0, 0.9451810327639825], halfWidth: 3.2 }, { at: [-0.4132411539693757, 18.095469226817887, -110.70604048109494], normal: [-0.31069520538283996, 0, 0.9505095945607887], halfWidth: 3.2 }], expectedRoad: [[168, { at: [37.75672050559807, 13.367730402116354, -82.07052558667942], normal: [-0.05764234389379349, 0, 0.9983372978059216], halfWidth: 4.8 }], [169, { at: [36.75945597005558, 13.466164778746782, -82.13968114897375], normal: [-0.0833789843324207, 0, 0.9965179100104995], halfWidth: 4.8 }], [170, { at: [35.76458025486735, 13.564506702251188, -82.23720862276446], normal: [-0.11460940111390318, 0, 0.9934106327074985], halfWidth: 4.8 }], [171, { at: [34.77365481617807, 13.662745688331908, -82.36878226132737], normal: [-0.15150126545531306, 0, 0.9884570635922629], halfWidth: 4.8 }], [172, { at: [33.788819373201264, 13.760872090452251, -82.54003439520791], normal: [-0.18163900622887108, 0, 0.9833653115182039], halfWidth: 4.8 }], [173, { at: [32.80782380649255, 13.85887854571905, -82.73241034640331], normal: [-0.1991601437760241, 0, 0.9799669593962202], halfWidth: 4.8 }], [174, { at: [31.82959120701744, 13.956759162112071, -82.93834622998223], normal: [-0.21748806067276677, 0, 0.9760662816328309], halfWidth: 4.8 }], [175, { at: [30.85532688132211, 14.054510499622195, -83.16226862770301], normal: [-0.24312971983207832, 0, 0.9700262625647904], halfWidth: 4.8 }], [176, { at: [29.886594093993654, 14.15212985214563, -83.40898396107914], normal: [-0.2761319231021091, 0, 0.9612489645078912], halfWidth: 4.8 }], [177, { at: [28.925487339227445, 14.249614513578585, -83.68386359194922], normal: [-0.31589848099989754, 0, 0.9491172666407021], halfWidth: 4.8 }], [178, { at: [27.974873146543576, 14.346961777817265, -83.99302135287873], normal: [-0.3611722330501486, 0, 0.933083331144389], halfWidth: 4.8 }], [179, { at: [27.038725408064256, 14.444168938757887, -84.34346274546728], normal: [-0.4100862518040925, 0, 0.912815777110929], halfWidth: 4.8 }], [180, { at: [26.12258088408773, 14.541233290296633, -84.74315668899106], normal: [-0.4605944060013642, 0, 0.8882921464229705], halfWidth: 4.8 }], [181, { at: [25.2341229386859, 14.638152126329723, -85.2009356686635], normal: [-0.5114460008424395, 0, 0.8596023084711255], halfWidth: 4.8 }], [182, { at: [24.383846415600022, 14.734922740753367, -85.72607006686991], normal: [-0.5633176715778573, 0, 0.826241741691001], halfWidth: 4.8 }], [183, { at: [23.58252779348445, 14.831542427463765, -86.32336853108782], normal: [-0.6165027494940292, 0, 0.7873756259310688], halfWidth: 4.8 }], [184, { at: [22.818018752991733, 14.928014384417068, -86.96731824568774], normal: [-0.6706458031420169, 0, 0.7418315792209439], halfWidth: 4.8 }], [185, { at: [22.088149891572737, 15.024347082224924, -87.65026857893456], normal: [-0.7261593470452752, 0, 0.6883343459946121], halfWidth: 4.8 }], [186, { at: [21.39565181347122, 15.120549077042428, -88.37105183532161], normal: [-0.7834131056783378, 0, 0.6246181583279139], halfWidth: 4.8 }], [187, { at: [20.74772310831339, 15.216629870449433, -89.13210364199516], normal: [-0.8419712695347619, 0, 0.5474701628345497], halfWidth: 4.8 }], [188, { at: [20.156401428789035, 15.312599424475172, -89.93778875102475], normal: [-0.8995573657979604, 0, 0.4532720179221907], halfWidth: 4.8 }], [189, { at: [19.641565177610637, 15.4084677011489, -90.79409498679973], normal: [-0.9505244811297197, 0, 0.33912925638762054], halfWidth: 4.8 }], [190, { at: [19.239412062342215, 15.504244662499845, -91.70819354784896], normal: [-0.985344590148665, 0, 0.2053807024071147], halfWidth: 4.8 }], [191, { at: [19.017717245867008, 15.59994027055727, -92.68047839484368], normal: [-0.9986961869651706, 0, 0.05887328251376605], halfWidth: 4.8 }], [192, { at: [19.065445935730658, 15.695564487350397, -93.67544345100916], normal: [-0.9983942488936424, 0, -0.0913309224553931], halfWidth: 4.8 }], [193, { at: [19.338726652551784, 15.791128492965997, -94.63553135541345], normal: [-0.9780852527946531, 0, -0.2377551991808344], halfWidth: 4.8 }], [194, { at: [19.753475929065033, 15.886644041369092, -95.54431641258769], normal: [-0.9346189043659808, 0, -0.37111615338628595], halfWidth: 4.8 }], [195, { at: [20.266407079790945, 15.982122886524698, -96.40185347869341], normal: [-0.8764576384411528, 0, -0.4875074157117832], halfWidth: 4.8 }], [196, { at: [20.854145292889633, 16.07757678239782, -97.21011997374985], normal: [-0.8101315385697999, 0, -0.5877277557790018], halfWidth: 4.8 }], [197, { at: [21.50546283898295, 16.173017482953465, -97.96816032105036], normal: [-0.7386328589988806, 0, -0.6741707900539615], halfWidth: 4.8 }], [198, { at: [22.21411552294998, 16.26845674215667, -98.67285220684475], normal: [-0.6628476452214959, 0, -0.7489419861415487], halfWidth: 4.8 }], [199, { at: [22.978506029461347, 16.363906313972418, -99.3165761833146], normal: [-0.5830225640502699, 0, -0.8129811770613479], halfWidth: 4.8 }], [200, { at: [23.80161565582504, 16.45937775092939, -99.88305654616741], normal: [-0.5000100129707205, 0, -0.8661152580389437], halfWidth: 4.8 }], [201, { at: [24.691910308514593, 16.554881870119804, -100.33535012773429], normal: [-0.4167698307797101, 0, -0.9095889761393189], halfWidth: 4.8 }], [202, { at: [25.638721363505972, 16.650424584613617, -100.6538643639588], normal: [-0.334717837563468, 0, -0.9450056401029762], halfWidth: 4.8 }], [203, { at: [26.61518853043856, 16.746034358095553, -100.86621040756032], normal: [-0.25276307516399205, 0, -0.970933454397492], halfWidth: 4.8 }], [204, { at: [27.605832897236183, 16.84176056999115, -100.99884547572003], normal: [-0.17520000692362572, 0, -0.9871927509920664], halfWidth: 4.8 }], [205, { at: [28.602713102711146, 16.93765259972594, -101.07235740530328], normal: [-0.10749068917335208, 0, -0.9957344822363259], halfWidth: 4.8 }], [206, { at: [29.601860528416243, 17.033759826725458, -101.10361638448289], normal: [-0.05317691688220963, 0, -0.9992602138840682], halfWidth: 4.8 }], [207, { at: [30.60152195792318, 17.130131630415267, -101.10525511490565], normal: [-0.013314627431210469, 0, -1.0001352546729765], halfWidth: 4.8 }], [208, { at: [31.601048758273503, 17.226817390220916, -101.0879299296189], normal: [0.012454989815018613, 0, -0.9999715817625778], halfWidth: 4.8 }], [209, { at: [32.60035811322938, 17.323866485567915, -101.06053656594753], normal: [0.025243206847696244, 0, -0.9996864476586023], halfWidth: 4.8 }], [210, { at: [33.599610164386434, 17.421328295881832, -101.03107242033117], normal: [0.026109184977045535, 0, -0.999659171469489], halfWidth: 4.8 }], [211, { at: [34.59901596024094, 17.51924924855822, -101.00756434537973], normal: [0.016490883703012136, 0, -0.9998640161315407], halfWidth: 4.8 }], [212, { at: [35.598641748116684, 17.617673134664916, -100.9981021395389], normal: [0.004686193918738817, 0, -0.9999890197329948], halfWidth: 4.8 }], [213, { at: [36.59830266149729, 17.716643745269746, -100.99819519732274], normal: [0.016412949347980012, 0, -0.9998652984745997], halfWidth: 4.8 }], [214, { at: [37.59739356168149, 17.816203498639013, -100.96529230772929], normal: [0.04825376754227558, 0, -0.9988351084728531], halfWidth: 4.8 }], [215, { at: [38.5950275654808, 17.91639389214021, -100.90173333034852], normal: [0.07519794721119864, 0, -0.997168626028327], halfWidth: 4.8 }], [216, { at: [39.59092466547197, 18.017256423140815, -100.81495720612887], normal: [0.09509617538416482, 0, -0.9954680896077502], halfWidth: 4.8 }], [217, { at: [40.58524675274977, 18.11883258900835, -100.71160947317894], normal: [0.10882549558153289, 0, -0.9940608691178995], halfWidth: 4.8 }], [218, { at: [41.57838251665274, 18.22116373568437, -100.59737889445658], normal: [0.11712149963365288, 0, -0.9931175934014885], halfWidth: 4.8 }]] };

// src/harbour/mountain/orchardJunction.ts
var ORCHARD_JUNCTION_END_ROW = orchardJunction_generated_default.fixedFromRow;
var ORCHARD_BRIDGE_ART_START_ROW = orchardJunction_generated_default.bridgeArtFromRow;
var ORCHARD_JUNCTION_POINTS = orchardJunction_generated_default.points;
var ORCHARD_JUNCTION_TRIANGLES = orchardJunction_generated_default.triangles;
var ORCHARD_JUNCTION_BANDS = orchardJunction_generated_default.bands;
var ORCHARD_JUNCTION_COLUMNS = orchardJunction_generated_default.columns;
var ORCHARD_JUNCTION_OWNERSHIP = orchardJunction_generated_default.ownership;
var size = 2;
var cells = /* @__PURE__ */ new Map();
var faces = [];
for (let index = 0; index < orchardJunction_generated_default.triangles.length; index++) {
  const ids = orchardJunction_generated_default.triangles[index], p = ORCHARD_JUNCTION_POINTS[ids[0]], q = ORCHARD_JUNCTION_POINTS[ids[1]], r = ORCHARD_JUNCTION_POINTS[ids[2]];
  const ux = q[0] - p[0], uz = q[2] - p[2], vx = r[0] - p[0], vz = r[2] - p[2], det = ux * vz - uz * vx;
  if (Math.abs(det) < 1e-12) throw new Error("Degenerate generated Orchard junction face");
  const gx = ((q[1] - p[1]) * vz - (r[1] - p[1]) * uz) / det, gz = (ux * (r[1] - p[1]) - vx * (q[1] - p[1])) / det;
  const face = { p, q, r, ux, uz, vx, vz, det, gx, gz, index };
  faces.push(face);
  for (let x2 = Math.floor(Math.min(p[0], q[0], r[0]) / size); x2 <= Math.floor(Math.max(p[0], q[0], r[0]) / size); x2++) for (let z = Math.floor(Math.min(p[2], q[2], r[2]) / size); z <= Math.floor(Math.max(p[2], q[2], r[2]) / size); z++) {
    const key2 = `${x2}:${z}`, bucket = cells.get(key2) ?? [];
    bucket.push(face);
    cells.set(key2, bucket);
  }
}
function orchardJunctionAt(x2, z, ceiling = Infinity) {
  let hit = null;
  for (const f of cells.get(`${Math.floor(x2 / size)}:${Math.floor(z / size)}`) ?? []) {
    const px = x2 - f.p[0], pz = z - f.p[2], u = (px * f.vz - pz * f.vx) / f.det, v = (f.ux * pz - f.uz * px) / f.det;
    if (u < -1e-8 || v < -1e-8 || u + v > 1 + 1e-8) continue;
    const y = f.p[1] + f.gx * px + f.gz * pz;
    if (y > ceiling + 1e-8 || hit && hit.y >= y) continue;
    hit = { y, gx: f.gx, gz: f.gz };
  }
  return hit;
}
function applyOrchardCentreProfile(points) {
  if (orchardJunction_generated_default.expectedLane.some((p, i2) => !points[i2] || points[i2].some((v, k) => v !== p.at[k]))) throw new Error("Regenerate Orchard junction: lane centre changed");
  return points.map((p, i2) => {
    if (i2 >= orchardJunction_generated_default.fixedFromRow) return p;
    const y = i2 >= 8 ? orchardJunction_generated_default.bridgeRowY[i2] : orchardJunctionAt(p[0], p[2])?.y;
    if (y === void 0) throw new Error(`Missing Orchard centre ${i2}`);
    return [p[0], Math.abs(y - p[1]) < 1e-12 ? p[1] : y, p[2]];
  });
}
function applyOrchardJunctionProfile(line, main) {
  const matches = (actual, expected) => actual.halfWidth === expected.halfWidth && actual.at.every((v, i2) => v === expected.at[i2]) && actual.normal.every((v, i2) => v === expected.normal[i2]);
  if (line.id !== "orchard-lane" || orchardJunction_generated_default.expectedLane.some((p, i2) => !matches(line.samples[i2], p)) || orchardJunction_generated_default.expectedRoad.some((pair) => {
    const [i2, p] = pair;
    return !matches(main.samples[i2], p);
  })) throw new Error("Regenerate Orchard junction: source geometry changed");
  const samples = line.samples.map((s, i2) => {
    if (i2 >= orchardJunction_generated_default.fixedFromRow) return { ...s };
    const h = i2 >= orchardJunction_generated_default.bridgeArtFromRow ? orchardJunction_generated_default.bridgeRowY[i2] : orchardJunctionAt(s.at[0], s.at[2])?.y;
    if (h === void 0) throw new Error(`Missing Orchard profile row ${i2}`);
    return { ...s, at: [s.at[0], Math.abs(h - s.at[1]) < 1e-12 ? s.at[1] : h, s.at[2]] };
  });
  let length = 0;
  for (let i2 = 0; i2 < samples.length; i2++) {
    const p = samples[i2], a = samples[Math.max(0, i2 - 1)], b = samples[Math.min(samples.length - 1, i2 + 1)];
    if (i2) length += Math.hypot(p.at[0] - a.at[0], p.at[1] - a.at[1], p.at[2] - a.at[2]);
    const dx = b.at[0] - a.at[0], dy = b.at[1] - a.at[1], dz = b.at[2] - a.at[2], distance2 = Math.hypot(dx, dy, dz) || 1;
    p.s = length;
    p.grade = dy / (Math.hypot(dx, dz) || 1);
    p.tangent = [dx / distance2, dy / distance2, dz / distance2];
  }
  return { ...line, length, samples };
}
function orchardEdgeHeight(lineId, x2, z, fallback) {
  return lineId === "orchard-lane" ? orchardJunctionAt(x2, z)?.y ?? fallback : fallback;
}
var edges = /* @__PURE__ */ new Map();
for (const f of faces) {
  const ids = orchardJunction_generated_default.triangles[f.index];
  for (let k = 0; k < 3; k++) {
    const i2 = ids[k], j = ids[(k + 1) % 3], key2 = i2 < j ? `${i2}:${j}` : `${j}:${i2}`, old = edges.get(key2);
    if (old) old.count++;
    else edges.set(key2, { a: ORCHARD_JUNCTION_POINTS[i2], b: ORCHARD_JUNCTION_POINTS[j], count: 1, face: f });
  }
}
var ORCHARD_JUNCTION_OPEN_EDGES = [...edges.values()].filter((e) => e.count === 1 && orchardJunction_generated_default.bands[e.face.index] <= 8 && orchardJunction_generated_default.ownership[e.face.index] === "blend").map((e) => ({ a: e.a, b: e.b, column: orchardJunction_generated_default.columns[e.face.index] - 1 }));
var boundary = [...edges.values()].filter((e) => e.count === 1);
var bounds = { x0: Math.min(...orchardJunction_generated_default.points.map((p) => p[0])) - 1.5, x1: Math.max(...orchardJunction_generated_default.points.map((p) => p[0])) + 1.5, z0: Math.min(...orchardJunction_generated_default.points.map((p) => p[2])) - 1.5, z1: Math.max(...orchardJunction_generated_default.points.map((p) => p[2])) + 1.5 };
function orchardGroundCeiling(x2, z) {
  if (x2 < bounds.x0 || x2 > bounds.x1 || z < bounds.z0 || z > bounds.z1) return null;
  const top = orchardJunctionAt(x2, z);
  if (top) return top.y - 0.08;
  let best = null;
  for (const e of boundary) {
    const dx = e.b[0] - e.a[0], dz = e.b[2] - e.a[2], t = Math.max(0, Math.min(1, ((x2 - e.a[0]) * dx + (z - e.a[2]) * dz) / (dx * dx + dz * dz || 1))), distance2 = Math.hypot(x2 - e.a[0] - dx * t, z - e.a[2] - dz * t);
    if (distance2 <= 1.5 && (!best || distance2 < best.distance)) best = { distance: distance2, y: e.a[1] + (e.b[1] - e.a[1]) * t };
  }
  return best ? best.y - 0.08 + best.distance * 2 : null;
}
function capOrchardGroundLattice(lattice) {
  const P = lattice.positions, I = lattice.indices, original = P.slice(), affected = /* @__PURE__ */ new Set();
  const point3 = (i2) => [P[i2 * 3], P[i2 * 3 + 1], P[i2 * 3 + 2]];
  const clip = (poly, a, b, sign) => {
    const output = [];
    for (let i2 = 0; i2 < poly.length; i2++) {
      const p = poly[i2], q = poly[(i2 + 1) % poly.length], cross = (v2) => sign * ((b[0] - a[0]) * (v2[2] - a[2]) - (b[2] - a[2]) * (v2[0] - a[0])), u = cross(p), v = cross(q);
      if (u >= -1e-10) output.push(p);
      if (u >= 0 !== v >= 0) {
        const t = u / (u - v);
        output.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, p[2] + (q[2] - p[2]) * t]);
      }
    }
    return output;
  };
  for (let i2 = 0; i2 < I.length; i2 += 3) {
    const ids = [I[i2], I[i2 + 1], I[i2 + 2]], initial = ids.map(point3), near2 = /* @__PURE__ */ new Set();
    for (let x2 = Math.floor(Math.min(...initial.map((p) => p[0])) / size); x2 <= Math.floor(Math.max(...initial.map((p) => p[0])) / size); x2++) for (let z = Math.floor(Math.min(...initial.map((p) => p[2])) / size); z <= Math.floor(Math.max(...initial.map((p) => p[2])) / size); z++) for (const f of cells.get(`${x2}:${z}`) ?? []) near2.add(f);
    for (const f of near2) {
      let poly = ids.map(point3);
      for (const [a, b] of [[f.p, f.q], [f.q, f.r], [f.r, f.p]]) {
        poly = clip(poly, a, b, Math.sign(f.det));
        if (!poly.length) break;
      }
      let excess = 0;
      for (const p of poly) excess = Math.max(excess, p[1] - (f.p[1] + f.gx * (p[0] - f.p[0]) + f.gz * (p[2] - f.p[2]) - 0.08));
      if (excess > 0) for (const id of ids) {
        P[id * 3 + 1] = P[id * 3 + 1] - excess - 1e-5;
        affected.add(id);
      }
    }
  }
  return [...affected].map((i2) => ({ index: i2, at: point3(i2), delta: P[i2 * 3 + 1] - original[i2 * 3 + 1] }));
}

// src/harbour/mountain/islandShape.ts
var ISLAND_RADIUS = 84;
var ISLAND_LAWN = 58;
var ISLAND_TERRACE = 10.4;
var SEA_LEVEL = -0.45;
var TERRACE_LEVEL = -0.05;
function islandHeight(x2, z) {
  const r = Math.hypot(x2, z);
  if (r <= ISLAND_TERRACE) return TERRACE_LEVEL;
  if (r <= ISLAND_LAWN) {
    const t = (r - ISLAND_TERRACE) / (ISLAND_LAWN - ISLAND_TERRACE);
    return TERRACE_LEVEL + Math.sin(t * Math.PI) * (1.25 + 0.35 * Math.sin(x2 * 0.065) * Math.cos(z * 0.075));
  }
  if (r <= ISLAND_RADIUS) {
    const t = (r - ISLAND_LAWN) / (ISLAND_RADIUS - ISLAND_LAWN);
    return TERRACE_LEVEL - t * t * 1.1;
  }
  return SEA_LEVEL - 0.3;
}

// src/harbour/mountain/roadLine.ts
var FOOT_Y = islandHeight(-26, -44);
var A = (x2, z, y, tag) => ({ at: [x2, z], y, ...tag ? { tag } : {} });
function anchored(list) {
  const s = [0];
  for (let i2 = 1; i2 < list.length; i2++) s.push(s[i2 - 1] + Math.hypot(list[i2].at[0] - list[i2 - 1].at[0], list[i2].at[1] - list[i2 - 1].at[1]));
  return list.map((w, i2) => {
    if (w.y !== null) return { at: w.at, y: w.y, ...w.tag ? { tag: w.tag } : {} };
    let a = i2, b = i2;
    while (list[a].y === null) a--;
    while (list[b].y === null) b++;
    const t = (s[i2] - s[a]) / (s[b] - s[a]);
    return { at: w.at, y: list[a].y + (list[b].y - list[a].y) * t, ...w.tag ? { tag: w.tag } : {} };
  });
}
var W = (x2, z, y, tag, halfWidth) => ({ at: [x2, z], y, ...tag ? { tag } : {}, ...halfWidth ? { halfWidth } : {} });
var ROAD_WAYPOINTS = anchored([
  A(-26, -44, FOOT_Y, "foot"),
  // Up the west bank past the Northlight lookout, over the river on the harbour bridge.
  A(-26.6, -48, FOOT_Y + 0.1),
  A(-27.4, -53, null),
  A(-27.6, -58, null),
  A(-26, -64, null),
  A(-22, -70, null),
  A(-15, -75, 6.2, "bf-west"),
  A(-6, -78, null),
  A(4, -78.5, 7.1, "bf-east"),
  A(14, -75.5, null),
  A(25, -71, null),
  // Neighbourhood switchbacks: three legs up the lower east slope, hairpins of ~9 unit radius.
  A(36, -65, null),
  A(48, -62.5, null),
  A(60, -64, 8.2, "hairpin-1"),
  A(69, -69, null),
  A(70, -77, null),
  A(62, -82, null),
  A(48, -82, null),
  A(34, -82.5, null),
  A(24, -86, 14.8, "hairpin-2"),
  A(19, -93, null),
  A(24, -100, null),
  A(36, -101, null),
  // East flank sweep: past Hearth Terrace and the sunny shelf, round the east arm.
  A(52, -100, 19.2, "hearth"),
  A(66, -104, null),
  A(81, -112, null),
  A(90, -124, null),
  A(93, -137, 27, "shelf"),
  A(93, -150, null),
  A(89, -162, null),
  A(79, -166, null),
  A(68, -163, null),
  A(56, -158, 35.2, "library"),
  A(42, -162, null),
  A(32, -172, null),
  A(30, -182, 40.8, "b2-east"),
  A(7, -191.5, null),
  // High timber bridge west-south-west across the gorge (a gentle arc), then the meadow sweep.
  A(-16, -194, 43.6, "b2-west"),
  A(-34, -200, null),
  A(-50, -197.5, null),
  A(-64, -192.5, null),
  A(-80, -193, null),
  A(-94, -199, null, "clearing"),
  A(-100, -213, null),
  A(-93, -228, null),
  A(-78, -235.5, null, "glasshouse"),
  A(-62, -237, null),
  A(-47, -232.5, null),
  A(-30, -224.5, 69, "b3-west"),
  // Metal-and-glass bridge in front of the dam, bowed toward town like the dam, then the loop up to Reservoir Heights.
  A(-4, -213, null),
  A(22, -210.5, 71, "b3-east"),
  A(40, -213, null),
  A(58, -208.5, null),
  A(75, -209, null),
  A(86, -219, null),
  A(89, -232, null),
  A(82, -244, null),
  A(71, -250, null),
  A(62, -250, 88.8, "reservoir"),
  // Alpine bends to the summit.
  A(47, -255, null),
  A(45, -264, null),
  A(55, -271, null),
  A(69, -272.5, null),
  A(80, -276, 96.6, "high-terrace"),
  A(85, -284, null),
  A(77, -291.5, null),
  A(58, -291, null),
  A(39, -286.5, null),
  A(25, -290.5, null),
  A(17, -293.5, 104.2, "summit")
]);
var ROAD_STEP = 1;
var authored = authorCurve(ROAD_WAYPOINTS.map((w) => [w.at[0], w.y, w.at[1]]), ROAD_STEP, 26, true);
var ROAD_CENTRE = authored.points;
var ROAD_SAMPLE_STEP = authored.step;
var ROAD_WAY_S = authored.wayS;
var roadTagS = (tag) => {
  const i2 = ROAD_WAYPOINTS.findIndex((w) => w.tag === tag);
  if (i2 < 0) throw new Error(`road tag ${tag}`);
  return ROAD_WAY_S[i2];
};
var laneJunction = (() => {
  let best = ROAD_CENTRE[0], d = Infinity;
  for (const p of ROAD_CENTRE) {
    const e = Math.hypot(p[0] - 19.5, p[2] + 95);
    if (e < d) {
      d = e;
      best = p;
    }
  }
  return best;
})();
var ORCHARD_LANE_WAYPOINTS = [
  W(laneJunction[0], laneJunction[2], laneJunction[1], "junction"),
  W(13, -101, 16.8),
  W(6, -108, 17.6, "b0-east"),
  W(-18, -115, 19.4, "b0-west"),
  W(-34, -117, 21.6),
  W(-48, -114, 24),
  W(-58, -115, 26.6),
  W(-62, -118, 27.6, "orchard")
];
var ORCHARD_LANE_HALF_WIDTH = 3.2;
var lane = authorCurve(ORCHARD_LANE_WAYPOINTS.map((w) => [w.at[0], w.y, w.at[1]]), ROAD_STEP, 16);
var ORCHARD_LANE_AUTHORED_CENTRE = lane.points;
var ORCHARD_LANE_CENTRE = applyOrchardCentreProfile(lane.points);
var ORCHARD_LANE_WAY_S = lane.wayS;
var laneTagS = (tag) => {
  const i2 = ORCHARD_LANE_WAYPOINTS.findIndex((w) => w.tag === tag);
  if (i2 < 0) throw new Error(`lane tag ${tag}`);
  return ORCHARD_LANE_WAY_S[i2];
};
var BRIDGE_TAGS = [
  { id: "b-foot", name: "Harbour bridge", type: "masonry", line: "road", from: "bf-west", to: "bf-east" },
  { id: "b0", name: "Orchard masonry bridge", type: "masonry", line: "lane", from: "b0-east", to: "b0-west" },
  { id: "b2", name: "High woodland bridge", type: "timber", line: "road", from: "b2-east", to: "b2-west" },
  { id: "b3", name: "Dam glass bridge", type: "metal-glass", line: "road", from: "b3-west", to: "b3-east" }
];

// src/harbour/mountain/terrainBase.ts
var TERRAIN_GRID_BOUNDS = { minX: -200, maxX: 200, minZ: -396, maxZ: -30 };
function makeGrid(step) {
  const b = TERRAIN_GRID_BOUNDS, cols = Math.round((b.maxX - b.minX) / step) + 1, rows = Math.round((b.maxZ - b.minZ) / step) + 1;
  return { minX: b.minX, minZ: b.minZ, step, cols, rows, data: new Float32Array(cols * rows) };
}
function sampleGrid(g2, x2, z) {
  const fx = Math.max(0, Math.min(g2.cols - 1.000001, (x2 - g2.minX) / g2.step)), fz = Math.max(0, Math.min(g2.rows - 1.000001, (z - g2.minZ) / g2.step));
  const ix = Math.floor(fx), iz = Math.floor(fz), u = fx - ix, v = fz - iz, i2 = iz * g2.cols + ix, d = g2.data;
  return (d[i2] * (1 - u) + d[i2 + 1] * u) * (1 - v) + (d[i2 + g2.cols] * (1 - u) + d[i2 + g2.cols + 1] * u) * v;
}
var bump2 = (u) => u >= 1 ? 0 : (1 - u * u) * (1 - u * u);
function shapingSamples() {
  const cut = (points, spans) => {
    const out = [];
    let run = [];
    let s = 0;
    for (let i2 = 0; i2 < points.length; i2++) {
      if (i2) s += Math.hypot(points[i2][0] - points[i2 - 1][0], points[i2][2] - points[i2 - 1][2]);
      if (spans.some(([a, b]) => s >= a && s <= b)) {
        if (run.length) out.push(run);
        run = [];
      } else run.push(points[i2]);
    }
    if (run.length) out.push(run);
    return out;
  };
  const roadSpans = BRIDGE_TAGS.filter((b) => b.line === "road").map((b) => {
    const a = roadTagS(b.from), c = roadTagS(b.to);
    return [Math.min(a, c) - 4, Math.max(a, c) + 4];
  });
  const laneSpans = BRIDGE_TAGS.filter((b) => b.line === "lane").map((b) => {
    const a = laneTagS(b.from), c = laneTagS(b.to);
    return [Math.min(a, c) - 4, Math.max(a, c) + 4];
  });
  void laneSpans;
  return cut(ROAD_CENTRE, roadSpans).map((points) => ({ points, halfWidth: 4.8 }));
}
function bakeBase() {
  const t0 = performance.now();
  const coarse = makeGrid(4);
  for (let r = 0; r < coarse.rows; r++) for (let c = 0; c < coarse.cols; c++) coarse.data[r * coarse.cols + c] = macroHeight(coarse.minX + c * 4, coarse.minZ + r * 4);
  const t1 = performance.now();
  const g2 = makeGrid(1), { cols, rows, data } = g2;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) data[r * cols + c] = sampleGrid(coarse, g2.minX + c, g2.minZ + r);
  const R2 = 24, W0 = R2 * 16 / 15, sumW = new Float32Array(cols * rows), sumY = new Float32Array(cols * rows);
  for (const run of shapingSamples()) for (const p of run.points) {
    const cx = Math.round(p[0] - g2.minX), cz = Math.round(p[2] - g2.minZ);
    for (let dz = -R2; dz <= R2; dz++) {
      const row = cz + dz;
      if (row < 0 || row >= rows) continue;
      for (let dx = -R2; dx <= R2; dx++) {
        const col = cx + dx;
        if (col < 0 || col >= cols) continue;
        const x2 = g2.minX + col, z = g2.minZ + row, w = bump2(Math.hypot(x2 - p[0], z - p[2]) / R2);
        if (w <= 0) continue;
        const i2 = row * cols + col;
        sumW[i2] += w;
        sumY[i2] += w * p[1];
      }
    }
  }
  const t2 = performance.now();
  for (let i2 = 0; i2 < data.length; i2++) if (sumW[i2] > 0) {
    const a = Math.min(1, sumW[i2] / W0 * 1.35);
    data[i2] = mix3(data[i2], sumY[i2] / sumW[i2], 0.92 * a * a * (3 - 2 * a));
  }
  const each = (minX, maxX, minZ, maxZ, fn) => {
    const c0 = Math.max(0, Math.floor(minX - g2.minX)), c1 = Math.min(cols - 1, Math.ceil(maxX - g2.minX)), r0 = Math.max(0, Math.floor(minZ - g2.minZ)), r1 = Math.min(rows - 1, Math.ceil(maxZ - g2.minZ));
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) fn(g2.minX + c, g2.minZ + r, r * cols + c);
  };
  for (const t of TERRACES) {
    const reach = Math.max(t.radii[0], t.radii[1]) * (1 + t.bank / Math.min(t.radii[0], t.radii[1])) + 1;
    each(t.at[0] - reach, t.at[0] + reach, t.at[2] - reach, t.at[2] + reach, (x2, z, i2) => {
      const w = terraceWeight(t, x2, z);
      if (w > 0) data[i2] = mix3(data[i2], t.level, w);
    });
  }
  {
    const b = RESERVOIR_BOWL, rx = b.radii[0] * 2.4, rz = b.radii[1] * 2.4;
    each(b.at[0] - rx, b.at[0] + rx, b.at[1] - rz, b.at[1] + rz, (x2, z, i2) => {
      const bowl = bowlHeight(x2, z);
      if (bowl < Infinity) data[i2] = smin(data[i2], bowl, 6);
    });
  }
  {
    let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (const p of GORGE_POINTS) {
      x0 = Math.min(x0, p[0]);
      x1 = Math.max(x1, p[0]);
      z0 = Math.min(z0, p[2]);
      z1 = Math.max(z1, p[2]);
    }
    each(x0 - 70, x1 + 70, z0 - 70, z1 + 70, (x2, z, i2) => {
      const river = nearestRiver(x2, z);
      if (river.d < 70) data[i2] = smin(data[i2], river.y + channelProfile(river.d, river.wall), 3);
    });
  }
  for (let r = 0; r < rows; r++) {
    const z = g2.minZ + r;
    if (z <= -48) continue;
    for (let c = 0; c < cols; c++) {
      const x2 = g2.minX + c, i2 = r * cols + c;
      data[i2] = Math.min(data[i2], islandHeight(x2, z) - 0.03);
    }
  }
  if (typeof process !== "undefined" && process.env?.HEARTH_TERRAIN_TIMING) console.info("base bake", { macro: t1 - t0, shape: t2 - t1, detail: performance.now() - t2 });
  return g2;
}
var BASE_GRID = typeof process !== "undefined" && process.env?.HEARTH_REBAKE === "1" ? bakeBase() : (await loadTerrainAsset()).base;
var baseHeight = (x2, z) => sampleGrid(BASE_GRID, x2, z);

// src/harbour/mountain/transport.ts
var ground = (x2, z) => z > -48 ? islandHeight(x2, z) : Math.max(islandHeight(x2, z), baseHeight(x2, z));
function pchip(ts, ys) {
  const n = ts.length, d = [], m = new Array(n).fill(0);
  for (let i2 = 0; i2 < n - 1; i2++) d.push((ys[i2 + 1] - ys[i2]) / (ts[i2 + 1] - ts[i2] || 1));
  m[0] = d[0];
  m[n - 1] = d[n - 2];
  for (let i2 = 1; i2 < n - 1; i2++) m[i2] = d[i2 - 1] * d[i2] <= 0 ? 0 : 3 * (d[i2 - 1] + d[i2]) / ((2 * d[i2] + d[i2 - 1]) / d[i2 - 1] + (d[i2] + 2 * d[i2 - 1]) / d[i2]);
  return (t) => {
    if (t <= ts[0]) return ys[0];
    if (t >= ts[n - 1]) return ys[n - 1];
    let i2 = 0;
    while (i2 < n - 2 && ts[i2 + 1] < t) i2++;
    const h = ts[i2 + 1] - ts[i2], u = (t - ts[i2]) / h, u2 = u * u, u3 = u2 * u;
    return (2 * u3 - 3 * u2 + 1) * ys[i2] + (u3 - 2 * u2 + u) * h * m[i2] + (-2 * u3 + 3 * u2) * ys[i2 + 1] + (u3 - u2) * h * m[i2 + 1];
  };
}
function planCurve(ctrl, perUnit = 2) {
  const out = [], P = (i2) => ctrl[Math.max(0, Math.min(ctrl.length - 1, i2))];
  for (let i2 = 0; i2 < ctrl.length - 1; i2++) {
    const p0 = P(i2 - 1), p1 = P(i2), p2 = P(i2 + 1), p3 = P(i2 + 2), k = (a, b) => Math.max(1e-4, Math.sqrt(Math.hypot(b[0] - a[0], b[1] - a[1])));
    const t0 = 0, t1 = k(p0, p1) + (i2 === 0 ? 1e-3 : 0), t2 = t1 + k(p1, p2), t3 = t2 + k(p2, p3) + (i2 === ctrl.length - 2 ? 1e-3 : 0), n = Math.max(4, Math.ceil(Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) * perUnit));
    for (let q = 0; q < n; q++) {
      const t = t1 + (t2 - t1) * q / n, L = (a, b, ta, tb) => ta === tb ? a : (tb - t) / (tb - ta) * a + (t - ta) / (tb - ta) * b;
      const c = (j) => {
        const A1 = L(p0[j], p1[j], t0, t1), A2 = L(p1[j], p2[j], t1, t2), A3 = L(p2[j], p3[j], t2, t3), B1 = (t2 - t) / (t2 - t0) * A1 + (t - t0) / (t2 - t0) * A2, B2 = (t3 - t) / (t3 - t1) * A2 + (t - t1) / (t3 - t1) * A3;
        return (t2 - t) / (t2 - t1) * B1 + (t - t1) / (t2 - t1) * B2;
      };
      out.push([c(0), c(1)]);
    }
  }
  out.push([ctrl[ctrl.length - 1][0], ctrl[ctrl.length - 1][1]]);
  return out;
}
function makeLine(kind, path, cruise, stations, towers, rails, hang) {
  const S = arcLengths(path), length = S[S.length - 1];
  const frameAt = (s) => {
    const c = Math.max(0, Math.min(length, s));
    let lo = 0, hi = S.length - 1;
    while (hi - lo > 1) {
      const m = lo + hi >> 1;
      if (S[m] <= c) lo = m;
      else hi = m;
    }
    const a = path[lo], b = path[hi], t = (c - S[lo]) / (S[hi] - S[lo] || 1), at = [mix3(a[0], b[0], t), mix3(a[1], b[1], t) - hang, mix3(a[2], b[2], t)];
    const i0 = Math.max(0, lo - 1), i1 = Math.min(path.length - 1, hi + 1), p = path[i0], q = path[i1], dx = q[0] - p[0], dy = q[1] - p[1], dz = q[2] - p[2], l = Math.hypot(dx, dy, dz) || 1;
    const tangent = [dx / l, dy / l, dz / l], dot = tangent[1], ux = -tangent[0] * dot, uy = 1 - tangent[1] * dot, uz = -tangent[2] * dot, ul = Math.hypot(ux, uy, uz) || 1, up = [ux / ul, uy / ul, uz / ul];
    const side = [tangent[1] * up[2] - tangent[2] * up[1], tangent[2] * up[0] - tangent[0] * up[2], tangent[0] * up[1] - tangent[1] * up[0]];
    return { s: c, at, tangent, up, side };
  };
  const built = stations.map((st) => {
    const s = S[st.index], f = frameAt(s), yaw = Math.atan2(f.tangent[0], f.tangent[2]), offset = kind === "funicular" ? 2.6 : 2.4;
    const hx = f.tangent[2], hz = -f.tangent[0], hl = Math.hypot(hx, hz) || 1, px = f.at[0] + hx / hl * offset * st.side, pz = f.at[2] + hz / hl * offset * st.side, py = f.at[1];
    return { id: st.id, name: st.name, s, at: [f.at[0], f.at[1], f.at[2]], platform: { at: [px, py, pz], yaw, half: [3.2, 1.6] } };
  });
  const railPts = (side) => path.filter((_, i2) => i2 % 2 === 0).map((p) => {
    const f = frameAt(S[path.indexOf(p)]);
    return [f.at[0] + f.side[0] * 0.8 * side, f.at[1] + f.side[1] * 0.8 * side, f.at[2] + f.side[2] * 0.8 * side];
  });
  return { kind, length, cruise, stations: built, towers, path, at: frameAt, frames(step = 1) {
    const out = [];
    for (let s = 0; s < length; s += step) out.push(frameAt(s));
    out.push(frameAt(length));
    return out;
  }, ...rails ? { rails: [railPts(-1), railPts(1)] } : {} };
}
var FUNICULAR_CONTROL = [
  // Town station west of the north lane (clear of the Northlight run and the lane's end), up past
  // Northlight, over the harbour bridge and the river, to the lower-neighbourhood station.
  { at: [-19.5, -36], y: islandHeight(-19.5, -36) + 0.3, station: { id: "town", name: "The square", side: -1 } },
  { at: [-19, -45], y: 3 },
  { at: [-17.8, -54], y: 5.8 },
  { at: [-14.5, -62.5], y: 8.8 },
  { at: [-10.5, -70], y: 11.6 },
  { at: [-7.5, -78], y: 13.6 },
  { at: [-4.5, -84], y: 14.6 },
  { at: [0, -87.5], y: 15.2 },
  { at: [5, -89], y: 15.6, station: { id: "hearth", name: "Lower neighbourhood", side: -1 } },
  { at: [9.5, -94], y: 19.6 },
  { at: [11.2, -100], y: 24.2 },
  { at: [12.2, -106], y: 26.6 },
  { at: [13.2, -116], y: 29.2 },
  { at: [15.6, -134], y: 33.6 },
  { at: [18.4, -148], y: 37.6 },
  { at: [20, -156], y: 39.6, station: { id: "library", name: "Library Woods", side: 1 } },
  { at: [22, -168], y: 45.5 },
  { at: [25, -186], y: 60 },
  { at: [29, -206], y: 80.6 },
  { at: [34, -218], y: 86 },
  { at: [39, -226], y: 87.6, station: { id: "reservoir", name: "Reservoir Heights", side: 1 } }
];
function funicular() {
  const plan2 = planCurve(FUNICULAR_CONTROL.map((c) => c.at), 4), ps2 = [0];
  for (let i2 = 1; i2 < plan2.length; i2++) ps2.push(ps2[i2 - 1] + Math.hypot(plan2[i2][0] - plan2[i2 - 1][0], plan2[i2][1] - plan2[i2 - 1][1]));
  const cs = FUNICULAR_CONTROL.map((c) => {
    let best = 0, d = Infinity;
    plan2.forEach((p, i2) => {
      const e = Math.hypot(p[0] - c.at[0], p[1] - c.at[1]);
      if (e < d) {
        d = e;
        best = i2;
      }
    });
    return ps2[best];
  });
  const y = pchip(cs, FUNICULAR_CONTROL.map((c) => c.y));
  const path = plan2.map((p, i2) => [p[0], y(ps2[i2]), p[1]]);
  const stations = FUNICULAR_CONTROL.flatMap((c, k) => c.station ? [{ ...c.station, index: plan2.findIndex((_, i2) => ps2[i2] >= cs[k] - 1e-6) }] : []);
  return makeLine("funicular", path, 5, stations, [], true, 0);
}
var GONDOLA_HANG = 3.1;
var SUMMIT_STATION_Y = 104.05;
var GONDOLA_SUPPORTS = [
  { at: [-26, 46], top: islandHeight(-26, 46) + 0.05 + GONDOLA_HANG, station: { id: "quay", name: "Waterfront" } },
  { at: [-58, -54], top: 46 },
  { at: [-80, -150], top: 74 },
  { at: [62, -214], top: 104 },
  { at: [-8, -284], top: SUMMIT_STATION_Y + GONDOLA_HANG, station: { id: "summit", name: "Summit Commons" } }
];
function gondola() {
  const path = [], supportIndex = [];
  for (let k = 0; k < GONDOLA_SUPPORTS.length - 1; k++) {
    const a = GONDOLA_SUPPORTS[k], b = GONDOLA_SUPPORTS[k + 1], span = Math.hypot(b.at[0] - a.at[0], b.at[1] - a.at[1]), sag = span * 0.032, n = Math.ceil(span);
    supportIndex.push(path.length);
    for (let q = 0; q < n; q++) {
      const t = q / n;
      path.push([mix3(a.at[0], b.at[0], t), mix3(a.top, b.top, t) - sag * 4 * t * (1 - t), mix3(a.at[1], b.at[1], t)]);
    }
  }
  const last = GONDOLA_SUPPORTS[GONDOLA_SUPPORTS.length - 1];
  supportIndex.push(path.length);
  path.push([last.at[0], last.top, last.at[1]]);
  const towers = GONDOLA_SUPPORTS.slice(1, -1).map((t) => [t.at[0], ground(t.at[0], t.at[1]), t.at[1]]);
  const stations = GONDOLA_SUPPORTS.flatMap((t, k) => t.station ? [{ ...t.station, index: supportIndex[k], side: 1 }] : []);
  return makeLine("gondola", path, 8, stations, towers, false, GONDOLA_HANG);
}
var FUNICULAR_LINE = funicular();
var GONDOLA_LINE = gondola();
var TRANSPORT_LINES = { funicular: FUNICULAR_LINE, gondola: GONDOLA_LINE };
var FUNICULAR_STOPS = FUNICULAR_LINE.stations.map((s) => ({ id: s.id, name: s.name, at: s.platform.at }));
var GONDOLA_STOPS = GONDOLA_LINE.stations.map((s) => ({ id: s.id, name: s.name, at: s.platform.at }));
var TRANSPORT_STOPS = { funicular: FUNICULAR_STOPS, gondola: GONDOLA_STOPS };

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/mountainV2/funicularFootStation.ts
init_placement();
var station = () => {
  const st = FUNICULAR_LINE.stations.find((s) => s.id === "town");
  if (!st) throw new Error("Missing native town station");
  return st.platform;
};
function funicularFootStationFloor(x2, z) {
  const p = station(), c = Math.cos(p.yaw), s = Math.sin(p.yaw), dx = x2 - MOUNTAIN_V2_OFFSET.x - p.at[0], dz = z - MOUNTAIN_V2_OFFSET.z - p.at[2], along = dx * s + dz * c, across = dx * c - dz * s;
  return Math.abs(along) <= p.half[0] + 0.05 && Math.abs(across) <= p.half[1] + 0.05 ? p.at[1] + MOUNTAIN_V2_OFFSET.y : null;
}

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/geometry/capGroundMesh.ts
function capGroundMesh(lattice, triangles, clearance) {
  const size2 = 2, cells2 = /* @__PURE__ */ new Map();
  for (const [p, q, r] of triangles) {
    const ux = q[0] - p[0], uz = q[2] - p[2], vx = r[0] - p[0], vz = r[2] - p[2], det = ux * vz - uz * vx;
    if (Math.abs(det) < 1e-12) continue;
    const f = { p, q, r, det, gx: ((q[1] - p[1]) * vz - (r[1] - p[1]) * uz) / det, gz: (ux * (r[1] - p[1]) - vx * (q[1] - p[1])) / det };
    for (let x2 = Math.floor(Math.min(p[0], q[0], r[0]) / size2); x2 <= Math.floor(Math.max(p[0], q[0], r[0]) / size2); x2++) for (let z = Math.floor(Math.min(p[2], q[2], r[2]) / size2); z <= Math.floor(Math.max(p[2], q[2], r[2]) / size2); z++) {
      const key2 = `${x2}:${z}`, a = cells2.get(key2) ?? [];
      a.push(f);
      cells2.set(key2, a);
    }
  }
  const P = lattice.positions, I = lattice.indices, original = P.slice(), affected = /* @__PURE__ */ new Set(), point3 = (i2) => [P[i2 * 3], P[i2 * 3 + 1], P[i2 * 3 + 2]];
  const clip = (poly, a, b, sign) => {
    const out = [];
    for (let i2 = 0; i2 < poly.length; i2++) {
      const p = poly[i2], q = poly[(i2 + 1) % poly.length], cross = (v2) => sign * ((b[0] - a[0]) * (v2[2] - a[2]) - (b[2] - a[2]) * (v2[0] - a[0])), u = cross(p), v = cross(q);
      if (u >= -1e-10) out.push(p);
      if (u >= 0 !== v >= 0) {
        const t = u / (u - v);
        out.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, p[2] + (q[2] - p[2]) * t]);
      }
    }
    return out;
  };
  for (let i2 = 0; i2 < I.length; i2 += 3) {
    const ids = [I[i2], I[i2 + 1], I[i2 + 2]], initial = ids.map(point3), near2 = /* @__PURE__ */ new Set();
    for (let x2 = Math.floor(Math.min(...initial.map((p) => p[0])) / size2); x2 <= Math.floor(Math.max(...initial.map((p) => p[0])) / size2); x2++) for (let z = Math.floor(Math.min(...initial.map((p) => p[2])) / size2); z <= Math.floor(Math.max(...initial.map((p) => p[2])) / size2); z++) for (const f of cells2.get(`${x2}:${z}`) ?? []) near2.add(f);
    for (const f of near2) {
      let poly = ids.map(point3);
      for (const [a, b] of [[f.p, f.q], [f.q, f.r], [f.r, f.p]]) {
        poly = clip(poly, a, b, Math.sign(f.det));
        if (!poly.length) break;
      }
      let excess = 0;
      for (const p of poly) excess = Math.max(excess, p[1] - (f.p[1] + f.gx * (p[0] - f.p[0]) + f.gz * (p[2] - f.p[2]) - clearance));
      if (excess > 0) for (const id of ids) {
        P[id * 3 + 1] = P[id * 3 + 1] - excess - 1e-5;
        affected.add(id);
      }
    }
  }
  return [...affected].map((i2) => ({ index: i2, at: point3(i2), delta: P[i2 * 3 + 1] - original[i2 * 3 + 1] }));
}

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/walkingJoinGround.ts
init_placement();
function walkingJoinGround(solids = []) {
  const triangles = [], edgeCounts = /* @__PURE__ */ new Map();
  for (const s of solids) {
    if ((s.sourceId ?? s.id.split("@")[0]) !== "mountainV2.funicularFoot.apron") continue;
    for (let k = 0; k < s.indices.length; k += 3) {
      const ids = s.indices.slice(k, k + 3), p = ids.map((i2) => [s.positions[i2 * 3] - MOUNTAIN_V2_OFFSET.x, s.positions[i2 * 3 + 1] - MOUNTAIN_V2_OFFSET.y, s.positions[i2 * 3 + 2] - MOUNTAIN_V2_OFFSET.z]);
      const [a, b, c] = p, ny = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]);
      if (ny <= 1e-9) continue;
      triangles.push(p);
      for (let i2 = 0; i2 < 3; i2++) {
        const a2 = p[i2], b2 = p[(i2 + 1) % 3], A2 = a2.join(","), B = b2.join(","), key2 = A2 < B ? `${A2}:${B}` : `${B}:${A2}`, old = edgeCounts.get(key2);
        if (old) old.count++;
        else edgeCounts.set(key2, { a: a2, b: b2, count: 1 });
      }
    }
  }
  if (!triangles.length) return null;
  const boundary2 = [...edgeCounts.values()].filter((e) => e.count === 1), clearance = 0.02;
  const bounds2 = { x0: Math.min(...triangles.flatMap((t) => t.map((p) => p[0]))) - 1.5, x1: Math.max(...triangles.flatMap((t) => t.map((p) => p[0]))) + 1.5, z0: Math.min(...triangles.flatMap((t) => t.map((p) => p[2]))) - 1.5, z1: Math.max(...triangles.flatMap((t) => t.map((p) => p[2]))) + 1.5 };
  const cell = 1, cells2 = /* @__PURE__ */ new Map();
  for (const t of triangles) {
    const xs = t.map((p) => p[0]), zs = t.map((p) => p[2]), x0 = Math.min(...xs), x1 = Math.max(...xs), z0 = Math.min(...zs), z1 = Math.max(...zs);
    const padX = (x1 - x0) * 4e-8 + 1e-9, padZ = (z1 - z0) * 4e-8 + 1e-9;
    for (let x2 = Math.floor((x0 - padX) / cell); x2 <= Math.floor((x1 + padX) / cell); x2++) for (let z = Math.floor((z0 - padZ) / cell); z <= Math.floor((z1 + padZ) / cell); z++) {
      const key2 = `${x2}:${z}`, list = cells2.get(key2) ?? [];
      list.push(t);
      cells2.set(key2, list);
    }
  }
  const edgeCells = /* @__PURE__ */ new Map(), edgeMinY = Math.min(...boundary2.flatMap((e) => [e.a[1], e.b[1]]));
  const edgeGrid = { x0: Infinity, x1: -Infinity, z0: Infinity, z1: -Infinity };
  for (let i2 = 0; i2 < boundary2.length; i2++) {
    const { a, b } = boundary2[i2], x0 = Math.floor(Math.min(a[0], b[0]) - 1e-9), x1 = Math.floor(Math.max(a[0], b[0]) + 1e-9), z0 = Math.floor(Math.min(a[2], b[2]) - 1e-9), z1 = Math.floor(Math.max(a[2], b[2]) + 1e-9);
    edgeGrid.x0 = Math.min(edgeGrid.x0, x0);
    edgeGrid.x1 = Math.max(edgeGrid.x1, x1);
    edgeGrid.z0 = Math.min(edgeGrid.z0, z0);
    edgeGrid.z1 = Math.max(edgeGrid.z1, z1);
    for (let x2 = x0; x2 <= x1; x2++) for (let z = z0; z <= z1; z++) {
      const key2 = `${x2}:${z}`, list = edgeCells.get(key2) ?? [];
      list.push(i2);
      edgeCells.set(key2, list);
    }
  }
  const edgeCandidates = (x2, z, radius) => {
    const found = /* @__PURE__ */ new Set();
    for (let cx = Math.max(edgeGrid.x0, Math.floor(x2 - radius - 1e-9)); cx <= Math.min(edgeGrid.x1, Math.floor(x2 + radius + 1e-9)); cx++) for (let cz = Math.max(edgeGrid.z0, Math.floor(z - radius - 1e-9)); cz <= Math.min(edgeGrid.z1, Math.floor(z + radius + 1e-9)); cz++) for (const i2 of edgeCells.get(`${cx}:${cz}`) ?? []) found.add(i2);
    return [...found].sort((a, b) => a - b);
  };
  const ceiling = (hx, hz) => {
    const x2 = hx - MOUNTAIN_V2_OFFSET.x, z = hz - MOUNTAIN_V2_OFFSET.z;
    if (x2 < bounds2.x0 || x2 > bounds2.x1 || z < bounds2.z0 || z > bounds2.z1) return null;
    let top = -Infinity;
    for (const [a, b, c] of cells2.get(`${Math.floor(x2 / cell)}:${Math.floor(z / cell)}`) ?? []) {
      const D = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2]);
      if (Math.abs(D) < 1e-12) continue;
      const u = ((b[2] - c[2]) * (x2 - c[0]) + (c[0] - b[0]) * (z - c[2])) / D, v = ((c[2] - a[2]) * (x2 - c[0]) + (a[0] - c[0]) * (z - c[2])) / D;
      if (u >= -1e-8 && v >= -1e-8 && u + v <= 1 + 1e-8) top = Math.max(top, u * a[1] + v * b[1] + (1 - u - v) * c[1]);
    }
    if (Number.isFinite(top)) return top + MOUNTAIN_V2_OFFSET.y - clearance;
    const grade = 0.7;
    const evaluate = (i2) => {
      const { a, b } = boundary2[i2];
      const dx = b[0] - a[0], dz = b[2] - a[2], length = Math.hypot(dx, dz);
      if (length < 1e-9) return null;
      const along = ((x2 - a[0]) * dx + (z - a[2]) * dz) / length, away = Math.abs((x2 - a[0]) * dz - (z - a[2]) * dx) / length, slope = (b[1] - a[1]) / length;
      const t = slope >= grade ? 0 : slope <= -grade ? 1 : Math.max(0, Math.min(1, (along - slope * away / Math.sqrt(grade * grade - slope * slope)) / length));
      return { distance: Math.hypot(away, along - Math.max(0, Math.min(length, along))), y: a[1] + (b[1] - a[1]) * t + grade * Math.hypot(away, along - length * t) };
    };
    let best = Infinity, distance2 = Infinity;
    const seeds = edgeCandidates(x2, z, 1.5);
    for (const i2 of seeds) {
      const value = evaluate(i2);
      if (value) {
        best = Math.min(best, value.y);
        distance2 = Math.min(distance2, value.distance);
      }
    }
    if (distance2 > 1.5) return null;
    const radius = Math.max(0, (best - edgeMinY) / grade) + 1e-8;
    const candidates = [.../* @__PURE__ */ new Set([...seeds, ...edgeCandidates(x2, z, radius)])].sort((a, b) => a - b);
    let y = Infinity;
    for (const i2 of candidates) {
      const value = evaluate(i2);
      if (value) y = Math.min(y, value.y);
    }
    return distance2 <= 1.5 ? y + MOUNTAIN_V2_OFFSET.y - clearance : null;
  };
  return { ceiling, triangles, capLattice: (lattice) => capGroundMesh(lattice, triangles, clearance) };
}

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/walkingGroundPatch.ts
var STEP = 0.5;
var CEILING_MARGIN = 1.5;
var OUTER_RING = 2;
var BOUNDARY_TOLERANCE = 0.02;
var BOUNDARY_REFINE = 5e-3;
var MAX_BOUNDARY_DEPTH = 9;
var MAX_FAIR_PASSES = 32;
var MAX_FAIR_LOWERING = 0.03;
var point2 = (p, i2) => [p[i2 * 3], p[i2 * 3 + 1], p[i2 * 3 + 2]];
var bary = (a, b, c, x2, z) => {
  const D = (b[2] - c[2]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[2] - c[2]);
  return [((b[2] - c[2]) * (x2 - c[0]) + (c[0] - b[0]) * (z - c[2])) / D, ((c[2] - a[2]) * (x2 - c[0]) + (a[0] - c[0]) * (z - c[2])) / D, 0];
};
var weighted = (p, w) => [0, 1, 2].map((j) => p[0][j] * w[0] + p[1][j] * w[1] + p[2][j] * w[2]);
var normal = (a, b, c) => {
  const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2], nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, L = Math.hypot(nx, ny, nz);
  return { nx: nx / L, ny: ny / L, nz: nz / L, slope: Math.atan2(Math.hypot(nx, nz), ny) * 180 / Math.PI, L };
};
function createWalkingGroundPatch(triangles, baseline, ceiling, owns) {
  if (!triangles.length) throw new Error("A walking ground patch requires its actual apron triangles");
  const raw = { x0: Math.min(...triangles.flatMap((t) => t.map((p) => p[0]))), x1: Math.max(...triangles.flatMap((t) => t.map((p) => p[0]))), z0: Math.min(...triangles.flatMap((t) => t.map((p) => p[2]))), z1: Math.max(...triangles.flatMap((t) => t.map((p) => p[2]))) };
  const impact = { x0: raw.x0 - CEILING_MARGIN, x1: raw.x1 + CEILING_MARGIN, z0: raw.z0 - CEILING_MARGIN, z1: raw.z1 + CEILING_MARGIN };
  const bounds2 = { x0: Math.floor((impact.x0 - OUTER_RING) / STEP) * STEP, x1: Math.ceil((impact.x1 + OUTER_RING) / STEP) * STEP, z0: Math.floor((impact.z0 - OUTER_RING) / STEP) * STEP, z1: Math.ceil((impact.z1 + OUTER_RING) / STEP) * STEP };
  const cols = Math.round((bounds2.x1 - bounds2.x0) / STEP), rows = Math.round((bounds2.z1 - bounds2.z0) / STEP), gridVertices = (cols + 1) * (rows + 1);
  if (cols * rows > 12e3) throw new Error("Walking ground exceeds its bounded12000-cell local allocation: " + JSON.stringify(bounds2));
  const xs = Float32Array.from({ length: cols + 1 }, (_, i2) => bounds2.x0 + i2 * STEP), zs = Float32Array.from({ length: rows + 1 }, (_, i2) => bounds2.z0 + i2 * STEP), P = [], B = [], baseIndices = [], paintRecipes = [];
  let maxBaselineQuantization = 0;
  for (let iz = 0; iz <= rows; iz++) for (let ix = 0; ix <= cols; ix++) {
    const x2 = xs[ix], z = zs[iz], g2 = baseline(x2, z), cap = ceiling(x2, z);
    if (!Number.isFinite(g2) || !owns(x2, z)) throw new Error("Walking ground crosses an unowned/nonfinite native floor at " + JSON.stringify([x2, z]));
    const old2 = Math.fround(g2), y = Math.fround(cap === null ? g2 : Math.min(g2, cap));
    maxBaselineQuantization = Math.max(maxBaselineQuantization, Math.abs(old2 - g2));
    P.push(x2, y, z);
    B.push(old2);
    if ((x2 < impact.x0 || x2 > impact.x1 || z < impact.z0 || z > impact.z1) && old2 !== y) throw Object.assign(new Error("Walking ceiling reached its fixed outer ring"), { proof: { bounds: bounds2, at: [x2, y, z], baseline: old2 } });
  }
  for (let iz = 0; iz < rows; iz++) for (let ix = 0; ix < cols; ix++) {
    const a = iz * (cols + 1) + ix, b = a + 1, c = a + cols + 1, d = c + 1, ad = Math.abs(P[a * 3 + 1] - P[d * 3 + 1]), bc = Math.abs(P[b * 3 + 1] - P[c * 3 + 1]);
    baseIndices.push(...ad <= bc ? [a, c, d, a, d, b] : [a, c, b, b, c, d]);
  }
  const at = (i2) => [P[i2 * 3], P[i2 * 3 + 1], P[i2 * 3 + 2]];
  const appended = /* @__PURE__ */ new Map();
  let refinedCells = 0, maxBoundaryDepth = 0, sampledMaximum = 0;
  const add = (x2, z, ids, weights) => {
    x2 = Math.fround(x2);
    z = Math.fround(z);
    const key2 = x2 + ":" + z, hit = appended.get(key2);
    if (hit !== void 0) return hit;
    const g2 = baseline(x2, z), y = Math.fround(g2), id = P.length / 3;
    if (id - gridVertices >= 2048) throw new Error("Boundary refinement exceeded its2048-vertex local allocation");
    if (!Number.isFinite(g2) || !owns(x2, z)) throw new Error("Boundary knot crosses unowned/nonfinite ground");
    maxBaselineQuantization = Math.max(maxBaselineQuantization, Math.abs(y - g2));
    P.push(x2, y, z);
    B.push(y);
    paintRecipes.push({ vertex: id, ids, weights });
    appended.set(key2, id);
    return id;
  };
  const boundaryEdge = (a, b, baseA = a, baseB = b, ta = 0, tb = 1, depth = 0) => {
    const A2 = at(a), C2 = at(b), gaps = [0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875].map((t2) => {
      const x2 = A2[0] + (C2[0] - A2[0]) * t2, z = A2[2] + (C2[2] - A2[2]) * t2;
      return { t: t2, x: x2, z, gap: Math.abs(baseline(x2, z) - (A2[1] + (C2[1] - A2[1]) * t2)) };
    }), worst = gaps.reduce((a2, b2) => a2.gap > b2.gap ? a2 : b2);
    if (worst.gap <= BOUNDARY_REFINE) {
      sampledMaximum = Math.max(sampledMaximum, worst.gap);
      return [a, b];
    }
    if (depth >= MAX_BOUNDARY_DEPTH) throw Object.assign(new Error("Boundary curve cannot meet fixed local refinement bound"), { proof: { bounds: bounds2, a: A2, b: C2, worst, depth, boundaryTolerance: BOUNDARY_TOLERANCE } });
    const t = (ta + tb) / 2, m = add((A2[0] + C2[0]) / 2, (A2[2] + C2[2]) / 2, [baseA, baseB, baseB], [1 - t, t, 0]);
    maxBoundaryDepth = Math.max(maxBoundaryDepth, depth + 1);
    return [...boundaryEdge(a, m, baseA, baseB, ta, t, depth + 1).slice(0, -1), ...boundaryEdge(m, b, baseA, baseB, t, tb, depth + 1)];
  };
  const I = [], cellStarts = [];
  for (let iz = 0; iz < rows; iz++) for (let ix = 0; ix < cols; ix++) {
    cellStarts.push(I.length);
    const cell = iz * cols + ix, a = iz * (cols + 1) + ix, b = a + 1, c = a + cols + 1, d = c + 1, original = baseIndices.slice(cell * 6, cell * 6 + 6), corners = [a, c, d, b], poly = [];
    for (let j = 0; j < 4; j++) {
      const from = corners[j], to = corners[(j + 1) % 4], A2 = at(from), C2 = at(to), boundary2 = A2[0] === C2[0] && (A2[0] === bounds2.x0 || A2[0] === bounds2.x1) || A2[2] === C2[2] && (A2[2] === bounds2.z0 || A2[2] === bounds2.z1);
      poly.push(...(boundary2 ? boundaryEdge(from, to) : [from, to]).slice(0, -1));
    }
    if (poly.length === 4) {
      I.push(...original);
      continue;
    }
    refinedCells++;
    const ids = original.slice(0, 3), T = ids.map(at), x2 = (xs[ix] + xs[ix + 1]) / 2, z = (zs[iz] + zs[iz + 1]) / 2, q = bary(...T, x2, z), mid = add(x2, z, ids, [q[0], q[1], 1 - q[0] - q[1]]);
    for (let j = 0; j < poly.length; j++) I.push(mid, poly[j], poly[(j + 1) % poly.length]);
  }
  cellStarts.push(I.length);
  if (P.length / 3 - gridVertices > 2048) throw new Error("Boundary refinement exceeded its2048-vertex local allocation");
  const positions = new Float32Array(P), old = new Float32Array(B), indices2 = new Uint32Array(I), lattice = { positions, indices: indices2, cols, rows, xs, zs };
  const beforeFace = (k) => [indices2[k], indices2[k + 1], indices2[k + 2]].map((i2) => [positions[i2 * 3], old[i2], positions[i2 * 3 + 2]]);
  const baselineGrades = Array.from({ length: indices2.length / 3 }, (_, i2) => {
    const n = normal(...beforeFace(i2 * 3));
    return Math.hypot(n.nx, n.nz) / n.ny;
  });
  capGroundMesh(lattice, triangles, 0.02);
  const capped = positions.slice();
  let passes = 0;
  for (; passes < MAX_FAIR_PASSES; passes++) {
    let violations = 0;
    for (let k = 0; k < indices2.length; k += 3) {
      const ids = [indices2[k], indices2[k + 1], indices2[k + 2]], T = ids.map((i2) => point2(positions, i2)), n = normal(...T), g2 = [-n.nx / n.ny, -n.nz / n.ny], grade = Math.hypot(...g2), limit = Math.max(Math.tan(40 * Math.PI / 180), baselineGrades[k / 3]);
      if (grade <= limit + 1e-9) continue;
      violations++;
      const target = limit - 1e-6, D = (T[1][0] - T[0][0]) * (T[2][2] - T[0][2]) - (T[2][0] - T[0][0]) * (T[1][2] - T[0][2]);
      const coefficients = [[T[1][2] - T[2][2], T[2][0] - T[1][0]], [T[2][2] - T[0][2], T[0][0] - T[2][0]], [T[0][2] - T[1][2], T[1][0] - T[0][0]]].map((v) => [v[0] / D, v[1] / D]);
      let best;
      for (let j = 0; j < 3; j++) {
        const a = coefficients[j], A2 = a[0] * a[0] + a[1] * a[1], b = g2[0] * a[0] + g2[1] * a[1], C2 = grade * grade - target * target, disc = b * b - A2 * C2;
        if (b <= 0 || disc < 0) continue;
        const delta = C2 / (b + Math.sqrt(disc));
        if (delta > 0 && (!best || delta < best.delta)) best = { j, delta };
      }
      if (best) {
        const id = ids[best.j];
        positions[id * 3 + 1] = positions[id * 3 + 1] - best.delta - 1e-6;
      } else {
        const low = Math.min(...T.map((p) => p[1])), ratio = target / grade;
        ids.forEach((id, j) => {
          if (T[j][1] > low) positions[id * 3 + 1] = low + (T[j][1] - low) * ratio - 1e-6;
        });
      }
      for (const id of ids) if (capped[id * 3 + 1] - positions[id * 3 + 1] > MAX_FAIR_LOWERING) throw Object.assign(new Error("Lower-only ground fairing exceeded its3cm local bound"), { proof: { bounds: bounds2, face: k / 3, id, before: capped[id * 3 + 1], after: positions[id * 3 + 1], passes } });
    }
    if (!violations) break;
  }
  const changes = [];
  for (let i2 = 0; i2 < old.length; i2++) if (positions[i2 * 3 + 1] !== capped[i2 * 3 + 1]) changes.push({ index: i2, before: capped[i2 * 3 + 1], after: positions[i2 * 3 + 1], extraLowering: capped[i2 * 3 + 1] - positions[i2 * 3 + 1] });
  let changedVertices = 0, maxLowering = 0, maxTopDegrees = 0, maxBaselineTopDegrees = 0, outerRingChanged = 0;
  const facesOverLimit = [];
  for (let i2 = 0; i2 < old.length; i2++) {
    const x2 = positions[i2 * 3], z = positions[i2 * 3 + 2], delta = positions[i2 * 3 + 1] - old[i2];
    if (delta > 0) throw new Error("Walking ground unexpectedly raises baseline");
    if (delta !== 0) {
      changedVertices++;
      maxLowering = Math.max(maxLowering, -delta);
      if (x2 < impact.x0 || x2 > impact.x1 || z < impact.z0 || z > impact.z1) outerRingChanged++;
    }
  }
  for (let k = 0; k < indices2.length; k += 3) {
    const T = [indices2[k], indices2[k + 1], indices2[k + 2]].map((i2) => point2(positions, i2)), n = normal(...T), before = beforeFace(k), bn = normal(...before);
    if (!Number.isFinite(n.L) || n.L <= 1e-8 || n.ny <= 0) throw new Error("Invalid canonical ground face " + k / 3);
    maxTopDegrees = Math.max(maxTopDegrees, n.slope);
    maxBaselineTopDegrees = Math.max(maxBaselineTopDegrees, bn.slope);
    if (n.slope > 40 + 1e-7) facesOverLimit.push({ index: k / 3, degrees: n.slope, baselineDegrees: bn.slope, introducedOrWorsened: bn.slope <= 40 + 1e-7 || n.slope > bn.slope + 1e-7, points: T, baselinePoints: before });
    for (const w of [[1 / 3, 1 / 3, 1 / 3], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]]) {
      const q = weighted(T, w);
      if (!owns(q[0], q[2])) throw new Error("Walking ground face crosses native ownership at " + JSON.stringify(q));
    }
  }
  const proof = { step: STEP, ceilingMargin: CEILING_MARGIN, outerRing: OUTER_RING, bounds: bounds2, dimensions: [bounds2.x1 - bounds2.x0, bounds2.z1 - bounds2.z0], triangles: indices2.length / 3, changedVertices, maxLowering, maxBaselineQuantization, maxTopDegrees, maxBaselineTopDegrees, outerRingChanged, facesOverLimit, boundarySamples: [], maxBoundaryPhysicalDelta: 0, boundaryTolerance: BOUNDARY_TOLERANCE, boundaryRefinement: { addedVertices: positions.length / 3 - gridVertices, refinedCells, maxDepth: maxBoundaryDepth, sampledMaximum }, fairing: { passes, changedVertices: changes.length, maxAdditionalLowering: Math.max(0, ...changes.map((c) => c.extraLowering)), changes } };
  const floorAt = (x2, z) => {
    if (x2 < bounds2.x0 || x2 > bounds2.x1 || z < bounds2.z0 || z > bounds2.z1) return null;
    const ix = Math.min(cols - 1, Math.floor((x2 - bounds2.x0) / STEP)), iz = Math.min(rows - 1, Math.floor((z - bounds2.z0) / STEP)), cell = iz * cols + ix;
    for (let k = cellStarts[cell]; k < cellStarts[cell + 1]; k += 3) {
      const ids = [indices2[k], indices2[k + 1], indices2[k + 2]], T = ids.map((i2) => point2(positions, i2)), q = bary(...T, x2, z), w = [q[0], q[1], 1 - q[0] - q[1]];
      if (w.some((v) => v < -1e-12)) continue;
      const n = normal(...T);
      return { y: weighted(T, w)[1], nx: n.nx, ny: n.ny, nz: n.nz, slope: n.slope, ids, weights: w };
    }
    return null;
  };
  for (const axis2 of [0, 2]) for (const fixed of axis2 === 0 ? [bounds2.x0, bounds2.x1] : [bounds2.z0, bounds2.z1]) {
    const lo = axis2 === 0 ? bounds2.z0 : bounds2.x0, hi = axis2 === 0 ? bounds2.z1 : bounds2.x1, count = Math.ceil((hi - lo) / 0.02);
    for (let i2 = 0; i2 <= count; i2++) {
      const t = lo + (hi - lo) * i2 / count, x2 = axis2 === 0 ? fixed : t, z = axis2 === 0 ? t : fixed, f = floorAt(x2, z);
      if (!f) throw new Error("Missing actual boundary triangle");
      const base = baseline(x2, z), delta = f.y - base;
      proof.boundarySamples.push({ x: x2, z, base, patch: f.y, delta });
      proof.maxBoundaryPhysicalDelta = Math.max(proof.maxBoundaryPhysicalDelta, Math.abs(delta));
    }
  }
  if (outerRingChanged) throw Object.assign(new Error("Walking cap/fairing reached its fixed outer ring; no automatic expansion"), { proof });
  if (facesOverLimit.some((f) => f.introducedOrWorsened) || passes >= MAX_FAIR_PASSES) throw Object.assign(new Error("New or worsened ground face exceeds its original/40-degree limit"), { proof });
  if (proof.maxBoundaryPhysicalDelta > BOUNDARY_TOLERANCE) throw Object.assign(new Error("Sampled canonical boundary exceeds unchanged2cm closure bound"), { proof });
  const paintLattice = { positions: positions.slice(0, gridVertices * 3), indices: new Uint32Array(baseIndices), cols, rows, xs, zs };
  const boundaryPoints = Array.from({ length: positions.length / 3 }, (_, i2) => point2(positions, i2)).filter((p) => p[0] === bounds2.x0 || p[0] === bounds2.x1 || p[2] === bounds2.z0 || p[2] === bounds2.z1);
  return { lattice, paintLattice, paintRecipes, boundaryPoints, bounds: bounds2, floorAt, height: (x2, z) => floorAt(x2, z)?.y ?? baseline(x2, z), baselineHeight: baseline, proof };
}
var area = (p) => {
  let a = 0;
  for (let i2 = 1; i2 < p.length - 1; i2++) {
    const p0 = p[0].p, p1 = p[i2].p, p2 = p[i2 + 1].p;
    a += (p1[0] - p0[0]) * (p2[2] - p0[2]) - (p1[2] - p0[2]) * (p2[0] - p0[0]);
  }
  return a;
};
var clean = (p) => p.filter((v, i2) => i2 === 0 || v.p.some((x2, j) => x2 !== p[i2 - 1].p[j])).filter((v, i2, all) => i2 !== all.length - 1 || all.length < 2 || v.p.some((x2, j) => x2 !== all[0].p[j]));
function split(poly, axis2, at, sign) {
  const inside = [], outside = [];
  for (let i2 = 0; i2 < poly.length; i2++) {
    const a = poly[i2], b = poly[(i2 + 1) % poly.length], da = (a.p[axis2] - at) * sign, db = (b.p[axis2] - at) * sign, ia = da >= 0, ib = db >= 0;
    (ia ? inside : outside).push(a);
    if (ia !== ib) {
      const t = da / (da - db), p = a.p.map((x2, j) => j === axis2 ? at : x2 + (b.p[j] - x2) * t), weights = a.weights.map((x2, j) => x2 + (b.weights[j] - x2) * t), q = { p, weights };
      inside.push(q);
      outside.push(q);
    }
  }
  return [clean(inside), clean(outside)];
}
function composeWalkingGround(base, patch) {
  const B = patch.bounds, WIDTH = 1.5, outer = { x0: B.x0 - WIDTH, x1: B.x1 + WIDTH, z0: B.z0 - WIDTH, z1: B.z1 + WIDTH }, MAX_PASSES = 10, MAX_FACES = 8192, TARGET_ERROR = 2e-3, ROUNDING = 1e-7;
  const baseVertices = base.positions.length / 3, patchVertices = patch.lattice.positions.length / 3, positions = [...base.positions, ...patch.lattice.positions], indices2 = [], recipes = [], boundaryGaps = [], inheritedCoreBoundaryGaps = [];
  const faces2 = [], exteriorFaces = [], originalOuterNodes = /* @__PURE__ */ new Map(), nodes2 = /* @__PURE__ */ new Map(), coreNodes = /* @__PURE__ */ new Map();
  for (let i2 = 0; i2 < patchVertices; i2++) {
    const p = point2(patch.lattice.positions, i2);
    if (p[0] === B.x0 || p[0] === B.x1 || p[2] === B.z0 || p[2] === B.z1) coreNodes.set(p[0] + ":" + p[2], baseVertices + i2);
  }
  let clippedBaseTriangles = 0, maxBoundaryDrawnGap = 0, maxInheritedCoreBoundaryGap = 0, innerJoinSamples = 0, outerJoinSamples = 0;
  const get = (id) => [positions[id * 3], positions[id * 3 + 1], positions[id * 3 + 2]];
  const planes = (box2) => [[0, box2.x0, 1], [0, box2.x1, -1], [2, box2.z0, 1], [2, box2.z1, -1]];
  const onSide = (a, b, box2, axis2, fixed) => {
    const other = axis2 === 0 ? 2 : 0, lo = other === 0 ? box2.x0 : box2.z0, hi = other === 0 ? box2.x1 : box2.z1;
    return a[axis2] === fixed && b[axis2] === fixed && a[other] >= lo && a[other] <= hi && b[other] >= lo && b[other] <= hi;
  };
  for (let i2 = 0; i2 < baseVertices; i2++) {
    const p = point2(base.positions, i2);
    if (planes(outer).some(([axis2, fixed]) => onSide(p, p, outer, axis2, fixed))) originalOuterNodes.set(p[0] + ":" + p[2], i2);
  }
  const sourceAt = (ids, x2, z) => {
    const T = ids.map((i2) => point2(base.positions, i2)), q = bary(...T, x2, z), weights2 = [q[0], q[1], 1 - q[0] - q[1]];
    return { y: weighted(T, weights2)[1], weights: weights2 };
  };
  const target = (ids, x2, z) => {
    const original = sourceAt(ids, x2, z), d = Math.max(0, B.x0 - x2, x2 - B.x1, B.z0 - z, z - B.z1), amount = Math.max(0, Math.min(1, 1 - d / WIDTH));
    const cx = Math.max(B.x0, Math.min(B.x1, x2)), cz = Math.max(B.z0, Math.min(B.z1, z)), edge2 = patch.floorAt(cx, cz);
    if (!edge2) throw new Error("Missing common core edge in render collar");
    const physical = patch.baselineHeight(x2, z), edgeError = edge2.y - patch.baselineHeight(cx, cz), y = original.y + amount * (physical - original.y + edgeError);
    return { ...original, physical, y, amount, edge: edge2 };
  };
  const node2 = (ids, x2, z) => {
    x2 = Math.fround(x2);
    z = Math.fround(z);
    const key2 = x2 + ":" + z, old = nodes2.get(key2);
    if (old) return old.index;
    const t = target(ids, x2, z), shared = coreNodes.get(key2) ?? originalOuterNodes.get(key2), index = shared ?? positions.length / 3;
    if (shared === void 0) {
      positions.push(x2, Math.fround(t.y), z);
      recipes.push({ vertex: index, source: "base", ids, weights: t.weights, patchBlend: { ids: t.edge.ids, weights: t.edge.weights, amount: t.amount } });
    }
    nodes2.set(key2, { index, point: get(index) });
    return index;
  };
  const addFace = (out, a, b, c, source) => {
    const A2 = get(a), C2 = get(b), D = get(c), ny = (C2[2] - A2[2]) * (D[0] - A2[0]) - (C2[0] - A2[0]) * (D[2] - A2[2]);
    if (a === b || a === c || b === c || ny === 0) return;
    if (ny < 0) throw new Error("Render collar face inverted after Float32 conversion");
    out.push({ ids: [a, b, c], source });
  };
  const appendBase = (p, ids) => {
    const mapped = p.map((v) => {
      if (planes(outer).some(([axis2, fixed]) => onSide(v.p, v.p, outer, axis2, fixed))) return node2(ids, v.p[0], v.p[2]);
      for (const id of ids) {
        const old = point2(base.positions, id);
        if (old.every((n, k) => n === v.p[k])) return id;
      }
      const index = positions.length / 3;
      positions.push(...v.p.map(Math.fround));
      recipes.push({ vertex: index, source: "base", ids, weights: v.weights });
      return index;
    });
    for (let j = 1; j < p.length - 1; j++) {
      const A2 = get(mapped[0]), C2 = get(mapped[j]), D = get(mapped[j + 1]), ny = (C2[2] - A2[2]) * (D[0] - A2[0]) - (C2[0] - A2[0]) * (D[2] - A2[2]);
      if (ny > 0) exteriorFaces.push({ ids: [mapped[0], mapped[j], mapped[j + 1]], source: ids });
      else if (ny < 0) throw new Error("Original exterior clipping inverted a face");
    }
  };
  const collarPolygon = (poly, source) => {
    const boundary2 = [];
    for (let j = 0; j < poly.length; j++) {
      const a = poly[j].p, b = poly[(j + 1) % poly.length].p;
      boundary2.push(node2(source, a[0], a[2]));
      for (const [axis2, fixed] of planes(B)) if (a[axis2] === fixed && b[axis2] === fixed) {
        const other = axis2 === 0 ? 2 : 0, delta = b[other] - a[other];
        if (Math.abs(delta) < 1e-12) continue;
        const knots = patch.boundaryPoints.filter((p) => p[axis2] === fixed).map((p) => ({ p, t: (p[other] - a[other]) / delta })).filter((q) => q.t > 1e-12 && q.t < 1 - 1e-12).sort((a2, b2) => a2.t - b2.t);
        for (const q of knots) boundary2.push(node2(source, q.p[0], q.p[2]));
      }
    }
    const unique = boundary2.filter((id, j) => id !== boundary2[(j + boundary2.length - 1) % boundary2.length]);
    if (unique.length < 3) return;
    const centre = node2(source, unique.reduce((sum, id) => sum + get(id)[0], 0) / unique.length, unique.reduce((sum, id) => sum + get(id)[2], 0) / unique.length);
    for (let j = 0; j < unique.length; j++) addFace(faces2, centre, unique[j], unique[(j + 1) % unique.length], source);
  };
  for (let k = 0; k < base.indices.length; k += 3) {
    const ids = [base.indices[k], base.indices[k + 1], base.indices[k + 2]], tri = ids.map((i2, j) => ({ p: point2(base.positions, i2), weights: [+(j === 0), +(j === 1), +(j === 2)] }));
    if (Math.max(...tri.map((v) => v.p[0])) <= outer.x0 || Math.min(...tri.map((v) => v.p[0])) >= outer.x1 || Math.max(...tri.map((v) => v.p[2])) <= outer.z0 || Math.min(...tri.map((v) => v.p[2])) >= outer.z1) {
      exteriorFaces.push({ ids: [...ids], source: ids });
      continue;
    }
    let kept = tri;
    const outside = [];
    for (const [axis2, at, sign] of planes(outer)) {
      const pair = split(kept, axis2, at, sign);
      if (pair[1].length >= 3 && Math.abs(area(pair[1])) > 1e-12) outside.push(pair[1]);
      kept = pair[0];
      if (kept.length < 3) break;
    }
    if (kept.length < 3 || Math.abs(area(kept)) <= 1e-12) {
      exteriorFaces.push({ ids: [...ids], source: ids });
      continue;
    }
    clippedBaseTriangles++;
    for (const p of outside) appendBase(p, ids);
    for (const [axis2, at, sign] of planes(B)) {
      const pair = split(kept, axis2, at, sign);
      if (pair[1].length >= 3 && Math.abs(area(pair[1])) > 1e-12) collarPolygon(pair[1], ids);
      kept = pair[0];
      if (kept.length < 3) break;
    }
  }
  const seedNodes = [...nodes2.values()], conforming = [];
  for (const f of faces2) {
    const polygon = [];
    let splitEdge = false;
    for (let j = 0; j < 3; j++) {
      const a = f.ids[j], b = f.ids[(j + 1) % 3], A2 = get(a), C2 = get(b), dx = C2[0] - A2[0], dz = C2[2] - A2[2], length2 = dx * dx + dz * dz;
      polygon.push(a);
      const between = [];
      for (const n of seedNodes) {
        if (n.index === a || n.index === b) continue;
        const q = n.point, t = ((q[0] - A2[0]) * dx + (q[2] - A2[2]) * dz) / length2;
        if (t <= 1e-8 || t >= 1 - 1e-8) continue;
        const distance2 = Math.abs((q[0] - A2[0]) * dz - (q[2] - A2[2]) * dx) / Math.sqrt(length2);
        if (distance2 <= 1e-7) between.push({ index: n.index, t });
      }
      between.sort((a2, b2) => a2.t - b2.t);
      for (const n of between) polygon.push(n.index);
      if (between.length) splitEdge = true;
    }
    if (!splitEdge) {
      conforming.push(f);
      continue;
    }
    const c = node2(f.source, polygon.reduce((sum, id) => sum + get(id)[0], 0) / polygon.length, polygon.reduce((sum, id) => sum + get(id)[2], 0) / polygon.length);
    for (let j = 0; j < polygon.length; j++) addFace(conforming, c, polygon[j], polygon[(j + 1) % polygon.length], f.source);
  }
  const weights = [[1 / 3, 1 / 3, 1 / 3], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5], [0.8, 0.1, 0.1], [0.1, 0.8, 0.1], [0.1, 0.1, 0.8]];
  const assess = (f) => {
    const T = f.ids.map(get);
    let maxTargetError = 0, maxPhysicalError = 0, maxInheritedPhysicalError = 0, maxWorsening = 0;
    for (const w of weights) {
      const q = weighted(T, w), t = target(f.source, q[0], q[2]), error = Math.abs(q[1] - t.physical), old = Math.abs(sourceAt(f.source, q[0], q[2]).y - t.physical);
      maxTargetError = Math.max(maxTargetError, Math.abs(q[1] - t.y));
      maxPhysicalError = Math.max(maxPhysicalError, error);
      maxInheritedPhysicalError = Math.max(maxInheritedPhysicalError, old);
      maxWorsening = Math.max(maxWorsening, error - Math.max(0.06, old));
    }
    return { maxTargetError, maxPhysicalError, maxInheritedPhysicalError, maxWorsening, bad: maxWorsening > ROUNDING };
  };
  let current = conforming, refinementPasses = 0;
  const refinementHistory = [];
  const edgeKey = (a, b) => a < b ? a + ":" + b : b + ":" + a;
  for (; refinementPasses < MAX_PASSES; refinementPasses++) {
    const splitEdges = /* @__PURE__ */ new Map(), checks = current.map(assess);
    refinementHistory.push({ pass: refinementPasses, triangles: current.length, failingPhysicalFaces: checks.filter((q) => q.bad).length, maxTargetError: Math.max(0, ...checks.map((q) => q.maxTargetError)), maxWorsening: Math.max(0, ...checks.map((q) => q.maxWorsening)) });
    for (let fi = 0; fi < current.length; fi++) {
      const f = current[fi];
      if (!checks[fi].bad) continue;
      let selected;
      for (let j = 0; j < 3; j++) {
        const a = f.ids[j], b = f.ids[(j + 1) % 3], A2 = get(a), C2 = get(b), length = Math.hypot(A2[0] - C2[0], A2[2] - C2[2]);
        if (!selected || length > selected.length) selected = { a, b, length };
      }
      const e = selected;
      splitEdges.set(edgeKey(e.a, e.b), { a: e.a, b: e.b, source: f.source });
    }
    if (!splitEdges.size) break;
    const mids = /* @__PURE__ */ new Map();
    for (const [key2, e] of splitEdges) {
      const a = get(e.a), b = get(e.b), mid = node2(e.source, (a[0] + b[0]) / 2, (a[2] + b[2]) / 2);
      if (mid === e.a || mid === e.b) throw new Error("Collar refinement reached Float32 plan resolution");
      mids.set(key2, mid);
    }
    const next = [];
    for (const f of current) {
      const [A2, C2, D] = f.ids, m = [mids.get(edgeKey(A2, C2)), mids.get(edgeKey(C2, D)), mids.get(edgeKey(D, A2))], count = m.filter((q) => q !== void 0).length;
      if (!count) {
        next.push(f);
        continue;
      }
      if (count === 3) {
        addFace(next, A2, m[0], m[2], f.source);
        addFace(next, m[0], C2, m[1], f.source);
        addFace(next, m[2], m[1], D, f.source);
        addFace(next, m[0], m[1], m[2], f.source);
        continue;
      }
      if (count === 1) {
        const j2 = m.findIndex((q) => q !== void 0), a2 = f.ids[j2], b2 = f.ids[(j2 + 1) % 3], c2 = f.ids[(j2 + 2) % 3], v2 = m[j2];
        addFace(next, a2, v2, c2, f.source);
        addFace(next, v2, b2, c2, f.source);
        continue;
      }
      const j = m.findIndex((q, k) => q !== void 0 && m[(k + 1) % 3] !== void 0), a = f.ids[j], b = f.ids[(j + 1) % 3], c = f.ids[(j + 2) % 3], u = m[j], v = m[(j + 1) % 3];
      addFace(next, a, u, c, f.source);
      addFace(next, u, v, c, f.source);
      addFace(next, u, b, v, f.source);
    }
    if (next.length > MAX_FACES) throw Object.assign(new Error("Render collar exceeded its bounded8192-face allocation"), { proof: { refinementPasses, triangles: next.length, outer, refinementHistory } });
    current = next;
  }
  const assessments = current.map(assess), failed = assessments.map((a, i2) => ({ ...a, index: i2 })).filter((a) => a.bad);
  if (failed.length) throw Object.assign(new Error("Render collar failed unchanged no-worsened inherited-or6cm physical error bound"), { proof: { outer, refinementPasses, triangles: current.length, refinementHistory, failures: failed.slice(0, 30) } });
  const outerNodes = [...nodes2.values()].filter((n) => planes(outer).some(([axis2, fixed]) => onSide(n.point, n.point, outer, axis2, fixed))), exterior = [];
  for (const f of exteriorFaces) {
    const polygon = [];
    let changed = false;
    for (let j = 0; j < 3; j++) {
      const a = f.ids[j], b = f.ids[(j + 1) % 3], A2 = get(a), C2 = get(b);
      polygon.push(a);
      if (!planes(outer).some(([axis2, fixed]) => onSide(A2, C2, outer, axis2, fixed))) continue;
      const dx = C2[0] - A2[0], dz = C2[2] - A2[2], length2 = dx * dx + dz * dz, between = outerNodes.map((n) => ({ index: n.index, t: ((n.point[0] - A2[0]) * dx + (n.point[2] - A2[2]) * dz) / length2 })).filter((q) => q.t > 1e-8 && q.t < 1 - 1e-8 && Math.abs((get(q.index)[0] - A2[0]) * dz - (get(q.index)[2] - A2[2]) * dx) < 1e-10).sort((a2, b2) => a2.t - b2.t);
      for (const q of between) polygon.push(q.index);
      if (between.length) changed = true;
    }
    if (!changed) {
      exterior.push(f);
      continue;
    }
    const cx = polygon.reduce((sum, id) => sum + get(id)[0], 0) / polygon.length, cz = polygon.reduce((sum, id) => sum + get(id)[2], 0) / polygon.length, index = node2(f.source, cx, cz);
    for (let j = 0; j < polygon.length; j++) addFace(exterior, index, polygon[j], polygon[(j + 1) % polygon.length], f.source);
  }
  const exteriorBoundaryAddedTriangles = exterior.length - exteriorFaces.length;
  if (current.length + exteriorBoundaryAddedTriangles > MAX_FACES) throw Object.assign(new Error("Collar and shared exterior subdivisions exceed unchanged8192-face bound"), { proof: { collarTriangles: current.length, exteriorBoundaryAddedTriangles, refinementHistory } });
  const exteriorEdges = /* @__PURE__ */ new Map();
  for (const f of exterior) for (let j = 0; j < 3; j++) {
    const key2 = edgeKey(f.ids[j], f.ids[(j + 1) % 3]);
    exteriorEdges.set(key2, (exteriorEdges.get(key2) ?? 0) + 1);
  }
  let sharedOuterEdges = 0;
  for (const f of current) for (let j = 0; j < 3; j++) {
    const a = f.ids[j], b = f.ids[(j + 1) % 3], A2 = get(a), C2 = get(b);
    if (planes(outer).some(([axis2, fixed]) => onSide(A2, C2, outer, axis2, fixed))) {
      const count = exteriorEdges.get(edgeKey(a, b)) ?? 0;
      if (count !== 1) throw Object.assign(new Error("Collar outer edge does not share exactly one actual exterior edge"), { proof: { a: A2, b: C2, count } });
      sharedOuterEdges++;
    }
  }
  const edgeCounts = /* @__PURE__ */ new Map();
  for (const f of current) for (let j = 0; j < 3; j++) {
    const a = f.ids[j], b = f.ids[(j + 1) % 3], key2 = edgeKey(a, b), old = edgeCounts.get(key2);
    if (old) old.count++;
    else edgeCounts.set(key2, { a, b, count: 1 });
  }
  const badEdges = [...edgeCounts.values()].filter((e) => {
    if (e.count === 2) return false;
    if (e.count !== 1) return true;
    const a = get(e.a), b = get(e.b);
    return ![B, outer].some((box2) => planes(box2).some(([axis2, fixed]) => onSide(a, b, box2, axis2, fixed)));
  });
  if (badEdges.length) throw Object.assign(new Error("Render collar has an unmatched or nonmanifold interior edge"), { proof: { count: badEdges.length, edges: badEdges.slice(0, 30).map((e) => ({ ...e, a: get(e.a), b: get(e.b) })), triangles: current.length } });
  for (const f of current) for (let j = 0; j < 3; j++) {
    const a = get(f.ids[j]), b = get(f.ids[(j + 1) % 3]);
    for (const [box2, inner] of [[B, true], [outer, false]]) for (const [axis2, fixed] of planes(box2)) if (onSide(a, b, box2, axis2, fixed)) {
      for (const u of [0, 0.25, 0.5, 0.75, 1]) {
        const q = a.map((v, k) => v + (b[k] - v) * u), expected = inner ? patch.floorAt(q[0], q[2])?.y : sourceAt(f.source, q[0], q[2]).y;
        if (expected === void 0) throw new Error("Missing shared core floor at actual collar join");
        const delta = q[1] - expected;
        boundaryGaps.push({ x: q[0], z: q[2], base: expected, patch: q[1], delta });
        maxBoundaryDrawnGap = Math.max(maxBoundaryDrawnGap, Math.abs(delta));
        if (inner) {
          innerJoinSamples++;
          const old = sourceAt(f.source, q[0], q[2]).y, difference = expected - old;
          inheritedCoreBoundaryGaps.push({ x: q[0], z: q[2], base: old, patch: expected, delta: difference });
          maxInheritedCoreBoundaryGap = Math.max(maxInheritedCoreBoundaryGap, Math.abs(difference));
        } else outerJoinSamples++;
      }
    }
  }
  if (!innerJoinSamples || !outerJoinSamples || maxBoundaryDrawnGap > 1e-6) throw Object.assign(new Error("Render collar does not close both actual Float32 edges"), { proof: { innerJoinSamples, outerJoinSamples, maxBoundaryDrawnGap, outer } });
  for (const f of exterior) indices2.push(...f.ids);
  for (const f of current) indices2.push(...f.ids);
  const patchIndexStart = indices2.length;
  for (const i2 of patch.lattice.indices) indices2.push(baseVertices + i2);
  const patchIndexCount = indices2.length - patchIndexStart;
  const collarProof = { width: WIDTH, triangles: current.length, refinementPasses, maxTargetError: Math.max(0, ...assessments.map((a) => a.maxTargetError)), maxPhysicalError: Math.max(0, ...assessments.map((a) => a.maxPhysicalError)), maxInheritedPhysicalError: Math.max(0, ...assessments.map((a) => a.maxInheritedPhysicalError)), maxWorseningBeyondInheritedOrSixCm: Math.max(0, ...assessments.map((a) => a.maxWorsening)), innerJoinSamples, outerJoinSamples, inheritedCoreBoundaryGaps, maxInheritedCoreBoundaryGap, sharedOuterEdges, exteriorBoundaryAddedTriangles, targetApproximation: { reference: TARGET_ERROR, facesAboveReference: assessments.filter((a) => a.maxTargetError > TARGET_ERROR).length, acceptanceGate: false }, refinementHistory };
  return { positions: new Float32Array(positions), indices: new Uint32Array(indices2), baseVertices, patchVertices, recipes, patchIndexStart, patchIndexCount, seamTriangles: 0, clippedBaseTriangles, boundaryGaps, maxBoundaryDrawnGap, collarProof };
}

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/geography.ts
init_drawnRoadFloor();
init_drawnRoadGround();

// src/harbour/village/layout.ts
var VILLAGE_SITES = {
  home: { spot: BUILDING_SITES.home, half: BUILDING_FORMS.home.half, door: BUILDING_FORMS.home.door, name: "Our home", exterior: "village-home", entry: "kitchen" },
  bank: { spot: [8, -26], half: [4.6, 3.6], door: [0, 3.35], name: "The Fund bank", exterior: "village-bank", entry: "bank" },
  library: { spot: BUILDING_SITES.library, half: BUILDING_FORMS.library.half, door: BUILDING_FORMS.library.door, name: "The Library", exterior: "village-library", entry: "library" },
  glasshouse: { spot: BUILDING_SITES.glasshouse, half: BUILDING_FORMS.glasshouse.half, door: BUILDING_FORMS.glasshouse.door, name: "The Glasshouse", exterior: "village-glasshouse", entry: "glasshouse" },
  studio: { spot: [33, 10], half: [3.8, 2.9], door: [1.95, 2.82], name: "The Kiln", exterior: "village-studio", entry: "kiln" },
  cottage: { spot: BUILDING_SITES.cottage, half: BUILDING_FORMS.cottage.half, door: BUILDING_FORMS.cottage.door, name: "Hercules\u2019s cottage", exterior: "village-cottage", entry: "cottage" },
  boathouse: { spot: [42, -41], half: [3.6, 3], door: [1.5, 2.8], name: "The Boathouse", exterior: "village-boathouse", entry: "boathouse" }
};
var VILLAGE_WATERFRONT = { spot: [0, 69], half: [3.8, 3.6], door: [0, 3.45], yaw: Math.PI };

// src/harbour/village/world.ts
var HARBOUR_LAND = Object.freeze({ radius: 84, lawn: 58, terrace: 10.4, shore: 73.2, overview: 160 });
var HARBOUR_WANDERS = [
  { id: "orchard", name: "The old orchard", at: [-47, 25], words: "Apple trees, a low stone wall, and nowhere you have to be." },
  { id: "lookout", name: "Northlight lookout", at: [-5, -62], words: "The whole harbour behind you. The next part of the journey ahead." },
  { id: "tidepools", name: "The tide pools", at: [49, 43], words: "Small pools keep a piece of the sky when the tide goes out." },
  { id: "meadow", name: "The long meadow", at: [-17, 51], words: "A little room between one thing and the next." }
];
var HARBOUR_LANDMARK_SOLIDS = [
  ...[[-3, -2], [-3, 2], [3, -2], [3, 2]].map(([x2, z], i2) => ({ kind: "circle", id: `orchard-trunk-${i2}`, x: HARBOUR_WANDERS[0].at[0] + x2, z: HARBOUR_WANDERS[0].at[1] + z, r: 0.24 })),
  ...[-2.3, 2.3].flatMap((x2, i2) => [-1.6, 1.6].map((z, j) => ({ kind: "circle", id: `lookout-post-${i2}-${j}`, x: HARBOUR_WANDERS[1].at[0] + x2, z: HARBOUR_WANDERS[1].at[1] + z, r: 0.13 }))),
  ...HARBOUR_WANDERS.map((w) => ({ kind: "circle", id: `${w.id}-waymarker`, x: w.at[0] + 1.5, z: w.at[1], r: 0.1 }))
];
var curve = (from, control, to) => Array.from({ length: 19 }, (_, i2) => {
  const t = i2 / 18;
  return [(1 - t) * (1 - t) * from[0] + 2 * (1 - t) * t * control[0] + t * t * to[0], (1 - t) * (1 - t) * from[1] + 2 * (1 - t) * t * control[1] + t * t * to[1]];
});
var join = (first, second) => [...first, ...second.slice(1)];
var north = [0, -18];
var south = [0, 20];
var east = [23, -4];
var west = [-25, 4];
var northEnd = [-3, -43];
var southEnd = [0, 44];
var eastEnd = [31, -17];
var westEnd = [-35, 14];
var approaches = {
  home: [south, [-12, 13]],
  bank: [north, [3, -17]],
  library: [north, [-12, -8]],
  glasshouse: [west, [-32, -2]],
  studio: [east, [22, 7]],
  cottage: [south, [12, 21]],
  boathouse: [eastEnd, [30, -29]]
};
var HARBOUR_LANES = [
  { id: "north-road", points: join(curve([0, 0], [1, -7], north), curve(north, [-1, -28], northEnd)) },
  { id: "south-road", points: join(curve([0, 0], [-1, 8], south), curve(south, [3, 31], southEnd)) },
  { id: "east-road", points: join(curve([0, 0], [11, -1], east), curve(east, [29, -6], eastEnd)) },
  { id: "west-road", points: join(curve([0, 0], [-11, 0], west), curve(west, [-32, 6], westEnd)) },
  ...Object.entries(VILLAGE_SITES).filter(([, site]) => site.spot[1] > -70).map(([id, site]) => {
    const [x2, z] = site.spot, yaw = Math.atan2(-x2, -z), c = Math.cos(yaw), s = Math.sin(yaw);
    const end = [x2 + site.door[0] * c + (site.door[1] + 1.1) * s, z + (site.door[1] + 1.1) * c - site.door[0] * s];
    const [from, control] = approaches[id];
    return { id: site.entry, points: curve(from, control, end) };
  }),
  { id: "campfire", points: curve(southEnd, [2, 59], [VILLAGE_WATERFRONT.spot[0], VILLAGE_WATERFRONT.spot[1] - VILLAGE_WATERFRONT.door[1] - 1.1]) },
  { id: "orchard", points: join(curve(westEnd, [-35, 32], [-47, 31]), curve([-47, 31], [-47, 28], HARBOUR_WANDERS[0].at)) },
  { id: "lookout", points: curve(northEnd, [-7, -54], HARBOUR_WANDERS[1].at) },
  { id: "tidepools", points: join(curve(east, [44, -5], [45, 20]), curve([45, 20], [57, 31], HARBOUR_WANDERS[2].at)) },
  { id: "meadow", points: curve(southEnd, [-10, 42], HARBOUR_WANDERS[3].at) }
];
function distanceToTrail(x2, z, points) {
  let closest = Infinity;
  for (let i2 = 1; i2 < points.length; i2++) {
    const a = points[i2 - 1], b = points[i2], dx = b[0] - a[0], dz = b[1] - a[1], square = dx * dx + dz * dz;
    const t = square ? Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[1]) * dz) / square)) : 0;
    closest = Math.min(closest, Math.hypot(x2 - a[0] - dx * t, z - a[1] - dz * t));
  }
  return closest;
}

// src/harbour/mountain/roadFrameFairing.ts
function fairMountainRoadFrames(line) {
  const source = line.samples, span = 10, anchors = [[70, -77], [85, -284], [19, -93]];
  const centres = anchors.map(([x2, z]) => source.reduce((best, s, i2) => Math.hypot(s.at[0] - x2, s.at[2] - z) < Math.hypot(source[best].at[0] - x2, source[best].at[2] - z) ? i2 : best, 0));
  const samples = source.map((s, i2) => {
    const distance2 = Math.min(...centres.map((c) => Math.abs(i2 - c)));
    if (distance2 >= 2 * span || s.bridgeId || source[i2 - 1]?.bridgeId || source[i2 + 1]?.bridgeId) return s;
    const blend = distance2 <= span ? 1 : (1 + Math.cos((distance2 - span) / span * Math.PI)) / 2;
    let nx = 0, nz = 0;
    for (let j = Math.max(0, i2 - span); j <= Math.min(source.length - 1, i2 + span); j++) {
      const weight = Math.exp(-(((i2 - j) / (span / 2)) ** 2));
      nx += source[j].normal[0] * weight;
      nz += source[j].normal[2] * weight;
    }
    let length = Math.hypot(nx, nz);
    nx = nx / length * blend + s.normal[0] * (1 - blend);
    nz = nz / length * blend + s.normal[2] * (1 - blend);
    length = Math.hypot(nx, nz);
    nx /= length;
    nz /= length;
    const perpendicular = nx * s.normal[0] + nz * s.normal[2];
    return { ...s, placementNormal: s.placementNormal ?? s.normal, normal: [nx / perpendicular, 0, nz / perpendicular] };
  });
  return { ...line, samples };
}

// src/harbour/mountain/bridges.ts
var ROAD_HALF_WIDTH = 4.8;
function open(points, i2, halfWidth, gap) {
  const p = points[i2], a = points[Math.max(0, i2 - 1)], b = points[Math.min(points.length - 1, i2 + 1)], dx = b[0] - a[0], dz = b[2] - a[2], l = Math.hypot(dx, dz) || 1, nx = -dz / l, nz = dx / l;
  for (const side of [-1, -0.5, 0, 0.5, 1]) {
    const x2 = p[0] + nx * halfWidth * side, z = p[2] + nz * halfWidth * side;
    if (baseHeight(x2, z) > p[1] - gap) return false;
  }
  return true;
}
function grow(points, halfWidth, sA, sB) {
  const s = arcLengths(points, true);
  let i0 = s.findIndex((v) => v >= Math.min(sA, sB)), i1 = s.findIndex((v) => v >= Math.max(sA, sB));
  if (i1 < 0) i1 = points.length - 1;
  while (i0 > 0 && open(points, i0 - 1, halfWidth, 1.4)) i0--;
  while (i1 < points.length - 1 && open(points, i1 + 1, halfWidth, 1.4)) i1++;
  return [Math.max(0, i0 - 2), Math.min(points.length - 1, i1 + 2)];
}
var roadS = arcLengths(ROAD_CENTRE, true);
var laneS = arcLengths(ORCHARD_LANE_AUTHORED_CENTRE, true);
var BRIDGE_SPANS = BRIDGE_TAGS.map((t) => {
  const road = t.line === "road", points = road ? ROAD_CENTRE : ORCHARD_LANE_AUTHORED_CENTRE, s = road ? roadS : laneS;
  const [i0, i1] = grow(points, road ? ROAD_HALF_WIDTH : ORCHARD_LANE_HALF_WIDTH, road ? roadTagS(t.from) : laneTagS(t.from), road ? roadTagS(t.to) : laneTagS(t.to));
  return { id: t.id, name: t.name, type: t.type, line: t.line, i0, i1, s0: s[i0], s1: s[i1] };
});

// src/harbour/mountain/terrain.ts
var EASE = 6;
var benchDeviation = (u, slope) => u <= 0 ? 0 : (u < EASE ? slope * u * u / (2 * EASE) : slope * (u - EASE / 2)) + (u > 12 ? (u - 12) * (u - 12) * 3 : 0);
function bakeFinal(lines, pads, recarveRiver = false) {
  const g2 = makeGrid(1), { cols, rows } = g2;
  g2.data.set(BASE_GRID.data);
  const lo = new Float32Array(cols * rows), hi = new Float32Array(cols * rows), loU = new Float32Array(cols * rows), hiU = new Float32Array(cols * rows);
  const R2 = 16;
  const apply = (x2, z, y, edge2, slope, ux, uz, half, pad, endCap = 0, footprint = false) => {
    const cx = Math.round(x2 - g2.minX), cz = Math.round(z - g2.minZ), reach = Math.ceil(edge2 + R2 + (pad ? Math.max(pad.hx, pad.hz) : half));
    for (let dz = -reach; dz <= reach; dz++) {
      const row = cz + dz;
      if (row < 0 || row >= rows) continue;
      const pz = g2.minZ + row - z;
      for (let dx = -reach; dx <= reach; dx++) {
        const col = cx + dx;
        if (col < 0 || col >= cols) continue;
        const px = g2.minX + col - x2;
        let d;
        if (pad) {
          const u2 = Math.abs(px * pad.c - pz * pad.s) - pad.hx, v = Math.abs(px * pad.s + pz * pad.c) - pad.hz;
          d = Math.hypot(Math.max(0, u2), Math.max(0, v));
        } else {
          const along = px * ux + pz * uz;
          if (along < -half && endCap !== -1 || along > half && endCap !== 1) continue;
          const c = along < -half ? -half : along > half ? half : along;
          d = Math.hypot(px - ux * c, pz - uz * c);
        }
        if (d > edge2 + R2) continue;
        const u = d > edge2 ? d - edge2 : 0, dev = benchDeviation(u, slope), i2 = row * cols + col;
        if ((!footprint || u <= 0) && y - dev > lo[i2]) {
          lo[i2] = y - dev;
          loU[i2] = u;
        }
        if (y + dev < hi[i2]) {
          hi[i2] = y + dev;
          hiU[i2] = u;
        }
      }
    }
  };
  let conflicts = 0;
  const conflictCells = [];
  const priorities = [.../* @__PURE__ */ new Set([...lines.map((l) => l.priority ?? 0), ...pads.map((p) => p.priority ?? 0)])].sort((a, b) => a - b);
  for (const priority of priorities) {
    lo.fill(-Infinity);
    hi.fill(Infinity);
    for (const line of lines) {
      if ((line.priority ?? 0) !== priority) continue;
      const s = arcLengths(line.points, true);
      for (let i2 = 0; i2 < line.points.length; i2++) {
        if (line.skip?.some(([a2, b2]) => s[i2] >= a2 && s[i2] <= b2)) continue;
        const p = line.points[i2], a = line.points[Math.max(0, i2 - 1)], b = line.points[Math.min(line.points.length - 1, i2 + 1)];
        const tx = b[0] - a[0], tz = b[2] - a[2], tl = Math.hypot(tx, tz) || 1;
        apply(p[0], p[2], p[1] - line.inset, line.halfWidth + line.shoulder, line.slope, tx / tl, tz / tl, tl * 0.4, void 0, i2 === 0 ? -1 : i2 === line.points.length - 1 ? 1 : 0, line.fill === "footprint");
      }
    }
    for (const pad of pads) if ((pad.priority ?? 0) === priority) apply(pad.at[0], pad.at[2], pad.at[1] - pad.inset, 0, pad.slope, 1, 0, 0, { c: Math.cos(pad.yaw), s: Math.sin(pad.yaw), hx: pad.half[0], hz: pad.half[1] }, 0, pad.fill === "footprint");
    for (let i2 = 0; i2 < g2.data.length; i2++) {
      const l = lo[i2], h = hi[i2];
      if (l === -Infinity && h === Infinity) continue;
      if (l > h) {
        if (l - h > 0.3 && priority === priorities[priorities.length - 1]) {
          conflicts++;
          conflictCells.push(i2);
        }
        const a = hiU[i2], b = loU[i2];
        g2.data[i2] = h + (l - h) * (a / (a + b || 1));
      } else g2.data[i2] = Math.min(h, Math.max(l, g2.data[i2]));
    }
  }
  for (const line of lines) {
    if (!line.carve) continue;
    for (let i2 = 0; i2 < line.points.length; i2++) {
      const p = line.points[i2], a = line.points[Math.max(0, i2 - 1)], b = line.points[Math.min(line.points.length - 1, i2 + 1)], tx = b[0] - a[0], tz = b[2] - a[2], tl = Math.hypot(tx, tz) || 1, ux = tx / tl, uz = tz / tl, half = tl * 0.4;
      const ahead = i2 < line.points.length - 1 ? line.points[i2 + 1] : p, behind = i2 > 0 ? line.points[i2 - 1] : p;
      const reach = Math.ceil(line.halfWidth + line.shoulder + 3), cx = Math.round(p[0] - g2.minX), cz = Math.round(p[2] - g2.minZ);
      for (let dz = -reach; dz <= reach; dz++) {
        const row = cz + dz;
        if (row < 0 || row >= rows) continue;
        const pz = g2.minZ + row - p[2];
        for (let dx = -reach; dx <= reach; dx++) {
          const col = cx + dx;
          if (col < 0 || col >= cols) continue;
          const px = g2.minX + col - p[0];
          const along = px * ux + pz * uz;
          if (along < -half && i2 > 0 || along > half && i2 < line.points.length - 1) continue;
          const c = Math.max(-half, Math.min(half, along)), d = Math.hypot(px - ux * c, pz - uz * c);
          const q = c >= 0 ? ahead : behind, t = Math.min(1, Math.abs(c) / (Math.hypot(q[0] - p[0], q[2] - p[2]) || 1)), y = p[1] + (q[1] - p[1]) * t - line.inset;
          const u = Math.max(0, d - line.halfWidth - line.shoulder), k = row * cols + col;
          if (u <= 3) g2.data[k] = Math.min(g2.data[k], y + u * line.slope);
        }
      }
    }
  }
  if (recarveRiver) {
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const x2 = g2.minX + c, z = g2.minZ + r;
      if (z > -40) continue;
      const river = nearestRiver(x2, z);
      if (river.d < 14) {
        const i2 = r * cols + c;
        g2.data[i2] = smin(g2.data[i2], river.y + channelProfile(river.d, river.wall), 1.5);
        if (river.d < 3) g2.data[i2] = Math.max(g2.data[i2], river.y - RIVER_BED_DEPTH);
      }
    }
  }
  return { grid: g2, conflicts, conflictCells };
}

// src/harbour/mountain/pathGraph.ts
var ground2 = (x2, z) => z > -48 ? islandHeight(x2, z) : Math.max(islandHeight(x2, z), baseHeight(x2, z));
var nodes = /* @__PURE__ */ new Map();
var edges2 = [];
var node = (id, kind, at, extra = {}) => {
  const n = { id, kind, at, ...extra };
  nodes.set(id, n);
  return n;
};
var district = (id) => DISTRICTS.find((d) => d.id === id);
var roadAt = (planS, line = "road") => {
  const pts = line === "road" ? ROAD_CENTRE : ORCHARD_LANE_CENTRE;
  return pts[Math.max(0, Math.min(pts.length - 1, Math.round(planS / ROAD_SAMPLE_STEP)))];
};
var nearestRoadS = (x2, z, line = "road") => {
  const pts = line === "road" ? ROAD_CENTRE : ORCHARD_LANE_CENTRE;
  let best = 0, d = Infinity;
  pts.forEach((p, i2) => {
    const e = Math.hypot(p[0] - x2, p[2] - z);
    if (e < d) {
      d = e;
      best = i2;
    }
  });
  return best * ROAD_SAMPLE_STEP;
};
var onRoadXZ = (x2, z) => {
  for (const [pts, hw] of [[ROAD_CENTRE, 4.8], [ORCHARD_LANE_CENTRE, 3.2]]) {
    for (let i2 = 0; i2 < pts.length; i2 += 2) {
      const q = pts[i2];
      if (Math.hypot(q[0] - x2, q[2] - z) < hw + 0.6) return true;
    }
  }
  return false;
};
var PLATFORMS = [...FUNICULAR_LINE.stations, ...GONDOLA_LINE.stations].map((st) => st.platform);
var onPlatformXZ = (x2, z) => PLATFORMS.some((p) => {
  const px = x2 - p.at[0], pz = z - p.at[2], c = Math.cos(p.yaw), s = Math.sin(p.yaw);
  return Math.abs(px * c - pz * s) <= p.half[0] + 0.3 && Math.abs(px * s + pz * c) <= p.half[1] + 0.3;
});
var LANDING = 1.6;
function edge(kind, from, to, via = [], halfWidth = kind === "stair" ? 1.4 : kind === "promenade" ? 1.8 : 1.5, id) {
  const a = nodes.get(from).at, b = nodes.get(to).at, plan2 = [[a[0], a[2]], ...via.map((v) => [v[0], v[1]]), [b[0], b[2]]];
  const dense = [];
  for (let i2 = 1; i2 < plan2.length; i2++) {
    const p = plan2[i2 - 1], q = plan2[i2], n = Math.max(1, Math.ceil(Math.hypot(q[0] - p[0], q[1] - p[1]) / 1.5));
    for (let k = 0; k < n; k++) dense.push([mix3(p[0], q[0], k / n), mix3(p[1], q[1], k / n)]);
  }
  dense.push(plan2[plan2.length - 1]);
  const hs = [0];
  for (let i2 = 1; i2 < dense.length; i2++) hs.push(hs[i2 - 1] + Math.hypot(dense[i2][0] - dense[i2 - 1][0], dense[i2][1] - dense[i2 - 1][1]));
  const L = hs[hs.length - 1] || 1;
  let climb = null;
  if (kind === "stair") {
    const turns = plan2.slice(1, -1).map((v, k) => {
      const p = plan2[k], q = plan2[k + 2], h1 = Math.atan2(v[0] - p[0], v[1] - p[1]), h2 = Math.atan2(q[0] - v[0], q[1] - v[1]);
      return { v, sharp: Math.abs(Math.atan2(Math.sin(h2 - h1), Math.cos(h2 - h1))) > 0.6 };
    }).filter((t) => t.sharp).map((t) => t.v);
    const level = (x2, z) => onRoadXZ(x2, z) || onPlatformXZ(x2, z) || turns.some((v) => Math.hypot(v[0] - x2, v[1] - z) < LANDING);
    const w = dense.map((p, i2) => i2 === 0 ? 0 : level((p[0] + dense[i2 - 1][0]) / 2, (p[1] + dense[i2 - 1][1]) / 2) ? 0 : hs[i2] - hs[i2 - 1]);
    const total = w.reduce((m, v) => m + v, 0);
    if (total > 2) {
      let acc = 0;
      climb = w.map((v) => (acc += v) / total);
    }
  }
  let points = dense.map(([x2, z], i2) => {
    const t = climb ? climb[i2] : hs[i2] / L, lin = mix3(a[1], b[1], t);
    if (kind !== "path") return [x2, lin, z];
    const w = Math.min(1, Math.min(hs[i2], L - hs[i2]) / 6) * 0.85;
    return [x2, mix3(lin, ground2(x2, z), w), z];
  });
  if (kind === "path") {
    for (let pass = 0; pass < 3; pass++) points = points.map((p, i2) => i2 === 0 || i2 === points.length - 1 ? p : [p[0], (points[i2 - 1][1] + p[1] * 2 + points[i2 + 1][1]) / 4, p[2]]);
  }
  const e = { id: id ?? `${kind}:${from}~${to}`, kind, from, to, halfWidth, points, length: arcLengths(points).at(-1) };
  edges2.push(e);
  return e;
}
var DOOR_APRONS = [];
function door2(id, level, label) {
  const d = buildingDoor(id), door3 = [d.at[0], level, d.at[1]], out = [d.at[0] + d.facing[0] * 5.5, level, d.at[1] + d.facing[1] * 5.5];
  DOOR_APRONS.push({ site: id, door: door3, facing: d.yaw, apron: { at: [d.at[0] + d.facing[0] * 2.6, level, d.at[1] + d.facing[1] * 2.6], half: [2.4, 2.6], yaw: d.yaw } });
  node(`door:${id}`, "door", door3, { facing: d.yaw, label });
  node(`apron:${id}`, "junction", out, { facing: d.yaw });
  edge("path", `apron:${id}`, `door:${id}`, [], 1.6);
}
node("town:north", "town", [-3, islandHeight(-3, -43), -43], { label: "North lane" });
node("road:foot", "junction", roadAt(0), { label: "Road foot" });
for (const line of [FUNICULAR_LINE, GONDOLA_LINE]) for (const st of line.stations) node(`station:${line.kind}:${st.id}`, "station", st.platform.at, { label: `${st.name} ${line.kind}`, facing: st.platform.yaw });
edge("path", "town:north", "station:funicular:town", [[-10, -38.5]], 1.6);
edge("path", "station:funicular:town", "road:foot", [], 1.8);
for (const d of DISTRICTS) node(`district:${d.id}`, "district", d.at, { district: d.id, label: d.name });
door2("home", district("hearth").at[1], "Our home");
node("road:hearth", "junction", roadAt(nearestRoadS(50, -101)));
edge("path", "road:hearth", "apron:home");
edge("path", "district:hearth", "apron:home");
node("road:leg1-steps", "stair-bottom", roadAt(nearestRoadS(34, -65.5)));
node("road:leg2-steps", "stair-top", roadAt(nearestRoadS(49, -82)));
edge("stair", "road:leg1-steps", "road:leg2-steps", [[36, -71], [47, -76.6]], 1.4, "stair:harbour-steps");
node("road:leg2-steps-b", "stair-bottom", roadAt(nearestRoadS(56, -82)));
node("road:leg3-steps", "stair-top", roadAt(nearestRoadS(40, -101)));
edge("stair", "road:leg2-steps-b", "road:leg3-steps", [[55, -87.6], [42, -95.1]], 1.4, "stair:hearth-steps");
node("lane:junction", "junction", ORCHARD_LANE_CENTRE[0]);
node("road:station-steps", "stair-bottom", roadAt(nearestRoadS(20.5, -73.4)));
edge("stair", "road:station-steps", "station:funicular:hearth", [[20.6, -79.2], [11, -84.8]], 1.4, "stair:station-steps");
node("road:hairpin-2-west", "junction", roadAt(nearestRoadS(19, -93)));
edge("bridge", "station:funicular:hearth", "road:hairpin-2-west", [[10.8, -89.8]], 1.3, "bridge:station-walk");
node("path:river-west", "junction", [-4.5, 2.2, -51]);
node("path:river-east", "junction", [5.5, 2.6, -57]);
edge("path", "town:north", "path:river-west", [[-4, -47]]);
edge("bridge", "path:river-west", "path:river-east", [], 1.3, "bridge:river-footbridge");
edge("path", "path:river-east", "road:station-steps", [[12, -64]]);
node("overlook:hearth", "overlook", [46, district("hearth").at[1], -110], { facing: Math.atan2(-46, 110), label: "Harbour lookout" });
edge("path", "district:hearth", "overlook:hearth");
node("road:library", "junction", roadAt(nearestRoadS(46, -161)));
node("stair:woods-bottom", "stair-bottom", [50, district("hearth").at[1], -124]);
node("stair:woods-mid", "stair-top", [42, 27.5, -140]);
node("stair:woods-top", "stair-top", [38, 35.5, -156]);
edge("path", "district:hearth", "stair:woods-bottom");
edge("stair", "stair:woods-bottom", "stair:woods-mid", [[46, -132]], 1.4, "stair:woods-steps-1");
edge("stair", "stair:woods-mid", "stair:woods-top", [[39, -148]], 1.4, "stair:woods-steps-mid");
edge("stair", "stair:woods-top", "road:library", [], 1.4, "stair:woods-steps-2");
door2("library", district("library").at[1], "The Library");
edge("path", "district:library", "apron:library");
edge("path", "road:library", "apron:library");
node("overlook:gorge-balcony", "overlook", [20.5, baseHeight(20.5, -164), -164], { facing: Math.atan2(-22, -58), label: "Gorge balcony" });
edge("path", "road:library", "overlook:gorge-balcony", [[30, -160]]);
edge("path", "station:funicular:library", "overlook:gorge-balcony");
door2("cottage", district("orchard").at[1], "Hercules\u2019s cottage");
node("lane:orchard", "junction", ORCHARD_LANE_CENTRE[ORCHARD_LANE_CENTRE.length - 1]);
edge("path", "lane:orchard", "apron:cottage");
edge("path", "lane:orchard", "district:orchard");
door2("glasshouse", district("glasshouse").at[1], "The Glasshouse");
node("road:b2-west", "junction", roadAt(nearestRoadS(-30, -198)));
node("stair:meadow-mid", "stair-top", [-44, roadAt(nearestRoadS(-44, -198.4))[1] + 0.3, -205.2]);
edge("stair", "road:b2-west", "stair:meadow-mid", [[-32, -201]], 1.4, "stair:meadow-steps-1");
edge("stair", "stair:meadow-mid", "apron:glasshouse", [[-56, -209]], 1.4, "stair:meadow-steps-2");
edge("path", "district:glasshouse", "apron:glasshouse");
node("road:glasshouse", "junction", roadAt(nearestRoadS(-78, -234)));
edge("path", "road:glasshouse", "district:glasshouse");
node("road:clearing", "junction", roadAt(nearestRoadS(-98, -202)));
var damEnd = (side) => [DAM.centre[0] + Math.sin(side * DAM.halfAngle) * DAM.radius, DAM.crest, DAM.centre[2] + Math.cos(side * DAM.halfAngle) * DAM.radius];
node("dam:west", "overlook", damEnd(-1), { facing: Math.atan2(20, 34), label: "Dam west abutment" });
node("dam:east", "junction", damEnd(1));
node("road:dam-stairs", "stair-bottom", roadAt(nearestRoadS(-40, -228)));
edge("stair", "road:dam-stairs", "dam:west", [[-36.5, -235], [-33.5, -243]], 1.4, "stair:dam-west-steps");
var crest = [];
for (let k = 1; k < 12; k++) {
  const a = -DAM.halfAngle + 2 * DAM.halfAngle * k / 12;
  crest.push([DAM.centre[0] + Math.sin(a) * (DAM.radius + 1.2), DAM.centre[2] + Math.cos(a) * (DAM.radius + 1.2)]);
}
edge("promenade", "dam:west", "dam:east", crest, 1.8, "promenade:dam-crest");
node("door:pavilion", "door", GOAL_PAVILION_SITE.at, { facing: Math.atan2(-1, 0.4), label: "Goal pavilion" });
DOOR_APRONS.push({ site: "pavilion", door: GOAL_PAVILION_SITE.at, facing: Math.atan2(-1, 0.4), apron: { at: [GOAL_PAVILION_SITE.at[0] - 2.5, GOAL_PAVILION_SITE.at[1], GOAL_PAVILION_SITE.at[2] + 1], half: [2.4, 2.4], yaw: Math.atan2(-1, 0.4) } });
edge("path", "dam:east", "door:pavilion");
edge("path", "door:pavilion", "district:reservoir");
node("road:reservoir", "junction", roadAt(nearestRoadS(54, -244)));
edge("path", "road:reservoir", "district:reservoir");
edge("path", "station:funicular:reservoir", "dam:east");
node("road:b3-east", "junction", roadAt(nearestRoadS(56, -209)));
edge("stair", "road:b3-east", "station:funicular:reservoir", [[58, -216], [48, -221], [42, -224]], 1.4, "stair:reservoir-steps");
node("road:b2-east", "junction", roadAt(nearestRoadS(31.5, -174)));
node("road:rim-steps", "stair-bottom", roadAt(nearestRoadS(25.6, -185.2)));
node("road:rim-top", "stair-top", roadAt(nearestRoadS(41, -213)));
edge("stair", "road:rim-steps", "road:rim-top", [[27.6, -190.8], [38, -191.4], [38.4, -195], [21.6, -195.3], [21.6, -199.2], [38.4, -199.5], [39.4, -202.4], [40.2, -207.4]], 1.9, "stair:rim-steps");
edge("path", "district:library", "road:b2-east", [[38, -180]]);
node("road:summit", "junction", ROAD_CENTRE[ROAD_CENTRE.length - 1]);
edge("path", "road:summit", "district:summit");
node("door:observatory", "door", [SUMMIT_OBSERVATORY_SITE.at[0], SUMMIT_OBSERVATORY_SITE.at[1], SUMMIT_OBSERVATORY_SITE.at[2] + SUMMIT_OBSERVATORY_SITE.radius], { facing: 0, label: "Observatory" });
DOOR_APRONS.push({ site: "observatory", door: nodes.get("door:observatory").at, facing: 0, apron: { at: [SUMMIT_OBSERVATORY_SITE.at[0], SUMMIT_OBSERVATORY_SITE.at[1], SUMMIT_OBSERVATORY_SITE.at[2] + SUMMIT_OBSERVATORY_SITE.radius + 2.5], half: [2.4, 2.4], yaw: 0 } });
edge("path", "district:summit", "door:observatory");
edge("path", "district:summit", "station:gondola:summit");
node("overlook:summit", "overlook", [district("summit").at[0] + 2, district("summit").at[1], district("summit").at[2] + 12], { facing: 0, label: "Harbour panorama" });
edge("path", "district:summit", "overlook:summit");
node("town:quay", "town", [-34, islandHeight(-34, 40), 40], { label: "Quay" });
edge("path", "town:quay", "station:gondola:quay", [], 1.8);
edge("path", "town:north", "town:quay", [[-2, -20], [-12, -2], [-25, 4], [-35, 14], [-38, 30]], 1.6, "town:west-lanes");
for (const p of RESERVED_PLOTS) {
  node(`gate:${p.id}`, "plot-gate", p.gate, { label: p.name });
  node(`plot:${p.id}`, "district", p.at, { label: p.name });
  edge("path", `gate:${p.id}`, `plot:${p.id}`);
}
node("road:shelf", "junction", roadAt(nearestRoadS(102, -134)));
edge("path", "road:shelf", "gate:sunny-shelf");
edge("path", "road:clearing", "gate:woodland-clearing");
node("road:high-terrace", "junction", roadAt(nearestRoadS(80, -278)));
edge("path", "road:high-terrace", "gate:high-terrace");
node("road:dam-overlook", "overlook", roadAt(nearestRoadS(44, -209)), { facing: Math.atan2(8 - 44, -228 + 209), label: "Dam overlook" });
function roadEdges(line) {
  const pts = line === "road" ? ROAD_CENTRE : ORCHARD_LANE_CENTRE, prefix = line === "road" ? "road:" : "lane:";
  const on = [...nodes.values()].filter((n) => n.id.startsWith(prefix)).map((n) => ({ n, i: pts.findIndex((p) => p === n.at || p[0] === n.at[0] && p[2] === n.at[2]) })).filter((e) => e.i >= 0).sort((a, b) => a.i - b.i);
  for (let k = 1; k < on.length; k++) {
    const a = on[k - 1], b = on[k];
    edges2.push({ id: `${line}:${a.n.id}~${b.n.id}`, kind: "road", from: a.n.id, to: b.n.id, halfWidth: line === "road" ? 4.8 : 3.2, points: pts.slice(a.i, b.i + 1), length: arcLengths(pts.slice(a.i, b.i + 1)).at(-1) });
  }
}
node("road:hearth-lane", "junction", roadAt(nearestRoadS(ORCHARD_LANE_WAYPOINTS[0].at[0], ORCHARD_LANE_WAYPOINTS[0].at[1])));
roadEdges("road");
roadEdges("lane");
edge("path", "road:hearth-lane", "lane:junction", [], 3, "link:lane-junction");
var MOUNTAIN_PATH_GRAPH = { nodes: [...nodes.values()], edges: edges2 };
var OVERLOOKS = [...nodes.values()].filter((n) => n.kind === "overlook").map((n) => ({ id: n.id, name: n.label ?? n.id, at: n.at, facing: n.facing ?? 0, look: [n.at[0] + Math.sin(n.facing ?? 0) * 40, n.at[1] - 8, n.at[2] + Math.cos(n.facing ?? 0) * 40] }));
var onRoad = (p) => onRoadXZ(p[0], p[2]);
var beyondRoadEdge = (x2, z) => {
  let best = Infinity;
  for (const [pts, hw] of [[ROAD_CENTRE, 4.8], [ORCHARD_LANE_CENTRE, 3.2]]) {
    for (const q of pts) {
      const d = Math.hypot(q[0] - x2, q[2] - z) - hw;
      if (d < best) best = d;
    }
  }
  return best;
};
var atRoadEdge = (inside, outside) => {
  let lo = 0, hi = 1;
  for (let k = 0; k < 18; k++) {
    const m = (lo + hi) / 2;
    if (beyondRoadEdge(mix3(inside[0], outside[0], m), mix3(inside[2], outside[2], m)) < -0.15) lo = m;
    else hi = m;
  }
  return [mix3(inside[0], outside[0], lo), mix3(inside[1], outside[1], lo), mix3(inside[2], outside[2], lo)];
};
var trimmed = (e) => {
  let a = 0, b = e.points.length;
  while (a < b - 2 && onRoad(e.points[a])) a++;
  while (b > a + 2 && onRoad(e.points[b - 1])) b--;
  const points = e.points.slice(a, b);
  if (a > 0) points.unshift(atRoadEdge(e.points[a - 1], e.points[a]));
  if (b < e.points.length) points.push(atRoadEdge(e.points[b], e.points[b - 1]));
  return { ...e, points, length: arcLengths(points).at(-1) };
};
var PATH_EDGES = edges2.filter((e) => e.kind !== "road").map(trimmed);
var BUILDING_PADS = Object.keys(BUILDING_SITES).map((id) => ({ id, spot: BUILDING_SITES[id] }));

// src/harbour/mountain/damParts.ts
var onArc = (a, radius, y) => [DAM.centre[0] + Math.sin(a) * radius, y, DAM.centre[2] + Math.cos(a) * radius];
var DAM_PARTS = {
  centre: DAM.centre,
  crest: DAM.crest,
  foot: DAM.foot,
  radius: DAM.radius,
  halfAngle: DAM.halfAngle,
  /** Crest line, west to east. */
  arc: Array.from({ length: 25 }, (_, k) => onArc(-DAM.halfAngle + 2 * DAM.halfAngle * k / 24, DAM.radius, DAM.crest)),
  /** Unit horizontal direction the glass faces (toward town). */
  face: DAM.face,
  abutments: [-1, 1].map((side) => ({ side: side < 0 ? "west" : "east", at: onArc(side * DAM.halfAngle * 1.04, DAM.radius, (DAM.crest + DAM.foot) / 2), size: [7, DAM.crest - DAM.foot + 4, 9] })),
  apron: { at: [DAM.centre[0], DAM.foot, DAM.centre[2] + DAM.radius + 6], half: [10, 5] },
  promenade: Array.from({ length: 13 }, (_, k) => onArc(-DAM.halfAngle + 2 * DAM.halfAngle * k / 12, DAM.radius + 1.2, DAM.crest))
};
var RESERVOIR = { bottom: BASIN.bottom, level: RESERVOIR_LEVEL_MAX, shore: Array.from({ length: 48 }, (_, k) => {
  const a = k / 48 * Math.PI * 2, cx = RESERVOIR_BOWL.at[0], cz = RESERVOIR_BOWL.at[1];
  let r = 2;
  while (r < 60 && baseHeight(cx + Math.sin(a) * r, cz + Math.cos(a) * r) < RESERVOIR_LEVEL_MAX) r += 0.5;
  return [cx + Math.sin(a) * r, RESERVOIR_LEVEL_MAX, cz + Math.cos(a) * r];
}) };
var KITTY_CHAMBERS = [[-20, -247], [-25, -254]].map(([x2, z], i2) => ({ id: `kitty-${i2 + 1}`, at: [x2, Math.round(baseHeight(x2, z) * 2) / 2, z], radius: 3.4, depth: 7 }));

// src/harbour/mountain/benches.ts
var DISTRICT_OF = { home: "hearth", cottage: "orchard", library: "library", glasshouse: "glasshouse" };
function trackRuns() {
  const out = [];
  let run = [];
  for (const p of FUNICULAR_LINE.path) {
    if (Math.abs(p[1] - baseHeight(p[0], p[2])) < 2.5) run.push(p);
    else {
      if (run.length > 3) out.push(run);
      run = [];
    }
  }
  if (run.length > 3) out.push(run);
  return out;
}
var maxPitch = (pts) => {
  let m = 0;
  for (let i2 = 1; i2 < pts.length; i2++) {
    const a = pts[i2 - 1], b = pts[i2], h = Math.hypot(b[0] - a[0], b[2] - a[2]);
    if (h > 0.05) m = Math.max(m, Math.abs(b[1] - a[1]) / h);
  }
  return m;
};
function underStair(pts) {
  const deep = 1.25 * maxPitch(pts), s = [0];
  for (let i2 = 1; i2 < pts.length; i2++) s.push(s[i2 - 1] + Math.hypot(pts[i2][0] - pts[i2 - 1][0], pts[i2][2] - pts[i2 - 1][2]));
  const L = s[s.length - 1];
  return pts.map((p, i2) => [p[0], p[1] - deep * Math.min(1, s[i2] / 2.5, (L - s[i2]) / 2.5), p[2]]);
}
var EXTRA_BENCH_LINES = [
  // A stair is a built flight: the ground under it sits below its whole pitch (each bench sample holds
  // ±1.2 of line, so on a 0.5 pitch the ground would otherwise poke up to 0.6 through the treads).
  // Its ends stay flush with the ground they meet (no pit at the foot or the head).
  ...PATH_EDGES.filter((e) => e.kind === "path" || e.kind === "stair").map((e) => ({ id: e.id, points: e.kind === "stair" ? underStair(e.points) : e.points, halfWidth: e.halfWidth, shoulder: 0.4, slope: 1, inset: 0.04, fill: "footprint", carve: e.kind === "stair" })),
  ...trackRuns().map((points, i2) => ({ id: `funicular-formation:${i2}`, points, halfWidth: 1.8, shoulder: 0.3, slope: 1, inset: 0.35, fill: "footprint" }))
];
var EXTRA_BENCH_PADS = [
  ...Object.keys(BUILDING_SITES).map((id) => {
    const spot = BUILDING_SITES[id], level = DISTRICTS.find((d) => d.id === DISTRICT_OF[id]).at[1];
    return { id: `building:${id}`, at: [spot[0], level, spot[1]], half: [BUILDING_FORMS[id].half[0] + 1, BUILDING_FORMS[id].half[1] + 1], yaw: buildingYaw(spot), inset: 0.05, slope: 1, priority: 1 };
  }),
  ...DOOR_APRONS.map((a) => ({ id: `apron:${a.site}`, at: a.apron.at, half: a.apron.half, yaw: a.apron.yaw, inset: 0.03, slope: 1, priority: 1 })),
  ...[...FUNICULAR_LINE.stations, ...GONDOLA_LINE.stations].map((s) => ({ id: `platform:${s.id}`, at: s.platform.at, half: [s.platform.half[0] + 0.4, s.platform.half[1] + 0.4], yaw: s.platform.yaw, inset: 0.05, slope: 1, priority: 1, fill: "footprint" })),
  ...RESERVED_PLOTS.map((p) => ({ id: `plot:${p.id}`, at: p.at, half: p.half, yaw: 0, inset: 0.02, slope: 1 })),
  ...KITTY_CHAMBERS.map((c) => ({ id: `kitty:${c.id}`, at: c.at, half: [c.radius + 1.2, c.radius + 1.2], yaw: 0, inset: 0.02, slope: 1 })),
  { id: "goal-pavilion", at: GOAL_PAVILION_SITE.at, half: [GOAL_PAVILION_SITE.half[0] + 1, GOAL_PAVILION_SITE.half[1] + 1], yaw: 0, inset: 0.03, slope: 1 },
  { id: "observatory", at: SUMMIT_OBSERVATORY_SITE.at, half: [SUMMIT_OBSERVATORY_SITE.radius + 1.5, SUMMIT_OBSERVATORY_SITE.radius + 1.5], yaw: 0, inset: 0.03, slope: 1 }
];

// src/harbour/mountain/mountainGround.ts
function skips(line, points) {
  const s = arcLengths(points, true), out = [];
  for (const b of BRIDGE_SPANS.filter((b2) => b2.line === line)) {
    let run = null;
    for (let i2 = b.i0; i2 <= b.i1; i2++) {
      const p = points[i2], a = points[Math.max(0, i2 - 1)], c = points[Math.min(points.length - 1, i2 + 1)], dx = c[0] - a[0], dz = c[2] - a[2], l = Math.hypot(dx, dz) || 1, hw = line === "road" ? ROAD_HALF_WIDTH : 3.2;
      let open2 = true;
      for (const side of [-1.2, -0.6, 0, 0.6, 1.2]) {
        if (baseHeight(p[0] + dz / l * hw * side, p[2] - dx / l * hw * side) > p[1] - 2.5) {
          open2 = false;
          break;
        }
      }
      if (open2) {
        if (!run) run = [s[i2], s[i2]];
        else run[1] = s[i2];
      } else if (run) {
        out.push([run[0], run[1]]);
        run = null;
      }
    }
    if (run) out.push([run[0], run[1]]);
  }
  return out;
}
var rebake = typeof process !== "undefined" && process.env?.HEARTH_REBAKE === "1";
var BENCH_LINES = rebake ? [
  { id: "road", points: ROAD_CENTRE, halfWidth: ROAD_HALF_WIDTH, shoulder: 1.2, slope: 1, inset: 0.02, skip: skips("road", ROAD_CENTRE), priority: 3 },
  { id: "orchard-lane", points: ORCHARD_LANE_CENTRE, halfWidth: ORCHARD_LANE_HALF_WIDTH, shoulder: 1, slope: 1, inset: 0.02, skip: skips("lane", ORCHARD_LANE_CENTRE), priority: 2 },
  ...EXTRA_BENCH_LINES
] : [];
var BENCH_PADS = rebake ? EXTRA_BENCH_PADS : [];
var asset = rebake ? void 0 : await loadTerrainAsset();
var baked = rebake ? bakeFinal(BENCH_LINES, BENCH_PADS, true) : { grid: asset.ground, conflicts: asset.conflicts, conflictCells: asset.conflictCells };
var GROUND_GRID = baked.grid;
var GROUND_CONFLICTS = baked.conflicts;
var GROUND_CONFLICT_CELLS = baked.conflictCells;
var mountainGround = (x2, z) => sampleGrid(GROUND_GRID, x2, z);

// src/harbour/mountain/roads.ts
var mountainGround2 = (x2, z) => Math.max(islandHeight(x2, z), z < -30 ? mountainGround(x2, z) : -Infinity);
var EDGE_RULES = { parapetDrop: 1, kerbDrop: 0.35, wallRise: 1.6, kerbRise: 0.6, probe: [0.6, 3.2], parapetHeight: 1.1, kerbHeight: 0.22 };
function classify(points, id, halfWidthAt, bridgeAt) {
  const s3 = arcLengths(points), samples = [];
  const n = points.length;
  for (let i2 = 0; i2 < n; i2++) {
    const p = points[i2], a = points[Math.max(0, i2 - 1)], b = points[Math.min(n - 1, i2 + 1)];
    const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2], hl = Math.hypot(dx, dz) || 1, l = Math.hypot(dx, dy, dz) || 1;
    const tangent = [dx / l, dy / l, dz / l], normal2 = [dz / hl, 0, -dx / hl];
    const a3 = points[Math.max(0, i2 - 6)], b3 = points[Math.min(n - 1, i2 + 6)];
    const h1 = Math.atan2(p[0] - a3[0], p[2] - a3[2]), h2 = Math.atan2(b3[0] - p[0], b3[2] - p[2]), turn = Math.atan2(Math.sin(h2 - h1), Math.cos(h2 - h1));
    const span = Math.hypot(b3[0] - a3[0], b3[2] - a3[2]) || 1;
    const hw = halfWidthAt(i2), bridgeId = bridgeAt(i2);
    const edge2 = (side) => {
      if (bridgeId) return "bridge";
      let drop = 0, rise = 0;
      for (let o = EDGE_RULES.probe[0]; o <= EDGE_RULES.probe[1]; o += 0.65) {
        const x2 = p[0] + normal2[0] * (hw + o) * side, z = p[2] + normal2[2] * (hw + o) * side, g2 = mountainGround2(x2, z);
        drop = Math.max(drop, p[1] - g2);
        rise = Math.max(rise, g2 - p[1]);
      }
      return drop > EDGE_RULES.parapetDrop ? "parapet" : rise > EDGE_RULES.wallRise ? "wall" : drop > EDGE_RULES.kerbDrop || rise > EDGE_RULES.kerbRise ? "kerb" : "open";
    };
    const fill = p[1] - baseHeight(p[0], p[2]);
    samples.push({
      s: s3[i2],
      at: p,
      tangent,
      normal: normal2,
      halfWidth: hw,
      grade: dy / hl,
      curvature: turn / span,
      left: edge2(1),
      right: edge2(-1),
      support: bridgeId ? "bridge" : fill > 1.5 ? "embankment" : "ground",
      bridgeId
    });
  }
  const rank = { open: 0, kerb: 1, wall: 2, parapet: 3, bridge: 4 };
  for (const side of ["left", "right"]) {
    for (let pass = 0; pass < 2; pass++) for (let i2 = 0; i2 < n; i2++) {
      const k = samples[i2][side];
      let j = i2;
      while (j + 1 < n && samples[j + 1][side] === k) j++;
      if (j - i2 < 6 && k !== "bridge") {
        const before = samples[i2 - 1]?.[side], after = samples[j + 1]?.[side];
        const stronger = [before, after].filter((e) => !!e).sort((x2, y) => rank[y] - rank[x2])[0];
        if (stronger && rank[stronger] > rank[k]) for (let m = i2; m <= j; m++) samples[m][side] = stronger;
      }
      i2 = j;
    }
  }
  return { id, length: s3[n - 1], step: s3[n - 1] / (n - 1), samples };
}
var BRANCH_DEPARTURES = [
  { id: "library-balcony", line: "mountain-road", planS: roadTagS("b2-east") - 1, toward: [37, 41.2, -181.6], halfWidth: 1.6 }
];
var BRANCH_ARRIVALS = [
  { id: "hearth-awning:landing", line: "mountain-road", planS: roadTagS("hairpin-2") + 2, toward: [24.5, 15.6, -90], halfWidth: 1.2 },
  { id: "library-balcony:landing", line: "mountain-road", planS: roadTagS("library") - 31, toward: [88, 32.5, -170], halfWidth: 1.6 },
  { id: "dam-promenade:landing", line: "mountain-road", planS: roadTagS("b3-west") + 10, toward: [-18, 71, -225.5], halfWidth: 1.7 }
];
var OPENINGS = [];
var OPENED = { left: /* @__PURE__ */ new WeakSet(), right: /* @__PURE__ */ new WeakSet() };
function departures(line) {
  const out = [];
  for (const d of [...BRANCH_DEPARTURES, ...BRANCH_ARRIVALS]) {
    if (d.line !== line.id) continue;
    out.push({ id: d.id, by: "branch", corridor: [line.samples[Math.max(0, Math.min(line.samples.length - 1, Math.round(d.planS / ROAD_SAMPLE_STEP)))].at, d.toward], halfWidth: d.halfWidth });
  }
  const prefix = line.id === "mountain-road" ? "road:" : "lane:";
  for (const e of MOUNTAIN_PATH_GRAPH.edges) {
    if (e.kind === "road") continue;
    for (const [end, pts] of [[e.from, e.points], [e.to, [...e.points].reverse()]]) {
      if (!end.startsWith(prefix)) continue;
      const node2 = pts[0], reach = (line.id === "mountain-road" ? ROAD_HALF_WIDTH : ORCHARD_LANE_HALF_WIDTH) + 3, corridor = [];
      for (const p of pts) {
        corridor.push(p);
        if (Math.hypot(p[0] - node2[0], p[2] - node2[2]) > reach) break;
      }
      if (corridor.length > 1) out.push({ id: e.id, by: "path", corridor, halfWidth: e.halfWidth });
    }
  }
  return out;
}
function openJunctions(line) {
  const others = line.id === "mountain-road" ? [{ id: "orchard-lane", pts: ORCHARD_LANE_AUTHORED_CENTRE, hw: ORCHARD_LANE_HALF_WIDTH }] : [{ id: "mountain-road", pts: ROAD_CENTRE, hw: ROAD_HALF_WIDTH }];
  for (const o of others) {
    const opened = [];
    let corridor = [];
    for (const sample of line.samples) for (const side of ["left", "right"]) {
      const sign = side === "left" ? 1 : -1, x2 = sample.at[0] + sample.normal[0] * sample.halfWidth * sign, z = sample.at[2] + sample.normal[2] * sample.halfWidth * sign;
      let best = Infinity, near2 = null;
      for (const q of o.pts) {
        const e = Math.hypot(q[0] - x2, q[2] - z);
        if (e < best) {
          best = e;
          near2 = q;
        }
      }
      if (near2 && best < o.hw - 0.1 && Math.abs(near2[1] - sample.at[1]) < 1.5) {
        sample[side] = "open";
        OPENED[side].add(sample);
        opened.push({ side, s: sample.s });
        corridor.push(near2);
      }
    }
    for (const side of ["left", "right"]) {
      const ss = opened.filter((x2) => x2.side === side).map((x2) => x2.s);
      if (ss.length) OPENINGS.push({ id: `${line.id}:${side}:junction:${o.id}`, line: line.id, side, s0: Math.min(...ss), s1: Math.max(...ss), by: "junction", corridor, halfWidth: o.hw });
    }
  }
  return line;
}
function closeStubs(line) {
  const S = line.samples;
  for (const side of ["left", "right"]) for (let i2 = 1; i2 < S.length - 1; i2++) {
    if (S[i2][side] === "open") continue;
    let j = i2;
    while (j + 1 < S.length && S[j + 1][side] === S[i2][side]) j++;
    if (j - i2 < 2 && OPENED[side].has(S[i2 - 1]) && j + 1 < S.length && OPENED[side].has(S[j + 1])) {
      for (let m = i2; m <= j; m++) {
        S[m][side] = "open";
        OPENED[side].add(S[m]);
      }
      const o = OPENINGS.find((o2) => o2.line === line.id && o2.side === side && (Math.abs(o2.s1 - S[i2 - 1].s) < 0.01 || Math.abs(o2.s0 - S[j + 1].s) < 0.01));
      if (o) {
        o.s0 = Math.min(o.s0, S[i2].s);
        o.s1 = Math.max(o.s1, S[j].s);
      }
    }
    i2 = j;
  }
}
function openDepartures(line) {
  openJunctions(line);
  for (const d of departures(line)) {
    const reach = d.halfWidth + 0.9, opened = [];
    for (const sample of line.samples) for (const side of ["left", "right"]) {
      const sign = side === "left" ? 1 : -1, x2 = sample.at[0] + sample.normal[0] * sample.halfWidth * sign, z = sample.at[2] + sample.normal[2] * sample.halfWidth * sign;
      let best = Infinity, y = 0;
      for (let k = 1; k < d.corridor.length; k++) {
        const a = d.corridor[k - 1], b = d.corridor[k], dx = b[0] - a[0], dz = b[2] - a[2], t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / (dx * dx + dz * dz || 1))), e = Math.hypot(x2 - a[0] - dx * t, z - a[2] - dz * t);
        if (e < best) {
          best = e;
          y = mix3(a[1], b[1], t);
        }
      }
      if (best < reach && Math.abs(y - sample.at[1]) < 2.5) {
        sample[side] = "open";
        OPENED[side].add(sample);
        opened.push({ side, s: sample.s });
      }
    }
    for (const side of ["left", "right"]) {
      const ss = opened.filter((o) => o.side === side).map((o) => o.s);
      if (ss.length) OPENINGS.push({ id: `${line.id}:${side}:${d.id}`, line: line.id, side, s0: Math.min(...ss), s1: Math.max(...ss), by: d.by, corridor: d.corridor, halfWidth: d.halfWidth });
    }
  }
  closeStubs(line);
  return line;
}
var roadBridge = (i2) => BRIDGE_SPANS.find((b) => b.line === "road" && i2 >= b.i0 && i2 <= b.i1)?.id ?? null;
var laneBridge = (i2) => BRIDGE_SPANS.find((b) => b.line === "lane" && i2 >= b.i0 && i2 <= b.i1)?.id ?? null;
var TOWN_HALF_WIDTH = 3.5;
var MOUNTAIN_ROAD_LINE = openDepartures(fairMountainRoadFrames(classify(ROAD_CENTRE, "mountain-road", (i2) => mix3(TOWN_HALF_WIDTH, ROAD_HALF_WIDTH, Math.min(1, i2 / 18)), roadBridge)));
var ORCHARD_LANE_LINE = applyOrchardJunctionProfile(openDepartures(classify(ORCHARD_LANE_AUTHORED_CENTRE, "orchard-lane", () => ORCHARD_LANE_HALF_WIDTH, laneBridge)), MOUNTAIN_ROAD_LINE);
function gorgeBridge(span) {
  const line = span.line === "road" ? MOUNTAIN_ROAD_LINE : ORCHARD_LANE_LINE, deck = line.samples.slice(span.i0, span.i1 + 1).map((s) => s.at);
  const deckThickness = span.type === "timber" ? 1.1 : span.type === "masonry" ? span.i1 - span.i0 < 32 ? 1 : 1.6 : 0.9;
  let clearance = Infinity;
  const piers = [];
  const spacing = span.type === "masonry" ? 14 : span.type === "timber" ? 11 : 18;
  let lowest = Infinity;
  for (const p of deck) {
    const g2 = mountainGround2(p[0], p[2]);
    if (g2 < lowest) {
      lowest = g2;
      clearance = p[1] - deckThickness - g2;
    }
  }
  for (let k = 0; k < deck.length; k++) {
    const p = deck[k];
    if (k > 2 && k < deck.length - 3 && k % spacing === 0) piers.push([p[0], mountainGround2(p[0], p[2]), p[2]]);
  }
  const a = deck[0], b = deck[deck.length - 1];
  return { id: span.id, name: span.name, type: span.type, carries: span.line, s0: line.samples[span.i0].s, s1: line.samples[span.i1].s, a, b, span: Math.hypot(b[0] - a[0], b[2] - a[2]), deckThickness, clearance, piers, crosses: ["gorge", "river"], halfWidth: span.line === "road" ? ROAD_HALF_WIDTH : ORCHARD_LANE_HALF_WIDTH, deck };
}
var GORGE_BRIDGES = BRIDGE_SPANS.map(gorgeBridge);
var departureGap = (sample, side) => OPENED[side].has(sample);
function runs(line) {
  const edges3 = [], walls = [];
  for (const side of ["left", "right"]) {
    const sign = side === "left" ? 1 : -1;
    let i2 = 0;
    const S = line.samples;
    while (i2 < S.length) {
      const kind = S[i2][side];
      let j = i2;
      while (j + 1 < S.length && S[j + 1][side] === kind) j++;
      if (kind !== "open") {
        const guarded = kind === "parapet" || kind === "bridge" || kind === "wall";
        const lo = guarded && i2 > 0 && !departureGap(S[i2 - 1], side) ? i2 - 1 : i2, hi = guarded && j + 1 < S.length && !departureGap(S[j + 1], side) ? j + 2 : j + 1;
        const pts = S.slice(lo, hi).map((s) => {
          const x2 = s.at[0] + s.normal[0] * s.halfWidth * sign, z = s.at[2] + s.normal[2] * s.halfWidth * sign;
          return [x2, orchardEdgeHeight(line.id, x2, z, s.at[1]), z];
        });
        const id = `${line.id}:${side}:${kind}:${Math.round(S[i2].s)}`;
        edges3.push({ id, line: line.id, side, kind, s0: S[i2].s, s1: S[j].s, points: pts, height: kind === "kerb" ? EDGE_RULES.kerbHeight : kind === "wall" ? 0 : EDGE_RULES.parapetHeight });
        if (kind === "wall") {
          const top = S.slice(i2, j + 1).map((s) => {
            const o = s.halfWidth + 3.2, x2 = s.at[0] + s.normal[0] * o * sign, z = s.at[2] + s.normal[2] * o * sign;
            return [s.at[0] + s.normal[0] * (s.halfWidth + 0.3) * sign, Math.max(s.at[1] + 0.9, mountainGround2(x2, z)), s.at[2] + s.normal[2] * (s.halfWidth + 0.3) * sign];
          });
          walls.push({ id: `${id}:retaining`, of: line.id, side, foot: pts, top, thickness: 0.7 });
        }
      }
      i2 = j + 1;
    }
  }
  return { edges: edges3, walls };
}
var roadRuns = runs(MOUNTAIN_ROAD_LINE);
var laneRuns = runs(ORCHARD_LANE_LINE);
var EDGE_RUNS = [...roadRuns.edges, ...laneRuns.edges];
var RETAINING_WALLS_ROAD = [...roadRuns.walls, ...laneRuns.walls];
var EDGE_SOLIDS = EDGE_RUNS.filter((r) => r.kind !== "kerb").flatMap((r) => {
  const out = [];
  for (let k = 0; k < r.points.length - 1; k += 2) {
    const a = r.points[k], b = r.points[Math.min(k + 2, r.points.length - 1)];
    const bottom = Math.min(a[1], b[1]) - 0.2, top = r.kind === "wall" ? Math.max(a[1], b[1]) + 2.4 : Math.max(a[1], b[1]) + r.height;
    out.push({ id: `${r.id}:${k}`, a: [a[0], a[2]], b: [b[0], b[2]], bottom, top, thickness: r.kind === "wall" ? 0.7 : 0.3 });
  }
  return out;
});
var roadSampleAtPlan = (planS, line = MOUNTAIN_ROAD_LINE) => line.samples[Math.max(0, Math.min(line.samples.length - 1, Math.round(planS / ROAD_SAMPLE_STEP)))];
var DAM_OVERLOOK = (() => {
  const sample = roadSampleAtPlan(roadTagS("reservoir") + 21), look = [8, 78, -228];
  return { s: sample.s, at: sample.at, facing: Math.atan2(look[0] - sample.at[0], look[2] - sample.at[2]), look };
})();

// src/harbour/mountain/branchLandings.ts
function gradient(a, b, c) {
  const ux = b[0] - a[0], uz = b[2] - a[2], vx = c[0] - a[0], vz = c[2] - a[2], det = ux * vz - uz * vx;
  if (Math.abs(det) < 1e-10) return 0;
  const dy = b[1] - a[1], ey = c[1] - a[1];
  return Math.hypot((dy * vz - ey * uz) / det, (ux * ey - vx * dy) / det);
}
function bandGrade(a, b) {
  let max2 = 0;
  for (let k = 1; k < a.length; k++) max2 = Math.max(max2, gradient(a[k - 1], b[k - 1], b[k]), gradient(a[k - 1], b[k], a[k]));
  return max2;
}
var softMin = (a, b) => {
  const k = 0.05, h = Math.max(k - Math.abs(a - b), 0) / k;
  return Math.min(a, b) - h * h * k * 0.25;
};
function repairBranchLanding(authored2, halfWidth, road, grade) {
  const rows = authored2.map((p, i2) => {
    const a = authored2[Math.max(0, i2 - 1)], b = authored2[Math.min(authored2.length - 1, i2 + 1)], dx = b[0] - a[0], dz = b[2] - a[2], len = Math.hypot(dx, dz) || 1;
    return Array.from({ length: 5 }, (_, k) => [p[0] + dz / len * halfWidth * (k / 2 - 1), p[1], p[2] - dx / len * halfWidth * (k / 2 - 1)]);
  });
  const arc = [0];
  for (let i2 = 1; i2 < rows.length; i2++) arc.push(arc[i2 - 1] + 1 / bandGrade(rows[i2 - 1].map((p) => [p[0], 0, p[2]]), rows[i2].map((p) => [p[0], 1, p[2]])));
  function near2(p, station2) {
    let hit = { d: Infinity, y: p[1], s: 0 };
    for (let j = 1; j < road.length; j++) {
      if (station2 !== void 0 && (road[j].s < station2 - 30 || road[j - 1].s > station2 + 30)) continue;
      const a = road[j - 1].at, b = road[j].at, dx = b[0] - a[0], dz = b[2] - a[2], t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[2] - a[2]) * dz) / (dx * dx + dz * dz || 1))), d = Math.hypot(p[0] - a[0] - t * dx, p[2] - a[2] - t * dz);
      if (d < hit.d) hit = { d, y: a[1] + t * (b[1] - a[1]), s: road[j - 1].s + t * (road[j].s - road[j - 1].s) };
    }
    return hit;
  }
  const n = rows.length, end = authored2[n - 1], endStation = near2(end).s, nearest = rows.map((row) => row.map((p) => near2(p, endStation)));
  const overlap = rows.findIndex((row, i2) => i2 > n / 2 && row.some((p, k) => Math.hypot(p[0] - end[0], p[2] - end[2]) < 28 && nearest[i2][k].d <= 4.8));
  const first = overlap < 0 ? -1 : Math.max(0, overlap - 1);
  if (first < 0) return { points: [...authored2], rows };
  const target = nearest.map((row) => row[2].y);
  const heights = authored2.map((p, i2) => {
    if (i2 >= first) return target[i2];
    let upper = Infinity;
    for (let j = first; j < n; j++) upper = Math.min(upper, target[j] + grade * (arc[j] - arc[i2]));
    return softMin(p[1], upper);
  });
  const start = Math.max(0, first - 8);
  const repaired = rows.map((row, i2) => {
    const w = smooth2((arc[i2] - arc[start]) / (arc[first] - arc[start]));
    return row.map((p, k) => [p[0], heights[i2] + w * (nearest[i2][k].y - target[i2]), p[2]]);
  });
  return { points: authored2.map((p, i2) => [p[0], heights[i2], p[2]]), rows: repaired };
}
function landingSample(rows, x2, z) {
  for (let i2 = 1; i2 < rows.length; i2++) for (let k = 1; k < rows[i2].length; k++) {
    const a = rows[i2 - 1][k - 1], b = rows[i2][k - 1], c = rows[i2][k], d = rows[i2 - 1][k];
    if (x2 < Math.min(a[0], b[0], c[0], d[0]) - 1e-6 || x2 > Math.max(a[0], b[0], c[0], d[0]) + 1e-6 || z < Math.min(a[2], b[2], c[2], d[2]) - 1e-6 || z > Math.max(a[2], b[2], c[2], d[2]) + 1e-6) continue;
    for (const [p, q, r] of [[a, b, c], [a, c, d]]) {
      const ux = q[0] - p[0], uz = q[2] - p[2], vx = r[0] - p[0], vz = r[2] - p[2], det = ux * vz - uz * vx;
      if (Math.abs(det) < 1e-10) continue;
      const px = x2 - p[0], pz = z - p[2], u = (px * vz - pz * vx) / det, v = (ux * pz - uz * px) / det;
      if (u < -1e-6 || v < -1e-6 || u + v > 1 + 1e-6) continue;
      const dy = q[1] - p[1], ey = r[1] - p[1];
      return { y: p[1] + dy * u + ey * v, gx: (dy * vz - ey * uz) / det, gz: (ux * ey - vx * dy) / det };
    }
  }
  return null;
}

// src/harbour/mountain/damEntry.ts
function repairDamEntry(landing, road) {
  const first = landing.points[0], entry = road.reduce((a, b) => Math.hypot(a.at[0] - first[0], a.at[2] - first[2]) < Math.hypot(b.at[0] - first[0], b.at[2] - first[2]) ? a : b);
  const local = road.filter((s) => Math.abs(s.s - entry.s) < 24), roadRows = local.map((s) => [-s.halfWidth, -s.halfWidth + 0.55, -0.45, 0.45, s.halfWidth - 0.55, s.halfWidth].map((w) => [s.at[0] + s.normal[0] * w, s.at[1], s.at[2] + s.normal[2] * w]));
  function roadTop(p) {
    const direct = landingSample(roadRows, p[0], p[2]);
    if (direct) return direct.y;
    let nearest = { d: Infinity, x: 0, z: 0, hw: 0 };
    for (let i2 = 1; i2 < local.length; i2++) {
      const a = local[i2 - 1], b = local[i2], dx = b.at[0] - a.at[0], dz = b.at[2] - a.at[2], t = Math.max(0, Math.min(1, ((p[0] - a.at[0]) * dx + (p[2] - a.at[2]) * dz) / (dx * dx + dz * dz || 1))), x3 = a.at[0] + dx * t, z2 = a.at[2] + dz * t, d = Math.hypot(p[0] - x3, p[2] - z2);
      if (d < nearest.d) nearest = { d, x: x3, z: z2, hw: a.halfWidth + (b.halfWidth - a.halfWidth) * t };
    }
    const f = Math.min(1, (nearest.hw - 0.1) / (nearest.d || 1)), x2 = nearest.x + (p[0] - nearest.x) * f, z = nearest.z + (p[2] - nearest.z) * f, hit = landingSample(roadRows, x2, z);
    if (!hit) throw new Error("Dam entry lost its existing road plane");
    return hit.y + hit.gx * (p[0] - x2) + hit.gz * (p[2] - z);
  }
  const rows = landing.rows.map((row, i2) => i2 >= 13 ? row : row.map((p) => {
    const w = 1 - smooth2((i2 - 5) / 8);
    const lift2 = 0.02 * smooth2(i2 - 4) * (1 - smooth2((i2 - 8) / 5));
    return [p[0], p[1] + w * (roadTop(p) - p[1]) + lift2, p[2]];
  }));
  return { points: landing.points.map((p, i2) => i2 === 0 || i2 >= 13 ? p : [p[0], rows[i2][2][1], p[2]]), rows };
}

// src/harbour/mountain/generated/library-landing.json
var library_landing_default = { note: "Generated by scripts/generate-mountain-landings.mjs. One landing mesh for native and Horizon art, surface and collision. Do not edit by hand.", sourceSha256: "4b8bd8e7da399b68275f264f20a07b07d03c3359710c828145e494595e2d2a2a", terrainSha256: "16e7a64647985f0a6bc5d90e91ba7b5311b5a9a2732f712934befaf0a9a6fd77", solverSha256: "66c3776903300f47ad6adc9358cd34c23008aab9e72115cfe8d2ac61f1581f4c", entryFairingSha256: "7d9bc3154f792caf0494f958b27fa11a80765bd48d5db1726404057e3bcc8ceb", entryPreservedFromRow: 12, lockedRows: 28, rows: [[[29.52447509105041, 40.32686770029603, -180.74211949647312], [29.61714255706596, 40.39633989641303, -181.53673433445582], [29.709810023081513, 40.46581209253004, -182.3313491724385], [29.802477489097065, 40.506305316700974, -183.1259640104212], [29.895144955112617, 40.54773555638278, -183.9205788484039]], [[29.90317745263474, 40.290604224511924, -180.54546762086963], [30.299739740944506, 40.33636693026801, -181.24026136831597], [30.696302029254273, 40.38212963602409, -181.9350551157623], [31.09286431756404, 40.42789234178017, -182.62984886320865], [31.489426605873806, 40.46581209253004, -183.324642610655]], [[30.73335068435014, 40.19280307894418, -179.91746531979544], [31.20828685267058, 40.23010066166344, -180.56123207571025], [31.683223020991022, 40.27609793271092, -181.20499883162506], [32.15815918931146, 40.328546464423795, -181.84876558753987], [32.63309535763191, 40.341993409821214, -182.49253234345468]], [[31.886033252201273, 40.08277257679823, -179.08409757027795], [32.27828950413968, 40.157111961131534, -179.78133141398837], [32.67054575607808, 40.1997843317335, -180.47856525769882], [33.062802008016476, 40.249515475605875, -181.17579910140927], [33.45505825995488, 40.24887848095735, -181.8730329451197]], [[33.27848536593276, 40.01210221637591, -178.53957090719098], [33.468401347928726, 40.09731127092856, -179.31670147523118], [33.65831732992469, 40.157111961131534, -180.09383204327142], [33.84823331192066, 40.16310781330455, -180.87096261131165], [34.038149293916625, 40.21773471976955, -181.64809317935186]], [[34.49438259129824, 39.9881378706663, -178.40290783971184], [34.570505876403914, 40.07630817937216, -179.19927788276013], [34.646629161509594, 40.157111961131534, -179.9956479258084], [34.722752446615274, 40.157111961131534, -180.7920179688567], [34.79887573172095, 40.21141286486224, -181.58838801190498]], [[35.498554339596765, 39.9706486402256, -178.31070749889335], [35.56709851590989, 40.05895008371104, -179.1077656497792], [35.635642692223016, 40.14725152719649, -179.90482380066504], [35.70418686853614, 40.157111961131534, -180.7018819515509], [35.772731044849266, 40.20194171304068, -181.49894010243673]], [[36.66523371768416, 39.95414045601905, -178.22595055808085], [36.64543423361524, 40.042057411011406, -179.0257055083191], [36.62563474954632, 40.131294290654516, -179.8254604585574], [36.6058352654774, 40.157111961131534, -180.62521540879567], [36.586035781408484, 40.157111961131534, -181.42497035903392]], [[38.036842125638735, 40.220415094324075, -178.40993192981458], [37.82694146348103, 40.295817295056196, -179.18190454074437], [37.61704080132331, 40.37121949578832, -179.95387715167416], [37.4071401391656, 40.38727897960979, -180.72584976260396], [37.19723947700789, 40.38727897960979, -181.49782237353375]], [[39.2853475043302, 40.55252071326083, -178.9146114386064], [38.94745876643456, 40.59601323023524, -179.63975363211281], [38.60957002853892, 40.62904369083452, -180.36489582561921], [38.27168129064328, 40.62904369083452, -181.09003801912561], [37.93379255274764, 40.62904369083452, -181.81518021263201]], [[40.29375797337374, 40.88208438714216, -179.4360549151441], [39.948162028676286, 40.89537711475182, -180.15755574189947], [39.60256608397883, 40.89741503860096, -180.87905656865485], [39.25697013928137, 40.89741503860096, -181.60055739541022], [38.91137419458392, 40.89741503860096, -182.3220582221656]], [[41.07049830338059, 41.15783977908078, -179.78831517167498], [40.83309934244542, 41.15783977908078, -180.55227965602415], [40.595700381510255, 41.15783977908078, -181.31624414037333], [40.35830142057509, 41.15783977908078, -182.0802086247225], [40.12090245963992, 41.15783977908078, -182.84417310907168]], [[41.573498815065605, 41.27632431491922, -179.89636104084852], [41.581175822896796, 41.27632431491922, -180.6963242047197], [41.588852830727994, 41.27632431491922, -181.49628736859086], [41.59652983855919, 41.27632431491922, -182.296250532462], [41.60420684639038, 41.27632431491922, -183.0962136963332]], [[42.55404077749507, 41.29091466950431, -179.88462618163692], [42.56799881542607, 41.29091466950431, -180.68450440560426], [42.581956853357084, 41.29091466950431, -181.48438262957157], [42.595914891288096, 41.29091466950431, -182.28426085353888], [42.6098729292191, 41.29091466950431, -183.08413907750622]], [[43.52531217019895, 41.29940336031082, -179.8623985851597], [43.5500889889453, 41.29940336031082, -180.66201481139126], [43.574865807691644, 41.29940336031082, -181.46163103762282], [43.59964262643799, 41.29940336031082, -182.2612472638544], [43.62441944518434, 41.29940336031082, -183.06086349008595]], [[44.490575806913945, 41.30260283629604, -179.82470514681907], [44.528923668681855, 41.30260283629604, -180.62378551918334], [44.567271530449766, 41.30260283629604, -181.42286589154762], [44.605619392217676, 41.30260283629604, -182.2219462639119], [44.643967253985586, 41.30260283629604, -183.02102663627616]], [[45.46126567008804, 41.30029830725768, -179.76939808571655], [45.51005095340315, 41.30029830725768, -180.56790919780696], [45.55883623671827, 41.30029830725768, -181.36642030989736], [45.60762152003339, 41.30029830725768, -182.16493142198777], [45.6564068033485, 41.30029830725768, -182.96344253407818]], [[46.44103701192851, 41.292596587980924, -179.70544440246388], [46.495470602307066, 41.292596587980924, -180.50359036921338], [46.549904192685624, 41.292596587980924, -181.3017363359629], [46.60433778306418, 41.292596587980924, -182.0998823027124], [46.65877137344274, 41.292596587980924, -182.8980282694619]], [[47.42286612776017, 41.280336231947445, -179.63560133455618], [47.48172200924371, 41.280336231947445, -180.43343338781978], [47.54057789072725, 41.280336231947445, -181.23126544108337], [47.59943377221079, 41.280336231947445, -182.02909749434696], [47.658289653694325, 41.280336231947445, -182.82692954761055]], [[48.40501977399105, 41.264355792638945, -179.56055809245268], [48.46794422025374, 41.264355792638945, -180.35807957433423], [48.53086866651644, 41.264355792638945, -181.15560105621577], [48.59379311277914, 41.264355792638945, -181.95312253809732], [48.65671755904183, 41.264355792638945, -182.75064401997886]], [[49.38702798369634, 41.24549382353712, -179.48062775446584], [49.45390013100438, 41.24549382353712, -180.27782792751802], [49.52077227831242, 41.24549382353712, -181.0750281005702], [49.58764442562046, 41.24549382353712, -181.87222827362237], [49.6545165729285, 41.24549382353712, -182.66942844667454]], [[50.368477164920456, 41.22479085114565, -179.39585667045426], [50.43937131616515, 41.22479085114565, -180.19270924108403], [50.51026546740984, 41.22479085114565, -180.98956181171383], [50.581159618654524, 41.22479085114565, -181.78641438234362], [50.65205376989922, 41.22479085114565, -182.5832669529734]], [[51.34901469532974, 41.20354410726444, -179.30607670107256], [51.424160032906876, 41.20354410726444, -180.10253961812546], [51.49930537048401, 41.20354410726444, -180.89900253517837], [51.57445070806114, 41.20354410726444, -181.69546545223128], [51.649596045638276, 41.20354410726444, -182.49192836928418]], [[52.328146153209104, 41.18305082369337, -179.21096928369386], [52.40798784876322, 41.18305082369337, -180.0069751276743], [52.487829544317336, 41.18305082369337, -180.80298097165476], [52.56767123987145, 41.18305082369337, -181.59898681563521], [52.64751293542557, 41.18305082369337, -182.39499265961567]], [[53.305097237803885, 41.16413554809888, -179.10988604542678], [53.39041435204024, 41.16413554809888, -179.90532365455675], [53.47573146627659, 41.16413554809888, -180.7007612636867], [53.561048580512946, 41.16413554809888, -181.49619887281665], [53.6463656947493, 41.16413554809888, -182.29163648194663]], [[54.27859200688944, 41.14725695879919, -179.00178906825042], [54.370715550335376, 41.14725695879919, -179.79646714945247], [54.46283909378131, 41.14725695879919, -180.59114523065452], [54.55496263722725, 41.14725695879919, -181.38582331185657], [54.647086180673185, 41.14725695879919, -182.18050139305862]], [[55.24921732028587, 41.13116311176025, -178.88452919677798], [55.34903007120295, 41.13116311176025, -179.6782781588273], [55.44884282212002, 41.13116311176025, -180.47202712087662], [55.548655573037095, 41.13116311176025, -181.26577608292592], [55.64846832395417, 41.13116311176025, -182.05952504497526]], [[56.232664489256045, 41.110879847697774, -178.75599237279138], [56.333153955228504, 41.110879847697774, -179.5496559458679], [56.43364342120097, 41.110879847697774, -180.3433195189444], [56.534132887173435, 41.110879847697774, -181.13698309202093], [56.63462235314589, 41.110879847697774, -181.93064666509744]], [[57.219554441308844, 41.08102906128345, -178.63505536870122], [57.319500018388055, 41.08102906128345, -179.42878761676874], [57.41944559546726, 41.08102906128345, -180.22251986483624], [57.51939117254646, 41.08102906128345, -181.01625211290374], [57.619336749625674, 41.08102906128345, -181.80998436097127]], [[58.16842323197531, 41.03571923659664, -178.51266210426996], [58.28641287859458, 41.03571923659664, -179.30391329276236], [58.404402525213854, 41.03571923659664, -180.09516448125478], [58.522392171833125, 41.03571923659664, -180.8864156697472], [58.6403818184524, 41.03571923659664, -181.6776668582396]], [[59.06385009627426, 40.96905885771658, -178.36190242936655], [59.22370168879263, 40.96905885771658, -179.14576942597336], [59.383553281311, 40.96905885771658, -179.92963642258013], [59.543404873829374, 40.96905885771658, -180.7135034191869], [59.703256466347746, 40.96905885771658, -181.4973704157937]], [[59.91883959990475, 40.85125290284574, -178.1575347281489], [60.13403422275977, 40.85125290284574, -178.92804837130797], [60.3492288456148, 40.85125290284574, -179.69856201446706], [60.56442346846983, 40.85125290284574, -180.46907565762615], [60.779618091324856, 40.85125290284574, -181.2395893007852]], [[60.7424962913528, 40.54499972875748, -177.89420090006735], [61.01867023631694, 40.54499972875748, -178.64501908852773], [61.294844181281086, 40.54499972875748, -179.39583727698812], [61.57101812624523, 40.54499972875748, -180.1466554654485], [61.84719207120937, 40.54499972875748, -180.8974736539089]], [[61.55069437800854, 40.229791655751555, -177.55637365392425], [61.880975313533696, 40.229791655751555, -178.28501245582038], [62.21125624905886, 40.229791655751555, -179.0136512577165], [62.54153718458403, 40.229791655751555, -179.74229005961263], [62.87181812010919, 40.229791655751555, -180.47092886150875]], [[62.37292354802548, 39.90005602431329, -177.15249525857035], [62.7378865198639, 39.90005602431329, -177.86439555298446], [63.102849491702315, 39.90005602431329, -178.57629584739854], [63.46781246354073, 39.90005602431329, -179.28819614181262], [63.83277543537915, 39.90005602431329, -180.00009643622673]], [[63.21221840619017, 39.557331365531354, -176.70308670813625], [63.59535148071184, 39.557331365531354, -177.40537514404247], [63.97848455523352, 39.557331365531354, -178.10766357994865], [64.3616176297552, 39.557331365531354, -178.80995201585483], [64.74475070427688, 39.557331365531354, -179.51224045176104]], [[64.06910627958267, 39.20436669174088, -176.2265996118819], [64.45780972368571, 39.20436669174088, -176.9258203442279], [64.84651316778874, 39.20436669174088, -177.62504107657386], [65.23521661189177, 39.20436669174088, -178.32426180891983], [65.62392005599482, 39.20436669174088, -179.02348254126582]], [[64.94817655478771, 38.85133465918335, -175.73804939965063], [65.33139184514391, 38.85133465918335, -176.44029297650783], [65.7146071355001, 38.85133465918335, -177.14253655336506], [66.0978224258563, 38.85133465918335, -177.8447801302223], [66.4810377162125, 38.85133465918335, -178.5470237070795]], [[65.85740479789355, 38.50756861042038, -175.25118678440217], [66.22373691273933, 38.50756861042038, -175.96238350938944], [66.59006902758509, 38.50756861042038, -176.67358023437671], [66.95640114243085, 38.50756861042038, -177.384776959364], [67.32273325727662, 38.50756861042038, -178.09597368435126]], [[66.80283331478971, 38.172292787284135, -174.78355253519953], [67.14149073595817, 38.172292787284135, -175.50833605535402], [67.48014815712664, 38.172292787284135, -176.2331195755085], [67.8188055782951, 38.172292787284135, -176.957903095663], [68.15746299946356, 38.172292787284135, -177.6826866158175]], [[67.74900947520034, 37.82956783748494, -174.3665928634102], [68.06904947343978, 37.82956783748494, -175.09978751664144], [68.38908947167923, 37.82956783748494, -175.8329821698727], [68.70912946991868, 37.82956783748494, -176.56617682310397], [69.02916946815812, 37.82956783748494, -177.2993714763352]], [[68.66802958053492, 37.47498489189597, -173.96884682593273], [68.98429823260234, 37.47498489189597, -174.7036761528648], [69.30056688466978, 37.47498489189597, -175.43850547979687], [69.61683553673721, 37.47498489189597, -176.17333480672895], [69.93310418880463, 37.47498489189597, -176.90816413366102]], [[69.59474085255918, 37.12278388167914, -173.57224672157122], [69.90418211981189, 37.12278388167914, -174.3099770938083], [70.2136233870646, 37.12278388167914, -175.04770746604535], [70.52306465431731, 37.12278388167914, -175.7854378382824], [70.83250592157002, 37.12278388167914, -176.5231682105195]], [[70.54292957218763, 36.77675117701638, -173.18269033140584], [70.83758604856352, 36.77675117701638, -173.9264494059251], [71.1322425249394, 36.77675117701638, -174.67020848044436], [71.42689900131528, 36.77675117701638, -175.41396755496362], [71.72155547769117, 36.77675117701638, -176.15772662948288]], [[71.51755747210366, 36.43724010113954, -172.81097737855006], [71.78884318046013, 36.43724010113954, -173.56357558771717], [72.0601288888166, 36.43724010113954, -174.31617379688427], [72.33141459717308, 36.43724010113954, -175.06877200605138], [72.60270030552955, 36.43724010113954, -175.82137021521848]], [[72.52372707549829, 36.10478838176738, -172.4694542521786], [72.76209256255432, 36.10478838176738, -173.2331177216339], [73.00045804961033, 36.10478838176738, -173.99678119108924], [73.23882353666635, 36.10745860130912, -174.76044466054458], [73.47718902372237, 36.19960993092687, -175.5241081299999]], [[73.56597551228901, 35.780025261917594, -172.17270611944159], [73.76071435694182, 35.76521949307808, -172.9486421879313], [73.95545320159464, 35.780025261917594, -173.72457825642104], [74.15019204624745, 35.83705605823699, -174.50051432491077], [74.34493089090026, 35.86131125037435, -175.2764503934005]], [[74.6690199976329, 35.667667362499515, -171.9343184593026], [74.79737426999934, 35.65699825022987, -172.72395456585122], [74.92572854236579, 35.77620339647688, -173.51359067239986], [75.05408281473224, 36.055700943673315, -174.3032267789485], [75.18243708709868, 35.792706839815956, -175.0928628854971]], [[75.83281793827011, 36.017859087724105, -171.80847688725262], [75.87253236581799, 36.07170961753771, -172.607490506814], [75.91224679336587, 36.12557575333118, -173.40650412637535], [75.95196122091374, 36.17209806918172, -174.2055177459367], [75.99167564846162, 35.88503403333233, -175.00453136549808]], [[76.97329952918575, 35.579025736781965, -171.8166717473484], [76.93914440157353, 35.6613688462271, -172.61594230683238], [76.9049892739613, 35.74372437350824, -173.41521286631632], [76.87083414634908, 35.816880869873174, -174.21448342580027], [76.83667901873686, 35.76210592186634, -175.01375398528424]], [[78.03401539981131, 35.17719979308777, -171.89727628245785], [77.96458846177997, 35.272939605030686, -172.6942580264618], [77.89516152374863, 35.36869020949516, -173.49123977046577], [77.82573458571729, 35.45206964133922, -174.28822151446974], [77.75630764768594, 35.40129151163719, -175.08520325847368]], [[79.01857155060003, 34.80605655289426, -171.99327746930751], [78.9511126391102, 34.9010556341454, -172.79042820490312], [78.8836537276204, 34.99606292724364, -173.58757894049873], [78.81619481613059, 35.07399287969294, -174.38472967609434], [78.74873590464077, 35.01191873908466, -175.18188041168995]], [[79.93000347336893, 34.460533075883, -172.0596877485834], [79.90208505818829, 34.54050335473423, -172.8592004514805], [79.87416664300765, 34.62047654706169, -173.65871315437758], [79.84624822782702, 34.67739032387634, -174.45822585727467], [79.81832981264638, 34.59779189667141, -175.25773856017176]], [[80.76430871398253, 34.139023454593485, -172.06012356554334], [80.81559746903093, 34.18837432347433, -172.85847778743084], [80.86688622407934, 34.23772047980494, -173.65683200931832], [80.91817497912774, 34.258320996879895, -174.4551862312058], [80.96946373417614, 34.194084369763594, -175.2535404530933]], [[81.55972599560435, 33.8236638946303, -171.95846354517275], [81.7054136692711, 33.83562595098324, -172.74508613685288], [81.85110134293784, 33.84757370691769, -173.531708728533], [81.99678901660458, 33.830943219490564, -174.31833132021313], [82.14247669027132, 33.781950699755086, -175.10495391189326]], [[82.40976270086135, 33.47785275487778, -171.74825594257618], [82.61276531928335, 33.46681296995735, -172.52207112523533], [82.81576793770536, 33.457232946102195, -173.29588630789448], [83.01877055612736, 33.42069529120089, -174.06970149055363], [83.22177317454937, 33.36522537413824, -174.84351667321278]], [[83.31342177373408, 33.1073474119853, -171.4949062138468], [83.54272416827683, 33.09124115958418, -172.2613397803462], [83.77202656281958, 33.06765727702406, -173.02777334684558], [84.00132895736232, 33.02512064043803, -173.79420691334496], [84.23063135190507, 32.95906298356985, -174.56064047984435]], [[84.20244944163134, 32.7393117823524, -171.21212661736814], [84.46042161641346, 32.716886456355, -171.96939166808565], [84.71839379119555, 32.67867946124575, -172.72665671880316], [84.97636596597765, 32.631408012086844, -173.48392176952066], [85.23433814075976, 32.55377251452934, -174.24118682023817]], [[85.06391553765147, 32.37785365868585, -170.89931777844293], [85.35782973123963, 32.351414438652625, -171.64337049620386], [85.65174392482781, 32.29032957017828, -172.38742321396478], [85.94565811841599, 32.238625039869916, -173.1314759317257], [86.23957231200416, 32.146420187176616, -173.87552864948663]], [[85.88002073829924, 32.028258481038584, -170.5512439524767], [86.2224527521715, 31.99372104175575, -171.27425177807433], [86.56488476604376, 31.907730138779, -171.99725960367195], [86.90731677991602, 31.963261356938652, -172.72026742926957], [87.24974879378829, 32.007438235255954, -173.4432752548672]], [[86.6159604131074, 31.70248608496293, -170.16964226094464], [87.03050840623725, 31.64970927491568, -170.85385711125997], [87.44505639936709, 31.621259163829762, -171.5380719615753], [87.85960439249693, 31.821872514541496, -172.22228681189063], [88.27415238562678, 31.868899174678265, -172.90650166220595]], [[87.18493112633342, 31.436404530728506, -169.78487665661837], [87.72187331260047, 31.331665006568326, -170.37791382965793], [88.2588154988675, 31.36978990495672, -170.97095100269752], [88.79575768513455, 31.584436385802576, -171.5639881757371], [89.33269987140159, 31.613351198799354, -172.15702534877667]], [[87.44009502992515, 31.30999624745639, -169.56610775794266], [88.17008221197936, 31.094310945064162, -169.89339771201477], [88.9000693940336, 31.111870382834276, -170.2206876660869], [89.63005657608782, 31.168057411375433, -170.547977620159], [90.36004375814204, 31.207854230719235, -170.87526757423112]], [[87.43191341030067, 31.259339892058094, -169.380018084377], [88.22955180906393, 31.023120152813934, -169.3185934572444], [89.02719020782719, 30.99608228886751, -169.25716883011174], [89.82482860659044, 30.859835305564776, -169.19574420297909], [90.62246700535371, 30.83648953981148, -169.13431957584646]], [[87.25101200483299, 31.04666656792718, -168.857522970985], [88.00177391756444, 30.968799469266227, -168.58119608052405], [88.75253583029588, 30.907808589236645, -168.3048691900631], [89.50329774302733, 30.8297376376059, -168.02854229960215], [90.25405965575878, 30.80760227416489, -167.7522154091412]], [[86.91093834691131, 31.04666656792718, -168.11234866752105], [87.62732060745431, 30.96261150657401, -167.75626376643805], [88.34370286799732, 30.894165322900918, -167.40017886535506], [89.06008512854034, 30.787955591483183, -167.04409396427207], [89.77646738908334, 30.726979817123986, -166.68800906318907]], [[86.4826640349753, 31.048465140811583, -167.32620662681896], [87.17595316985019, 30.968431453252308, -166.92701973391738], [87.86924230472509, 30.890719335728143, -166.5278328410158], [88.5625314396, 30.784299076561307, -166.1286459481142], [89.25582057447488, 30.711083341037313, -165.72945905521263]], [[86.00159899567262, 31.067918317076753, -166.53613626713354], [86.67727432289047, 30.980495328216506, -166.10781062910908], [87.35294965010831, 30.893688724397773, -165.67948499108462], [88.02862497732616, 30.787356680443438, -165.25115935306016], [88.704300304544, 30.70250236330368, -164.8228337150357]], [[85.48555916461255, 31.092084660565767, -165.7541547903114], [86.14576854021463, 30.997286108824277, -165.3023544136326], [86.80597791581673, 30.90148404484509, -164.8505540369538], [87.46618729141882, 30.795370006351973, -164.39875366027502], [88.1263966670209, 30.69913822210397, -163.94695328359623]], [[84.92637934390424, 31.12126553327663, -164.966279713034], [85.57887736253029, 31.0186892733366, -164.5034121988476], [86.23137538115633, 30.91372127329568, -164.0405446846612], [86.88387339978236, 30.807758375579464, -163.5776771704748], [87.53637141840841, 30.700419191166215, -163.1148096562884]]], points: [[29.709810023081513, 40.46581209253004, -182.3313491724385], [30.696302029254273, 40.38212963602409, -181.9350551157623], [31.683223020991022, 40.27609793271092, -181.20499883162506], [32.67054575607808, 40.1997843317335, -180.47856525769882], [33.65831732992469, 40.157111961131534, -180.09383204327142], [34.646629161509594, 40.157111961131534, -179.9956479258084], [35.635642692223016, 40.14725152719649, -179.90482380066504], [36.62563474954632, 40.131294290654516, -179.8254604585574], [37.61704080132331, 40.37121949578832, -179.95387715167416], [38.60957002853892, 40.62904369083452, -180.36489582561921], [39.60256608397883, 40.89741503860096, -180.87905656865485], [40.595700381510255, 41.15783977908078, -181.31624414037333], [41.588852830727994, 41.27632431491922, -181.49628736859086], [42.581956853357084, 41.29091466950431, -181.48438262957157], [43.574865807691644, 41.29940336031082, -181.46163103762282], [44.567271530449766, 41.30260283629604, -181.42286589154762], [45.55883623671827, 41.30029830725768, -181.36642030989736], [46.549904192685624, 41.292596587980924, -181.3017363359629], [47.54057789072725, 41.280336231947445, -181.23126544108337], [48.53086866651644, 41.264355792638945, -181.15560105621577], [49.52077227831242, 41.24549382353712, -181.0750281005702], [50.51026546740984, 41.22479085114565, -180.98956181171383], [51.49930537048401, 41.20354410726444, -180.89900253517837], [52.487829544317336, 41.18305082369337, -180.80298097165476], [53.47573146627659, 41.16413554809888, -180.7007612636867], [54.46283909378131, 41.14725695879919, -180.59114523065452], [55.44884282212002, 41.13116311176025, -180.47202712087662], [56.43364342120097, 41.110879847697774, -180.3433195189444], [57.41944559546726, 41.08102906128345, -180.22251986483624], [58.404402525213854, 41.03571923659664, -180.09516448125478], [59.383553281311, 40.96905885771658, -179.92963642258013], [60.3492288456148, 40.85125290284574, -179.69856201446706], [61.294844181281086, 40.54499972875748, -179.39583727698812], [62.21125624905886, 40.229791655751555, -179.0136512577165], [63.102849491702315, 39.90005602431329, -178.57629584739854], [63.97848455523352, 39.557331365531354, -178.10766357994865], [64.84651316778874, 39.20436669174088, -177.62504107657386], [65.7146071355001, 38.85133465918335, -177.14253655336506], [66.59006902758509, 38.50756861042038, -176.67358023437671], [67.48014815712664, 38.172292787284135, -176.2331195755085], [68.38908947167923, 37.82956783748494, -175.8329821698727], [69.30056688466978, 37.47498489189597, -175.43850547979687], [70.2136233870646, 37.12278388167914, -175.04770746604535], [71.1322425249394, 36.77675117701638, -174.67020848044436], [72.0601288888166, 36.43724010113954, -174.31617379688427], [73.00045804961033, 36.10478838176738, -173.99678119108924], [73.95545320159464, 35.780025261917594, -173.72457825642104], [74.92572854236579, 35.77620339647688, -173.51359067239986], [75.91224679336587, 36.12557575333118, -173.40650412637535], [76.9049892739613, 35.74372437350824, -173.41521286631632], [77.89516152374863, 35.36869020949516, -173.49123977046577], [78.8836537276204, 34.99606292724364, -173.58757894049873], [79.87416664300765, 34.62047654706169, -173.65871315437758], [80.86688622407934, 34.23772047980494, -173.65683200931832], [81.85110134293784, 33.84757370691769, -173.531708728533], [82.81576793770536, 33.457232946102195, -173.29588630789448], [83.77202656281958, 33.06765727702406, -173.02777334684558], [84.71839379119555, 32.67867946124575, -172.72665671880316], [85.65174392482781, 32.29032957017828, -172.38742321396478], [86.56488476604376, 31.907730138779, -171.99725960367195], [87.44505639936709, 31.621259163829762, -171.5380719615753], [88.2588154988675, 31.36978990495672, -170.97095100269752], [88.9000693940336, 31.111870382834276, -170.2206876660869], [89.02719020782719, 30.99608228886751, -169.25716883011174], [88.75253583029588, 30.907808589236645, -168.3048691900631], [88.34370286799732, 30.894165322900918, -167.40017886535506], [87.86924230472509, 30.890719335728143, -166.5278328410158], [87.35294965010831, 30.893688724397773, -165.67948499108462], [86.80597791581673, 30.90148404484509, -164.8505540369538], [86.23137538115633, 30.91372127329568, -164.0405446846612]], diagnostics: { maxGrade: 0.39501155406641003, maxConstraintDeficit: 0.002040069183337323, maxCrossfall: 0.27949754719643494, iterations: 1500, vertices: 350, triangles: 552, constraints: 27893 } };

// src/harbour/mountain/generated/awning-landing.json
var awning_landing_default = { note: "Generated by scripts/generate-mountain-landings.mjs. Shared native and Horizon contour return; original first rail preserved.", sourceSha256: "f06b728d3aa9ddec9440ebe52d1cad073cda66f0fb84a640ab0936d974bbf6a4", terrainSha256: "16e7a64647985f0a6bc5d90e91ba7b5311b5a9a2732f712934befaf0a9a6fd77", horizonTerrainSha256: "0dc23c32ca9af9d39f1719fecc5bd7b2f1017562af0f7b2c1bfa046cb44b0c76", inputSha256: "c56094181a51ec31d8d4868c6890aad215006eb4a396258f760225455052ba4a", awningEntrySha256: "3b4db9f4c522ac4161a2a09c3762cfbe50a499ff6d09a361cd3974c15d005a16", entryPreservedFromRow: 5, solverSha256: "4bff825f5384fa8edfd8629c0b8e0877ece7326350f3222f52f893eaf8fe411e", exit: 252, lockedRows: 9, rows: [[[35.17027395085206, 17.5750592956884, -101.45725292961019], [35.884288306174675, 17.64569886531468, -101.22772406346647], [36.59830266149729, 17.716643745269746, -100.99819519732274], [37.31231701681991, 17.788386803958762, -100.76866633117902], [38.02633137214253, 17.86162132035271, -100.5391374650353]], [[34.864691699876985, 17.54607474980831, -100.50653151175644], [35.577071992742894, 17.615969961400427, -100.27198019895627], [36.2894522856088, 17.68687734400501, -100.0374288861561], [37.00183257847471, 17.75940132816344, -99.80287757335594], [37.71421287134062, 17.834883275619703, -99.56832626055578]], [[34.54992389418996, 17.516856870678957, -99.57264421075985], [35.258512699801386, 17.586519902241644, -99.3268762214647], [35.967101505412806, 17.655239930752764, -99.08110823216956], [36.675690311024226, 17.728050913429822, -98.83534024287441], [37.38427911663565, 17.804886285658572, -98.58957225357926]], [[34.22261367698713, 17.487483948356562, -98.6546698870687], [34.925346232618644, 17.55542848828295, -98.39262608299083], [35.62807878825016, 17.62194046266473, -98.13058227891297], [36.33081134388167, 17.694124257233604, -97.8685384748351], [37.033543899513184, 17.76998953139119, -97.60649467075723]], [[33.88615697461376, 17.45717117464514, -97.7877520101252], [34.574077094674514, 17.522489940687674, -97.48897800118935], [35.261997214735274, 17.58778530623278, -97.19020399225352], [35.949917334796034, 17.656106331059178, -96.89142998331768], [36.637837454856786, 17.729529119662995, -96.59265597438183]], [[33.531675598352756, 17.68656601983504, -97.04136127326798], [34.17836987139205, 17.68656601983504, -96.66151062206652], [34.82506414443134, 17.68656601983504, -96.28165997086504], [35.471758417470625, 17.68656601983504, -95.90180931966356], [36.11845269050992, 17.68656601983504, -95.52195866846209]], [[33.038632298754465, 17.55442502311574, -96.34992363463626], [33.64139813733094, 17.55442502311574, -95.90363522581836], [34.244163975907405, 17.55442502311574, -95.45734681700047], [34.84692981448387, 17.55442502311574, -95.01105840818258], [35.449695653060346, 17.55442502311574, -94.56476999936469]], [[32.38228086243011, 17.3963917515904, -95.50087897405831], [33.00356330848888, 17.3963917515904, -95.08075027684846], [33.62484575454764, 17.3963917515904, -94.66062157963863], [34.24612820060641, 17.3963917515904, -94.2404928824288], [34.86741064666518, 17.3963917515904, -93.82036418521895]], [[31.71104899910801, 17.08669623447073, -94.31258562024904], [32.41431426962664, 17.08669623447073, -94.05197487741147], [33.11757954014527, 17.08669623447073, -93.79136413457388], [33.82084481066391, 17.08669623447073, -93.5307533917363], [34.524110081182535, 17.08669623447073, -93.27014264889873]], [[31.65961864793735, 17.046906786236853, -94.13704738042291], [32.27559109779564, 17.018292875081155, -93.7360449602113], [32.89156354765393, 17.031438978693526, -93.33504253999968], [33.50753599751222, 17.041833600863338, -92.93404011978805], [34.12350844737051, 17.066863828311952, -92.53303769957644]], [[31.61411212410788, 17.021863619247526, -94.0377186560097], [32.086305338056825, 16.9493943484303, -93.49418064565481], [32.558498552005766, 16.95553952602959, -92.9506426352999], [33.03069176595471, 16.955168059868146, -92.40710462494499], [33.502884979903655, 16.981314451950407, -91.8635666145901]], [[31.51245652532581, 16.98776311419787, -93.93784217622641], [31.822700100915327, 16.868375088184393, -93.30477509936533], [32.132943676504844, 16.858901876753762, -92.67170802250425], [32.44318725209436, 16.831646297879615, -92.03864094564317], [32.75343082768388, 16.836075221231432, -91.40557386878208]], [[31.277483766015596, 16.920560577262076, -93.81966372135875], [31.466679253529826, 16.76111216555335, -93.15610884984905], [31.655874741044055, 16.741357526796108, -92.49255397833934], [31.845070228558285, 16.685108473248807, -91.82899910682964], [32.03426571607251, 16.661067356908614, -91.16544423531994]], [[30.915918402898008, 16.814129204625054, -93.7076012339674], [31.037194017076047, 16.62746121981254, -93.04358525117351], [31.158469631254086, 16.60289868009521, -92.37956926837961], [31.279745245432125, 16.523879005616926, -91.71555328558571], [31.401020859610163, 16.47648284144797, -91.05153730279183]], [[30.466053922401684, 16.68411854016265, -93.6058751643429], [30.560306223445746, 16.52176142141457, -92.95263975214611], [30.654558524489808, 16.44356844520551, -92.29940433994933], [30.74881082553387, 16.35033733928224, -91.64616892775256], [30.84306312657793, 16.288503445454023, -90.99293351555576]], [[29.956334157279773, 16.522255633631886, -93.50186057649832], [30.052932337605718, 16.389015236827824, -92.86413509358445], [30.149530517931662, 16.263399481643372, -92.22640961067059], [30.246128698257607, 16.165884842538134, -91.58868412775672], [30.34272687858355, 16.09897965135495, -90.95095864484286]], [[29.404213755808556, 16.376216862616303, -93.37699072522942], [29.52539266600429, 16.227700973151176, -92.75875478990717], [29.646571576200024, 16.086216862616304, -92.14051885458493], [29.76775048639576, 15.990559941332162, -91.52228291926268], [29.888929396591493, 15.927532134185025, -90.90404698394043]], [[28.823258131662055, 16.20653458868724, -93.21081788117598], [28.98647202624078, 16.04334048860484, -92.61787081387871], [29.1496859208195, 15.916534588687243, -92.02492374658142], [29.31289981539822, 15.8212894029074, -91.43197667928413], [29.476113709976946, 15.769514337107575, -90.83902961198686]], [[28.229565312406372, 16.0226464755783, -92.98360232654917], [28.447381346865377, 15.86475027257574, -92.424535089866], [28.665197381324383, 15.739711386933449, -91.86546785318284], [28.883013415783388, 15.657489649821821, -91.30640061649967], [29.100829450242394, 15.621426828791103, -90.7473333798165]], [[27.746236911853877, 15.857995809752724, -92.78204426966467], [27.97297051504228, 15.713140430124154, -92.22661731814259], [28.199704118230684, 15.567995809752725, -91.67119036662052], [28.426437721419088, 15.472615588677037, -91.11576341509844], [28.65317132460749, 15.431376515209525, -90.56033646357636]], [[27.262908511301383, 15.69955343070545, -92.58048621278016], [27.498559683219185, 15.594706838706296, -92.02869954641918], [27.734210855136986, 15.409553430705449, -91.4769128800582], [27.969862027054788, 15.293088057524495, -90.92512621369721], [28.20551319897259, 15.242403742281791, -90.37333954733623]], [[26.792395646374047, 15.581726233050624, -92.37495019732816], [27.032187979210796, 15.456626074568566, -91.8249690813918], [27.271980312047553, 15.291726233050623, -91.27498796545544], [27.511772644884303, 15.120322371593701, -90.72500684951906], [27.751564977721056, 15.050918267080641, -90.17502573358269]], [[26.32188278144671, 15.443544575707627, -92.16941418187618], [26.565816275202412, 15.298284626026774, -91.62123861636442], [26.809749768958117, 15.153544575707626, -91.07306305085267], [27.05368326271382, 15.008821126393663, -90.52488748534091], [27.297616756469523, 14.86378204617068, -89.97671191982916]], [[25.85533817828322, 15.285008032852236, -91.95798645936904], [26.102826135218457, 15.195338833929906, -91.41142037320951], [26.350314092153692, 14.995008032852239, -90.86485428704998], [26.597802049088926, 14.877153725436322, -90.31828820089046], [26.845290006024165, 14.76887400282404, -89.77172211473093]], [[25.388793575119728, 15.209213003492696, -91.7465587368619], [25.6398359952345, 15.07960393103936, -91.2016021300546], [25.890878415349267, 14.957752330933953, -90.6566455232473], [26.141920835464035, 14.875797458116812, -90.11168891644002], [26.392963255578806, 14.802607295834402, -89.56673230963271]], [[24.92440393883931, 15.167961096037814, -91.52912945774305], [25.179229341833803, 15.068903243488082, -90.98594757902337], [25.434054744828302, 14.983945005068698, -90.4427657003037], [25.688880147822793, 14.905476091807737, -89.89958382158402], [25.943705550817292, 14.83261370916891, -89.35640194286434]], [[24.46001430255889, 15.184139310230774, -91.3117001786242], [24.71862268843311, 15.090766887753984, -90.77029302799215], [24.977231074307333, 15.007665079748884, -90.22888587736009], [25.235839460181555, 14.931074611666096, -89.68747872672802], [25.494447846055778, 14.855601954707678, -89.14607157609596]], [[23.996265885122398, 15.194623204212482, -91.08573837493168], [24.260023783395567, 15.10769524251662, -90.54685165114915], [24.52378168166873, 15.027902357268578, -90.00796492736663], [24.7875395799419, 14.949655930397423, -89.46907820358409], [25.051297478215062, 14.881010268097949, -88.93019147980155]], [[23.53251746768591, 15.205107098194194, -90.85977657123917], [23.80142487835802, 15.123240354112724, -90.32341027430616], [24.07033228903013, 15.043080363638653, -89.78704397737316], [24.33923969970224, 14.968722041285163, -89.25067768044016], [24.60814711037435, 14.90641858148822, -88.71431138350715]], [[23.0748701904049, 15.213653773941488, -90.62381641798879], [23.348443878826334, 15.133273184537588, -90.0898408123187], [23.622017567247767, 15.057159479157974, -89.5558652066486], [23.895591255669196, 14.988717719780704, -89.02188960097851], [24.169164944090625, 14.929757578120237, -88.4879139953084]], [[22.617222913123896, 15.220037651914476, -90.38785626473842], [22.895462879294648, 15.143306014962452, -89.85627135033123], [23.1737028454654, 15.071238594677293, -89.32468643592404], [23.45194281163615, 15.00871339827624, -88.79310152151685], [23.730182777806903, 14.947113222776448, -88.26151660710966]], [[22.166412086787204, 15.224590804054378, -90.14838401523454], [22.447326401093616, 15.152682409748055, -89.61821612870064], [22.72824071540003, 15.084724606366555, -89.08804824216675], [23.009155029706445, 15.026859521910051, -88.55788035563286], [23.290069344012856, 14.964056679928783, -88.02771246909896]], [[21.71560126045051, 15.22914395619428, -89.90891176573065], [21.999189922892583, 15.162058804533656, -89.38016090707005], [22.28277858533466, 15.098210618055814, -88.85141004840946], [22.56636724777674, 15.040264305511247, -88.32265918974888], [22.849955910218814, 14.98100013708112, -87.79390833108828]], [[21.269934265260098, 15.233257105412397, -89.66759901583515], [21.554574732331517, 15.17100286747572, -89.13941497885034], [21.83921519940294, 15.11130860379135, -88.61123094186553], [22.123855666474363, 15.052263168950155, -88.08304690488072], [22.408496133545782, 14.995378224274516, -87.5548628678959]], [[20.824267270069683, 15.235403514936117, -89.42628626593967], [21.10995954177045, 15.176772318324797, -88.89866905063064], [21.39565181347122, 15.120549077042428, -88.37105183532161], [21.681344085171986, 15.0632758323265, -87.84343462001257], [21.967036356872754, 15.008592195620777, -87.31581740470355]]], points: [[36.59830266149729, 17.716643745269746, -100.99819519732274], [36.2894522856088, 17.68687734400501, -100.0374288861561], [35.967101505412806, 17.655239930752764, -99.08110823216956], [35.62807878825016, 17.62194046266473, -98.13058227891297], [35.261997214735274, 17.58778530623278, -97.19020399225352], [34.82506414443134, 17.68656601983504, -96.28165997086504], [34.244163975907405, 17.55442502311574, -95.45734681700047], [33.62484575454764, 17.3963917515904, -94.66062157963863], [33.11757954014527, 17.08669623447073, -93.79136413457388], [32.89156354765393, 17.031438978693526, -93.33504253999968], [32.558498552005766, 16.95553952602959, -92.9506426352999], [32.132943676504844, 16.858901876753762, -92.67170802250425], [31.655874741044055, 16.741357526796108, -92.49255397833934], [31.158469631254086, 16.60289868009521, -92.37956926837961], [30.654558524489808, 16.44356844520551, -92.29940433994933], [30.149530517931662, 16.263399481643372, -92.22640961067059], [29.646571576200024, 16.086216862616304, -92.14051885458493], [29.1496859208195, 15.916534588687243, -92.02492374658142], [28.665197381324383, 15.739711386933449, -91.86546785318284], [28.199704118230684, 15.567995809752725, -91.67119036662052], [27.734210855136986, 15.409553430705449, -91.4769128800582], [27.271980312047553, 15.291726233050623, -91.27498796545544], [26.809749768958117, 15.153544575707626, -91.07306305085267], [26.350314092153692, 14.995008032852239, -90.86485428704998], [25.890878415349267, 14.957752330933953, -90.6566455232473], [25.434054744828302, 14.983945005068698, -90.4427657003037], [24.977231074307333, 15.007665079748884, -90.22888587736009], [24.52378168166873, 15.027902357268578, -90.00796492736663], [24.07033228903013, 15.043080363638653, -89.78704397737316], [23.622017567247767, 15.057159479157974, -89.5558652066486], [23.1737028454654, 15.071238594677293, -89.32468643592404], [22.72824071540003, 15.084724606366555, -89.08804824216675], [22.28277858533466, 15.098210618055814, -88.85141004840946], [21.83921519940294, 15.11130860379135, -88.61123094186553], [21.39565181347122, 15.120549077042428, -88.37105183532161]], diagnostics: { maxGrade: 0.3950000000000521, maxConstraintDeficit: 0.001713177341569505, maxCrossfall: 0.2900000000000009, iterations: 6e3, vertices: 175, triangles: 272, constraints: 20694, fixedRoadCrests: [{ row: 24, column: 4, gradeDropPerMetre: 0.014984513167029714 }, { row: 25, column: 2, gradeDropPerMetre: 0.00971809809217543 }, { row: 25, column: 3, gradeDropPerMetre: 0.016305165264429083 }, { row: 25, column: 4, gradeDropPerMetre: 0.02852086534781852 }, { row: 26, column: 0, gradeDropPerMetre: 0.0218304869465088 }, { row: 26, column: 1, gradeDropPerMetre: 0.0192487600252611 }, { row: 26, column: 2, gradeDropPerMetre: 0.013687062214536637 }, { row: 26, column: 3, gradeDropPerMetre: 0.027853088278694555 }, { row: 26, column: 4, gradeDropPerMetre: -0.010521286625351471 }, { row: 27, column: 0, gradeDropPerMetre: -20754693749865587e-30 }, { row: 27, column: 1, gradeDropPerMetre: 0.005315279962454755 }, { row: 27, column: 2, gradeDropPerMetre: 0.01988531982662541 }, { row: 27, column: 3, gradeDropPerMetre: -0.0019495278620136486 }, { row: 27, column: 4, gradeDropPerMetre: -2012960457074944e-30 }, { row: 28, column: 0, gradeDropPerMetre: 0.007225570800473234 }, { row: 28, column: 1, gradeDropPerMetre: 0.021155090739738258 }, { row: 28, column: 2, gradeDropPerMetre: 0.004319921361202457 }, { row: 28, column: 3, gradeDropPerMetre: -0.003656179795788063 }, { row: 28, column: 4, gradeDropPerMetre: 0.00869952525310908 }, { row: 29, column: 0, gradeDropPerMetre: 0.008157861572190278 }, { row: 29, column: 1, gradeDropPerMetre: 4969449442488016e-31 }, { row: 29, column: 2, gradeDropPerMetre: 8040644255881746e-30 }, { row: 29, column: 3, gradeDropPerMetre: 15318836185364837e-30 }, { row: 29, column: 4, gradeDropPerMetre: 0.02452584240965596 }, { row: 30, column: 0, gradeDropPerMetre: 0.006785506615401102 }, { row: 30, column: 1, gradeDropPerMetre: 0.0023750088176369795 }, { row: 30, column: 2, gradeDropPerMetre: 0.0023315620260955998 }, { row: 30, column: 3, gradeDropPerMetre: 0.007728313528830655 }, { row: 30, column: 4, gradeDropPerMetre: 0.0022976247982916982 }, { row: 31, column: 0, gradeDropPerMetre: 336431855643922e-30 }, { row: 31, column: 1, gradeDropPerMetre: 6898674836276451e-30 }, { row: 31, column: 2, gradeDropPerMetre: 69813369260767886e-31 }, { row: 31, column: 3, gradeDropPerMetre: 0.01886049452058656 }, { row: 31, column: 4, gradeDropPerMetre: -849328262600808e-29 }, { row: 32, column: 0, gradeDropPerMetre: 0.0015801470429814143 }, { row: 32, column: 1, gradeDropPerMetre: 0.0015559726960306208 }, { row: 32, column: 2, gradeDropPerMetre: 0.0015250881046981284 }, { row: 32, column: 3, gradeDropPerMetre: 0.005755841641416658 }, { row: 32, column: 4, gradeDropPerMetre: 0.010712184226851012 }, { row: 33, column: 0, gradeDropPerMetre: 0.007657125547303467 }, { row: 33, column: 1, gradeDropPerMetre: 0.012418230036000101 }, { row: 33, column: 2, gradeDropPerMetre: 0.015161123114974716 }, { row: 33, column: 3, gradeDropPerMetre: 0.003894475116146989 }, { row: 33, column: 4, gradeDropPerMetre: 0.004618967205967043 }], roadFieldDifferenceAtVertices: 0.04601726296146147 } };

// src/harbour/mountain/course.ts
var MOUNTAIN_ROAD = (() => {
  const S = MOUNTAIN_ROAD_LINE.samples, out = [];
  for (let i2 = 0; i2 < S.length; i2 += 3) out.push(S[i2].at);
  if (out[out.length - 1] !== S[S.length - 1].at) out.push(S[S.length - 1].at);
  return out;
})();
var ROAD_PLAN_S = arcLengths(MOUNTAIN_ROAD, true);
var TOWN_LANE_PLAN = [[-26.5, -34], [-26.5, -22], [-26, -10], [-24.5, 2], [-21, 13], [-16, 22], [-10.5, 27.5], [-4, 27], [3, 24], [10, 25], [16, 30.5], [20.5, 38], [23.5, 45], [30, 50.4], [38, 52.2], [45, 53.6]];
var TOWN_LANE_HALF_WIDTH = 3.5;
var riverDistance = (x2, z) => {
  let best = Infinity;
  for (let i2 = 1; i2 < RIVER.length; i2++) {
    const a = RIVER[i2 - 1], b = RIVER[i2];
    if (a[2] < -40) continue;
    const dx = b[0] - a[0], dz = b[2] - a[2], l = dx * dx + dz * dz, t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / (l || 1)));
    best = Math.min(best, Math.hypot(x2 - a[0] - dx * t, z - a[2] - dz * t));
  }
  return best;
};
var CHANNEL_REACH = 6.2;
var TOWN_RACE_ROAD = (() => {
  const foot = MOUNTAIN_ROAD[0], plan2 = [[foot[0], foot[1], foot[2]], ...TOWN_LANE_PLAN.map(([x2, z]) => [x2, islandHeight(x2, z) + 0.06, z])];
  const curve2 = authorCurve(plan2, 1.5, 0).points;
  return curve2.map((p, i2) => i2 === 0 ? foot : [p[0], islandHeight(p[0], p[2]), p[2]]);
})();
var deckRange = (() => {
  let k = 0, best = Infinity;
  TOWN_RACE_ROAD.forEach((p, i2) => {
    const d = riverDistance(p[0], p[2]);
    if (i2 > 0 && d < best) {
      best = d;
      k = i2;
    }
  });
  let i0 = k, i1 = k;
  while (i0 > 1 && riverDistance(TOWN_RACE_ROAD[i0 - 1][0], TOWN_RACE_ROAD[i0 - 1][2]) < CHANNEL_REACH) i0--;
  while (i1 < TOWN_RACE_ROAD.length - 1 && riverDistance(TOWN_RACE_ROAD[i1 + 1][0], TOWN_RACE_ROAD[i1 + 1][2]) < CHANNEL_REACH) i1++;
  return { i0: i0 - 1, i1: i1 + 1, k };
})();
var TOWN_LANE_DECK = TOWN_RACE_ROAD.slice(deckRange.i0, deckRange.i1 + 1);
var CANAL_BRIDGE = {
  id: "canal-bridge",
  name: "Canal bridge",
  type: "masonry",
  at: TOWN_RACE_ROAD[deckRange.k],
  span: arcLengths(TOWN_LANE_DECK, true).at(-1),
  halfWidth: TOWN_LANE_HALF_WIDTH,
  a: TOWN_LANE_DECK[0],
  b: TOWN_LANE_DECK[TOWN_LANE_DECK.length - 1]
};
var finishIndex = TOWN_RACE_ROAD.findIndex((p) => p[0] >= 20);
var RACE_FINISH = (() => {
  const at = TOWN_RACE_ROAD[finishIndex], next = TOWN_RACE_ROAD[finishIndex + 1], dx = next[0] - at[0], dz = next[2] - at[2], l = Math.hypot(dx, dz) || 1, heading = [dx / l, dz / l];
  const b = at[0] * heading[0] + at[2] * heading[1], c = at[0] * at[0] + at[2] * at[2] - 73.2 * 73.2, runout = -b + Math.sqrt(b * b - c);
  return { at, heading, runout, laneRunout: arcLengths(TOWN_RACE_ROAD.slice(finishIndex)).at(-1) };
})();
var MOUNTAIN_COURSE_POINTS = [...[...MOUNTAIN_ROAD].reverse(), ...TOWN_RACE_ROAD.slice(1, finishIndex + 1)];
var COURSE_S = arcLengths(MOUNTAIN_COURSE_POINTS);
var MOUNTAIN_COURSE_LENGTH = COURSE_S[COURSE_S.length - 1];
var roadCount = MOUNTAIN_ROAD.length;
var courseIndexAt = (uphillPlanS) => {
  let best = 0, d = Infinity;
  ROAD_PLAN_S.forEach((s, i2) => {
    const e = Math.abs(s - uphillPlanS);
    if (e < d) {
      d = e;
      best = i2;
    }
  });
  return roadCount - 1 - best;
};
var townIndex = (x2, z) => {
  let best = roadCount, d = Infinity;
  for (let i2 = roadCount; i2 < MOUNTAIN_COURSE_POINTS.length; i2++) {
    const p = MOUNTAIN_COURSE_POINTS[i2], e = Math.hypot(p[0] - x2, p[2] - z);
    if (e < d) {
      d = e;
      best = i2;
    }
  }
  return best;
};
function branch(id, name, kind, material, halfWidth, entry, exit, parts, even = false) {
  const a = MOUNTAIN_COURSE_POINTS[entry], b = MOUNTAIN_COURSE_POINTS[exit];
  const way = [a, ...parts.flatMap((p) => p.via), b];
  const pts = authorCurve(way, 1, 6).points;
  pts[0] = a;
  pts[pts.length - 1] = b;
  if (even) {
    const rampEnd = parts[0].via[parts[0].via.length - 1];
    let j0 = 0, best = Infinity;
    pts.forEach((p, k) => {
      const e = Math.hypot(p[0] - rampEnd[0], p[2] - rampEnd[2]);
      if (e < best) {
        best = e;
        j0 = k;
      }
    });
    const L = arcLengths(pts, true), y0 = pts[j0][1], span = L[L.length - 1] - L[j0];
    pts.forEach((p, i2) => {
      if (i2 > j0 && i2 < pts.length - 1) pts[i2] = [p[0], mix3(y0, b[1], (L[i2] - L[j0]) / span), p[2]];
    });
  }
  if (id === "hearth-awning") for (let i2 = 1; i2 < pts.length - 1; i2++) {
    const p = pts[i2], a2 = pts[i2 - 1], b2 = pts[i2 + 1], dx = b2[0] - a2[0], dz = b2[2] - a2[2], l = Math.hypot(dx, dz) || 1;
    const top = Math.max(...[-1, 0, 1].map((side) => mountainGround(p[0] + dz / l * halfWidth * side, p[2] - dx / l * halfWidth * side)));
    pts[i2] = [p[0], Math.max(p[1], top + 0.03), p[2]];
  }
  const repaired = id === "library-balcony" || id === "dam-promenade", raw = pts.map((p) => [...p]);
  const authoredLanding = repaired ? repairBranchLanding(raw, halfWidth, MOUNTAIN_ROAD_LINE.samples, id === "library-balcony" ? 0.36 : 0.39) : void 0;
  const generated = library_landing_default;
  const landing = id === "library-balcony" && generated ? generated : id === "dam-promenade" && authoredLanding ? repairDamEntry(authoredLanding, MOUNTAIN_ROAD_LINE.samples) : authoredLanding, rows = landing?.rows;
  if (landing) for (let i2 = 1; i2 < pts.length - 1; i2++) pts[i2] = landing.points[i2];
  const segments = [];
  let cursor = 0;
  for (const part of parts) {
    const end = part.via[part.via.length - 1];
    let j = cursor;
    let best = Infinity;
    for (let k = cursor; k < pts.length; k++) {
      const e = Math.hypot(pts[k][0] - end[0], pts[k][2] - end[2]);
      if (e < best) {
        best = e;
        j = k;
      }
    }
    segments.push({ kind: part.kind, points: pts.slice(cursor, j + 1) });
    cursor = j;
  }
  segments.push({ kind: "landing", points: pts.slice(cursor) });
  if (rows) {
    let start = 0;
    for (const seg of segments) {
      seg.landingRows = rows.slice(start, start + seg.points.length);
      start += seg.points.length - 1;
    }
  }
  const points = pts.map((p) => [p[0], p[1], p[2]]);
  points[0] = a;
  points[points.length - 1] = b;
  return { id, name, kind, entry, exit, halfWidth, material, points, segments, branchLength: arcLengths(points).at(-1), roadLength: COURSE_S[exit] - COURSE_S[entry], ...rows ? { landingRows: rows } : {} };
}
var damArc = (from, to, y0, y1, radius, n = 8) => Array.from({ length: n }, (_, k) => {
  const t = (k + 0.5) / n, a = mix3(from, to, t);
  return [DAM.centre[0] + Math.sin(a) * radius, mix3(y0, y1, t), DAM.centre[2] + Math.cos(a) * radius];
});
var LIBRARY_DEPARTURE = BRANCH_DEPARTURES.find((d) => d.id === "library-balcony");
var SKILL_BRANCHES = [
  // Dam maintenance rail: off Reservoir Heights, down the glass face's downstream rail, then a short deck
  // that drops onto the metal-and-glass bridge from its upstream side.
  branch("dam-promenade", "Dam maintenance rail", "rail", "metal", 1.7, courseIndexAt(roadTagS("reservoir") + 13), courseIndexAt(roadTagS("b3-west") + 10), [
    { kind: "ramp", via: [[44, 90.9, -248], [37, 90.6, -240.5]] },
    { kind: "rail", via: damArc(DAM.halfAngle * 0.92, -0.72, 87.6, 73.4, DAM.radius + 2.2, 10) },
    { kind: "deck", via: [[-14, 72, -229], [-18, 71, -225.5]] }
  ], true),
  // Library roof line: off the woodland bridge onto the reading-room roof and balcony, down to the east bend.
  // It leaves the bridge head through the opening in the right rail (`BRANCH_DEPARTURES`).
  branch("library-balcony", "Library roof and balcony", "balcony", "wood", LIBRARY_DEPARTURE.halfWidth, courseIndexAt(LIBRARY_DEPARTURE.planS), courseIndexAt(roadTagS("library") - 31), [
    { kind: "ramp", via: [LIBRARY_DEPARTURE.toward] },
    { kind: "deck", via: [[45, 41.35, -181.4], [56, 41.1, -180.4]] },
    // The landing follows the contour outside the reading room before descending. Lowering the
    // old straight ramp alone would cut through the library's roof. This adds about 8 m of run.
    { kind: "deck", via: [[61, 41.1, -179.5]] },
    { kind: "ramp", via: [[68, 39, -176], [75, 36.8, -173.5], [82, 34.5, -173.5], [89, 32.5, -170]] }
  ]),
  // Neighbourhood awnings: across the inside of the second hairpin on awnings and a ramp, back onto the leg above town.
  branch("hearth-awning", "Neighbourhood awnings", "awning", "wood", 1.5, courseIndexAt(roadTagS("hearth") - 16), courseIndexAt(roadTagS("hairpin-2") - 16), [
    { kind: "deck", via: [[35, 17.9, -96.6]] },
    { kind: "rail", via: [[33, 17.1, -93.4]] },
    { kind: "deck", via: [[33.6, 16, -90]] },
    { kind: "ramp", via: [[36.6, 14.4, -86.4]] }
  ])
].map((br) => {
  const generated = awning_landing_default;
  if (br.id !== "hearth-awning" || !generated) return br;
  const { points, rows, exit } = generated;
  const ranges = [[0, 5, "deck"], [5, 8, "rail"], [8, 18, "deck"], [18, 28, "ramp"], [28, points.length - 1, "landing"]];
  const segments = ranges.map(([a, b, kind]) => ({ kind, points: points.slice(a, b + 1), landingRows: rows.slice(a, b + 1) }));
  return { ...br, exit, points, segments, landingRows: rows, branchLength: arcLengths(points).at(-1), roadLength: COURSE_S[exit] - COURSE_S[br.entry] };
});
var gateAt = (index, id, name, segment2, halfWidth = 5.3) => {
  const all = MOUNTAIN_COURSE_POINTS, at = all[index], next = all[Math.min(index + 1, all.length - 1)], prev = all[Math.max(0, index - 1)], dx = next[0] - prev[0], dz = next[2] - prev[2], d = Math.hypot(dx, dz) || 1;
  return { id, at, normal: [dx / d, dz / d], halfWidth, halfHeight: 2.4, name, segment: segment2, height: 4.4 };
};
var G = (uphill) => courseIndexAt(uphill);
var GATE_PLAN = [
  [0, "start", "Summit start", "summit-start"],
  [G(roadTagS("summit") - 60), "alpine-1", "Alpine bends \xB7 crown", "alpine-bends"],
  [G(roadTagS("high-terrace")), "alpine-2", "Alpine bends \xB7 high terrace", "alpine-bends"],
  [G(roadTagS("reservoir") + 36), "alpine-3", "Alpine bends \xB7 Reservoir Heights", "alpine-bends"],
  [G(roadTagS("reservoir") + 21), "dam-overlook", "Dam overlook", "dam-overlook"],
  [G(roadTagS("b3-west") - 24), "meadow-1", "Meadow sweep \xB7 upper terrace", "meadow-sweep"],
  [G(roadTagS("clearing") + 30), "meadow-2", "Meadow sweep \xB7 the turn", "meadow-sweep"],
  [G(roadTagS("clearing") - 40), "meadow-3", "Meadow sweep \xB7 lower terrace", "meadow-sweep"],
  [G((roadTagS("b2-east") + roadTagS("b2-west")) / 2), "woodland-bridge", "Woodland bridge", "woodland-bridges"],
  [G(roadTagS("library") - 36), "library", "Library Woods", "library-balcony"],
  [G(roadTagS("shelf") + 2), "east-arm", "East arm sweep", "neighbourhood-switchbacks"],
  [G(roadTagS("hearth") + 17), "hearth", "Hearth Terrace", "neighbourhood-switchbacks"],
  [G(roadTagS("hairpin-2") - 24), "switchback-2", "Second switchback", "neighbourhood-switchbacks"],
  [G(roadTagS("hairpin-1") - 6), "switchback-1", "First switchback", "neighbourhood-switchbacks"],
  [roadCount - 1, "road-foot", "Road foot", "town-canal-crossing", 4.4],
  [townIndex(CANAL_BRIDGE.at[0], CANAL_BRIDGE.at[2]), "canal", "Canal bridge", "town-canal-crossing", 4.4],
  [MOUNTAIN_COURSE_POINTS.length - 1, "finish", "Quay finish", "waterfront-finish", 4.6]
];
var MOUNTAIN_GATES = GATE_PLAN.map(([i2, id, name, segment2, hw]) => gateAt(i2, `mountain-gate-${id}`, name, segment2, hw));
var MOUNTAIN_RACE_SEGMENTS = (() => {
  const order = ["summit-start", "alpine-bends", "dam-overlook", "meadow-sweep", "woodland-bridges", "library-balcony", "neighbourhood-switchbacks", "town-canal-crossing", "waterfront-finish"];
  const names = { "summit-start": "Summit start", "alpine-bends": "Alpine bends", "dam-overlook": "Dam overlook", "meadow-sweep": "Meadow sweep", "woodland-bridges": "Woodland bridges", "library-balcony": "Library balcony", "neighbourhood-switchbacks": "Neighbourhood switchbacks", "town-canal-crossing": "Town canal crossing", "waterfront-finish": "Waterfront finish" };
  const gates = (seg) => GATE_PLAN.filter((g2) => g2[3] === seg).map((g2) => g2[0]);
  const starts = order.map((id, k) => k === 0 ? 0 : Math.round((Math.max(...gates(order[k - 1])) + Math.min(...gates(id))) / 2));
  return order.map((id, k) => {
    const i0 = starts[k], i1 = k === order.length - 1 ? MOUNTAIN_COURSE_POINTS.length - 1 : starts[k + 1];
    return { id, name: names[id], i0, i1, s0: COURSE_S[i0], s1: COURSE_S[i1] };
  });
})();
var courseGeometry = JSON.stringify([MOUNTAIN_VERSION, CURRENT_WORLD_GEOGRAPHY, MOUNTAIN_COURSE_POINTS, MOUNTAIN_ROAD_LINE.samples.map((s) => [s.at, s.normal, s.halfWidth]), SKILL_BRANCHES.map((b) => [b.id, b.entry, b.exit, b.halfWidth, b.points, b.landingRows ?? null])]);
var courseHash = 2166136261;
for (let i2 = 0; i2 < courseGeometry.length; i2++) courseHash = Math.imul(courseHash ^ courseGeometry.charCodeAt(i2), 16777619);
var MOUNTAIN_RACE_REVISION = `${MOUNTAIN_VERSION}-${(courseHash >>> 0).toString(16)}`;
var MOUNTAIN_RACE = { id: "mountain-descent", name: "Summit to sea", detail: "Summit start, alpine bends, the dam, the meadows, the woodland bridge, the Library, the switchbacks, the canal and the quay \xB7 aim for 60\u2013120 seconds", revision: MOUNTAIN_RACE_REVISION, seconds: [75, 95, 120], points: MOUNTAIN_GATES.map((g2) => [g2.at[0], g2.at[2]]), gates: MOUNTAIN_GATES };

// src/harbour/mountain/townSquare.ts
var TOWN_RIVER = RIVER.filter((p) => p[2] > -40);
function crossing(a, b, c, d) {
  const r = [b[0] - a[0], b[1] - a[1]], s = [d[0] - c[0], d[2] - c[2]], den = r[0] * s[1] - r[1] * s[0];
  if (Math.abs(den) < 1e-9) return null;
  const t = ((c[0] - a[0]) * s[1] - (c[2] - a[1]) * s[0]) / den, u = ((c[0] - a[0]) * r[1] - (c[2] - a[1]) * r[0]) / den;
  return t >= 0 && t <= 1 && u >= 0 && u <= 1 ? [a[0] + r[0] * t, a[1] + r[1] * t] : null;
}
var faceSquare = (x2, z) => Math.atan2(-x2, -z);
var laneCrossings = HARBOUR_LANES.flatMap((lane2) => {
  const out = [];
  for (let i2 = 1; i2 < lane2.points.length; i2++) for (let k = 1; k < TOWN_RIVER.length; k++) {
    const hit = crossing(lane2.points[i2 - 1], lane2.points[i2], TOWN_RIVER[k - 1], TOWN_RIVER[k]);
    if (hit && !out.some((o) => Math.hypot(o.at[0] - hit[0], o.at[1] - hit[1]) < 3)) out.push({ id: `culvert:${lane2.id}:${out.length}`, at: hit, kind: "culvert", span: 5, carries: lane2.id });
  }
  return out;
});
var TOWN_SQUARE = {
  /** The pedestrian square around the fountain; skating lines keep outside it. */
  plaza: { centre: [0, 0], radius: 12 },
  /** The visible financial/natural channel through town (surface water line). */
  channels: [{ id: "town-channel", points: TOWN_RIVER, halfWidth: 2.2 }],
  crossings: [
    ...laneCrossings,
    { id: CANAL_BRIDGE.id, at: [CANAL_BRIDGE.at[0], CANAL_BRIDGE.at[2]], kind: "bridge", span: CANAL_BRIDGE.span, carries: "town-race-road" },
    { id: "footbridge:outfitters", at: [-8, -5], kind: "footbridge", span: 5, carries: "path" },
    { id: "footbridge:potters-supply", at: [-8, 7.5], kind: "footbridge", span: 5, carries: "path" }
  ],
  /** The two small storefronts face the square across the channel. */
  storefronts: [
    { id: "outfitters", name: "Outfitters", at: [-15, -6], yaw: faceSquare(-15, -6), half: [2.6, 2], door: [0, 2.05], opens: "appearance" },
    { id: "potters-supply", name: "Potter\u2019s Supply", at: [-15, 8.5], yaw: faceSquare(-15, 8.5), half: [2.6, 2], door: [0, 2.05], opens: "pottery" }
  ],
  /** The four sites the moved buildings left, re-used. */
  vacated: [
    { id: "old-home", at: [-24, 26], was: "home", use: "garden", half: [6, 5] },
    { id: "old-library", at: [-28, -18], was: "library", use: "lane-garden", half: [6, 5] },
    { id: "old-glasshouse", at: [-43, 6], was: "glasshouse", use: "orchard-edge", half: [7, 6] },
    { id: "old-cottage", at: [17, 35], was: "cottage", use: "quay-widening", half: [8, 6] }
  ],
  /** The mountain road narrows to a town lane over its first samples, then the lane continues on town ground. */
  roadTaper: { points: MOUNTAIN_ROAD_LINE.samples.slice(0, 19).map((s) => s.at), halfWidths: MOUNTAIN_ROAD_LINE.samples.slice(0, 19).map((s) => s.halfWidth), lane: TOWN_RACE_ROAD, laneHalfWidth: TOWN_LANE_HALF_WIDTH },
  /** Sheltered arrival points (a canopy or porch over each). */
  arrivals: [
    { id: "arrival:road-foot", at: [-20, -38], facing: faceSquare(-20, -38), label: "Mountain road gate" },
    { id: "arrival:funicular", at: [FUNICULAR_LINE.stations[0].platform.at[0], FUNICULAR_LINE.stations[0].platform.at[2]], facing: faceSquare(FUNICULAR_LINE.stations[0].platform.at[0], FUNICULAR_LINE.stations[0].platform.at[2]), label: "Funicular" },
    { id: "arrival:gondola", at: [GONDOLA_LINE.stations[0].platform.at[0], GONDOLA_LINE.stations[0].platform.at[2]], facing: faceSquare(GONDOLA_LINE.stations[0].platform.at[0], GONDOLA_LINE.stations[0].platform.at[2]), label: "Gondola" },
    { id: "arrival:finish", at: [RACE_FINISH.at[0] + 2, RACE_FINISH.at[2] - 7], facing: faceSquare(RACE_FINISH.at[0] + 2, RACE_FINISH.at[2] - 7), label: "Quay finish" }
  ]
};
var STOREFRONT_SOLIDS = TOWN_SQUARE.storefronts.map((s) => ({ kind: "obox", id: `storefront:${s.id}`, x: s.at[0], z: s.at[1], halfX: s.half[0], halfZ: s.half[1], yaw: s.yaw, bottom: -1, top: 4.4 }));
var TOWN_STOREFRONT_APRONS = TOWN_SQUARE.storefronts.map((s) => {
  const c = Math.cos(s.yaw), n = Math.sin(s.yaw);
  return { x: s.at[0] + s.door[1] * n, z: s.at[1] + s.door[1] * c, radius: 4.5 };
});

// src/harbour/mountain/townChannel.ts
function nearestOnRoute(x2, z, points) {
  let best = Infinity, py = 0;
  for (let i2 = 1; i2 < points.length; i2++) {
    const a = points[i2 - 1], b = points[i2], dx = b[0] - a[0], dz = b[2] - a[2], l = dx * dx + dz * dz, t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / (l || 1))), d = Math.hypot(x2 - a[0] - dx * t, z - a[2] - dz * t);
    if (d < best) {
      best = d;
      py = a[1] + (b[1] - a[1]) * t;
    }
  }
  return { distance: best, point: [0, py, 0] };
}
var crossings = HARBOUR_LANES.flatMap((lane2) => lane2.points.slice(1).flatMap((b, i2) => {
  const a = lane2.points[i2];
  if (a[1] < -48 && b[1] < -48) return [];
  const distance2 = Math.min(nearestOnRoute(a[0], a[1], RIVER).distance, nearestOnRoute(b[0], b[1], RIVER).distance);
  return distance2 < 7 ? [[a, b]] : [];
}));
var aprons = [
  ...Object.values(VILLAGE_SITES).filter((s) => s.spot[1] > -48).map((s) => ({ x: s.spot[0], z: s.spot[1], radius: Math.hypot(...s.half) + 2 })),
  { x: VILLAGE_WATERFRONT.spot[0], z: VILLAGE_WATERFRONT.spot[1], radius: 6.5 },
  ...TOWN_STOREFRONT_APRONS
];
function townChannelProtection(x2, z) {
  let keep = 0;
  for (const a of aprons) keep = Math.max(keep, 1 - smooth2((Math.hypot(x2 - a.x, z - a.z) - a.radius) / 1.2));
  for (const points of crossings) keep = Math.max(keep, 1 - smooth2((distanceToTrail(x2, z, points) - 1.25) / 1.1));
  return keep;
}
function townChannelHeight(x2, z, base) {
  if (z <= -48 || z > 74) return base;
  const river = nearestOnRoute(x2, z, RIVER);
  if (river.distance >= 5.8) return base;
  const cut = (1 - smooth2((river.distance - 2.7) / 3.1)) * smooth2((z + 48) / 4) * (1 - townChannelProtection(x2, z));
  const bed = Math.min(base, river.point[1] - 0.48);
  return base + (bed - base) * cut;
}

// src/harbour/mountain/transportAll.ts
var MONORAIL_STOPS = [
  { id: "quay", name: "Waterfront", at: [0, 0.57, 58] },
  { id: "studio", name: "The Kiln", at: [20, 1.31, 20] },
  { id: "boathouse", name: "Boathouse", at: [54, 1.31, -40] },
  { id: "bank", name: "Fund bank", at: [7, 1.31, -14] },
  { id: "town", name: "The square", at: [-20, 1.31, -37] },
  { id: "hearth", name: "Hearth Terrace", at: [112, 20, -101] },
  { id: "orchard", name: "Orchard Hollow", at: [-121, 34, -137] },
  { id: "library", name: "Library Woods", at: [106, 51, -190] },
  { id: "glasshouse", name: "Glasshouse Meadows", at: [-87, 66, -208] },
  { id: "reservoir", name: "Reservoir Heights", at: [47, 83, -240] },
  { id: "summit", name: "Summit Commons", at: [-7, 110, -277] }
].map((s) => {
  const district2 = DISTRICTS.find((d) => d.id === s.id);
  return district2 ? { ...s, at: [district2.at[0] - 7, district2.at[1], district2.at[2] + 8] } : s;
});
var TRANSPORT_STOPS2 = { ...TRANSPORT_STOPS, monorail: MONORAIL_STOPS };

// src/harbour/mountain/crossings.ts
var FUNICULAR_DECK = 1;
var ROAD_DECK = 1.2;
function crossings2() {
  const out = [];
  for (const [name, line] of [["road", MOUNTAIN_ROAD_LINE], ["lane", ORCHARD_LANE_LINE]]) {
    let run = [];
    const flush = () => {
      if (!run.length) return;
      const best = run.reduce((m, r) => r.d < m.d ? r : m);
      const over = best.p[1] > best.q[1];
      out.push({
        id: `${over ? "funicular-over" : `${name}-over`}-${name}:${out.length}`,
        over: over ? "funicular" : name,
        under: over ? name : "funicular",
        at: [best.p[0], Math.min(best.p[1], best.q[1]), best.p[2]],
        overY: Math.max(best.p[1], best.q[1]),
        underY: Math.min(best.p[1], best.q[1]),
        clearance: Math.abs(best.p[1] - best.q[1]) - (over ? FUNICULAR_DECK : ROAD_DECK)
      });
      run = [];
    };
    for (const p of FUNICULAR_LINE.path) {
      let d = Infinity, q = p;
      for (const s of line.samples) {
        const e = Math.hypot(s.at[0] - p[0], s.at[2] - p[2]);
        if (e < d) {
          d = e;
          q = s.at;
        }
      }
      if (d < line.samples[0].halfWidth + 1.5) run.push({ p, q, d });
      else flush();
    }
    flush();
  }
  return out;
}
var TRANSPORT_CROSSINGS = crossings2();
var BRIDGES = [
  ...GORGE_BRIDGES.map((b) => ({ ...b, crosses: [...b.crosses, ...TRANSPORT_CROSSINGS.filter((c) => c.under === "funicular" && (b.carries === "road" || b.carries === "lane") && b.deck.some((p) => Math.hypot(p[0] - c.at[0], p[2] - c.at[2]) < 4)).map(() => "funicular")] })),
  ...TRANSPORT_CROSSINGS.filter((c) => c.over === "funicular").map((c, i2) => {
    const k = FUNICULAR_LINE.path.findIndex((p) => Math.hypot(p[0] - c.at[0], p[2] - c.at[2]) < 0.6), deck = FUNICULAR_LINE.path.slice(Math.max(0, k - 14), k + 15);
    const a = deck[0], b = deck[deck.length - 1], type = c.at[2] < -195 ? "metal-glass" : "timber";
    return {
      id: `funicular-viaduct-${i2}`,
      name: "Funicular viaduct",
      type,
      carries: "funicular",
      s0: 0,
      s1: 0,
      a,
      b,
      span: Math.hypot(b[0] - a[0], b[2] - a[2]),
      deckThickness: FUNICULAR_DECK,
      clearance: c.clearance,
      piers: [a, b].map((p) => [p[0], mountainGround(p[0], p[2]), p[2]]),
      crosses: [c.under],
      halfWidth: 1.8,
      deck
    };
  }),
  {
    id: CANAL_BRIDGE.id,
    name: CANAL_BRIDGE.name,
    type: CANAL_BRIDGE.type,
    carries: "race-lane",
    s0: 0,
    s1: 0,
    a: CANAL_BRIDGE.a,
    b: CANAL_BRIDGE.b,
    span: CANAL_BRIDGE.span,
    deckThickness: 0.5,
    clearance: 0.6,
    piers: [],
    crosses: ["town-channel"],
    halfWidth: CANAL_BRIDGE.halfWidth,
    deck: TOWN_LANE_DECK
  }
];

// src/harbour/mountain/definition.ts
var routeIndices = /* @__PURE__ */ new WeakMap();
var CELL = 16;
function routeIndex(points) {
  const cached = routeIndices.get(points);
  if (cached) return cached;
  const index = { cells: /* @__PURE__ */ new Map(), minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
  for (let i2 = 1; i2 < points.length; i2++) {
    const a = points[i2 - 1], b = points[i2];
    for (let x2 = Math.floor(Math.min(a[0], b[0]) / CELL); x2 <= Math.floor(Math.max(a[0], b[0]) / CELL); x2++) for (let z = Math.floor(Math.min(a[2], b[2]) / CELL); z <= Math.floor(Math.max(a[2], b[2]) / CELL); z++) {
      const key2 = `${x2}:${z}`, bucket = index.cells.get(key2) ?? [];
      bucket.push(i2);
      index.cells.set(key2, bucket);
      index.minX = Math.min(index.minX, x2);
      index.maxX = Math.max(index.maxX, x2);
      index.minZ = Math.min(index.minZ, z);
      index.maxZ = Math.max(index.maxZ, z);
    }
  }
  routeIndices.set(points, index);
  return index;
}
function nearestOnRoute2(x2, z, points = MOUNTAIN_ROAD) {
  let bestD = Infinity, bestI = 1, bestT = 0;
  const check = (i2) => {
    const a2 = points[i2 - 1], b2 = points[i2], dx2 = b2[0] - a2[0], dz2 = b2[2] - a2[2], l2 = dx2 * dx2 + dz2 * dz2, t = clamp3(((x2 - a2[0]) * dx2 + (z - a2[2]) * dz2) / (l2 || 1)), ex = x2 - a2[0] - dx2 * t, ez = z - a2[2] - dz2 * t, d = ex * ex + ez * ez;
    if (d < bestD) {
      bestD = d;
      bestI = i2;
      bestT = t;
    }
  };
  if (points.length < 200) {
    for (let i2 = 1; i2 < points.length; i2++) check(i2);
  } else {
    const index = routeIndex(points), cx = Math.floor(x2 / CELL), cz = Math.floor(z / CELL), limit = Math.max(Math.abs(cx - index.minX), Math.abs(cx - index.maxX), Math.abs(cz - index.minZ), Math.abs(cz - index.maxZ));
    const outside = Math.max(index.minX - cx, cx - index.maxX, index.minZ - cz, cz - index.maxZ);
    if (outside > 2) {
      for (let i2 = 1; i2 < points.length; i2++) check(i2);
    } else for (let r = 0; r <= limit; r++) {
      for (let ix = cx - r; ix <= cx + r; ix++) for (let iz = cz - r; iz <= cz + r; iz++) {
        if (r && ix !== cx - r && ix !== cx + r && iz !== cz - r && iz !== cz + r) continue;
        for (const i2 of index.cells.get(`${ix}:${iz}`) ?? []) check(i2);
      }
      const border = Math.min(x2 - (cx - r) * CELL, (cx + r + 1) * CELL - x2, z - (cz - r) * CELL, (cz + r + 1) * CELL - z);
      if (bestD < border * border) break;
    }
  }
  const a = points[bestI - 1], b = points[bestI], dx = b[0] - a[0], dz = b[2] - a[2], l = dx * dx + dz * dz;
  return { point: [mix3(a[0], b[0], bestT), mix3(a[1], b[1], bestT), mix3(a[2], b[2], bestT)], distance: Math.sqrt(bestD), index: bestI - 1, t: bestT, gradientX: (b[1] - a[1]) * dx / (l || 1), gradientZ: (b[1] - a[1]) * dz / (l || 1) };
}
var ROAD_LENGTH = MOUNTAIN_ROAD_LINE.length;
var FOOTPATHS = PATH_EDGES.map((e) => ({ id: e.id, points: e.points, kind: e.kind, halfWidth: e.halfWidth }));
function mountainBaseHeight(x2, z) {
  if (z > -48) return -0.75;
  return mountainGround(x2, z);
}
function mountainContains(x2, z) {
  if (!(z < -48 && z >= WORLD_BOUNDS.minZ && Math.abs(x2) <= WORLD_BOUNDS.maxX - 2)) return false;
  if (mountainGround(x2, z) > -0.2) return true;
  return nearestOnRoute2(x2, z).distance <= ROAD_HALF_WIDTH + 0.3 || nearestOnRoute2(x2, z, ORCHARD_LANE_LINE.samples.map((s) => s.at)).distance <= 3.5 || SKILL_BRANCHES.some((b) => nearestOnRoute2(x2, z, b.points).distance <= b.halfWidth + 0.3);
}

// src/harbour/mountain/damSolids.ts
var DAM_SOLIDS = [
  ...DAM_PARTS.abutments.map((a, i2) => {
    const yaw = (a.side === "west" ? -1 : 1) * DAM_PARTS.halfAngle * 1.04, c = Math.abs(Math.cos(yaw)), s = Math.abs(Math.sin(yaw)), hx = c * (a.size[0] / 2 + 0.4) + s * (a.size[2] / 2 + 0.4), hz = s * (a.size[0] / 2 + 0.4) + c * (a.size[2] / 2 + 0.4);
    return { id: `dam:abutment:${i2}`, min: [a.at[0] - hx, Math.min(mountainGround(a.at[0], a.at[2]), DAM_PARTS.foot) - 2, a.at[2] - hz], max: [a.at[0] + hx, DAM_PARTS.crest + 2.5, a.at[2] + hz] };
  }),
  ...Array.from({ length: 48 }, (_, i2) => {
    const a = -DAM_PARTS.halfAngle + 2 * DAM_PARTS.halfAngle * (i2 + 0.5) / 48, r = DAM_PARTS.radius, inner = r - 1.4, outer = r + 0.6 + (RESERVOIR.bottom - DAM_PARTS.foot + 2) * 0.2, x2 = DAM_PARTS.centre[0] + Math.sin(a) * (inner + outer) / 2, z = DAM_PARTS.centre[2] + Math.cos(a) * (inner + outer) / 2, radial = (outer - inner) / 2, tangent = r * DAM_PARTS.halfAngle / 48 + 0.08, hx = Math.abs(Math.sin(a)) * radial + Math.abs(Math.cos(a)) * tangent, hz = Math.abs(Math.cos(a)) * radial + Math.abs(Math.sin(a)) * tangent;
    return { id: `dam:plinth:${i2}`, min: [x2 - hx, DAM_PARTS.foot - 2, z - hz], max: [x2 + hx, RESERVOIR.bottom, z + hz] };
  })
];

// src/harbour/mountain/generated/planting-authoring-corridors.json
var planting_authoring_corridors_default = { baselineHead: "1cf76c551e6f49124b6257162bc4d36ca18d7bd1", courseSourceSha256: "7aa7a1b66ebdd2fece042b67052a7cc2bd4de32cd8408cfec934af5cceea3446", plantingSourceSha256: "37d58c29cee5c08de35b26874e18c3e31e70995da15f8e40d11dd5c82261208b", purpose: "Historical planting authoring input only. Not a route, surface, collider or runtime clearance owner.", branches: [{ id: "dam-promenade", halfWidth: 1.7, points: [[48.596662419836065, 90.4875310561927, -253.73340441205832], [47.98598956211517, 90.54355334976849, -252.9437978391803], [47.371925599377775, 90.59957564334425, -252.1568251197019], [46.75463851868366, 90.6505343265335, -251.37237809738937], [46.133594924858556, 90.69801554500442, -250.5909021441506], [45.507990916606815, 90.73917227372203, -249.81307333665865], [44.87627627035487, 90.7722657803272, -249.0402018298109], [44.23552926266533, 90.79555733246075, -248.27481006195052], [43.58337976430416, 90.80730819776349, -247.51910233873252], [42.928068103997596, 90.80799622922783, -246.7661297921688], [42.2694176186239, 90.79936015921292, -246.01607703423645], [41.60619285972045, 90.78313872007797, -245.2700672560387], [40.937231674884444, 90.75891511313156, -244.52919864041772], [40.26142280539597, 90.72235352558467, -243.79457287538338], [39.57767136345709, 90.66911814464824, -243.0673361104699], [38.88486919973785, 90.59487315753329, -242.34871904746382], [38.18186857791532, 90.49417445877495, -241.6400791559787], [37.46745823678463, 90.360947503225, -240.94294783830125], [36.739661894745865, 90.18911774573527, -240.25982243015292], [35.99277039714636, 89.88576053881161, -239.597641271271], [35.23033717342864, 89.58239834167763, -238.9533904232425], [34.45681213018789, 89.27903327183589, -238.32248515805585], [33.67545921334941, 88.97566656221201, -237.7012920825558], [32.888951692042994, 88.67229903247303, -237.0866340281115], [32.09973208430329, 88.36893107139721, -236.47545987196318], [31.31014911244055, 88.06556304663363, -235.86475487993403], [30.52286801332911, 87.76219554222214, -235.25108810588443], [29.741314751153077, 87.4588297167072, -234.63015178993408], [28.970466899095573, 87.15546818430174, -233.99599660520005], [28.219281864658615, 86.85211990912278, -233.33873473095113], [27.503101949904593, 86.54879400577329, -232.64360056190097], [26.821505023005326, 86.2454465516003, -231.91442817914688], [26.150960245347754, 85.94208085565413, -231.17499849343082], [25.450112754994766, 85.63878024318525, -230.46452549994063], [24.696750639930666, 85.33546531129325, -229.80992741911248], [23.91538445185375, 85.03211756374375, -229.18885130324566], [23.11108874612687, 84.72876960678465, -228.59776885990522], [22.28505067491649, 84.42542184217771, -228.03747440292494], [21.43822655623415, 84.12207465105622, -227.50912421725425], [20.57166734436612, 83.81872694482492, -227.0138025818509], [19.68690864877392, 83.51537835699614, -226.55176770057068], [18.785349197074463, 83.2120293277998, -226.12343647928674], [17.868191909846544, 82.90868019966389, -225.72960880066756], [16.936551776650173, 82.60533070759024, -225.37138152265223], [15.991850396861881, 82.30198021543823, -225.04916111271814], [15.035638891967794, 81.99862993335852, -224.76290097300264], [14.06929491666637, 81.69528052570985, -224.5129832118349], [13.094095083336216, 81.3919324242838, -224.30024799829542], [12.111430624649094, 81.0885843525516, -224.1252012828282], [11.122834978920556, 80.78523614255211, -223.98754101834243], [10.129750681162724, 80.48188817155507, -223.8872728437759], [9.133574641357017, 80.17854086069929, -223.82483014308224], [8.135732635741252, 79.87519373409302, -223.8008319193504], [7.137698924927475, 79.57184578640283, -223.8149276021074], [6.14090741518693, 79.26849744151305, -223.8666892800958], [5.14678718818798, 78.96514908733923, -223.9561186961334], [4.156829434410103, 78.66180087045495, -224.08361532404732], [3.17249866295798, 78.35845138045003, -224.2490633197449], [2.1951361506823788, 78.05510084601444, -224.45167004937701], [1.226137910823495, 77.75175024228072, -224.6911065412338], [0.26698484194306177, 77.44840079700299, -224.9673405065119], [-0.6808015541456732, 77.14505203985027, -225.28035207265805], [-1.6159904952537518, 76.8417032473159, -225.62920328734137], [-2.5373511416886014, 76.53835474350873, -226.01308893209796], [-3.4435030987633217, 76.23500694805315, -226.43160727928304], [-4.319766611709223, 75.93187657529323, -226.90805623186122], [-5.132751506812808, 75.62860084847583, -227.48671952812433], [-5.932767581018899, 75.32525213905048, -228.0835857280939], [-6.781869397596325, 75.02217223431067, -228.60659263047978], [-7.71260366389881, 74.71945121910028, -228.96140237279954], [-8.686350157402366, 74.41617693913224, -229.17958558745732], [-9.674038289454018, 74.1128704685225, -229.3226579697069], [-10.669205554144273, 73.80956810558939, -229.3975758624917], [-11.667116438454537, 73.50628644420912, -229.4004895097292], [-12.661373820340309, 73.20305103127711, -229.31692404020993], [-13.638325876614095, 72.89995763470677, -229.11651610796366], [-14.564597187372199, 72.59714088206701, -228.74935764471192], [-15.409196040075022, 72.29413278637696, -228.21955420192913], [-16.17239748460916, 71.99094661378066, -227.57711261279258], [-16.868980679490214, 71.68766122648647, -226.86252815772113], [-17.517883410506197, 71.38432552083964, -226.10416491251738], [-18.134931833481026, 71.08098741862133, -225.31965452316706], [-18.67423452115157, 70.77773436795158, -224.48013123343014], [-19.158363250832753, 70.47439823905867, -223.6073129710906], [-19.610260519537956, 70.17104331433785, -222.71731035094913], [-20.039825977480163, 69.86768207110045, -221.81629379882256], [-20.451650254122903, 69.56431860993695, -220.90702340770525], [-20.846708455116815, 69.2609562524938, -219.9903480853138]] }, { id: "library-balcony", halfWidth: 1.6, points: [[29.709810023081513, 40.46581209253004, -182.3313491724385], [30.69995120264122, 40.565693120792, -182.2158870794345], [31.690524314220106, 40.66557414905396, -182.10418889317043], [32.68150181226043, 40.76056981116593, -181.9961380491602], [33.67293214664924, 40.85225125670138, -181.89232649865988], [34.66491153500308, 40.93788529141812, -181.7939057907207], [35.657600307207886, 41.01581480702789, -181.70294042809635], [36.65127922525409, 41.08438269524241, -181.62360824802357], [37.64639265156153, 41.14193184777342, -181.56529620364051], [38.64261509009852, 41.18895732824048, -181.53039427714626], [39.639293925053536, 41.22659463055292, -181.5122232466896], [40.636102850370754, 41.25566031840485, -181.50316445433862], [41.632927670180926, 41.27697095549039, -181.49590747462656], [42.62969979216571, 41.291343105503664, -181.4835900984202], [43.62626458620291, 41.2995933321388, -181.46006743911215], [44.622299705468436, 41.302538199089895, -181.4201410742203], [45.61780063393343, 41.29991818409717, -181.368377395103], [46.61388298675097, 41.29193597132433, -181.32938014536327], [47.61023504920065, 41.27943210536552, -181.2978524572086], [48.606606178529894, 41.26324713081491, -181.2669209650794], [49.60279853536231, 41.24422159226661, -181.2307610923164], [50.598536980263304, 41.22237845714593, -181.18385548387562], [51.59334734536668, 41.19695960597859, -181.12038110741153], [52.586380352296686, 41.167206919290344, -181.03358793842963], [53.57609965187653, 41.131840663227955, -180.91505162973922], [54.559688546255984, 41.089262173723014, -180.75367929545135], [55.53189168029673, 41.03787278670708, -180.534354718525], [56.48243520148169, 40.97607383811175, -180.23534850592134], [57.39940874037546, 40.90153907028529, -179.84531972192792], [58.27903942838378, 40.81171920900085, -179.37685902867196], [59.12642062206089, 40.70406498003165, -178.8520242622606], [59.955783538054206, 40.576027109150964, -178.29899287360098], [60.78476657438175, 40.42505632213192, -177.74538929178325], [61.62921135178092, 40.2486033447478, -177.21579939138644], [62.49428829878477, 40.04411890277178, -176.72052585786852], [63.361455065864824, 39.8129616406503, -176.22886090175052], [64.22825658228898, 39.55927949667863, -175.73655217531604], [65.09508613092106, 39.286676973750964, -175.24429281467803], [65.96229542497339, 38.997799741570326, -174.75270285857178], [66.83022239552305, 38.695293469839825, -174.26238130409794], [67.69921563296278, 38.38180382826249, -173.7739522873834], [68.56965923212537, 38.05997648654141, -173.28811319027332], [69.44200169951831, 37.73009436645858, -172.80569266855971], [70.31673949809851, 37.390655199421836, -172.3276299407066], [71.19374746093537, 37.04124358764102, -171.85374392535078], [72.07276811941246, 36.68356605187637, -171.38360145708145], [72.95353613735223, 36.31961244916186, -170.91674023841395], [73.83569956456459, 35.951372636531424, -170.45252063284872], [74.71885104922352, 35.58083647101902, -169.9901831295891], [75.60256656292312, 35.209993809658535, -169.5289244168734], [76.4864442622454, 34.84083450948395, -169.06797650932185], [77.37030372384962, 34.47480499212822, -168.60699374403652], [78.2549684368173, 34.111984341696925, -168.14755841081393], [79.14024948248502, 33.75188496974829, -167.68931161204702], [80.02592826494968, 33.39401928784053, -167.23183395467552], [80.91189477383432, 33.03789970753184, -166.774913742459], [81.79808351415944, 32.68303864038041, -166.31842468244216], [82.68445304766001, 32.3289484979445, -165.86228676338374], [83.57097918968421, 31.975141691782287, -165.40645329267616], [84.4576413514325, 31.621334885620126, -164.95088445524593], [85.34443564205718, 31.26752807945786, -164.49557286852848], [86.23137538115633, 30.91372127329568, -164.0405446846612]] }, { id: "hearth-awning", halfWidth: 1.5, points: [[36.59830266149729, 17.716643745269746, -100.99819519732274], [36.2894522856088, 17.797750708500367, -100.0374288861561], [35.967101505412806, 17.76490257516889, -99.08110823216956], [35.62807878825016, 17.72998345273359, -98.13058227891297], [35.261997214735274, 17.690800452604417, -97.19020399225352], [34.82506414443134, 17.68656601983504, -96.28165997086504], [34.244163975907405, 17.55442502311574, -95.45734681700047], [33.62484575454764, 17.3963917515904, -94.66062157963863], [33.11757954014527, 17.08669623447073, -93.79136413457388], [32.93681922659754, 16.798303745773683, -92.80396303581037], [33.01561593502149, 16.52480880038414, -91.79985053260776], [33.26978264734275, 16.229673082841988, -90.82429528496705], [33.6553263939606, 15.921893366236345, -89.8926504971992], [34.23767742977477, 15.608743622837617, -89.07167145612615], [34.93893178878561, 15.295153731404607, -88.34627982022892], [35.655309869838284, 14.986053570696125, -87.63551870898073], [36.30868634891318, 14.685133950825742, -86.86761155442238], [36.787108841320475, 14.398539731556095, -85.98237893683957], [37.10933954214991, 14.125779956476189, -85.0264836932673], [37.36286691259505, 13.852668387512324, -84.04975414893185], [37.57565270623312, 13.599512970002479, -83.06329508138073], [37.75672050559807, 13.367730402116354, -82.07052558667942]] }] };

// src/harbour/mountain/art/land.ts
function landHeight(x2, z) {
  if (z < -48) return Math.max(islandHeight(x2, z), mountainBaseHeight(x2, z));
  const island = z < -30 ? Math.max(islandHeight(x2, z), mountainGround(x2, z)) : islandHeight(x2, z);
  return townChannelHeight(x2, z, island);
}

// src/harbour/mountain/art/spots.ts
function footGround(x2, z, yaw, hx, hz) {
  const c = Math.cos(yaw), s = Math.sin(yaw);
  let min = Infinity, max2 = -Infinity;
  for (const lx of [-hx, 0, hx]) for (const lz of [-hz, 0, hz]) {
    const y = landHeight(x2 + lx * c + lz * s, z + lz * c - lx * s);
    if (y < min) min = y;
    if (y > max2) max2 = y;
  }
  return { min, max: max2 };
}
function corridorClearance(x2, z) {
  let best = Infinity;
  for (const line of [MOUNTAIN_ROAD_LINE, ORCHARD_LANE_LINE]) for (let i2 = 0; i2 < line.samples.length; i2 += 2) {
    const s = line.samples[i2], d = Math.hypot(x2 - s.at[0], z - s.at[2]) - s.halfWidth;
    if (d < best) best = d;
  }
  for (const e of PATH_EDGES) for (let i2 = 1; i2 < e.points.length; i2++) {
    const a = e.points[i2 - 1], b = e.points[i2], dx = b[0] - a[0], dz = b[2] - a[2], l = dx * dx + dz * dz || 1, t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / l)), d = Math.hypot(x2 - a[0] - dx * t, z - a[2] - dz * t) - e.halfWidth;
    if (d < best) best = d;
  }
  for (const line of Object.values(TRANSPORT_LINES)) for (const st of line.stations) {
    const p = st.platform.at, d = Math.hypot(x2 - p[0], z - p[2]) - Math.hypot(...st.platform.half) - 0.5;
    if (d < best) best = d;
  }
  if (z > -60) for (const lane2 of HARBOUR_LANES) best = Math.min(best, distanceToTrail(x2, z, lane2.points) - 1.3);
  for (const site of Object.values(VILLAGE_SITES)) best = Math.min(best, Math.hypot(x2 - site.spot[0], z - site.spot[1]) - Math.hypot(...site.half) - 1);
  return best;
}
function riverClearance(x2, z) {
  let best = Infinity;
  for (let i2 = 1; i2 < RIVER.length; i2++) {
    const a = RIVER[i2 - 1], b = RIVER[i2], dx = b[0] - a[0], dz = b[2] - a[2], l = dx * dx + dz * dz || 1, t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / l));
    best = Math.min(best, Math.hypot(x2 - a[0] - dx * t, z - a[2] - dz * t));
  }
  return best;
}
function findSpot(cx, cz, angle, radius, half, opts = {}) {
  const level = opts.level ?? 0.55, clear = opts.clear ?? half + 0.35;
  let best = null, score = Infinity;
  for (let ring = 0; ring < 14; ring++) for (let k = 0; k < 24; k++) {
    const a = angle + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * 0.19, r = Math.max(1.5, radius + (ring % 2 ? 1 : -1) * Math.ceil(ring / 2) * 1.6), x2 = cx + Math.sin(a) * r, z = cz + Math.cos(a) * r;
    const g2 = footGround(x2, z, 0, half, half);
    if (g2.max - g2.min > level) continue;
    const c = corridorClearance(x2, z);
    if (c < clear || riverClearance(x2, z) < half + 3.2) continue;
    if (opts.near !== void 0 && c > clear + opts.near) continue;
    const s = Math.abs(r - radius) * 0.4 + Math.abs(k) * 0.15 + (g2.max - g2.min);
    if (s < score) {
      score = s;
      best = [x2, z];
    }
    if (best && ring > 2) return best;
  }
  return best ?? [cx + Math.sin(angle) * radius, cz + Math.cos(angle) * radius];
}

// src/harbour/mountain/artGeometry.ts
var box = (id, x2, z, hx, hz, y0, y1) => ({ id, min: [x2 - hx, y0, z - hz], max: [x2 + hx, y1, z + hz] });
var STATION_SOLIDS = Object.values(TRANSPORT_LINES).flatMap((line) => line.stations.flatMap((st) => {
  const p = st.platform, c = Math.cos(p.yaw), s = Math.sin(p.yaw), [hl, hw] = p.half, id = `station-art:${line.kind}:${st.id}`;
  const W2 = (along, across) => [p.at[0] + s * along + c * across, p.at[2] + c * along - s * across];
  const y = p.at[1];
  if (line.kind === "funicular") {
    const f = line.at(st.s), toTrack = Math.sign((f.at[0] - p.at[0]) * c - (f.at[2] - p.at[2]) * s) || 1, outer = -toTrack * (hw - 0.2);
    return [-hl + 0.4, 0, hl - 0.4].map((a, k) => {
      const [x2, z] = W2(a, outer);
      return box(`${id}:post:${k}`, x2, z, 0.12, 0.12, y, y + 3.2);
    });
  }
  return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, d], k) => {
    const [x2, z] = W2(a * (hl + 0.6), d * (hw + 2.2));
    return box(`${id}:post:${k}`, x2, z, 0.16, 0.16, Math.min(y, landHeight(x2, z)) - 0.2, st.at[1] + 3.1 + 1.4);
  });
}));
function districtArtClear(d, x2, z, radius = 1) {
  void d;
  return corridorClearance(x2, z) > radius + 0.4 && SKILL_BRANCHES.every((p) => nearestOnRoute2(x2, z, p.points).distance > p.halfWidth + 1 + radius);
}
function authoredDistrictFixtureClear(x2, z, radius) {
  return planting_authoring_corridors_default.branches.every((branch2) => nearestOnRoute2(x2, z, branch2.points).distance > branch2.halfWidth + 1 + radius);
}
var DISTRICT_FIXTURES = DISTRICTS.flatMap((d) => {
  const out = [];
  let seed = d.id.split("").reduce((n2, c) => n2 + c.charCodeAt(0), 17);
  const random = () => {
    seed = Math.imul(seed, 1664525) + 1013904223 >>> 0;
    return seed / 4294967296;
  };
  const kinds = d.biome === "garden" ? ["bed", "bed", "crate", "bed"] : d.biome === "orchard" ? ["crate", "bed", "crate", "logs"] : d.biome === "woods" ? ["logs", "logs", "rock"] : d.biome === "meadow" ? ["bed", "bed", "bed"] : ["rock", "rock", "rock", "rock"];
  const n = d.biome === "meadow" ? 5 : 7;
  for (let i2 = 0; i2 < n; i2++) {
    const kind = kinds[i2 % kinds.length], size2 = kind === "rock" ? 0.8 + random() * 0.9 : 1, yaw = random() * Math.PI;
    const hx = kind === "bed" ? 1.5 : kind === "logs" ? 1.05 : kind === "crate" ? 0.45 : size2, hz = kind === "bed" ? 0.75 : kind === "logs" ? 0.5 : kind === "crate" ? 0.45 : size2 * 0.8;
    const ex = Math.abs(Math.cos(yaw)) * hx + Math.abs(Math.sin(yaw)) * hz, ez = Math.abs(Math.sin(yaw)) * hx + Math.abs(Math.cos(yaw)) * hz, reach = Math.hypot(ex, ez);
    const [x2, z] = findSpot(d.at[0], d.at[2], i2 * 2.399 + random() * 0.6, d.radius * 0.7 + random() * 9, reach, { level: 0.7 });
    if (!districtArtClear(d, x2, z, reach) || !authoredDistrictFixtureClear(x2, z, reach)) continue;
    const g2 = footGround(x2, z, yaw, hx, hz), y = g2.min - 0.06;
    if (g2.max - g2.min > 0.85) continue;
    const height = kind === "rock" ? size2 * 0.9 : kind === "bed" ? 0.45 : kind === "logs" ? 0.8 : 0.7;
    const id = `district-art:${d.id}:${i2}`;
    out.push({ id, district: d.id, kind, at: [x2, y, z], size: size2, height, yaw, half: [hx, hz], solid: { id, min: [x2 - ex, y, z - ez], max: [x2 + ex, g2.max + height, z + ez] } });
  }
  return out;
});
var DISTRICT_ART_SOLIDS = DISTRICT_FIXTURES.map((f) => f.solid);
var OBSERVATORY_FORM = {
  parapet: 1.1,
  columns: 4.8,
  domeRise: 1,
  /** The telescope pier's offset from the centre (world x, z): toward the back, so the summit view looks over it. */
  pier: [0, -1.2]
};
var SUMMIT_OBSERVATORY = { at: SUMMIT_OBSERVATORY_SITE.at, radius: SUMMIT_OBSERVATORY_SITE.radius, spring: 3.75 };
var [ox, , oz] = SUMMIT_OBSERVATORY.at;
var orad = SUMMIT_OBSERVATORY.radius;
var oy = footGround(ox, oz, 0, orad, orad);
var obsDoor = DOOR_APRONS.find((a) => a.site === "observatory")?.facing ?? 0;
var pav = GOAL_PAVILION_SITE;
var pavYaw = DOOR_APRONS.find((a) => a.site === "pavilion")?.facing ?? 0;
var pc = Math.cos(pavYaw);
var ps = Math.sin(pavYaw);
var pg = footGround(pav.at[0], pav.at[2], pavYaw, pav.half[0] + 1, pav.half[1] + 1);
var PAVILION_COLUMNS = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [-1, 1], [-1, 0]].map(([a, b]) => [a * pav.half[0], b * pav.half[1]]).filter(([lx, lz]) => {
  const x2 = pav.at[0] + lx * pc + lz * ps, z = pav.at[2] + lz * pc - lx * ps;
  return SKILL_BRANCHES.every((br) => nearestOnRoute2(x2, z, br.points).distance > br.halfWidth + 0.7);
});
var SUMMIT_ART_SOLIDS = [
  // The open observatory: its parapet ring (a gateway left at the door), columns and the telescope pier.
  ...Array.from({ length: 16 }, (_, k) => k).flatMap((k) => {
    const a = (k + 0.5) / 16 * Math.PI * 2, door3 = Math.atan2(Math.cos(obsDoor), Math.sin(obsDoor)), off = Math.atan2(Math.sin(a - door3), Math.cos(a - door3));
    if (Math.abs(off) < 0.3) return [];
    return [box(`summit-art:parapet:${k}`, ox + Math.cos(a) * (orad - 0.2), oz + Math.sin(a) * (orad - 0.2), 0.55, 0.55, oy.min, oy.max + 0.15 + 1.1)];
  }),
  ...Array.from({ length: 8 }, (_, k) => {
    const a = k / 8 * Math.PI * 2 + Math.PI / 16;
    return box(`summit-art:column:${k}`, ox + Math.cos(a) * (orad - 0.2), oz + Math.sin(a) * (orad - 0.2), 0.16, 0.16, oy.min, oy.max + 0.15 + OBSERVATORY_FORM.columns);
  }),
  // The stone pier only (the mount and tube above it stay out of the way of the summit view's camera ray).
  box("summit-art:pier", ox + OBSERVATORY_FORM.pier[0], oz + OBSERVATORY_FORM.pier[1], 0.55, 0.55, oy.min, oy.max + 0.15 + 1.3),
  // The goal pavilion's columns (its floor is open between them).
  ...PAVILION_COLUMNS.map(([lx, lz], k) => box(`summit-art:pavilion:${k}`, pav.at[0] + lx * pc + lz * ps, pav.at[2] + lz * pc - lx * ps, 0.25, 0.25, pg.min, pg.max + 3.4))
];

// src/harbour/mountain/surfaces.ts
var platform = (kind, id, p) => {
  const dx = Math.sin(p.yaw) * p.half[0], dz = Math.cos(p.yaw) * p.half[0];
  return { id: `station:${kind}:${id}`, points: [[p.at[0] - dx, p.at[1], p.at[2] - dz], [p.at[0] + dx, p.at[1], p.at[2] + dz]], halfWidth: p.half[1], material: kind === "gondola" ? "metal" : "wood", walkable: true, kind: "platform" };
};
var WORLD_SURFACES = [
  // The town lane is paving on the town ground; only its canal bridge is a deck.
  { id: "town-race-road", points: TOWN_LANE_DECK, halfWidth: TOWN_LANE_HALF_WIDTH, material: "path", walkable: true, kind: "bridge" },
  { id: "mountain-road", points: MOUNTAIN_ROAD, halfWidth: ROAD_HALF_WIDTH, material: "path", walkable: true, kind: "road" },
  { id: "orchard-lane", points: ORCHARD_LANE_LINE.samples.filter((_, i2, all) => i2 % 2 === 0 || i2 === all.length - 1).map((s) => s.at), halfWidth: ORCHARD_LANE_HALF_WIDTH, material: "path", walkable: true, kind: "lane" },
  ...PATH_EDGES.filter((e) => e.kind !== "path").map((e) => ({ id: `path:${e.id}`, points: e.points, halfWidth: e.halfWidth, material: e.kind === "promenade" ? "metal" : e.kind === "bridge" ? "wood" : "path", walkable: true, kind: e.kind })),
  ...Object.values(TRANSPORT_LINES).flatMap((line) => line.stations.map((s) => platform(line.kind, s.id, s.platform))),
  ...SKILL_BRANCHES.map((b) => ({ id: b.id, points: b.points, halfWidth: b.halfWidth, material: b.material, walkable: true, kind: "branch", ...b.landingRows ? { landingRows: b.landingRows } : {} }))
];
var indices = /* @__PURE__ */ new WeakMap();
var SC = 12;
var key = (cx, cz) => (cx + 4096) * 8192 + (cz + 4096);
function surfaceIndex(surfaces) {
  const cached = indices.get(surfaces);
  if (cached) return cached;
  const cells2 = /* @__PURE__ */ new Map();
  surfaces.forEach((s, si) => {
    let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (const p of s.points) {
      x0 = Math.min(x0, p[0]);
      x1 = Math.max(x1, p[0]);
      z0 = Math.min(z0, p[2]);
      z1 = Math.max(z1, p[2]);
    }
    const r = s.halfWidth + 1;
    for (let cx = Math.floor((x0 - r) / SC); cx <= Math.floor((x1 + r) / SC); cx++) for (let cz = Math.floor((z0 - r) / SC); cz <= Math.floor((z1 + r) / SC); cz++) {
      const mx = (cx + 0.5) * SC, mz = (cz + 0.5) * SC;
      if (nearestOnRoute2(mx, mz, s.points).distance > r + SC * 0.72) continue;
      const k = key(cx, cz), b = cells2.get(k) ?? [];
      b.push(si);
      cells2.set(k, b);
    }
  });
  const index = { cells: cells2 };
  indices.set(surfaces, index);
  return index;
}
var near = (x2, z, surfaces) => surfaceIndex(surfaces).cells.get(key(Math.floor(x2 / SC), Math.floor(z / SC))) ?? [];
function onDeck(x2, z, points) {
  const p = nearestOnRoute2(x2, z, points), n = points.length;
  if (p.index === 0 && p.t === 0) {
    const a = points[0], b = points[1], dx = b[0] - a[0], dz = b[2] - a[2], l = Math.hypot(dx, dz) || 1;
    if (((x2 - a[0]) * dx + (z - a[2]) * dz) / l < -0.35) return null;
  }
  if (p.index === n - 2 && p.t === 1) {
    const a = points[n - 2], b = points[n - 1], dx = b[0] - a[0], dz = b[2] - a[2], l = Math.hypot(dx, dz) || 1;
    if (((x2 - b[0]) * dx + (z - b[2]) * dz) / l > 0.35) return null;
  }
  return p;
}
function worldDeckAt(surface, x2, z) {
  const p = onDeck(x2, z, surface.points);
  if (!p) return null;
  const junction = surface.id === "orchard-lane" ? orchardJunctionAt(x2, z) : null;
  if (junction) {
    p.point = [p.point[0], junction.y, p.point[2]];
    p.gradientX = junction.gx;
    p.gradientZ = junction.gz;
  } else if (surface.landingRows) {
    const hit = landingSample(surface.landingRows, x2, z);
    if (!hit) return null;
    p.point = [p.point[0], hit.y, p.point[2]];
    p.gradientX = hit.gx;
    p.gradientZ = hit.gz;
  }
  const widths = surface.widths, halfWidth = widths ? widths[p.index] + (widths[p.index + 1] - widths[p.index]) * p.t : surface.halfWidth;
  return { ...p, halfWidth };
}
function approachSlab(surface, p, x2, z, ground3, gy, gx, gz) {
  const pts = surface.points, n = pts.length;
  if (surface.kind !== "bridge" || n < 2) return null;
  for (const [e, f] of [[0, 1], [n - 1, n - 2]]) {
    const end = pts[e], q = pts[f], sx = q[0] - end[0], sz = q[2] - end[2], len = Math.hypot(sx, sz) || 1, along = ((x2 - end[0]) * sx + (z - end[2]) * sz) / len;
    if (along >= len || Math.abs(end[1] - ground3(end[0], end[2])) > 0.3) continue;
    const w = Math.max(0, along / len), k = w * w * (3 - 2 * w), dk = w > 0 ? 6 * w * (1 - w) / len : 0, lift2 = p.point[1] - gy;
    return { y: gy + lift2 * k, gx: gx + (p.gradientX - gx) * k + lift2 * dk * sx / len, gz: gz + (p.gradientZ - gz) * k + lift2 * dk * sz / len };
  }
  return null;
}
function queryWorldSurface(input, ground3, surfaces = WORLD_SURFACES) {
  const gy = ground3(input.x, input.z), e = 0.06, gx = (ground3(input.x + e, input.z) - ground3(input.x - e, input.z)) / (2 * e), gz = (ground3(input.x, input.z + e) - ground3(input.x, input.z - e)) / (2 * e);
  let height = gy, dx = gx, dz = gz, id = "terrain", material = "grass";
  const ceiling = input.y === void 0 ? Infinity : input.y + (input.stepHeight ?? 0.48);
  let preferred = false;
  for (const si of near(input.x, input.z, surfaces)) {
    const surface = surfaces[si], p = worldDeckAt(surface, input.x, input.z);
    if (!p) continue;
    const slab = p.distance <= p.halfWidth + 1e-6 ? approachSlab(surface, p, input.x, input.z, ground3, gy, gx, gz) : null;
    if (slab) {
      p.point = [p.point[0], slab.y, p.point[2]];
      p.gradientX = slab.gx;
      p.gradientZ = slab.gz;
    }
    const supported = surface.id === input.supportId && input.y !== void 0 && Math.abs(p.point[1] - input.y) < 1;
    if (p.distance > p.halfWidth + 1e-6 || p.point[1] > ceiling || p.point[1] < gy - 0.12 || !supported && p.point[1] < height - 0.12) continue;
    if (preferred && !supported) continue;
    if (supported) preferred = true;
    height = p.point[1];
    dx = p.gradientX;
    dz = p.gradientZ;
    id = surface.id;
    material = surface.material;
  }
  const inv = 1 / Math.hypot(dx, 1, dz);
  return { id, y: height, nx: -dx * inv, ny: inv, nz: -dz * inv, material, slope: Math.hypot(dx, dz) };
}
var branchById = new Map(SKILL_BRANCHES.map((b) => [b.id, b]));
function worldCeilingAt(x2, z, feet, radius = 0.2, surfaces = WORLD_SURFACES) {
  let ceiling = Infinity;
  for (const si of near(x2, z, surfaces)) {
    const s = surfaces[si], p = worldDeckAt(s, x2, z);
    if (!p) continue;
    const branch2 = branchById.get(s.id), ends = branch2 ? [branch2.points[0], branch2.points[branch2.points.length - 1]] : [];
    const junction = !s.landingRows && p.point[1] - feet < 3 && ends.some((at) => Math.hypot(x2 - at[0], z - at[2]) < 18);
    if (!junction && p.distance <= p.halfWidth + radius && p.point[1] > feet + 0.48) ceiling = Math.min(ceiling, p.point[1] - 0.28);
  }
  return ceiling;
}
var WORLD_SOLIDS = [...DAM_SOLIDS.filter((s) => s.id.startsWith("dam:plinth:")), ...STATION_SOLIDS, ...DISTRICT_ART_SOLIDS, ...SUMMIT_ART_SOLIDS, ...SKILL_BRANCHES.flatMap((s) => s.points.flatMap((p, i2) => {
  if (i2 % 8 !== 0) return [];
  const a = s.points[Math.max(0, i2 - 1)], b = s.points[Math.min(s.points.length - 1, i2 + 1)], dx = b[0] - a[0], dz = b[2] - a[2], l = Math.hypot(dx, dz) || 1;
  return [-1, 1].flatMap((side) => {
    const row = s.landingRows?.[i2], edge2 = row?.[side < 0 ? 0 : row.length - 1], width = edge2 ? Math.hypot(edge2[0] - p[0], edge2[2] - p[2]) : s.halfWidth, x2 = edge2 ? p[0] + (edge2[0] - p[0]) * (1 + 0.4 / width) : p[0] + dz / l * (s.halfWidth + 0.4) * side, z = edge2 ? p[2] + (edge2[2] - p[2]) * (1 + 0.4 / width) : p[2] - dx / l * (s.halfWidth + 0.4) * side, y = mountainBaseHeight(x2, z);
    if (nearestOnRoute2(x2, z).distance < ROAD_HALF_WIDTH + 1 || p[1] - y < 1) return [];
    return [{ id: `${s.id}:support:${i2}:${side}`, min: [x2 - 0.12, y, z - 0.12], max: [x2 + 0.12, p[1] - 0.25, z + 0.12] }];
  });
}))];

// src/harbour/skate/world/profiles.ts
var DEG = Math.PI / 180;
function frameToWorld(f, lx, lz) {
  const c = Math.cos(f.yaw), s = Math.sin(f.yaw);
  return [f.x + lx * c + lz * s, f.z + lz * c - lx * s];
}
function composeFrame(parent, lx, lz, yaw) {
  const [x2, z] = frameToWorld(parent, lx, lz);
  return { x: x2, z, yaw: parent.yaw + yaw };
}
function arcFor(height, angleDeg) {
  const angle = Math.min(84, Math.max(5, angleDeg)) * DEG;
  const R2 = height / (1 - Math.cos(angle));
  return { R: R2, T: R2 * Math.sin(angle), H: height, angle };
}

// src/harbour/skate/world/layout.ts
var APRON_ALLOWANCE = 2.2;
var H = Math.PI / 2;
var HOB = arcFor(1.1, 62);
var CHIMNEY = arcFor(1.9, 84);
var BREADBIN = arcFor(0.85, 72);
var BREADBIN_HALF = 2.4 / 2 + BREADBIN.T + 0.9;
var TIDELINE = {
  id: "tideline",
  name: "Tideline Park",
  words: "A little concrete. A lot of possibility.",
  frame: { x: 18.6, z: -38.3, yaw: 150 * DEG },
  pad: { at: [0, 0], half: [14.5, 10], corner: 1.5, maxSlope: 0.025 },
  start: [-1, 0.8],
  startYaw: -H,
  sign: { at: [2, -11.2], yaw: Math.PI },
  features: [
    // ---- the transition end (−X): the Kettle, its Hob wall and the Breadbin mini
    { type: "bowl", id: "tideline-kettle", name: "The Kettle", at: [-9.7, -5.8], floor: [1.9, 1.1], corner: 1.1, depth: 1.1, angle: 80, block: [3.9, 3.2] },
    { type: "quarter", id: "tideline-hob", name: "The Hob", at: [-9.7, -2.6 + HOB.T], yaw: Math.PI, width: 7.8, height: 1.1, angle: 62, deck: 0 },
    { type: "bank", id: "tideline-kettle-rollin", name: "Kettle roll-in", at: [-5.8 + 3, -6.2], yaw: -H, width: 4.4, run: 3, rise: 1.1, fillet: 0.35 },
    { type: "mini", id: "tideline-breadbin", name: "The Breadbin", at: [-9, 6.4], yaw: H, width: 4, height: 0.85, angle: 72, flat: 2.4, deck: 0.9 },
    { type: "bank", id: "tideline-breadbin-rollin", name: "Breadbin roll-in", at: [-9 + BREADBIN_HALF + 2.4, 6.4], yaw: -H, width: 4, run: 2.4, rise: 0.85, fillet: 0.3 },
    // ---- the long runway to the Chimney
    { type: "box", id: "tideline-breadboard", name: "The Breadboard", at: [4.3, -7.6], half: [1.8, 0.6], height: 0.18, role: "manual", ledges: [{ side: "+z" }, { side: "-z" }] },
    { type: "quarter", id: "tideline-chimney", name: "The Chimney", at: [13.1 - CHIMNEY.T, -6.7], yaw: H, width: 5, height: 1.9, angle: 84, deck: 1 },
    { type: "rail", id: "tideline-rolling-pin", name: "The Rolling Pin", kind: "round-rail", points: [[0.8, -3.4, 0.36], [6, -3.4, 0.36]] },
    // ---- the Cake Stand funbox: banks, a ledge and a kinked rail
    { type: "funbox", id: "tideline-cake-stand", name: "The Cake Stand", at: [9, -0.8], half: [1.4, 1], height: 0.5, runs: { px: 1.3, nx: 1.3 }, fillet: 0.25, ledges: [{ side: "-z", name: "Cake Stand ledge" }] },
    { type: "rail", id: "tideline-teaspoon", name: "The Teaspoon", kind: "kinked-rail", points: [[7.6, -0.05, 0.82], [10.4, -0.05, 0.82], [11.7, -0.05, 0.32], [12.4, -0.05, 0.32]] },
    // ---- the Hatch: kicker over the planter to a landing and down-bank (launches toward −X)
    { type: "kicker", id: "tideline-hatch", name: "The Hatch", at: [7.2, 2.5], yaw: -H, width: 1.8, height: 0.5, angle: 38 },
    { type: "planter", id: "tideline-hatch-planter", name: "Hatch planter", at: [4.5, 2.5], half: [0.4, 0.8], height: 0.42 },
    { type: "box", id: "tideline-hatch-landing", name: "Hatch landing", at: [2.8, 2.5], half: [0.4, 0.9], height: 0.45, role: "landing" },
    { type: "bank", id: "tideline-hatch-bank", name: "Hatch down-bank", at: [1, 2.5], yaw: H, width: 1.8, run: 1.4, rise: 0.45, fillet: 0.25 },
    // ---- the Lantern Steps: platform, five-stair, the Mantel hubba, the Lamplighter handrail, the Sill (bank-to-ledge)
    { type: "box", id: "tideline-lantern-deck", name: "Lantern terrace", at: [11.6, 7.5], half: [2.4, 1.9], height: 0.6, role: "platform" },
    { type: "stairs", id: "tideline-lantern-steps", name: "The Lantern Steps", at: [9.2, 7.35], yaw: -H, width: 3, steps: 5, rise: 0.12, run: 0.34 },
    { type: "hubba", id: "tideline-mantel", name: "The Mantel", at: [9.2, 9.125], yaw: -H, width: 0.55, profile: [[-1.2, 0.9], [0, 0.9], [1.7, 0.3]], ledges: ["+x", "-x"] },
    { type: "rail", id: "tideline-lamplighter", name: "The Lamplighter", kind: "round-rail", points: [[10, 5.62, 0.96], [9.2, 5.62, 0.96], [7.84, 5.62, 0.48], [7.34, 5.62, 0.3035]] },
    { type: "bank", id: "tideline-sill-bank", name: "Sill bank", at: [12.1, 3.6], yaw: 0, width: 3.8, run: 2, rise: 0.6, fillet: 0.25 },
    { type: "box", id: "tideline-sill", name: "The Sill", at: [13, 5.8], half: [1, 0.2], height: 0.9, role: "ledge", ledges: [{ side: "-z", name: "The Sill" }] },
    // ---- somewhere to sit
    { type: "box", id: "tideline-bench", name: "The Dunking Bench", at: [1.5, 9.1], half: [0.9, 0.22], height: 0.38, role: "bench", ledges: [{ side: "+z" }, { side: "-z" }] },
    // ---- paper lanterns round the edge (never rideable)
    ...[[-14.6, -10.1], [14.6, -10.1], [-14.6, 10.1], [14.6, 10.1], [-4.5, -10.6], [8.5, -10.6]].map(([x2, z], i2) => ({ type: "post", id: `tideline-lantern-${i2}`, at: [x2, z], r: 0.07, height: 1.7, look: "lantern" }))
  ]
};
var BOOKENDS = {
  id: "bookends",
  name: "Bookends Square",
  words: "Low ledges. Long lines. One more try.",
  frame: { x: -14, z: -6, yaw: 0 },
  pad: { at: [0, 0], half: [5, 4], corner: 1.2, maxSlope: 0.07 },
  start: [-4, 1.9],
  startYaw: H,
  sign: { at: [0, -4.9], yaw: Math.PI },
  features: [
    { type: "planter", id: "bookends-left", name: "Left bookend", at: [-2.4, -1.3], half: [2.1, 0.45], height: 0.42, ledges: [{ side: "+z", name: "Left bookend rim" }, { side: "-z", name: "Left bookend back" }] },
    { type: "planter", id: "bookends-right", name: "Right bookend", at: [2.4, 1.3], half: [2.1, 0.45], height: 0.42, ledges: [{ side: "+z", name: "Right bookend back" }, { side: "-z", name: "Right bookend rim" }] },
    { type: "box", id: "bookends-bench", name: "Reading bench", at: [0, -3.1], half: [1, 0.22], height: 0.38, role: "bench", ledges: [{ side: "+z" }, { side: "-z" }] },
    { type: "box", id: "bookends-curb", name: "Westway curb", at: [0, 3.55], half: [4.2, 0.14], height: 0.12, role: "curb", ledges: [{ side: "+z", kind: "curb" }, { side: "-z", kind: "curb" }] },
    { type: "post", id: "bookends-lantern-0", at: [-5.3, -4.3], r: 0.07, height: 1.7, look: "lantern" },
    { type: "post", id: "bookends-lantern-1", at: [5.3, -4.3], r: 0.07, height: 1.7, look: "lantern" }
  ]
};
var FUNDSTEPS = {
  id: "fundsteps",
  name: "Counting-House Steps",
  words: "Six steps down from the Fund. Count them on the way.",
  frame: { x: 15, z: -16, yaw: 0 },
  pad: { at: [0, 0], half: [5.5, 4.5], corner: 1.2, maxSlope: 0.07 },
  start: [-3.4, 0],
  startYaw: H,
  sign: { at: [-5.9, -3.6], yaw: -H },
  features: [
    { type: "box", id: "fundsteps-top", name: "Counting-house landing", at: [3.2, 0], half: [1.8, 2.2], height: 0.72, role: "platform" },
    { type: "stairs", id: "fundsteps-steps", name: "The Six", at: [1.4, 0], yaw: -H, width: 3, steps: 6, rise: 0.12, run: 0.34 },
    { type: "rail", id: "fundsteps-ledger", name: "The Ledger rail", kind: "round-rail", points: [[2.2, 1.75, 1.08], [1.4, 1.75, 1.08], [-0.3, 1.75, 0.48], [-0.8, 1.75, 0.3035]] },
    { type: "rail", id: "fundsteps-tally", name: "The Tally rail", kind: "round-rail", points: [[2.2, -1.75, 1.08], [1.4, -1.75, 1.08], [-0.3, -1.75, 0.48], [-0.8, -1.75, 0.3035]] },
    { type: "bank", id: "fundsteps-bank-n", name: "North bank", at: [3.2, -4.2], yaw: 0, width: 3.6, run: 2, rise: 0.72, fillet: 0.25 },
    { type: "bank", id: "fundsteps-bank-s", name: "South bank", at: [3.2, 4.2], yaw: Math.PI, width: 3.6, run: 2, rise: 0.72, fillet: 0.25 },
    { type: "box", id: "fundsteps-ledge", name: "The Counting ledge", at: [4.75, 0], half: [0.25, 1.6], height: 1.02, role: "ledge", ledges: [{ side: "-x", name: "The Counting ledge" }] }
  ]
};
var NORTHLIGHT = {
  id: "northlight",
  name: "Northlight Run",
  words: "The island ends. The line goes on.",
  frame: { x: -12, z: -48, yaw: 0 },
  pad: { at: [0, 0], half: [3, 8], corner: 1.2, maxSlope: 0.09 },
  start: [0, 6.6],
  startYaw: Math.PI,
  sign: { at: [-3.9, 6.8], yaw: -H },
  features: [
    { type: "kicker", id: "northlight-beacon", name: "The Beacon", at: [0, 4.6], yaw: Math.PI, width: 2.2, height: 0.42, angle: 32 },
    { type: "rail", id: "northlight-rail", name: "The Lighthouse rail", kind: "round-rail", points: [[1.5, 1, 0.36], [1.5, -5, 0.36]] },
    { type: "box", id: "northlight-keeper", name: "The Keeper's ledge", at: [-1.9, -2.5], half: [0.25, 2.9], height: 0.3, role: "ledge", ledges: [{ side: "+x", name: "The Keeper's ledge" }, { side: "-x" }] },
    { type: "quarter", id: "northlight-point", name: "The Point", at: [0, -6.3], yaw: Math.PI, width: 5.6, height: 0.7, angle: 55, deck: 0.3 }
  ]
};
var ORCHARD = {
  id: "orchard",
  name: "Orchard Culvert",
  words: "The rain found this line first.",
  frame: { x: -42, z: 39, yaw: 0 },
  pad: { at: [0, 0], half: [6.4, 3.5], corner: 1.2, maxSlope: 0.07 },
  start: [-5.4, 0],
  startYaw: H,
  sign: { at: [-7.3, 2.4], yaw: -H },
  features: [
    { type: "funbox", id: "orchard-berm-n", name: "North berm", at: [0, -2], half: [3.4, 0.25], height: 0.6, runs: { px: 1.2, nx: 1.2, pz: 1.2, nz: 1.2 }, fillet: 0.25 },
    { type: "funbox", id: "orchard-berm-s", name: "South berm", at: [0, 2], half: [3.4, 0.25], height: 0.6, runs: { px: 1.2, nx: 1.2, pz: 1.2, nz: 1.2 }, fillet: 0.25 },
    { type: "rail", id: "orchard-rail", name: "The Culvert rail", kind: "round-rail", points: [[-3.2, 0, 0.34], [3.2, 0, 0.34]] }
  ]
};
var TIDEPOOLS = {
  id: "tidepools",
  name: "Tidepool Promenade",
  words: "Save a little speed for the way back.",
  frame: { x: 46.2, z: 31, yaw: 0 },
  pad: { at: [0, 0], half: [1.9, 5.2], corner: 0.9, maxSlope: 0.09 },
  start: [0.1, -4.3],
  startYaw: 0,
  sign: { at: [-2.6, -4.6], yaw: -H },
  features: [
    { type: "box", id: "tidepools-curb", name: "Promenade curb", at: [1.55, 0], half: [0.14, 4.6], height: 0.12, role: "curb", ledges: [{ side: "+x", kind: "curb", name: "Promenade curb" }, { side: "-x", kind: "curb" }] },
    { type: "box", id: "tidepools-bench-a", name: "Low-tide bench", at: [-1.3, -2.4], half: [0.22, 1], height: 0.38, role: "bench", ledges: [{ side: "+x" }, { side: "-x" }] },
    { type: "box", id: "tidepools-bench-b", name: "High-tide bench", at: [-1.3, 2.4], half: [0.22, 1], height: 0.38, role: "bench", ledges: [{ side: "+x" }, { side: "-x" }] },
    { type: "box", id: "tidepools-manual", name: "Shell pad", at: [0.1, 0], half: [0.5, 1], height: 0.16, role: "manual", ledges: [{ side: "+x" }, { side: "-x" }] }
  ]
};
var DRYDOCK = {
  id: "drydock",
  name: "Drydock Pier",
  words: "Salt air and a rail all the way home.",
  frame: { x: 52, z: -32, yaw: 122 * DEG },
  pad: { at: [0, 0], half: [2.4, 7.2], corner: 1, maxSlope: 0.06 },
  start: [0, -6.6],
  startYaw: 0,
  sign: { at: [-2.9, -6.2], yaw: -H },
  features: [
    { type: "bank", id: "drydock-ramp", name: "Slipway", at: [0, -4.4], yaw: 0, width: 2.2, run: 1.2, rise: 0.4, fillet: 0.25, kind: "wood" },
    { type: "box", id: "drydock-pier", name: "The Pier", at: [0, 1.6], half: [1.1, 4.8], height: 0.4, role: "deck", kind: "wood", ledges: [{ side: "+x", name: "Salt plank" }, { side: "-x", name: "Tar plank" }] },
    { type: "rail", id: "drydock-mooring", name: "The Mooring rail", kind: "round-rail", points: [[1.85, -2.6, 0.38], [1.85, 5.2, 0.38]] },
    { type: "post", id: "drydock-bollard-0", at: [-0.75, 6], r: 0.12, height: 0.95, look: "bollard" },
    { type: "post", id: "drydock-bollard-1", at: [0.75, 6], r: 0.12, height: 0.95, look: "bollard" }
  ]
};
var SPOT_LAYOUTS = [TIDELINE, BOOKENDS, FUNDSTEPS, DRYDOCK, ORCHARD, NORTHLIGHT, TIDEPOOLS];
function spotRect(l) {
  const pf = composeFrame(l.frame, l.pad.at[0], l.pad.at[1], 0);
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const [x2, z] = frameToWorld(pf, sx * l.pad.half[0], sz * l.pad.half[1]);
    minX = Math.min(minX, x2);
    maxX = Math.max(maxX, x2);
    minZ = Math.min(minZ, z);
    maxZ = Math.max(maxZ, z);
  }
  const r = (n) => Math.round(n * 100) / 100;
  return { x: r((minX + maxX) / 2), z: r((minZ + maxZ) / 2), halfWidth: r((maxX - minX) / 2 + APRON_ALLOWANCE), halfDepth: r((maxZ - minZ) / 2 + APRON_ALLOWANCE) };
}
var SPOTS = SPOT_LAYOUTS.map((l) => {
  const rect2 = spotRect(l), start = frameToWorld(l.frame, l.start[0], l.start[1]);
  const startYaw = Math.atan2(Math.sin(l.frame.yaw + l.startYaw), Math.cos(l.frame.yaw + l.startYaw));
  const round = (n) => Math.round(n * 1e3) / 1e3;
  return { id: l.id, name: l.name, words: l.words, ...rect2, start: [round(start[0]), round(start[1])], startYaw: round(startYaw) };
});
var SKATE_KEEP_OUTS = SPOT_LAYOUTS.map((l) => {
  const f = composeFrame(l.frame, l.pad.at[0], l.pad.at[1], 0);
  return { kind: "rect", id: `skate-${l.id}`, x: f.x, z: f.z, halfWidth: l.pad.half[0] + APRON_ALLOWANCE, halfDepth: l.pad.half[1] + APRON_ALLOWANCE, yaw: f.yaw };
});
var parkPoint = (spotId, lx, lz) => {
  const l = SPOT_LAYOUTS.find((s) => s.id === spotId);
  if (!l) throw new Error(`unknown spot ${spotId}`);
  const [x2, z] = frameToWorld(l.frame, lx, lz);
  return [Math.round(x2 * 100) / 100, Math.round(z * 100) / 100];
};
var ROUTES = [
  {
    id: "first-line",
    name: "First light",
    detail: "A lap of Tideline. Find the Kettle, the Chimney and the Steps.",
    seconds: [26, 38, 58],
    points: [parkPoint("tideline", -1, 0.8), parkPoint("tideline", -12.2, 2.3), parkPoint("tideline", -1.2, -6.4), parkPoint("tideline", 8.6, -5.8), parkPoint("tideline", 12.6, 1.6), parkPoint("tideline", 5.6, 5.2), parkPoint("tideline", -2.2, 3)]
  },
  { id: "north-run", name: "Chase the lighthouse", detail: "Out of the square and all the way to Northlight.", seconds: [18, 27, 42], points: [[0, -8], [0, -18], [-3, -36], [-4, -47], [-5, -61]] },
  { id: "coast-run", name: "Salt on the wheels", detail: "Follow the east road to the tide pools.", seconds: [23, 35, 55], points: [[12, -1], [23, -4], [37, 4], [45, 20], [50.8, 30.5], [49, 43]] },
  { id: "orchard-run", name: "The scenic way", detail: "Find Bookends, then follow the western lane.", seconds: [22, 34, 52], points: [[-6, 0], [-16, 0], [-25, 4], [-35, 14], [-36, 26], [-44, 32]] },
  { id: "meadow-run", name: "Meet me by the sea", detail: "A south-road cruise through the long meadow.", seconds: [22, 34, 55], points: [[0, 9], [0, 20], [2, 32], [0, 44], [-10, 48], [-17, 51]] }
];

// src/harbour/skate/world/field.ts
var PAD_LIFT = 0.04;
var PAD_FIT_LIFT = PAD_LIFT + 2e-3;
var MAX_SLOPE = Math.tan(84 * Math.PI / 180);

// src/harbour/skate/park.ts
var SKATE_SPOTS = SPOTS;
var SKATE_ROUTES = [...ROUTES, MOUNTAIN_RACE];
var SKATE_RAILS = SPOT_LAYOUTS.flatMap((l) => l.features.flatMap((f) => {
  if (f.type !== "rail" || f.kind !== "round-rail" || f.points.length !== 2 || f.points[0][2] !== f.points[1][2]) return [];
  const a = frameToWorld(l.frame, f.points[0][0], f.points[0][1]), b = frameToWorld(l.frame, f.points[1][0], f.points[1][1]);
  return [{ id: f.id, name: f.name, a: [a[0], a[1]], b: [b[0], b[1]], height: f.points[0][2] + PAD_FIT_LIFT - 0.035 }];
}));

// src/harbour/scene/planting.ts
var rect = (id, x2, z, halfWidth, halfDepth, yaw) => ({ kind: "rect", id, x: x2, z, halfWidth, halfDepth, yaw });
var doorway = (id, x2, z, yaw, door3) => ({
  kind: "circle",
  id,
  x: x2 + door3[0] * Math.cos(yaw) + door3[1] * Math.sin(yaw),
  z: z + door3[1] * Math.cos(yaw) - door3[0] * Math.sin(yaw),
  r: 1.7
});
var ISLAND_KEEP_OUTS = Object.freeze([
  ...SKATE_SPOTS.map((s) => rect(`skate-${s.id}`, s.x, s.z, s.halfWidth + 1.5, s.halfDepth + 1.5, 0)),
  ...Object.values(VILLAGE_SITES).flatMap((site) => {
    const [x2, z] = site.spot, yaw = Math.atan2(-x2, -z);
    return [rect(site.entry, x2, z, site.half[0] + 0.25, site.half[1] + 0.25, yaw), doorway(`${site.entry}-door`, x2, z, yaw, site.door)];
  }),
  rect("campfire", ...VILLAGE_WATERFRONT.spot, VILLAGE_WATERFRONT.half[0] + 0.25, VILLAGE_WATERFRONT.half[1] + 0.25, VILLAGE_WATERFRONT.yaw),
  doorway("campfire-door", ...VILLAGE_WATERFRONT.spot, VILLAGE_WATERFRONT.yaw, VILLAGE_WATERFRONT.door),
  ...HARBOUR_WANDERS.map((wander) => ({ kind: "circle", id: wander.id, x: wander.at[0], z: wander.at[1], r: 4.5 }))
]);
var TREE_COUNT = Object.freeze({ full: 96, lite: 64 });

// src/harbour/scene/quality.ts
var DPR_CAP = Object.freeze({ full: 1.5, lite: 1 });

// src/harbour/scene/lightRig.ts
var SUN_TOWARD = (() => {
  const v = [-0.8, 0.52, 0.3], l = Math.hypot(v[0], v[1], v[2]);
  return [v[0] / l, v[1] / l, v[2] / l];
})();

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/scene/groundPaint.ts
function axis(min, max2, fineMin, fineMax, fine, coarse) {
  const out = [];
  const run = (a, b, step) => {
    const n = Math.max(1, Math.round((b - a) / step));
    for (let i2 = 0; i2 < n; i2++) out.push(a + (b - a) * i2 / n);
  };
  run(min, fineMin, coarse);
  run(fineMin, fineMax, fine);
  run(fineMax, max2, coarse);
  out.push(max2);
  return new Float32Array(out);
}
function buildLattice(bounds2, tier, height) {
  const full = tier === "full";
  const xs = axis(bounds2.minX, bounds2.maxX, -90, 90, full ? 1.25 : 2, full ? 2 : 3), zs = axis(bounds2.minZ, bounds2.maxZ, -64, bounds2.maxZ - 4, full ? 1.25 : 2, full ? 2 : 3);
  const cols = xs.length - 1, rows = zs.length - 1, positions = new Float32Array((cols + 1) * (rows + 1) * 3), indices2 = new Uint32Array(cols * rows * 6);
  for (let iz = 0; iz <= rows; iz++) for (let ix = 0; ix <= cols; ix++) {
    const i2 = iz * (cols + 1) + ix, x2 = xs[ix], z = zs[iz];
    positions[i2 * 3] = x2;
    positions[i2 * 3 + 1] = height(x2, z);
    positions[i2 * 3 + 2] = z;
  }
  let k = 0;
  for (let iz = 0; iz < rows; iz++) for (let ix = 0; ix < cols; ix++) {
    const a = iz * (cols + 1) + ix, b = a + 1, c = a + cols + 1, d = c + 1;
    const ad = Math.abs(positions[a * 3 + 1] - positions[d * 3 + 1]), bc = Math.abs(positions[b * 3 + 1] - positions[c * 3 + 1]);
    if (ad <= bc) {
      indices2[k++] = a;
      indices2[k++] = c;
      indices2[k++] = d;
      indices2[k++] = a;
      indices2[k++] = d;
      indices2[k++] = b;
    } else {
      indices2[k++] = a;
      indices2[k++] = c;
      indices2[k++] = b;
      indices2[k++] = b;
      indices2[k++] = c;
      indices2[k++] = d;
    }
  }
  capOrchardGroundLattice({ positions, indices: indices2 });
  return { positions, indices: indices2, cols, rows, xs, zs };
}
var BIOMES = ["garden", "orchard", "woods", "meadow", "alpine", "summit"];
var ALTITUDE = [["garden", -1e9], ["woods", 26], ["meadow", 48], ["alpine", 70], ["summit", 92]];
var hash2 = (x2, z) => {
  const s = Math.sin(x2 * 12.9898 + z * 78.233) * 43758.5453;
  return s - Math.floor(s);
};
function stamp(field, L, points, halfWidth, reach, keep = () => true) {
  const { xs, zs, cols } = L, col = (x2) => {
    let lo = 0, hi = xs.length - 1;
    while (hi - lo > 1) {
      const m = lo + hi >> 1;
      if (xs[m] <= x2) lo = m;
      else hi = m;
    }
    return lo;
  }, row = (z) => {
    let lo = 0, hi = zs.length - 1;
    while (hi - lo > 1) {
      const m = lo + hi >> 1;
      if (zs[m] <= z) lo = m;
      else hi = m;
    }
    return lo;
  };
  for (let i2 = 1; i2 < points.length; i2++) {
    const a = points[i2 - 1], b = points[i2];
    if (!keep(a, i2 - 1) && !keep(b, i2)) continue;
    const hw = typeof halfWidth === "number" ? halfWidth : halfWidth(i2), r = hw + reach;
    const x0 = col(Math.min(a[0], b[0]) - r), x1 = col(Math.max(a[0], b[0]) + r) + 1, z0 = row(Math.min(a[2], b[2]) - r), z1 = row(Math.max(a[2], b[2]) + r) + 1;
    const dx = b[0] - a[0], dz = b[2] - a[2], l = dx * dx + dz * dz || 1;
    for (let iz = z0; iz <= Math.min(z1, zs.length - 1); iz++) for (let ix = x0; ix <= Math.min(x1, xs.length - 1); ix++) {
      const x2 = xs[ix], z = zs[iz], t = Math.max(0, Math.min(1, ((x2 - a[0]) * dx + (z - a[2]) * dz) / l)), d = Math.hypot(x2 - a[0] - dx * t, z - a[2] - dz * t) - hw, k = iz * (cols + 1) + ix;
      if (d < field[k]) field[k] = d;
    }
  }
}
var maskCache = /* @__PURE__ */ new Map();
function groundMasks(L, tier, height, cache = maskCache) {
  const cached = cache.get(tier);
  if (cached) return cached;
  const n = L.positions.length / 3, P = L.positions, F = () => new Float32Array(n);
  const m = {
    n,
    slope: F(),
    nx: F(),
    ny: F(),
    nz: F(),
    cavity: F(),
    sun: F(),
    road: F().fill(99),
    path: F().fill(99),
    river: F().fill(99),
    scree: F(),
    biome: Object.fromEntries(BIOMES.map((b) => [b, F()])),
    mountain: F(),
    bowl: F(),
    grain: F()
  };
  const sx = SUN_TOWARD[0], sz = SUN_TOWARD[2], sh = Math.hypot(sx, sz), rise = SUN_TOWARD[1] / sh, ux = sx / sh, uz = sz / sh;
  const [bcx, , bcz] = DAM_PARTS.centre;
  for (let i2 = 0; i2 < n; i2++) {
    const x2 = P[i2 * 3], y = P[i2 * 3 + 1], z = P[i2 * 3 + 2];
    const gx = (height(x2 + 1, z) - height(x2 - 1, z)) / 2, gz = (height(x2, z + 1) - height(x2, z - 1)) / 2, g2 = Math.hypot(gx, gz), nl = Math.hypot(gx, 1, gz);
    m.slope[i2] = g2;
    m.nx[i2] = -gx / nl;
    m.ny[i2] = 1 / nl;
    m.nz[i2] = -gz / nl;
    m.grain[i2] = hash2(Math.floor(x2 * 0.9), Math.floor(z * 0.9)) * 0.6 + hash2(Math.floor(x2 * 0.23), Math.floor(z * 0.23)) * 0.4;
    let near2 = 0, far = 0;
    for (let k = 0; k < 8; k++) {
      const a = k * Math.PI / 4;
      near2 += height(x2 + Math.cos(a) * 3.5, z + Math.sin(a) * 3.5);
      far += height(x2 + Math.cos(a) * 9, z + Math.sin(a) * 9);
    }
    m.cavity[i2] = (near2 / 8 - y) * 0.6 + (far / 8 - y) * 0.25;
    let shadow = 0;
    if (z < -30 || y > 1) for (let s = 2.5; s <= 70; s += 2.5) {
      const h = height(x2 + ux * s, z + uz * s), ray = y + 0.4 + s * rise;
      if (h > ray) {
        shadow = Math.min(1, shadow + (h - ray) * 0.45);
        if (shadow >= 1) break;
      }
    }
    m.sun[i2] = shadow;
    if (g2 > 0.05 && z < -44) {
      const dx = gx / g2, dz = gz / g2;
      const up = Math.hypot((height(x2 + dx * 5 + 1, z + dz * 5) - height(x2 + dx * 5 - 1, z + dz * 5)) / 2, (height(x2 + dx * 5, z + dz * 5 + 1) - height(x2 + dx * 5, z + dz * 5 - 1)) / 2);
      m.scree[i2] = Math.max(0, Math.min(1, (up - 1.3) * 1.4)) * Math.max(0, Math.min(1, (1.25 - g2) * 2));
    }
    const r = Math.hypot(x2, z);
    m.mountain[i2] = z < -44 ? Math.min(1, Math.max(y > 1.4 ? 1 : 0, (-44 - z) / 14, r > HARBOUR_LAND.radius - 6 && y > 0.6 ? 1 : 0)) : y > 2.2 && z < -30 ? Math.min(1, (y - 2.2) / 2) : 0;
    let total = 0;
    for (const b of BIOMES) m.biome[b][i2] = 0;
    const lay = m.biome;
    for (const d of DISTRICTS) {
      const dd = Math.hypot(x2 - d.at[0], z - d.at[2]), R2 = d.radius + 26, w = Math.exp(-(dd / R2) * (dd / R2) * 1.6);
      {
        const arr = lay[d.biome];
        if (arr) arr[i2] = (arr[i2] ?? 0) + w;
      }
      total += w;
    }
    const base = 0.35;
    for (let k = 0; k < ALTITUDE.length; k++) {
      const lo = ALTITUDE[k][1], hi = ALTITUDE[k + 1]?.[1] ?? 1e9, w = (sm(lo - 8, lo + 8, y) - sm(hi - 8, hi + 8, y)) * base;
      if (w > 0) {
        const arr = lay[ALTITUDE[k][0]];
        if (arr) arr[i2] = (arr[i2] ?? 0) + w;
        total += w;
      }
    }
    for (const b of BIOMES) {
      const arr = lay[b];
      if (arr) arr[i2] = (arr[i2] ?? 0) / total;
    }
    const bowlR = Math.hypot(x2 - bcx, z - bcz + 6);
    m.bowl[i2] = y < RESERVOIR.level + 0.4 && y > RESERVOIR.bottom - 2 && bowlR < 44 && z < -236 ? 1 : 0;
  }
  const onGround = (p) => Math.abs(p[1] - height(p[0], p[2])) < 1.6;
  stamp(m.road, L, MOUNTAIN_ROAD_LINE.samples.map((s) => s.at), (i2) => MOUNTAIN_ROAD_LINE.samples[i2].halfWidth, 4, onGround);
  stamp(m.road, L, ORCHARD_LANE_LINE.samples.map((s) => s.at), ORCHARD_LANE_LINE.samples[0].halfWidth, 4, onGround);
  stamp(m.road, L, TOWN_RACE_ROAD, TOWN_LANE_HALF_WIDTH, 3);
  for (const e of PATH_EDGES) if (e.kind === "path" || e.kind === "stair") stamp(m.path, L, e.points, e.halfWidth, 2.5, onGround);
  const dense = [];
  for (let i2 = 1; i2 < RIVER.length; i2++) {
    const a = RIVER[i2 - 1], b = RIVER[i2], k = Math.ceil(Math.hypot(b[0] - a[0], b[2] - a[2]) / 2);
    for (let j = 0; j < k; j++) {
      const t = j / k;
      dense.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]);
    }
  }
  dense.push(RIVER[RIVER.length - 1]);
  stamp(m.river, L, dense, RIVER_HALF_WIDTH, 6);
  cache.set(tier, m);
  return m;
}
var sat = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
var sm = (e0, e1, v) => {
  const t = sat((v - e0) / (e1 - e0));
  return t * t * (3 - 2 * t);
};

// src/harbour/art/cardKit.ts
var UV_SCALE = 1 / 2.5;

// src/harbour/scene/ground.ts
var GROUND_RADIUS = HARBOUR_LAND.radius;
var TERRACE_RADIUS = HARBOUR_LAND.terrace;
var LAWN_RADIUS = HARBOUR_LAND.lawn;
var TERRAIN_LATTICE_BOUNDS = { minX: -200, maxX: 200, minZ: -396, maxZ: 84 };
function authoredGroundHeightAt(x2, z) {
  if (z < -48) return Math.max(islandHeight(x2, z), mountainBaseHeight(x2, z));
  const island = z < -30 ? Math.max(islandHeight(x2, z), mountainGround(x2, z)) : islandHeight(x2, z);
  return townChannelHeight(x2, z, island);
}
function groundHeightAt(x2, z) {
  const original = authoredGroundHeightAt(x2, z), ceiling = orchardGroundCeiling(x2, z);
  return ceiling === null ? original : Math.min(original, ceiling);
}

// src/harbour/mountain/art/damArt.ts
var { centre: C, radius: R, halfAngle: HA, crest: CREST } = DAM_PARTS;
var DAM_ZERO = RESERVOIR.bottom;
var DAM_FULL = RESERVOIR.level;
var g = (x2, z) => groundHeightAt(x2, z);
function reservoirOutline(level = DAM_FULL) {
  const cx = C[0] - 2, cz = C[2] - 6, out = [];
  for (let k = 0; k < 64; k++) {
    const a = k / 64 * Math.PI * 2;
    let r = 1;
    for (; r < 34; r += 0.5) {
      const x2 = cx + Math.sin(a) * r, z = cz + Math.cos(a) * r;
      if (Math.hypot(x2 - C[0], z - C[2]) >= R - 0.6 && Math.abs(Math.atan2(x2 - C[0], z - C[2])) < HA * 1.02) break;
      if (g(x2, z) > level + 0.25) break;
    }
    out.push([cx + Math.sin(a) * r, cz + Math.cos(a) * r]);
  }
  return out;
}

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/geography.ts
init_placement();
var FOOT_RADIUS = 66;
var NORTH_TOLERANCE = 1;
var LAND = -0.2;
var STEP2 = 0.48;
var BODY = 1.25;
function drawnRoadSurface(line) {
  return {
    ...WORLD_SURFACES.find((s) => s.id === line.id),
    points: line.samples.map((s) => s.at),
    widths: line.samples.map((s) => s.halfWidth),
    landingRows: line.samples.map((s) => [-s.halfWidth, -s.halfWidth + 0.55, -0.45, 0.45, s.halfWidth - 0.55, s.halfWidth].map((w) => [s.at[0] + s.normal[0] * w, s.at[1], s.at[2] + s.normal[2] * w]))
  };
}
var REGION_ROAD = drawnRoadSurface(MOUNTAIN_ROAD_LINE);
var REGION_ORCHARD = drawnRoadSurface(ORCHARD_LANE_LINE);
var REGION_SURFACES = WORLD_SURFACES.filter((s) => s.id !== "town-race-road").map((s) => s.id === "mountain-road" ? REGION_ROAD : s.id === "orchard-lane" ? REGION_ORCHARD : s);
var DRAWN_ROADS = [REGION_ROAD, REGION_ORCHARD];
var REGION_OTHER_SURFACES = REGION_SURFACES.filter((s) => !DRAWN_ROADS.includes(s));
var exactRoadFloors = DRAWN_ROADS.map((surface) => {
  const original = drawnRoadFloor(surface.landingRows);
  return { surface, floor: (x2, z, ceiling = Infinity) => {
    const local = surface.id === "orchard-lane" ? orchardJunctionAt(x2, z) : null;
    return local ? local.y <= ceiling + 1e-8 ? local : null : original(x2, z, ceiling);
  } };
});
var roadGroundCeiling = drawnRoadGroundCeiling(REGION_ROAD);
function highestDrawnFloor(x2, z, y, step, ground3, decks) {
  const ceiling = y === void 0 ? Infinity : y + step;
  const other = decks === REGION_SURFACES ? REGION_OTHER_SURFACES : decks.filter((s) => !DRAWN_ROADS.includes(s));
  let hit = queryWorldSurface({ x: x2, z, y, stepHeight: step }, ground3, other);
  for (const { surface, floor } of exactRoadFloors) {
    const road = decks.includes(surface) ? floor(x2, z, ceiling) : null;
    if (road && (hit.y > ceiling || road.y > hit.y)) {
      const inv = 1 / Math.hypot(road.gx, 1, road.gz);
      hit = { id: surface.id, y: road.y, nx: -road.gx * inv, ny: inv, nz: -road.gz * inv, material: "path", slope: Math.hypot(road.gx, road.gz) };
    }
  }
  return hit;
}
var NO_DECKS = [];
var REGION_SOLIDS = WORLD_SOLIDS.filter((s) => !s.id.startsWith("district-art:"));
var MOUTH_MARGIN = 6;
function mouthExclusion(mouths) {
  const boxes = mouths.map((m) => {
    const xs = m.outline.map((p) => p[0]), zs = m.outline.map((p) => p[1]);
    return [Math.min(...xs) - MOUTH_MARGIN, Math.min(...zs) - MOUTH_MARGIN, Math.max(...xs) + MOUTH_MARGIN, Math.max(...zs) + MOUTH_MARGIN];
  });
  return (hx, hz) => boxes.some((b) => hx >= b[0] && hz >= b[1] && hx <= b[2] && hz <= b[3]);
}
function regionMaterial(hit) {
  if (hit.id === "terrain") return "grass";
  if (hit.material === "wood") return "boardwalk";
  return "paved";
}
function deckIndex(surfaces) {
  const CELL2 = 12, cells2 = /* @__PURE__ */ new Map();
  surfaces.forEach((s, i2) => {
    for (let k = 0; k < s.points.length; k++) {
      const a = s.points[Math.max(0, k - 1)], b = s.points[k], r = s.halfWidth + 1;
      for (let x2 = Math.floor((Math.min(a[0], b[0]) - r) / CELL2); x2 <= Math.floor((Math.max(a[0], b[0]) + r) / CELL2); x2++) for (let z = Math.floor((Math.min(a[2], b[2]) - r) / CELL2); z <= Math.floor((Math.max(a[2], b[2]) + r) / CELL2); z++) {
        const key2 = `${x2}:${z}`, list = cells2.get(key2);
        if (!list) cells2.set(key2, [i2]);
        else if (list.at(-1) !== i2) list.push(i2);
      }
    }
  });
  return (x2, z) => cells2.get(`${Math.floor(x2 / CELL2)}:${Math.floor(z / CELL2)}`) ?? [];
}
var BRANCH_ENDS = new Map(REGION_SURFACES.filter((s) => s.kind === "branch").map((s) => [s.id, [s.points[0], s.points[s.points.length - 1]]]));
function branchJunction(s, over, x2, z) {
  const ends = BRANCH_ENDS.get(s.id);
  return !s.landingRows && !!ends && over < 3 && ends.some((at) => Math.hypot(x2 - at[0], z - at[2]) < 18);
}
var reservoirPlan = null;
function reservoirWater(x2, z) {
  if (!reservoirPlan) {
    const outline2 = reservoirOutline(RESERVOIR_LEVEL_MAX), cx2 = outline2.reduce((a, p) => a + p[0], 0) / outline2.length, cz2 = outline2.reduce((a, p) => a + p[1], 0) / outline2.length;
    reservoirPlan = { outline: outline2, cx: cx2, cz: cz2, reach: Math.max(...outline2.map((p) => Math.hypot(p[0] - cx2, p[1] - cz2))) + 1 };
  }
  const { outline, cx, cz, reach } = reservoirPlan;
  if (Math.hypot(x2 - cx, z - cz) > reach) return null;
  let inside = false;
  for (let i2 = 0, j = outline.length - 1; i2 < outline.length; j = i2++) {
    const a = outline[i2], b = outline[j];
    if (a[1] > z !== b[1] > z && x2 < (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside && groundHeightAt(x2, z) < RESERVOIR_LEVEL_MAX ? RESERVOIR_LEVEL_MAX : null;
}
function riverWater(x2, z) {
  const p = nearestOnRoute2(x2, z, RIVER);
  return p.distance <= RIVER_HALF_WIDTH ? p.point[1] : null;
}
function regionWaterAt(x2, z) {
  return reservoirWater(x2, z) ?? riverWater(x2, z);
}
var TERRACE_YIELD_BEDS = ["S1", "V03", "spur stillwater", "yearWalk"];
var DECK_CLEARANCE = 0.05;
var BATTER_FROM = 1.5;
var BATTER = 0.5;
function terraceBedExclusion(beds, ids = TERRACE_YIELD_BEDS) {
  const from = MOUNTAIN_V2_OFFSET.z + MOUNTAIN_V2_MASSIF_Z;
  const runs2 = beds.filter((b) => ids.includes(b.id)).flatMap((b) => {
    const groups = [];
    if (b.id === "yearWalk") {
      const carried = (b.carried ?? []).map((line) => line.map((p) => [p[0], 0, p[1]]));
      let run = [];
      for (let i2 = 1; i2 < b.points.length; i2++) {
        const a = b.points[i2 - 1], p = b.points[i2], mx = (a[0] + p[0]) / 2, mz = (a[2] + p[2]) / 2;
        const owns = a[2] >= from - 2 && p[2] >= from - 2 && !carried.some((line) => nearestOnRoute2(mx, mz, line).distance < 1);
        if (owns) {
          if (!run.length) run.push(a);
          run.push(p);
        } else if (run.length) {
          groups.push(run);
          run = [];
        }
      }
      if (run.length) groups.push(run);
    } else {
      const pts = b.points.filter((p) => p[2] >= from - 2);
      if (pts.length > 1) groups.push(pts);
    }
    return groups.map((pts) => {
      const half = (b.width ?? 4) / 2 + (b.shoulder ?? 0), xs = pts.map((p) => p[0]), zs = pts.map((p) => p[2]), grow2 = half + BATTER_FROM + 8;
      return { pts, half, box: [Math.min(...xs) - half, Math.min(...zs) - half, Math.max(...xs) + half, Math.max(...zs) + half], wide: [Math.min(...xs) - grow2, Math.min(...zs) - grow2, Math.max(...xs) + grow2, Math.max(...zs) + grow2] };
    });
  });
  const test = (hx, hz) => hz >= from && runs2.some((r) => hx >= r.box[0] && hz >= r.box[1] && hx <= r.box[2] && hz <= r.box[3] && nearestOnRoute2(hx, hz, r.pts).distance <= r.half);
  test.ceiling = (hx, hz) => {
    if (hz < from - 8) return null;
    let best = null;
    for (const r of runs2) {
      if (hx < r.wide[0] || hz < r.wide[1] || hx > r.wide[2] || hz > r.wide[3]) continue;
      const n = nearestOnRoute2(hx, hz, r.pts), over = Math.max(0, n.distance - r.half - BATTER_FROM);
      const c = n.point[1] - DECK_CLEARANCE + over * BATTER / (1 - BATTER) * 2;
      if (best === null || c < best) best = c;
    }
    return best;
  };
  return test;
}
function createRegionGeography(options = {}) {
  const walkingGround = walkingJoinGround(options.walkingJoinSolids);
  const near2 = deckIndex(REGION_SURFACES);
  const mouthDecks = REGION_SURFACES.filter((s) => s.landingRows);
  const inMouth = (hx, hz) => insideMountainV2(hx, hz) && Boolean(options.exclude?.(hx, hz));
  const deckAcrossMouth = (hx, hz) => inMouth(hx, hz) && mouthDecks.some((s) => {
    const p = worldDeckAt(s, hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z);
    return p && p.distance <= p.halfWidth + 1e-6;
  });
  function contains2(hx, hz) {
    if (!insideMountainV2(hx, hz) || options.exclude?.(hx, hz)) return false;
    const nx = hx - MOUNTAIN_V2_OFFSET.x, nz = hz - MOUNTAIN_V2_OFFSET.z;
    if (nz >= MOUNTAIN_V2_MASSIF_Z) return Math.hypot(nx, nz) <= FOOT_RADIUS;
    const g2 = groundHeightAt(nx, nz);
    if (nz < MOUNTAIN_V2_SUMMIT_Z) {
      if (!(g2 > LAND)) return false;
      return options.horizonGround ? g2 + MOUNTAIN_V2_OFFSET.y >= options.horizonGround(hx, hz) - NORTH_TOLERANCE : nz >= WORLD_BOUNDS.minZ;
    }
    return g2 > LAND || mountainContains(nx, nz);
  }
  const owns = (hx, hz) => contains2(hx, hz) && !options.yield?.(hx, hz);
  const groundCeiling = (hx, hz) => {
    const yielded = options.yield?.ceiling?.(hx, hz) ?? null, road = roadGroundCeiling(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z), drawn = road === null ? null : road + MOUNTAIN_V2_OFFSET.y;
    const values = [yielded, drawn].filter((v) => v !== null);
    return values.length ? Math.min(...values) : null;
  };
  const baselineGround = (nx, nz) => {
    const g2 = groundHeightAt(nx, nz), c = groundCeiling(nx + MOUNTAIN_V2_OFFSET.x, nz + MOUNTAIN_V2_OFFSET.z);
    return c === null ? g2 : Math.min(g2, c - MOUNTAIN_V2_OFFSET.y);
  };
  const walkingGroundPatch = walkingGround ? createWalkingGroundPatch(
    walkingGround.triangles,
    baselineGround,
    (nx, nz) => {
      const c = walkingGround.ceiling(nx + MOUNTAIN_V2_OFFSET.x, nz + MOUNTAIN_V2_OFFSET.z);
      return c === null ? null : c - MOUNTAIN_V2_OFFSET.y;
    },
    (nx, nz) => contains2(nx + MOUNTAIN_V2_OFFSET.x, nz + MOUNTAIN_V2_OFFSET.z)
  ) : void 0;
  const feltGround = (nx, nz) => walkingGroundPatch?.floorAt(nx, nz)?.y ?? baselineGround(nx, nz);
  function groundAt(hx, hz) {
    return owns(hx, hz) ? feltGround(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z) + MOUNTAIN_V2_OFFSET.y : null;
  }
  function surface(hx, hy, hz, step = STEP2, decks = REGION_SURFACES) {
    if (!contains2(hx, hz)) {
      if (!decks.length || !inMouth(hx, hz)) return null;
      const hit2 = highestDrawnFloor(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z, hy === void 0 ? void 0 : hy - MOUNTAIN_V2_OFFSET.y, step, () => -1e6, mouthDecks);
      if (hit2.id === "terrain") return null;
      return { id: `mountainV2:${hit2.id}`, y: hit2.y + MOUNTAIN_V2_OFFSET.y, n: [hit2.nx, hit2.ny, hit2.nz], material: regionMaterial(hit2), slope: Math.atan(hit2.slope) * 180 / Math.PI };
    }
    let hit = highestDrawnFloor(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z, hy === void 0 ? void 0 : hy - MOUNTAIN_V2_OFFSET.y, step, feltGround, decks);
    if (hit.id === "terrain") {
      const patch = walkingGroundPatch?.floorAt(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z);
      if (patch) hit = { ...hit, y: patch.y, nx: patch.nx, ny: patch.ny, nz: patch.nz, slope: Math.hypot(patch.nx, patch.nz) / patch.ny };
    }
    const plank = walkingGround && decks.some((s) => s.id === "station:funicular:town") ? funicularFootStationFloor(hx, hz) : null;
    if (plank !== null && (hy === void 0 || plank <= hy + step) && plank > hit.y + MOUNTAIN_V2_OFFSET.y) hit = { id: "station:funicular:town:planks", y: plank - MOUNTAIN_V2_OFFSET.y, nx: 0, ny: 1, nz: 0, material: "wood", slope: 0 };
    const y = hit.y + MOUNTAIN_V2_OFFSET.y;
    if (hy !== void 0 && y > hy + step) return null;
    return { id: hit.id === "terrain" ? "terrain" : `mountainV2:${hit.id}`, y, n: [hit.nx, hit.ny, hit.nz], material: regionMaterial(hit), slope: Math.atan(hit.slope) * 180 / Math.PI };
  }
  function ceiling(hx, hy, hz) {
    const plank = walkingGround && contains2(hx, hz) ? funicularFootStationFloor(hx, hz) : null, under = plank !== null && plank - 0.12 > hy ? plank - 0.12 : null;
    const withPlank = (value) => under === null ? value : value === null ? under : Math.min(value, under);
    if (!owns(hx, hz)) {
      if (!inMouth(hx, hz)) return withPlank(null);
      const c2 = worldCeilingAt(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z, hy - MOUNTAIN_V2_OFFSET.y, 0.2, mouthDecks);
      return withPlank(Number.isFinite(c2) ? c2 + MOUNTAIN_V2_OFFSET.y : null);
    }
    const c = worldCeilingAt(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z, hy - MOUNTAIN_V2_OFFSET.y, 0.2, REGION_SURFACES);
    return withPlank(Number.isFinite(c) ? c + MOUNTAIN_V2_OFFSET.y : null);
  }
  function contact(hx, hz, feet, radius = 0.3, travel, bodyHeight = BODY) {
    if (!owns(hx, hz) && !deckAcrossMouth(hx, hz)) return null;
    const x2 = hx - MOUNTAIN_V2_OFFSET.x, z = hz - MOUNTAIN_V2_OFFSET.z, lo = feet - MOUNTAIN_V2_OFFSET.y + STEP2, hi = feet - MOUNTAIN_V2_OFFSET.y + bodyHeight;
    const incoming = (nx, nz) => !travel || nx * travel[0] + nz * travel[1] <= 1e-8;
    for (const si of near2(x2, z)) {
      const s = REGION_SURFACES[si], p = worldDeckAt(s, x2, z);
      if (!p || p.distance >= p.halfWidth + radius) continue;
      const top = p.point[1] + 0.08, bottom = p.point[1] - 0.28;
      if (top <= lo || bottom >= hi) continue;
      if (branchJunction(s, p.point[1] - (feet - MOUNTAIN_V2_OFFSET.y), x2, z)) continue;
      const dx = x2 - p.point[0], dz = z - p.point[2], d = Math.hypot(dx, dz) || 1;
      if (incoming(dx / d, dz / d)) return { id: `mountainV2:${s.id}`, nx: dx / d, nz: dz / d };
    }
    for (const s of REGION_SOLIDS) {
      if (s.max[1] <= lo || s.min[1] >= hi || x2 <= s.min[0] - radius || x2 >= s.max[0] + radius || z <= s.min[2] - radius || z >= s.max[2] + radius) continue;
      const px = Math.max(s.min[0], Math.min(s.max[0], x2)), pz = Math.max(s.min[2], Math.min(s.max[2], z)), dx = x2 - px, dz = z - pz, d = Math.hypot(dx, dz);
      if (d > 0) {
        if (incoming(dx / d, dz / d)) return { id: `mountainV2:${s.id}`, nx: dx / d, nz: dz / d };
        continue;
      }
      const faces2 = [[x2 - s.min[0], -1, 0], [s.max[0] - x2, 1, 0], [z - s.min[2], 0, -1], [s.max[2] - z, 0, 1]], f = faces2.reduce((a, b) => b[0] < a[0] ? b : a);
      if (incoming(f[1], f[2])) return { id: `mountainV2:${s.id}`, nx: f[1], nz: f[2] };
    }
    if (z < -40) for (const s of EDGE_SOLIDS) {
      if (s.top <= lo || s.bottom >= hi) continue;
      const ax = s.a[0], az = s.a[1], dx = s.b[0] - ax, dz = s.b[1] - az, l = dx * dx + dz * dz, t = Math.max(0, Math.min(1, ((x2 - ax) * dx + (z - az) * dz) / (l || 1))), qx = x2 - ax - dx * t, qz = z - az - dz * t, d = Math.hypot(qx, qz);
      if (d < s.thickness / 2 + radius) {
        if (d > 1e-6) {
          if (incoming(qx / d, qz / d)) return { id: `mountainV2:${s.id}`, nx: qx / d, nz: qz / d };
          continue;
        }
        const n = Math.sqrt(l) || 1;
        if (incoming(-dz / n, dx / n)) return { id: `mountainV2:${s.id}`, nx: -dz / n, nz: dx / n };
      }
    }
    return null;
  }
  function blocked(hx, hy, hz, r = 0.2) {
    if (!owns(hx, hz) && !deckAcrossMouth(hx, hz)) return false;
    const x2 = hx - MOUNTAIN_V2_OFFSET.x, y = hy - MOUNTAIN_V2_OFFSET.y, z = hz - MOUNTAIN_V2_OFFSET.z;
    for (const si of near2(x2, z)) {
      const s = REGION_SURFACES[si], p = worldDeckAt(s, x2, z);
      if (p && p.distance < p.halfWidth + r && y > p.point[1] - 0.28 && y < p.point[1] + 0.08) return true;
    }
    if (REGION_SOLIDS.some((s) => x2 > s.min[0] - r && x2 < s.max[0] + r && z > s.min[2] - r && z < s.max[2] + r && y > s.min[1] && y < s.max[1])) return true;
    if (z < -40) for (const s of EDGE_SOLIDS) {
      if (y < s.bottom || y > s.top) continue;
      const ax = s.a[0], az = s.a[1], dx = s.b[0] - ax, dz = s.b[1] - az, l = dx * dx + dz * dz, t = Math.max(0, Math.min(1, ((x2 - ax) * dx + (z - az) * dz) / (l || 1)));
      if (Math.hypot(x2 - ax - dx * t, z - az - dz * t) < s.thickness / 2 + r) return true;
    }
    return false;
  }
  function waterLevel(hx, hz) {
    if (!owns(hx, hz)) return null;
    const w = regionWaterAt(hx - MOUNTAIN_V2_OFFSET.x, hz - MOUNTAIN_V2_OFFSET.z);
    return w === null ? null : w + MOUNTAIN_V2_OFFSET.y;
  }
  const asHit = (s) => s ? { id: s.id, y: s.y, nx: s.n[0], ny: s.n[1], nz: s.n[2], material: s.material, slope: s.slope } : null;
  const provider = {
    owns: contains2,
    // road (L1): where the region yields to a Horizon deck its ground answers under that deck (the drawn lawn does the same).
    ground: (x2, z) => feltGround(x2 - MOUNTAIN_V2_OFFSET.x, z - MOUNTAIN_V2_OFFSET.z) + MOUNTAIN_V2_OFFSET.y,
    waterLevel,
    surface(x2, z, y, step) {
      return asHit(surface(x2, y, z, step));
    },
    ceiling(x2, z, y) {
      return ceiling(x2, y, z) ?? Infinity;
    },
    contact(x2, z, y, radius, travel, bodyHeight) {
      return contact(x2, z, y, radius, travel, bodyHeight);
    }
  };
  function whileDrawn(drawn) {
    return {
      ...provider,
      surface(x2, z, y, step) {
        return asHit(surface(x2, y, z, step, drawn() ? REGION_SURFACES : NO_DECKS));
      },
      ceiling(x2, z, y) {
        return drawn() ? provider.ceiling(x2, z, y) : Infinity;
      },
      contact(x2, z, y, radius, travel, bodyHeight) {
        return drawn() ? contact(x2, z, y, radius, travel, bodyHeight) : null;
      }
    };
  }
  const requiresScene = (hx, hz) => contains2(hx, hz) || deckAcrossMouth(hx, hz);
  return { contains: contains2, requiresScene, groundAt, groundCeiling, walkingGroundPatch, surface, ceiling, contact, blocked, waterLevel, provider, whileDrawn };
}

// foot-shadow:/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/ground.ts
init_placement();
var patchMasksByMesh = /* @__PURE__ */ new WeakMap();
var prepared = /* @__PURE__ */ new Map();
function hiddenCell(contains2, step) {
  const memo = /* @__PURE__ */ new Map();
  return (hx, hz) => {
    const c = Math.floor(hx / step), r = Math.floor(hz / step), k = r * 65536 + c;
    let v = memo.get(k);
    if (v === void 0) {
      v = contains2((c + 0.5) * step, (r + 0.5) * step);
      memo.set(k, v);
    }
    return v;
  };
}
function prepareRegionGround(tier, contains2, terrainStep, cache = prepared, ceiling, walkingPatch) {
  const id = `${tier}:${terrainStep}${ceiling ? ":yield" : ""}`, hit = cache.get(id);
  if (hit && hit.walkingPatch === walkingPatch) return hit;
  const height = ceiling ? (x2, z) => {
    const g2 = groundHeightAt(x2, z), c = ceiling(x2 + MOUNTAIN_V2_OFFSET.x, z + MOUNTAIN_V2_OFFSET.z);
    return c === null ? g2 : Math.min(g2, c - MOUNTAIN_V2_OFFSET.y);
  } : groundHeightAt;
  const lattice = buildLattice(TERRAIN_LATTICE_BOUNDS, tier, height);
  const masks = groundMasks(lattice, tier, height, /* @__PURE__ */ new Map()), p = lattice.positions, n = p.length / 3;
  const hidden = hiddenCell(contains2, terrainStep), flag = new Uint8Array(n);
  for (let i2 = 0; i2 < n; i2++) {
    const hx = p[i2 * 3] + MOUNTAIN_V2_OFFSET.x, hz = p[i2 * 3 + 2] + MOUNTAIN_V2_OFFSET.z;
    flag[i2] = contains2(hx, hz) || hidden(hx, hz) ? 1 : 0;
  }
  const kept = [];
  const ix = lattice.indices;
  for (let t = 0; t < ix.length; t += 3) {
    const a = ix[t], b = ix[t + 1], c = ix[t + 2];
    if (flag[a] || flag[b] || flag[c]) kept.push(a, b, c);
  }
  const index = new Uint32Array(kept), render = walkingPatch ? composeWalkingGround({ positions: lattice.positions, indices: index }, walkingPatch) : {
    positions: lattice.positions,
    indices: index,
    baseVertices: lattice.positions.length / 3,
    patchVertices: 0,
    recipes: [],
    patchIndexStart: index.length,
    patchIndexCount: 0,
    seamTriangles: 0,
    clippedBaseTriangles: 0,
    boundaryGaps: [],
    maxBoundaryDrawnGap: 0
  };
  let patchMasks = walkingPatch ? patchMasksByMesh.get(walkingPatch) : void 0;
  if (walkingPatch && !patchMasks) {
    patchMasks = groundMasks(walkingPatch.paintLattice, "full", walkingPatch.height, /* @__PURE__ */ new Map());
    patchMasksByMesh.set(walkingPatch, patchMasks);
  }
  const result = { lattice, masks, index, render, walkingPatch, patchMasks };
  cache.set(id, result);
  return result;
}
export {
  createRegionGeography,
  decodeTerrainAsset,
  mouthExclusion,
  parseHorizonDefinition,
  prepareRegionGround,
  sampleTerrain,
  terraceBedExclusion
};
