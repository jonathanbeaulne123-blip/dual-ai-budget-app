# V5: shared actual exterior edge; bounded collar

Root is the sole checkout writer and heavy runner. This package has not imported the world, run tests or generated geometry. Only syntax transforms and the exact saved-JSON coplanar estimate were executed here.

Run the exact served preflight before applying anything:

```sh
FUNI_APRON_SOURCE="/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/mountainV2/footLaneJoin.ts" FUNI_CONE_SOURCE="/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/walkingJoinGround.ts" node /tmp/mountain-funicular-shared-ground-v5/run-ground-served.mjs "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book" /tmp/mountain-funicular-served-ground-proof-5
```

This uses the actual baked partition and current typed source/cone provenance; no source fit or source environment import. It retains all v2 constructor gates, adds actual generated-render checks against the independent saved collar corpus, and records actual full/lite triangles and preparation timings. A constructor/collar failure preserves failure.json. Runtime and test acceptance remain unproven until root runs them.

## V5 structural closure correction

V4 remains frozen and UNRUN. Its outer-edge check compared the collar to the ideal original plane while independently rounded outside clipping vertices could differ by a few Float32 ULPs. V5 uses the same actual boundary vertex indices on both drawing pieces. It also subdivides any exterior triangle touching that edge at the final collar knots, on its original plane, and rejects any outer collar edge without exactly one matching actual exterior edge. This is a structural check in addition to the recorded numerical join residual.

Every strictly exterior face remains verbatim. Faces touching the outer edge can be subdivided collinearly to join it; original source vertices are never moved. Those added exterior triangles count within the unchanged8192-face allocation together with the collar. No physical authority, footprint, native source, materials, real acceptance threshold or quality predicate changes fromv4. The common physical core remains verbatim; its actual-plane Float32 join residual stays reported.

## Retained v3 failure and bounded v4 correction

The immutable v3 run is `/tmp/mountain-funicular-served-ground-proof-3/failure.json`: full-tier construction reached9088 collar faces after pass5, exceeding the unchanged8192-face cap. It did not reach rendered seam or physical-error acceptance. The source refined whenever either the2mm blend interpolation heuristic OR an actual introduced/worsened physical-to-drawn error failed. That saved failure did not record the separate proportions; v4 does not invent them.

V4 keeps the same seed geometry, feature knots, shared-edge conformity, exact physical core,1.5m drawing boundary,10-pass/8192-face caps and all real acceptance thresholds. It refines only actual physical/error failures. The2mm target is reported through maximum deviation and face counts with `acceptanceGate:false`. Per-pass triangle counts, actual failing face counts, target deviation and worsening are now retained, including on any repeated allocation failure. The independent old/new dense corpus remains mandatory; this is not a declaration that a coarse blend passes.

## Measured reason for this proposal

The served v2 floor constructed in246.45ms, had4515 triangles, one additional7.221mm lower-only fairing,5.43mm maximum sampled physical boundary delta and no worsened steep faces. Its zero-width visible seam failed: full291.663mm / lite357.719mm. Moving the outer rectangle by0.25–1.5m does not avoid inherited analytic-versus-coarse-render banks. At1.5m the old full/lite outer-edge errors remain316.515mm /307.597mm.

The only published path crossing the proposed collar is town→funicular. Across its whole source width plus0.3m exterior, baseline full error is2.253mm and lite5.697mm. Funicular→Foot stays inside the common core. The larger out-of-path bank errors remain inherited evidence, not fixed or waived acceptance.

## Changed behavior

The exact v2 physical core, Float32 coordinates, triangles, normal queries, width, outer ring and lower-only fairing remain unchanged. Ground authority outside it remains the original analytic baseline. No native road, path, station, host or source land geometry changes.

The drawing replaces only a fixed1.5m exterior collar (core24×23m; outer27×26m). Every original vertex and every face wholly outside that collar remain verbatim. Existing triangles intersecting the collar are split, retaining their original plane/color interpolation outside it. The common core is copied verbatim into both tiers. There are no vertical curtains.

At collar points, the intended height is the original tier plane plus a bounded blend toward the analytic baseline, including the small canonical-boundary residual so the inner edge meets the actual physical mesh. Blend amount is1 at the inner edge and0 at the original outer edge. Both tier meshes share the same physical authority; their collars remain render approximations like the unchanged exterior. Original colors blend to the actual common-edge colors using the same amount and existing palette, without a new material or draw call.

Polygons insert every canonical perimeter knot. A conforming seed pass splits existing collinear corner nodes on neighbouring polygons. Local longest-edge refinement shares midpoint vertices across both adjacent faces; it rejects negative Float32 orientation, unmatched/nonmanifold interior edges, more than10 passes, or more than8192 collar faces. It samples seven points per face and refines only actual error above max(original tier error,6cm), apart from explicitly recorded0.1µm arithmetic allowance. Deviation from the intended blend field and the former2mm interpolation heuristic remain diagnostics, not acceptance thresholds. This is a finite geometric construction check, not proof of the entire analytic field.

The two actual mesh edges are sampled on their linear segments and must join within1µm Float32 arithmetic; residuals are retained rather than called mathematical zero. `maxBoundaryDrawnGap` now records actual collar-to-core/original connections. The former curtain gap is retained separately as `collarProof.inheritedCoreBoundaryGaps` and maximum. `seamTriangles` is zero. No old failure metric is silently discarded.

## Independent gates

The served runner additionally queries the actual new rendered triangles over the saved0.1m grid, seven <=2cm rings, and published width/body-safe/outer-edge corpus. It rejects:

- any missing rendered floor;
- a changed common core floor over1µm;
- outside-core error above max(original tier error,6cm), with0.1µm numeric allowance recorded;
- any published path width error above the unchanged6cm limit;
- source/asset/corpus drift or either drawn connection above the unchanged6cm preflight limit.

These finite checks do not replace actual path art,14walks,26width sweeps, six visual variants, final full/lite streaming latency, or rendering budgets. Existing full ground preparation was13.3–13.5seconds and lite5.4–5.7seconds;246ms geography time is not scene-ready latency.

## Review/apply artifacts

- `v5-only.patch`: shared exterior-edge delta against immutable, unrun v4. Older version-only patches in this package are historical context only.
- `combined-from-current.patch`: v2 physical repair + current v5 collar across walkingGroundPatch.ts, ground.ts and its focused test, against root's integrated v1 bytes recorded by BASE.json.
- `source/`: complete frozen overlay for the runner; supporting v2 files remain unchanged.
- New focused test exercises curved ground through both original render grids, actual connection residuals, unchanged physical core and outside analytic authority. Existing exterior preservation assertion uses the explicitly approved1.5m drawing boundary; strictly exterior original faces remain, and actual matched outer edges are asserted. Paint test checks the exact mixed recipe.

## Exact coplanar estimate — separate, not implemented

`coplanar-estimate.py` reads only the saved4515-face v2 canonical mesh and uses exact integer coordinates/plane equality. Fifteen edge-connected planar components could theoretically remove602 triangles while retaining every component boundary vertex, leaving3913. No mesh is modified, no approximate simplification is included, and an actual triangulation plus spanning-triangle query index would still be necessary. This is not an actual budget pass.
