# Stillwater shared retained rows — unexecuted proposal

Fresh variant of /tmp/mountain-stillwater-swept-study/study.py. No checkout changes or geometry runs. Python AST syntax check passed.

Root command, using a NEW output directory:

    python3 /tmp/mountain-stillwater-shared-rows-study/study.py /tmp/mountain-production-prejoin-v20 FRESH_CANDIDATE_DIRECTORY

Then run the existing independent saved-data proof against that fresh candidate directory:

    python3 /tmp/mountain-stillwater-swept-proof/proof.py /tmp/mountain-production-prejoin-v20 FRESH_CANDIDATE_DIRECTORY FRESH_PROOF_DIRECTORY

For each existing tolerance (0,.002,.005,.01,.02), the unchanged original reducer chooses rows independently for floor, roof, left/right walls, left/right footings. Their exact sorted union becomes the ONE row set used by all six chains. The script does not modify the route, frames, any corner coordinate, rise, width, thickness, footing heights, mesh winding, solid metadata or reducer. It makes no additional fitting decisions. `change.patch` is provided for source review, not checkout application.

The output retains the original source SHA256 and adds the frozen parent-script hash and current study hash. Each result reports the common retained indices, original independent retained indices/errors and recomputed interpolation errors on the common set. A union's chord error is not necessarily monotone under subdivision, so actual common-set errors are reported even if they exceed the requested tolerance; the script never silently adds rows or declares a pass based on the old independent metrics.

This is still an UNACCEPTED GEOMETRY REDESIGN. Sharing retained stations removes the avoidable independent-part tessellation mismatch, but does not make new immediate-neighbor mitres equal to the original JOINT_REACH mitres/lapped floor or prove support/clearance. All source-vs-candidate, assembly, portal, movement, terrain, precision and existing gates remain required. No triangle reductions or runtime have been measured for this revision.
