#!/usr/bin/env python3
"""Saved-data continuous comparison. No world imports; never accepts source integration."""
import sys,json,gzip,math,pathlib,hashlib,struct,time,collections
EPS=1e-11; AREA=1e-12
src=pathlib.Path(sys.argv[1]); cand=pathlib.Path(sys.argv[2]); out=pathlib.Path(sys.argv[3])
if out.exists(): raise RuntimeError('Output must be fresh')
out.mkdir(parents=True)
raw=(src/'cuts.json.gz').read_bytes(); cuts=json.loads(gzip.decompress(raw)); solids={s['id']:s for s in cuts['solids']}
study=json.loads((cand/'report.json').read_text()); assert study['sourceSha256']==hashlib.sha256(raw).hexdigest()
tube=json.loads((cand/'tube.json').read_text()); anchor=tube[0]; d=math.hypot(tube[1][0]-anchor[0],tube[1][2]-anchor[2]); ux=(tube[1][0]-anchor[0])/d; uz=(tube[1][2]-anchor[2])/d
# Translation and rotation independent: all clipping operates in this local road-aligned frame.
def local(p):
 x,z=p[0]-anchor[0],p[2]-anchor[2];return [x*ux+z*uz,-x*uz+z*ux,p[1]]
def world(p,y=0):return [anchor[0]+p[0]*ux-p[1]*uz,y,anchor[2]+p[0]*uz+p[1]*ux]
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def signed(p):return sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p)))/2 if len(p)>2 else 0
def area(p):return abs(signed(p))
def ccw(p):return p if signed(p)>0 else p[::-1]
def clean(p):
 q=[]
 for x in p:
  if not q or math.dist(q[-1],x)>1e-12:q.append(x)
 if len(q)>1 and math.dist(q[0],q[-1])<1e-12:q.pop()
 return q if len(q)>2 and area(q)>AREA else []
def half(poly,fn):
 if not poly:return []
 result=[];a=poly[-1];fa=fn(a)
 for b in poly:
  fb=fn(b);ina=fa>=0;inb=fb>=0
  if ina!=inb:
   t=fa/(fa-fb);result.append([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])])
  if inb:result.append(b)
  a,fa=b,fb
 return clean(result)
def intersect(a,b):
 p=a
 for i,x in enumerate(b):
  y=b[(i+1)%len(b)];p=half(p,lambda q:cross(x,y,q))
  if not p:break
 return p
def subtract(a,b):
 # Convex a minus convex b, returned as disjoint convex cells.
 inside=a;pieces=[]
 for i,x in enumerate(b):
  y=b[(i+1)%len(b)];outside=half(inside,lambda q:-cross(x,y,q))
  if outside:pieces.append(outside)
  inside=half(inside,lambda q:cross(x,y,q))
  if not inside:break
 return pieces

def face(a,b,c,tag):
 det=cross(a,b,c)
 if abs(det)<1e-14:return None
 ah,bh,ch=a[2],b[2],c[2]
 gx=((bh-ah)*(c[1]-a[1])-(ch-ah)*(b[1]-a[1]))/det
 gz=((b[0]-a[0])*(ch-ah)-(c[0]-a[0])*(bh-ah))/det
 p=ccw([a[:2],b[:2],c[:2]])
 return {'p':p,'k':[gx,gz,ah-gx*a[0]-gz*a[1]],'tag':tag,'up':det<0,'bounds':[min(q[0] for q in p),min(q[1] for q in p),max(q[0] for q in p),max(q[1] for q in p)]}
def h(f,p):return f['k'][0]*p[0]+f['k'][1]*p[1]+f['k'][2]
def meshfaces(s,up=None):
 ps=[local(s['positions'][i:i+3]) for i in range(0,len(s['positions']),3)];res=[]
 for i in range(0,len(s['indices']),3):
  f=face(*(ps[k] for k in s['indices'][i:i+3]),tag=s['id']+':'+str(i//3))
  if f and (up is None or f['up']==up):res.append(f)
 return res

def bbox(poly):return [min(p[0] for p in poly),min(p[1] for p in poly),max(p[0] for p in poly),max(p[1] for p in poly)]
def overlapping(a,b):return a[0]<=b[2]+EPS and b[0]<=a[2]+EPS and a[1]<=b[3]+EPS and b[1]<=a[3]+EPS
class Index:
 def __init__(self,faces):
  self.grid=collections.defaultdict(list);self.faces=faces
  for f in faces:
   for key in self.keys(f['bounds']):self.grid[key].append(f)
 def keys(self,b):return ((x,z) for x in range(math.floor(b[0]/4),math.floor(b[2]/4)+1) for z in range(math.floor(b[1]/4),math.floor(b[3]/4)+1))
 def query(self,p):
  b=bbox(p);found={id(f):f for key in self.keys(b) for f in self.grid.get(key,[]) if overlapping(f['bounds'],b)};return list(found.values())
def envelope(index,domain,upper):
 candidates=[]
 for f in index.query(domain):
  p=intersect(domain,f['p'])
  if p:candidates.append((f,p))
 result=[]
 for i,(f,p) in enumerate(candidates):
  pieces=[p]
  for j,(g,q) in enumerate(candidates):
   if i==j:continue
   diffs=[(h(g,x)-h(f,x))*(1 if upper else -1) for x in q]
   if max(diffs)<-EPS:continue
   # Deterministic ownership on numerically identical planes, not both erased.
   if max(abs(v) for v in diffs)<=1e-12:
    if j<i:continue
    occlusion=q
   else:occlusion=half(q,lambda x:(h(g,x)-h(f,x))*(1 if upper else -1))
   if not occlusion:continue
   pieces=[r for v in pieces for r in subtract(v,occlusion)]
   if not pieces:break
  result.extend((f,p) for p in pieces)
 return result

def uncovered(domain,cells):
 remaining=[domain]
 for f,p in cells:
  remaining=[r for q in remaining for r in subtract(q,p)]
 return sum(area(p) for p in remaining)
def comparison(a,b):
 low=math.inf;high=-math.inf;lo=None;hi=None;covered=0
 for f,p in a:
  for g,q in b:
   if not overlapping(bbox(p),bbox(q)):continue
   r=intersect(p,q)
   if not r:continue
   covered+=area(r)
   for x in r:
    delta=h(g,x)-h(f,x)
    if delta<low:low=delta;lo={'at':world(x,h(f,x)),'a':f['tag'],'b':g['tag'],'difference':delta}
    if delta>high:high=delta;hi={'at':world(x,h(f,x)),'a':f['tag'],'b':g['tag'],'difference':delta}
 return {'min':low if lo else None,'max':high if hi else None,'minWitness':lo,'maxWitness':hi,'overlapArea':covered}
def accum(summary,key,value):
 item=summary.setdefault(key,{'min':None,'max':None,'overlapArea':0})
 for op in ['min','max']:
  v=value[op]
  if v is not None and (item[op] is None or (v<item[op] if op=='min' else v>item[op])):item[op]=v;item[op+'Witness']=value[op+'Witness']
 item['overlapArea']+=value['overlapArea']
def record_gaps(summary,key,domain,cells):
 missing=uncovered(domain,cells);item=summary.setdefault(key,{'area':0,'maxCell':0,'witness':None});item['area']+=missing
 if missing>item['maxCell']:item['maxCell']=missing;item['witness']=world(domain[0])

# The continuous 10m road+shoulder ribbon follows all original 106 profile points.
# Half-width offsets use exact neighboring offset-line intersections. Reported explicitly:
# this domain is a geometric width contract, not a substitution for source floor triangles.
T=[local(p) for p in tube];frames=[]
for i,p in enumerate(T):
 dirs=[]
 for a,b in [(T[max(0,i-1)],p),(p,T[min(len(T)-1,i+1)])]:
  d=math.dist(a[:2],b[:2])
  if d>1e-10:dirs.append(((b[0]-a[0])/d,(b[1]-a[1])/d))
 if len(dirs)==1:frames.append((-dirs[0][1],dirs[0][0]))
 else:
  a,b=dirs;den=1+a[0]*b[0]+a[1]*b[1];assert den>.5;frames.append((-(a[1]+b[1])/den,(a[0]+b[0])/den))
rows=[[[p[0]+o*n[0],p[1]+o*n[1],p[2]] for o in [-5,5]] for p,n in zip(T,frames)]
domains=[]
for i in range(1,len(T)):
 a,b=rows[i-1],rows[i]
 for tri in [[a[0],a[1],b[1]],[a[0],b[1],b[0]]]:
  f=face(*tri,tag='profile:'+str(i));domains.append((i,f['p'],f))

# Closed index topology, vertex links, outward volume, positive top grade and precision variants.
def topology(s):
 ps=[s['positions'][i:i+3] for i in range(0,len(s['positions']),3)];ix=s['indices'];edges={};links=collections.defaultdict(list);deg=0;volume=0;flips=0;grades=[];origin=s.get('renderOrigin',[0,0,0]);variant=[]
 if len(ix)%3 or any(i<0 or i>=len(ps) or not isinstance(i,int) for i in ix):raise RuntimeError('Malformed indices')
 for k in range(0,len(ix),3):
  ids=ix[k:k+3];q=[ps[j] for j in ids]
  normals=[]
  for mode in range(3):
   def coord(p,j):
    r=p[j] if mode==0 else round(p[j],9)
    return struct.unpack('<f',struct.pack('<f',r-origin[j]))[0] if mode==2 else r-origin[j]
   a,b,c=[[coord(p,j) for j in range(3)] for p in q];u=[b[j]-a[j] for j in range(3)];v=[c[j]-a[j] for j in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];normals.append(n)
   if sum(t*t for t in n)<1e-22:variant.append({'face':k//3,'variant':mode,'error':'degenerate'})
  n=normals[0];is_top=n[1]>1e-8
  for mode,v in enumerate(normals):
   if sum(n[j]*v[j] for j in range(3))<=0:variant.append({'face':k//3,'variant':mode,'error':'orientation'})
   if is_top and v[1]<1e-8:variant.append({'face':k//3,'variant':mode,'error':'lost top determinant'})
  if is_top:grades.append(math.atan2(math.hypot(n[0],n[2]),n[1])*180/math.pi)
  aa=[q[0][j]-origin[j] for j in range(3)];volume+=sum(aa[j]*n[j] for j in range(3))/6
  for j,a in enumerate(ids):
   b=ids[(j+1)%3];key=tuple(sorted((a,b)));v=edges.setdefault(key,[0,0]);v[0]+=1;v[1]+=1 if a<b else -1
   links[a].append((ids[(j+1)%3],ids[(j+2)%3]))
 badlinks=0
 for v,pairs in links.items():
  adj=collections.defaultdict(set)
  for a,b in pairs:adj[a].add(b);adj[b].add(a)
  if any(len(x)!=2 for x in adj.values()):badlinks+=1;continue
  seen=set();queue=[next(iter(adj))]
  while queue:
   q=queue.pop()
   if q in seen:continue
   seen.add(q);queue.extend(adj[q]-seen)
  if len(seen)!=len(adj):badlinks+=1
 return {'triangles':len(ix)//3,'badEdges':sum(n!=2 or b!=0 for n,b in edges.values()),'badVertexLinks':badlinks,'signedVolume':volume,'maxPositiveTopDegrees':max(grades,default=0),'precisionFailures':len(variant),'precisionWitnesses':variant[:12]}

# Exact piecewise-affine terrain triangles from the saved full tier, preserving Float32 decoding.
terrain=(src/'terrain.bin').read_bytes();assert terrain[:8]==b'HZGEO001';cols,nrows=struct.unpack_from('<II',terrain,96);step=struct.unpack_from('<d',terrain,104)[0];offset,count=struct.unpack_from('<II',terrain,112);assert cols*nrows==count
allb=[local(s['positions'][i:i+3]) for part in ['floor','roof','walls','footings'] for s in [solids['stillwaterTunnel.'+part]] for i in range(0,len(s['positions']),3)]
wb=[world(p[:2]) for p in allb];x0=max(0,math.floor((min(p[0] for p in wb)-2)/step));x1=min(cols-2,math.floor((max(p[0] for p in wb)+2)/step));z0=max(0,math.floor((min(p[2] for p in wb)-2)/step));z1=min(nrows-2,math.floor((max(p[2] for p in wb)+2)/step))
def gp(x,z):
 cm=struct.unpack_from('<h',terrain,offset+(z*cols+x)*3)[0];y=struct.unpack('<f',struct.pack('<f',cm/100))[0];return local([x*step,y,z*step])
terrainfaces=[]
for z in range(z0,z1+1):
 for x in range(x0,x1+1):
  nw,ne,sw,se=gp(x,z),gp(x+1,z),gp(x,z+1),gp(x+1,z+1)
  for tri in [[nw,ne,sw],[se,sw,ne]]:terrainfaces.append(face(*tri,tag='terrain:'+str(x)+':'+str(z)))
ground=Index(terrainfaces);parts=['floor','roof','walls','footings'];source={p:solids['stillwaterTunnel.'+p] for p in parts};apron=solids['stillwaterTunnel.apron'];results=[];start=time.time()
for entry in study['results']:
 tolerance=entry['tolerance'];label=str(tolerance);candidate={p:json.loads((cand/(p+'-'+label+'.json')).read_text()) for p in parts}
 report={'tolerance':tolerance,'sourceTopology':{p:topology(source[p]) for p in parts},'candidateTopology':{p:topology(candidate[p]) for p in parts},'continuous':{},'foundation':{},'metadataPreserved':all({k:v for k,v in candidate[p].items() if k not in ['positions','indices']}=={k:v for k,v in source[p].items() if k not in ['positions','indices']} for p in parts)}
 sf=Index(meshfaces(source['floor'],True));cf=Index(meshfaces(candidate['floor'],True));sr=Index(meshfaces(source['roof'],False));cr=Index(meshfaces(candidate['roof'],False));af=meshfaces(apron,True)
 for i,domain,profile in domains:
  s=report['continuous'];old=envelope(sf,domain,True);new=envelope(cf,domain,True);oldroof=envelope(sr,domain,False);newroof=envelope(cr,domain,False)
  for name,cells in [('sourceFloorMissing',old),('candidateFloorMissing',new),('sourceRoofMissing',oldroof),('candidateRoofMissing',newroof)]:record_gaps(s,name,domain,cells)
  for name,a,b in [('floorChange',old,new),('sourceProfileError',[(profile,domain)],old),('candidateProfileError',[(profile,domain)],new),('sourceHeadroom',old,oldroof),('candidateHeadroom',new,newroof),('roofChange',oldroof,newroof)]:accum(s,name,comparison(a,b))
  # Portal neighborhood uses untouched actual apron plus each lining floor.
  if i<=3 or i>=len(T)-3:
   so=envelope(Index(sf.query(domain)+af),domain,True);cn=envelope(Index(cf.query(domain)+af),domain,True);accum(s,'portalComposedFloorChange',comparison(so,cn));record_gaps(s,'portalCandidateFloorMissing',domain,cn)
 for label0,meshes in [('source',source),('candidate',candidate)]:
  bottom=meshfaces(meshes['footings'],False);fb=report['foundation'].setdefault(label0,{})
  for f in bottom:
   dom=f['p'];terrainCells=envelope(ground,dom,False);record_gaps(fb,'terrainMissing',dom,terrainCells);accum(fb,'bottomMinusGround',comparison(terrainCells,[(f,dom)]))
  # Independently reduced roof and walls must meet over the complete wall top,
  # not merely share a nominal 5.4m rise at unrelated retained stations.
  roofBottom=Index(meshfaces(meshes['roof'],False))
  for f in meshfaces(meshes['walls'],True):
   dom=f['p'];ceiling=envelope(roofBottom,dom,False);record_gaps(fb,'wallTopOutsideRoof',dom,ceiling);accum(fb,'roofBottomMinusWallTop',comparison([(f,dom)],ceiling))
  # Full projected wall-footprint coverage by support tops, and bearing elevation.
  support=Index(meshfaces(meshes['footings'],True))
  for f in meshfaces(meshes['walls'],False):
   dom=f['p'];tops=envelope(support,dom,True);record_gaps(fb,'wallWithoutFooting',dom,tops);accum(fb,'footingTopMinusWallBottom',comparison([(f,dom)],tops))
 # Preserve exact endpoint floor & roof cross section: check endpoint row coordinates against original source vertices.
 for end in [0,-1]:
  p=tube[end];normal=frames[end];point=[local(p)[0],local(p)[1]];dom=[]
  # A 2mm ribbon straddling each portal face isolates cap and apron ownership; independent from 10m interior cells.
  tangent=[normal[1],-normal[0]];ln=math.hypot(*tangent);tangent=[v/ln for v in tangent]
  for along,lateral in [(-.001,-5),(.001,-5),(.001,5),(-.001,5)]:dom.append([point[0]+tangent[0]*along+normal[0]*lateral,point[1]+tangent[1]*along+normal[1]*lateral])
  dom=ccw(dom);old=envelope(Index(sf.query(dom)+af),dom,True);new=envelope(Index(cf.query(dom)+af),dom,True);record_gaps(report['continuous'],'portalStraddleMissing',dom,new);accum(report['continuous'],'portalStraddleChange',comparison(old,new))
 s=report['continuous'];maxabs=lambda k:max(abs(s[k]['min'] or 0),abs(s[k]['max'] or 0));gaps=[v['area'] for k,v in s.items() if 'Missing' in k];topology_ok=all(t['badEdges']==0 and t['badVertexLinks']==0 and t['signedVolume']>0 and t['precisionFailures']==0 for t in report['candidateTopology'].values());foundation=report['foundation']['candidate']
 report['gates']={'closedIndexManifoldAndPrecision':topology_ok,'floorProfileErrorStrictlyBelow2cm':maxabs('candidateProfileError')<.02,'headroomAtLeast5_35m':s['candidateHeadroom']['min'] is not None and s['candidateHeadroom']['min']>=5.35-1e-9,'noContinuousCoverageGap':max(gaps,default=0)<1e-8,'floorGradeAtMost40deg':report['candidateTopology']['floor']['maxPositiveTopDegrees']<=40+1e-8,'floorSourceEquality1e_9':maxabs('floorChange')<=1e-9,'footingSinkAtLeast25cm':foundation['bottomMinusGround']['max'] is not None and foundation['bottomMinusGround']['max']<=-.25+1e-9,'wallFootprintFullyBorne':foundation['wallWithoutFooting']['area']<1e-8,'roofCoversAllWallTops':foundation['wallTopOutsideRoof']['area']<1e-8,'noRoofWallVerticalGap':foundation['roofBottomMinusWallTop']['max'] is not None and foundation['roofBottomMinusWallTop']['max']<=1e-9,'noVerticalBearingGap':foundation['footingTopMinusWallBottom']['min'] is not None and foundation['footingTopMinusWallBottom']['min']>=-1e-9}
 report['status']='UNACCEPTED_SAVED_MESH_STUDY';results.append(report);(out/('result-'+str(tolerance)+'.json')).write_text(json.dumps(report,indent=2,allow_nan=False));print(json.dumps({'tolerance':tolerance,'gates':report['gates'],'elapsed':time.time()-start}),flush=True)
final={'status':'UNACCEPTED_SAVED_MESH_STUDY','sourceHash':hashlib.sha256(raw).hexdigest(),'studyHash':hashlib.sha256((cand/'report.json').read_bytes()).hexdigest(),'scriptHash':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'terrainHash':hashlib.sha256(terrain).hexdigest(),'areaRoundoffFloor':AREA,'coordinateFrame':{'anchor':anchor,'axis':[ux,uz]},'limitations':['Index manifold proof does not certify absence of nonadjacent geometric self-intersections.','Per-component closedness does not prove watertight assembly at independent wall/roof joins.','Terrain is saved full-tier unmasked support geometry, not runtime mouth visibility.','Actual runtime movement/body/ceiling, source route metadata integration, renderer themes, and baked parity remain required.'],'results':results,'elapsed':time.time()-start};(out/'report.json').write_text(json.dumps(final,indent=2,allow_nan=False))
