import {fitMountainHorizonJoins} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/mountainV2/joins.ts"; export {fitMountainHorizonJoins};
import {bed,addFlatPad,emitBedGeometry} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/beds/profiles.ts"; export {bed,addFlatPad,emitBedGeometry};
import {buildStair} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/structures/build.ts"; export {buildStair};
import {baseHeight,sampleTerrain} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/terrain/index.ts"; export {baseHeight,sampleTerrain};
import {decodeTerrainAsset} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/terrain/asset.ts"; export {decodeTerrainAsset};
import {createHorizonGeography} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/runtime/geography.ts"; export {createHorizonGeography};
import {createRegionGeography,REGION_ROAD} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/geography.ts"; export {createRegionGeography,REGION_ROAD};
import {prepareRegionGround} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/ground.ts"; export {prepareRegionGround};
import {drawnRoadGroundCeiling} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/drawnRoadGround.ts"; export {drawnRoadGroundCeiling};
import {drawnRoadFloor} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/regions/mountainV2/drawnRoadFloor.ts"; export {drawnRoadFloor};
import {solidTopAt} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/world/geometry.ts"; export {solidTopAt};
import {groundHeightAt} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/scene/ground.ts"; export {groundHeightAt};
import type {LandCuts,XYZ} from "/Users/jonathanbeaulne/Documents/ChatGPT/budget app 2/.codex-work/mountain-road-book/src/harbour/horizon/land/interfaces.ts";
export {legacyRoadGroundCeiling} from './legacy-ground.ts';
const station:XYZ[]=[[1298.3,158.05,481.7],[1300.8875,158.037177701,479.1125],[1304,158.024571818,476],[1307.249375,158.012215574,472.750625],[1310,158,470]];
const head:XYZ=[1319.108997805,170,468],foot:XYZ=[1312.599615031,158.81597646,454.960156792],join:XYZ=[1309.65,158.81597646,454.9125];
export function fixture():LandCuts{
  const cuts:LandCuts={beds:[],pads:[],solids:[],mouths:[],waters:[],diagnostics:[]};
  const walk=bed('walk summitStation','walk',structuredClone(station));walk.carried=[station.map(p=>[p[0],p[2]])];cuts.beds.push(walk);
  addFlatPad(cuts,'crossing.walkSummitStation.g1.1','threshold',[1300,480],158.041575688,[6,5]);
  addFlatPad(cuts,'place.L02','place',[1310,470],158,[12,10]);
  buildStair('crownLaunch.stair',head,foot,3,cuts,baseHeight);cuts.beds.find(b=>b.id==='crownLaunch.stair')!.points.push(join);
  return cuts;
}
