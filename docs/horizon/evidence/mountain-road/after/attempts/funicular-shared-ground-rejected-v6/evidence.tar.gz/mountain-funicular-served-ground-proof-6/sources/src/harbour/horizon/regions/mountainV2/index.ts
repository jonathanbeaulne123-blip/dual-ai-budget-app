/**
 * Mountain v2 on the Horizon (pass 5, T2): the placed region. One object answers the Horizon runtime's questions inside
 * v2's footprint with v2's own numbers — ground, decks, ceilings, solids, the walk graph, the two rides — and mounts v2's
 * stripped-down scene (scene.ts) under one host group at `MOUNTAIN_V2_OFFSET`. Native in, offset out, everywhere.
 *
 * `contains(hx, hz)` is the drawn footprint (geography.ts has the rule); the runtime hides its terrain cells there
 * (`runtime/cards.ts buildTerrainSteps` `skip`) and registers `provider` with `runtime/geography.ts addDynamic`, which
 * then owns the ground there. Importing this module evaluates v2's definition (a top-level-await terrain fetch): the
 * runtime imports it dynamically, once the Horizon's assets are in hand.
 */
import type * as THREE from 'three';
import type {StructureSolid} from '../../land/interfaces.ts';
import {SCENE_DRESSING,type PlaceDressing} from '../../../scene/place.ts';
import {finishBuild} from '../../../../house/world/buildTask.ts';
import {createRegionGeography,mouthExclusion,terraceBedExclusion,type RegionGeographyOptions,type RegionSurface} from './geography.ts';
import {regionPathGraph} from './graph.ts';
import {regionRides} from './rides.ts';
import {mountRegionSteps,type RegionScene,type RegionSeason,type RegionCabinPose} from './scene.ts';
import {MOUNTAIN_V2_OFFSET,MOUNTAIN_V2_FOOTPRINT} from './placement.ts';
import type {ExtraPathGraph} from '../../world/pathGraph.ts';

export {MOUNTAIN_V2_OFFSET,MOUNTAIN_V2_FOOTPRINT,mouthExclusion,terraceBedExclusion};
export type {RegionScene,RegionSurface,RegionCabinPose};
export const MOUNTAIN_V2_REGION_ID='mountainV2';

export type MountainV2RegionOptions=RegionGeographyOptions&{
  /** The Horizon terrain's cell size (`TerrainField.step`): the hidden-tile grid the ground mesh covers. Default 5. */
  terrainStep?:number;
  /** Final baked source surfaces for the explicitly owned town walking join. */
  walkingJoinSolids?:readonly StructureSolid[];
};
export type MountainV2MountOptions={season?:RegionSeason;quiet?:boolean};
export interface MountainV2Region {
  id:typeof MOUNTAIN_V2_REGION_ID;
  offset:typeof MOUNTAIN_V2_OFFSET;
  footprint:typeof MOUNTAIN_V2_FOOTPRINT;
  /** Inside the drawn footprint (Horizon x, z). */
  contains(hx:number,hz:number):boolean;
  /** Draw/readiness demand includes visible decks spanning an excluded terrain mouth. */
  requiresScene(hx:number,hz:number):boolean;
  /** The Horizon terrain cell whose centre is (hx, hz) is hidden under the region's ground (= `contains` at the centre). */
  hidesTerrainCell(hx:number,hz:number):boolean;
  /** v2's exact ground (+ offset y); null outside. */
  groundAt(hx:number,hz:number):number|null;
  /** v2's floor (ground or deck: bridges, the dam crest, platforms, stairs, branches) at or under hy + step; null outside. */
  surface(hx:number,hy:number,hz:number,step:number):RegionSurface|null;
  /** v2's drawn solids and edge solids at a point (v2's `worldCollisionAt` shape). */
  blocked(hx:number,hy:number,hz:number,r:number):boolean;
  /** The lowest deck underside above hy; null when open sky (or outside). */
  ceiling(hx:number,hy:number,hz:number):number|null;
  /** The Horizon `DynamicGeography` (plus `owns` / `ground` / `waterLevel`), always live (tests, tools). */
  provider:ReturnType<typeof createRegionGeography>['provider'];
  /** PR #566 Codex: the provider the runtime registers with `geography.addDynamic`: decks, solids and ceilings only while
   *  `drawn()` (the region's scene is visible); ownership, ground and water always. */
  providerWhileDrawn(drawn:()=>boolean):ReturnType<typeof createRegionGeography>['provider'];
  /** PR #566 Codex: v2's reservoir and river surface at a Horizon point (+ offset y); null when dry or outside. */
  waterLevel(hx:number,hz:number):number|null;
  /** v2's walk graph in Horizon space, for `withExtraGraph` / `buildPathGraph(…, extraGraph)`. */
  pathGraph():ExtraPathGraph;
  rides:ReturnType<typeof regionRides>;
  /** Refresh only the explicitly owned walking join. Invalidate the drawn/in-flight scene
   * synchronously before publishing new floor/ground answers; remount uses a fresh cache. */
  refreshWalkingJoinSolids(solids:readonly StructureSolid[],invalidate:()=>void):boolean;
  /** Builds the scene at once (tests, tools). The runtime uses `mountSteps` (one builder per step). */
  mount(scene:THREE.Scene,tier:'full'|'lite',dressing:PlaceDressing,options?:MountainV2MountOptions):RegionScene;
  mountSteps(scene:THREE.Scene,tier:'full'|'lite',dressing:PlaceDressing,options?:MountainV2MountOptions):Generator<void,RegionScene,void>;
}
type RegionProvider=MountainV2Region['provider'];
/** Consumers retain these provider objects; each call follows the current geometry snapshot. */
function forwardProvider(read:()=>RegionProvider):RegionProvider{
  return {
    owns:(...args:Parameters<RegionProvider['owns']>)=>read().owns(...args),
    ground:(...args:Parameters<RegionProvider['ground']>)=>read().ground(...args),
    waterLevel:(...args:Parameters<RegionProvider['waterLevel']>)=>read().waterLevel(...args),
    surface:(...args:Parameters<RegionProvider['surface']>)=>read().surface(...args),
    ceiling:(...args:Parameters<RegionProvider['ceiling']>)=>read().ceiling(...args),
    contact:(...args:Parameters<RegionProvider['contact']>)=>read().contact(...args),
  };
}
const isWalkingJoin=(solid:StructureSolid)=>(solid.sourceId??solid.id.split('@')[0])==='mountainV2.funicularFoot.apron';
export function createMountainV2Region(options:MountainV2RegionOptions={}):MountainV2Region{
  // Chunk loading appends to the caller's array. Geography, ground and path art
  // must share an immutable membership snapshot for each mounted generation.
  let walkingJoinSolids=options.walkingJoinSolids?[...options.walkingJoinSolids]:undefined;
  let walkingJoins=walkingJoinSolids?.filter(isWalkingJoin)??[];
  let geo=createRegionGeography({...options,walkingJoinSolids});
  const terrainStep=options.terrainStep??5,rides=regionRides();
  // Native/default callers keep the previous shared ground-cache behavior.
  let groundCache=options.horizonGround||walkingJoinSolids?new Map():undefined;
  const mountSteps=(scene:THREE.Scene,tier:'full'|'lite',dressing:PlaceDressing,o:MountainV2MountOptions={})=>mountRegionSteps(scene,tier,dressing,{contains:geo.contains,terrainStep,season:o.season,quiet:o.quiet,groundCache,groundCeiling:geo.groundCeiling,walkingJoinSolids,walkingGroundPatch:geo.walkingGroundPatch});
  function refreshWalkingJoinSolids(solids:readonly StructureSolid[],invalidate:()=>void):boolean{
    const nextJoins=solids.filter(isWalkingJoin);
    if(nextJoins.length===walkingJoins.length&&nextJoins.every((solid,i)=>solid===walkingJoins[i]))return false;
    const nextSolids=[...solids],nextGeo=createRegionGeography({...options,walkingJoinSolids:nextSolids});
    // No await: old scene/build is removed before any query can observe new
    // support. The runtime's existing region-ready gate holds movement until
    // the replacement terrain, paths and native structures are drawn together.
    invalidate();
    groundCache??=new Map();groundCache.clear();
    walkingJoinSolids=nextSolids;walkingJoins=nextJoins;geo=nextGeo;
    return true;
  }
  return {
    id:MOUNTAIN_V2_REGION_ID,offset:MOUNTAIN_V2_OFFSET,footprint:MOUNTAIN_V2_FOOTPRINT,
    contains:(x,z)=>geo.contains(x,z),requiresScene:(x,z)=>geo.requiresScene(x,z),hidesTerrainCell:(x,z)=>geo.contains(x,z),groundAt:(x,z)=>geo.groundAt(x,z),
    surface:(hx,hy,hz,step)=>geo.surface(hx,hy,hz,step),
    blocked:(hx,hy,hz,r)=>geo.blocked(hx,hy,hz,r),
    ceiling:(x,y,z)=>geo.ceiling(x,y,z),provider:forwardProvider(()=>geo.provider),
    providerWhileDrawn(drawn){
      let current=geo,view=current.whileDrawn(drawn);
      return forwardProvider(()=>{if(current!==geo){current=geo;view=current.whileDrawn(drawn);}return view;});
    },
    waterLevel:(x,z)=>geo.waterLevel(x,z),pathGraph:regionPathGraph,rides,
    refreshWalkingJoinSolids,
    mount:(scene,tier,dressing,o)=>finishBuild(mountSteps(scene,tier,dressing,o)),
    mountSteps,
  };
}
/** The place dressing v2's palette is built from, per app theme (Classic, Taylor, Newfoundland). */
export function regionDressing(theme:'classic'|'taylor'|'newfoundland'):PlaceDressing{return SCENE_DRESSING[theme];}
