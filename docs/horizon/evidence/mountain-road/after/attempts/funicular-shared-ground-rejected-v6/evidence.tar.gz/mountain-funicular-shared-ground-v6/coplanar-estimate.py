"""Saved-JSON exact arithmetic only; no world/source imports or simplification."""
import json,math,hashlib
from pathlib import Path
src=Path('/tmp/mountain-funicular-served-ground-proof-2/canonical-ground.json')
raw=src.read_bytes();data=json.loads(raw);P=data['positions'];I=data['indices'];ratios=[v.as_integer_ratio() if isinstance(v,float) else (v,1) for v in P];scale=max(d for n,d in ratios);V=[tuple(ratios[3*i+j][0]*(scale//ratios[3*i+j][1]) for j in range(3))for i in range(len(P)//3)]
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def plane(ids):
 a,b,c=[V[i]for i in ids];n=cross(tuple(b[j]-a[j]for j in range(3)),tuple(c[j]-a[j]for j in range(3)));d=-sum(n[j]*a[j]for j in range(3));values=(*n,d);g=math.gcd(*values);return tuple(v//g for v in values)
faces=[tuple(I[k:k+3])for k in range(0,len(I),3)];keys=[plane(f)for f in faces];parent=list(range(len(faces)))
def find(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
edges={}
for fi,f in enumerate(faces):
 for a,b in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((fi,a,b))
for owners in edges.values():
 if len(owners)==2 and keys[owners[0][0]]==keys[owners[1][0]]:parent[find(owners[0][0])]=find(owners[1][0])
groups={}
for i in range(len(faces)):groups.setdefault(find(i),[]).append(i)
rows=[]
for F in groups.values():
 faceSet=set(F);E=[]
 for fi in F:
  f=faces[fi]
  for a,b in zip(f,f[1:]+f[:1]):
   if not any(o[0]not in faceSet for o in edges[tuple(sorted((a,b)))]) and len(edges[tuple(sorted((a,b)))])==2:continue
   E.append((a,b))
 outgoing={};incoming={}
 for a,b in E:outgoing.setdefault(a,[]).append(b);incoming.setdefault(b,[]).append(a)
 valid=all(len(outgoing.get(i,[]))==1 and len(incoming.get(i,[]))==1 for i in set(outgoing)|set(incoming));loops=[]
 if valid:
  unused=set(outgoing)
  while unused:
   start=min(unused);loop=[];at=start
   while at in unused:unused.remove(at);loop.append(at);at=outgoing[at][0]
   if at!=start:valid=False;break
   loops.append(loop)
 areas=[sum(V[a][0]*V[b][2]-V[b][0]*V[a][2]for a,b in zip(q,q[1:]+q[:1]))for q in loops]
 holes=sum(a>0 for a in areas);outer=sum(a<0 for a in areas);boundaryVertices=len(outgoing)
 target=boundaryVertices+2*holes-2 if valid and outer==1 else len(F)
 row={'sourceFaces':len(F),'faceIds':F,'boundaryVertices':boundaryVertices,'boundaryEdges':len(E),'loops':len(loops),'holes':holes,'validSimpleBoundary':valid and outer==1,'interiorVertices':len({v for fi in F for v in faces[fi]})-boundaryVertices,'theoreticalFacesRetainingEveryBoundaryVertex':target,'reduction':len(F)-target,'planeIntegerCoefficients':[str(v)for v in keys[F[0]]]}
 if row['reduction']>0:rows.append(row)
result={'scope':'Exact coplanar component estimate; mesh is NOT changed and no triangulation is executed','source':str(src),'sourceSha256':hashlib.sha256(raw).hexdigest(),'integerCoordinateScale':str(scale),'sourceTriangles':len(faces),'coplanarComponents':len(groups),'reducibleComponents':len(rows),'exactBoundaryLockedTheoreticalReduction':sum(r['reduction']for r in rows),'theoreticalRemainingTriangles':len(faces)-sum(r['reduction']for r in rows),'components':sorted(rows,key=lambda r:-r['reduction']),'limits':['Every plane equality is exact integer arithmetic on saved Float32 coordinates; no tolerance or approximate geometry simplification.','Every component boundary vertex is retained; only interior coplanar vertices could be removed.','Counts use planar-polygon triangulation topology with retained boundary vertices and holes; an actual robust triangulation is still required.','Source cellStarts cannot consume spanning triangles unchanged. Any future implementation needs exact spatial query buckets and retains the separate row-major paint grid.','This estimate is separate from the collar repair and gives no actual submission-budget pass.']}
out=Path('/tmp/mountain-funicular-shared-ground-v3/coplanar-estimate.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='components'},indent=2))
