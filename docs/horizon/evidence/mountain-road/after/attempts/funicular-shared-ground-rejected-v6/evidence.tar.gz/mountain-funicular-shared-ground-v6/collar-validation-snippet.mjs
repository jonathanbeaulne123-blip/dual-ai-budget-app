// Independent saved-data samples: actual generated triangles, never target-field values.
const COLLAR_SAMPLES='/tmp/mountain-ground-collar-samples',collarInputHashes=[];
const readCorpus=(file)=>{const bytes=readFileSync(COLLAR_SAMPLES+'/'+file);collarInputHashes.push({file,sha256:digest(bytes)});return JSON.parse(gunzipSync(bytes));};
const collarSampleSummary=JSON.parse(readFileSync(COLLAR_SAMPLES+'/summary.json','utf8'));
for(const [key,value]of Object.entries(assetProvenance))if(value!==collarSampleSummary.provenance.assetProvenance[key])throw Error('Collar samples do not match current served/native assets: '+key);
const gridCorpus=readCorpus('ground-samples.json.gz'),ringCorpus=readCorpus('candidate-ring-samples.json.gz'),pathCorpus=readCorpus('published-width-samples.json.gz'),collarChecks=[];
function renderLookup(P,I,box){const cells=new Map();for(let k=0;k<I.length;k+=3){const ids=[I[k],I[k+1],I[k+2]],xs=ids.map(i=>P[3*i]),zs=ids.map(i=>P[3*i+2]),x0=Math.min(...xs),x1=Math.max(...xs),z0=Math.min(...zs),z1=Math.max(...zs);if(x1<box.x0||x0>box.x1||z1<box.z0||z0>box.z1)continue;
 for(let x=Math.floor(x0-1e-9);x<=Math.floor(x1+1e-9);x++)for(let z=Math.floor(z0-1e-9);z<=Math.floor(z1+1e-9);z++){const key=x+':'+z,list=cells.get(key)??[];list.push(k);cells.set(key,list);}}
 return(x,z)=>{let best=null;for(const k of cells.get(Math.floor(x)+':'+Math.floor(z))??[]){const a=I[k]*3,b=I[k+1]*3,c=I[k+2]*3,D=(P[b+2]-P[c+2])*(P[a]-P[c])+(P[c]-P[b])*(P[a+2]-P[c+2]);if(Math.abs(D)<1e-14)continue;const u=((P[b+2]-P[c+2])*(x-P[c])+(P[c]-P[b])*(z-P[c+2]))/D,v=((P[c+2]-P[a+2])*(x-P[c])+(P[a]-P[c])*(z-P[c+2]))/D,w=1-u-v;if(Math.min(u,v,w)<-1e-10)continue;const y=u*P[a+1]+v*P[b+1]+w*P[c+1];if(best===null||y>best)best=y;}return best;};}
function checkCollarSamples(tier,render){const floor=renderLookup(render.positions,render.indices,gridCorpus.outer),oldColumn=tier==='full'?4:5,failures=[],stats={tier,samples:0,maxPhysicalError:0,maxInheritedError:0,maxNewCoreError:0,maxWorsenedBankError:0,pathSamples:0,maxPathError:0};
 const visit=(r,label,path)=>{const y=floor(r[0],r[1]),inside=Boolean(r[6]),physical=inside?r[3]:r[2],oldError=Math.abs(r[oldColumn]-r[2]);stats.samples++;if(y===null){failures.push({label,reason:'missing rendered floor',row:r});return;}
  const error=Math.abs(y-physical);stats.maxPhysicalError=Math.max(stats.maxPhysicalError,error);stats.maxInheritedError=Math.max(stats.maxInheritedError,oldError);if(inside)stats.maxNewCoreError=Math.max(stats.maxNewCoreError,error);else stats.maxWorsenedBankError=Math.max(stats.maxWorsenedBankError,error-Math.max(.06,oldError));
  const invalid=inside?error>1e-6:error>Math.max(.06,oldError)+1e-7;if(invalid&&failures.length<100)failures.push({label,reason:inside?'canonical draw changed':'introduced/worsened collar physical-to-drawn error',row:r,drawn:y,error,oldError});
  if(path){stats.pathSamples++;stats.maxPathError=Math.max(stats.maxPathError,error);if(error>.06&&failures.length<100)failures.push({label,reason:'published path width exceeds unchanged6cm',row:r,drawn:y,error});}
 };
 for(const r of gridCorpus.rows)visit(r,'uniform0.1m',false);for(const ring of ringCorpus.rings)for(const r of ring.rows)visit(r,'ring '+ring.width,false);for(const r of pathCorpus.rows)visit(r.slice(4),'path '+pathCorpus.pathIds[r[0]],true);
 const result={...stats,failures,accepted:failures.length===0};collarChecks.push(result);return result;
}
