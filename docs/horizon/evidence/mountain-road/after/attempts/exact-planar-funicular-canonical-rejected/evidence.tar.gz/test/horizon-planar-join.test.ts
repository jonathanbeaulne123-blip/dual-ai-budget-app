import {describe,expect,it} from 'vitest';
import type {StructureSolid} from '../src/harbour/horizon/land/interfaces';
import {reducePlanarJoin} from '../src/harbour/horizon/land/mountainV2/reducePlanarJoin';

// A closed roof with a real crease, intermediate collinear perimeter points,
// and two independently planar top slopes. Its original positions stay fixed.
function foldedRoof():StructureSolid {
  const origin:[number,number,number]=[1286,55,726],positions:number[]=[],indices:number[]=[],edges=new Map<string,{a:number;b:number;count:number}>();
  for(let z=-2;z<=2;z++)for(let x=-2;x<=2;x++)positions.push(origin[0]+x,origin[1]+Math.abs(x)*.1,origin[2]+z,origin[0]+x,origin[1]-.3,origin[2]+z);
  const top=(a:number,b:number,c:number)=>{indices.push(a,b,c,a+1,c+1,b+1);for(const[u,v]of[[a,b],[b,c],[c,a]]){const k=u!<v!?u+':'+v:v+':'+u,e=edges.get(k);if(e)e.count++;else edges.set(k,{a:u!,b:v!,count:1});}};
  for(let z=0;z<4;z++)for(let x=0;x<4;x++){const a=2*(z*5+x),b=a+2,c=a+10,d=c+2;top(a,c,b);top(b,c,d);}
  for(const{a,b,count}of edges.values())if(count===1)indices.push(a,a+1,b+1,a,b+1,b);
  return{id:'mountainV2.funicularFoot.apron',kind:'landing',surface:'paved',role:'deck',bedIds:['mountainV2.footLane'],districtId:'lakeside',walkable:true,positions,indices,renderOrigin:origin};
}
function topAt(s:StructureSolid,x:number,z:number):number {
  let best=-Infinity;
  for(let k=0;k<s.indices.length;k+=3){const[a,b,c]=s.indices.slice(k,k+3).map(i=>s.positions.slice(i*3,i*3+3));
    const d=(b![2]!-c![2]!)*(a![0]!-c![0]!)+(c![0]!-b![0]!)*(a![2]!-c![2]!);if(d>=-1e-8)continue;
    const u=((b![2]!-c![2]!)*(x-c![0]!)+(c![0]!-b![0]!)*(z-c![2]!))/d,v=((c![2]!-a![2]!)*(x-c![0]!)+(a![0]!-c![0]!)*(z-c![2]!))/d;
    if(u>=-1e-9&&v>=-1e-9&&u+v<=1+1e-9)best=Math.max(best,u*a![1]!+v*b![1]!+(1-u-v)*c![1]!);
  }return best;
}
describe('exact planar walking-join reduction',()=>{
  it('removes redundant fans while retaining the crease and every original coordinate',()=>{
    const source=foldedRoof(),before=JSON.stringify(source),result=reducePlanarJoin(source);
    expect(result.diagnostics.status).toBe('reduced');expect(result.diagnostics.queueExhausted).toBe(true);
    expect(result.solid.indices.length).toBeLessThan(source.indices.length/2);
    expect(result.solid.positions).toBe(source.positions);expect(result.solid.renderOrigin).toBe(source.renderOrigin);expect(JSON.stringify(source)).toBe(before);
    expect(result.diagnostics.topologyFailures).toEqual([]);expect(result.diagnostics.variants.every(v=>v.invalid===0)).toBe(true);
    for(const x of[-2,-1.7,-.8,-.1,0,.1,.8,1.7,2])for(const z of[-2,-1.3,0,.7,2])expect(topAt(result.solid,1286+x,726+z)).toBeCloseTo(55+Math.abs(x)*.1,9);
    expect(reducePlanarJoin(source).solid.indices).toEqual(result.solid.indices);
  });
  it('retains a malformed input verbatim and reports rejection',()=>{
    const source=foldedRoof();source.indices=source.indices.slice(3);const before=JSON.stringify(source),result=reducePlanarJoin(source);
    expect(result.diagnostics.status).toBe('rejected');expect(result.solid).toBe(source);expect(JSON.stringify(source)).toBe(before);
  });
  it('refuses unrelated native or corridor solids',()=>{
    expect(()=>reducePlanarJoin({...foldedRoof(),id:'mountainV2.road'})).toThrow('restricted to the funicular apron');
  });
});
